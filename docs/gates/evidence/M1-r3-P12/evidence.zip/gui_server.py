import sys,subprocess,socket,time,json,hashlib,re,urllib.request,importlib.util,ctypes
from gate_guard import ROOT,OUT,environment,check
env=environment();dest=OUT/'gui';dest.mkdir(exist_ok=True);port=19521;origin=f'http://127.0.0.1:{port}'
check('before-own-gui-server')
with socket.socket() as s:s.bind(('127.0.0.1',port))
exe=ROOT/'target/debug/oh_server.exe';args=[str(exe),'--port',str(port),'--pack-root',str(ROOT/'data/packs')]
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
log=(dest/'server.log').open('wb');p=subprocess.Popen(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NEW_CONSOLE,startupinfo=startup)
try:
 for _ in range(100):
  try:html=urllib.request.urlopen(origin,timeout=1).read();break
  except Exception:time.sleep(.1)
 else:raise RuntimeError('server not ready')
 assets=[]
 for path in re.findall(rb'(?:src|href)="(/assets/[^\"]+)"',html):
  rel=path.decode();data=urllib.request.urlopen(origin+rel).read();local=ROOT/'client/dist'/rel.lstrip('/');assert data==local.read_bytes();assets.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 metadata=json.loads(urllib.request.urlopen(origin+'/maps/testland/metadata').read())
 ps=f'Get-CimInstance Win32_Process -Filter "ProcessId={p.pid}" | Select-Object ProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress'
 process=json.loads(subprocess.check_output(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-Command',ps],cwd=ROOT,env=env).decode('utf-8-sig'))
 assert process['ProcessId']==p.pid and __import__('pathlib').Path(process['ExecutablePath']).resolve()==exe.resolve()
 record={'head':'89964f4400c1affbfc484a60f486af51788c7298','cwd':str(ROOT),'origin':origin,'pid':p.pid,'process':process,'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'assets':assets,'metadata':metadata,'scenario':'m1','default_seed':1,'default_seed_source':'data/packs/testland/defines.toml network.default_seed','map_source':'syntheticTestland','ready_kst':__import__('datetime').datetime.now(__import__('datetime').timezone(__import__('datetime').timedelta(hours=9))).isoformat()}
 (dest/'identity.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
 check('gui-server-ready')
 for _ in range(12000):
  if (dest/'stop.request').exists():break
  if p.poll() is not None:raise RuntimeError('premature server exit '+str(p.returncode))
  time.sleep(.1)
finally:
 spec=importlib.util.spec_from_file_location('lifecycle',ROOT/'crates/oh_server/tests/lifecycle.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 if p.poll() is None:module.ctrl_c(p)
 rc=p.wait(timeout=15);log.close()
 with socket.socket() as s:connection=s.connect_ex(('127.0.0.1',port))
 result={'own_pid':p.pid,'native_exit':rc,'listener_gone':connection!=0,'normal_stop_log':'OpenHOI stopped normally' in (dest/'server.log').read_text()}
 (dest/'cleanup.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 assert rc==0 and connection!=0 and result['normal_stop_log'];check('after-own-gui-server')
