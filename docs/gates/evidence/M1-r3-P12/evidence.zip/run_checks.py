import sys,subprocess,json,time
from gate_guard import ROOT,OUT,check,environment,git
sys.stdout.reconfigure(encoding='utf-8')
env=environment()
cargo='C:/Users/user/.cargo/bin/cargo.exe'
npm='C:/Program Files/nodejs/npm.cmd'
tracked=set(git('ls-files','-z').decode().split('\0'))
paths=[OUT,ROOT/'target/wp05',ROOT/'target/wp09',ROOT/'target/wp12',ROOT/'target/wp11-native-red',ROOT/'client/node_modules',ROOT/'client/dist',ROOT/'client/test-results']
for p in paths:
 rel=p.relative_to(ROOT).as_posix()
 assert not any(x==rel or x.startswith(rel+'/') for x in tracked if x)
 subprocess.run(['git','-C',str(ROOT),'check-ignore',str(p)+'/'],env=env,check=True,stdout=subprocess.DEVNULL)
results=[]
commands=[('npm-ci',[npm,'ci'],ROOT/'client'),('unit',[npm,'test'],ROOT/'client'),('typecheck',[npm,'run','typecheck'],ROOT/'client'),('build',[npm,'run','build'],ROOT/'client'),('fmt',[cargo,'fmt','--check'],ROOT),('clippy',[cargo,'clippy','--workspace','--all-targets','--locked','--','-D','warnings'],ROOT),('workspace',[cargo,'test','--workspace','--locked'],ROOT),('native-build',[cargo,'build','-p','oh_server','--locked'],ROOT)]
for scenario in ['m0','m1']:
 for i in [1,2]: commands.append((scenario+'-hash-'+str(i),[cargo,'run','-p','oh_cli','--locked','--','run',*(['--scenario','testland'] if scenario=='m0' else ['--pack',str(ROOT/'data/packs/testland'),'--scenario','m1']),'--days','365','--seed','1','--hash-out'],ROOT))
commands += [('save',[sys.executable,str(ROOT/'crates/oh_save/tools/check_save_determinism.py'),'capture','--out',str(OUT/'save-capture')],ROOT),('docs',[sys.executable,str(ROOT/'tools/check_docs.py')],ROOT),('assets',[sys.executable,str(ROOT/'tools/check_assets.py'),'--release'],ROOT),('architecture',[sys.executable,str(ROOT/'tools/check_architecture.py')],ROOT),('policy',[sys.executable,'-m','unittest','discover','-s',str(ROOT/'tools/tests'),'-p','test_wp01.py','-v'],ROOT),('npm-licenses',[npm,'run','licenses'],ROOT/'client'),('cargo-licenses',[cargo,'deny','check','licenses'],ROOT)]
for label,cmd,cwd in commands:
 check('before-'+label)
 node=subprocess.check_output(['node','-e','process.stdout.write(JSON.stringify({cwd:process.cwd(),env:Object.fromEntries(Object.entries(process.env).filter(([k])=>k.startsWith("OH_")||["GIT_OPTIONAL_LOCKS","TMP","TEMP","PWTEST_CACHE_DIR","npm_config_cache"].includes(k)))}))'],cwd=cwd,env=env)
 start=time.monotonic()
 with (OUT/(label+'.log')).open('wb') as log:rc=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 result={'label':label,'command':cmd,'cwd':str(cwd),'exit':rc,'seconds':time.monotonic()-start,'actual_node':json.loads(node),'log':str(OUT/(label+'.log'))}
 results.append(result);(OUT/'command-results.json').write_text(json.dumps(results,indent=2))
 check('after-'+label)
 print(json.dumps({k:result[k] for k in ['label','exit','seconds','log']}),flush=True)
 print('\n'.join((OUT/(label+'.log')).read_text(encoding='utf-8',errors='replace').splitlines()[-5:]),flush=True)
