import json,subprocess,hashlib
from gate_guard import ROOT,OUT,check,environment,git
env=environment();h=OUT/'proto-harness';(h/'src').mkdir(parents=True,exist_ok=True)
(h/'Cargo.toml').write_text('[package]\nname="m1r3_gate_proto"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\noh_proto={path="'+(ROOT/'crates/oh_proto').as_posix()+'"}\n')
(h/'src/main.rs').write_text('fn main() { print!("{}", oh_proto::typescript()); }\n')
check('before-protocol')
cmd=['C:/Users/user/.cargo/bin/cargo.exe','run','--quiet','--offline','--manifest-path',str(h/'Cargo.toml'),'--target-dir',str(ROOT/'target')]
r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True);(OUT/'protocol-output.ts').write_bytes(r.stdout);(OUT/'protocol.stderr').write_bytes(r.stderr)
assert r.returncode==0
original=(ROOT/'client/src/proto/protocol.ts').read_bytes();blob=git('show','HEAD:client/src/proto/protocol.ts')
assert r.stdout==original==blob
mutated=bytes([r.stdout[0]^1])+r.stdout[1:];(OUT/'protocol-mutated.ts').write_bytes(mutated)
positive=subprocess.run(['git','diff','--no-index','--exit-code',str(OUT/'protocol-output.ts'),str(ROOT/'client/src/proto/protocol.ts')],cwd=ROOT,env=env,capture_output=True)
negative=subprocess.run(['git','diff','--no-index','--exit-code',str(OUT/'protocol-mutated.ts'),str(ROOT/'client/src/proto/protocol.ts')],cwd=ROOT,env=env,capture_output=True)
assert positive.returncode==0 and negative.returncode==1
(OUT/'protocol-negative.log').write_bytes(negative.stdout+negative.stderr)
result={'command':cmd,'cwd':str(ROOT),'exit':r.returncode,'bytes':len(original),'sha256':hashlib.sha256(original).hexdigest(),'generated_git_worktree_equal':True,'positive_exit':positive.returncode,'one_byte_negative_exit':negative.returncode}
(OUT/'protocol-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));check('after-protocol')
