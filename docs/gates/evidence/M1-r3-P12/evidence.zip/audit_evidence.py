import json,hashlib,zipfile,collections
from gate_guard import ROOT,OUT,git,check
check('before-evidence-audit')
heads=['0ab691d958a96e79f5f421004801a72173870d58','02cca1f05340d162ca5e3058a6b32d90a15eccd9','c316650b660b39a610899fe197e3c548e26ff01a','89964f4400c1affbfc484a60f486af51788c7298']
trees={}
for h in heads:
 tree={}
 for line in git('ls-tree','-r','-z',h).split(b'\0'):
  if not line:continue
  a,p=line.split(b'\t');p=p.decode()
  if p.startswith('docs/') or p=='HANDOFF.md':continue
  tree[p]=a.decode()
 trees[h]=tree
assert all(t==trees[heads[0]] for t in trees.values())
cust=ROOT/'docs/verify/evidence/WP-08-M1-r3'
manifest=json.loads((cust/'SHA256SUMS.json').read_text())
orig=ROOT.parent/'WP-08-M1-r3-verify/target/m1-r3-p05'
z=zipfile.ZipFile(cust/'evidence.zip'); mismatches=[]
for item in manifest:
 p=item['path'];data=z.read(p)
 if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:mismatches.append(p)
 if (orig/p).read_bytes()!=data:mismatches.append('live:'+p)
assert not mismatches
assert (orig/'evidence.zip').read_bytes()==(cust/'evidence.zip').read_bytes()
parents=zipfile.ZipFile(cust/'parent-originals.zip')
pc=json.loads((cust/'parent-custody.json').read_text())
for item in pc['parent_originals']:
 data=parents.read(item['member']);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
assert parents.read('original-before.json')==parents.read('parent-final.json')
assert parents.read('original-before.index')==parents.read('parent-final.index')
assert json.loads(parents.read('original-before.json'))['raw_index_sha256']==hashlib.sha256(parents.read('original-before.index')).hexdigest()
reports={}
for name in ['m0','m1','guards','independent','faults']:
 r=json.loads(z.read(name+'/report.json'));tests=[]
 def walk(s):
  for spec in s.get('specs',[]):
   for t in spec['tests']:tests.append({'title':spec['title'],'project':t['projectName'],'timeout':t['timeout'],'expectedStatus':t['expectedStatus'],'results':[(x['status'],x['retry']) for x in t['results']]})
  for c in s.get('suites',[]):walk(c)
 for s in r['suites']:walk(s)
 if name!='faults':assert all(t['results']==[('passed',0)] and t['expectedStatus']=='passed' and t['timeout']==30000 for t in tests)
 reports[name]={'stats':r['stats'],'tests':tests}
identity=json.loads((OUT/'latest-main-planning/identity.json').read_text())
for item in identity['files']:
 assert git('show',heads[-1]+':'+item['path'])==(ROOT/item['path']).read_bytes()==__import__('pathlib').Path(item['copy']).read_bytes()
result={'product_blobs':len(trees[heads[0]]),'product_equal_heads':heads,'product_manifest':trees[heads[0]],'p05_manifest_verified':len(manifest),'p05_zip_members':len(z.namelist()),'p05_zip_sha256':hashlib.sha256((cust/'evidence.zip').read_bytes()).hexdigest(),'custody_originals':len(pc['parent_originals']),'reports':reports,'latest_planning_verified':len(identity['files'])}
(OUT/'evidence-audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['product_manifest','reports']}))
for k,v in reports.items():print(k,json.dumps(v['stats']))
check('after-evidence-audit')
