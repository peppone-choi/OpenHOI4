import subprocess,json,hashlib,zipfile,io,sys
from gate_guard import ROOT,OUT,check,environment
env=environment();repo='peppone-choi/OpenHOI4';dest=OUT/'ci';dest.mkdir(exist_ok=True)
def api(path):return subprocess.check_output(['gh','api','repos/'+repo+'/'+path],cwd=ROOT,env=env)
heads={'c316':'c316650b660b39a610899fe197e3c548e26ff01a','899':'89964f4400c1affbfc484a60f486af51788c7298'}
check('before-ci-audit')
summary=[]
for name,head in heads.items():
 runs=json.loads(api('actions/runs?head_sha='+head+'&per_page=20'))['workflow_runs']
 folder=dest/name;folder.mkdir(exist_ok=True)
 (folder/'runs.json').write_text(json.dumps(runs,indent=2))
 for run in runs:
  rid=run['id'];rdir=folder/str(rid);rdir.mkdir(exist_ok=True)
  jobs=json.loads(api(f'actions/runs/{rid}/jobs?per_page=100'));(rdir/'jobs.json').write_text(json.dumps(jobs,indent=2))
  arts=json.loads(api(f'actions/runs/{rid}/artifacts?per_page=100'));(rdir/'artifacts.json').write_text(json.dumps(arts,indent=2))
  row={'head':head,'run':rid,'name':run['name'],'event':run['event'],'status':run['status'],'conclusion':run['conclusion'],'jobs':[(j['name'],j['status'],j['conclusion']) for j in jobs['jobs']],'artifacts':[]}
  if run['status']=='completed':
   logs=subprocess.check_output(['gh','run','view',str(rid),'--repo',repo,'--log'],cwd=ROOT,env=env);(rdir/'run.log').write_bytes(logs)
   for art in arts['artifacts']:
    path=rdir/(str(art['id'])+'.zip')
    if not path.exists():path.write_bytes(api(f'actions/artifacts/{art["id"]}/zip'))
    data=path.read_bytes();digest='sha256:'+hashlib.sha256(data).hexdigest();assert digest==art['digest']
    z=zipfile.ZipFile(io.BytesIO(data));unpack=rdir/art['name'];unpack.mkdir(exist_ok=True)
    for info in z.infolist():
     target=(unpack/info.filename).resolve();assert target.is_relative_to(unpack.resolve())
    z.extractall(unpack)
    row['artifacts'].append({'id':art['id'],'name':art['name'],'bytes':len(data),'digest':digest,'members':len(z.namelist()),'path':str(path)})
  summary.append(row);print(json.dumps(row),flush=True)
(dest/'summary.json').write_text(json.dumps(summary,indent=2));check('after-ci-audit')
