import json,subprocess,shutil,sys,collections,hashlib,re
from pathlib import Path
from PIL import Image
from gate_guard import ROOT,OUT,environment,check
env=environment();check('before-artifact-content-compare');dest=OUT/'ci-compare';dest.mkdir(exist_ok=True)
summary=json.loads((OUT/'ci/summary.json').read_text());latest=[x for x in summary if x['head'].startswith('899')]
assert len(latest)==4 and all(x['status']=='completed' and x['conclusion']=='success' and all(j[2]=='success' for j in x['jobs']) for x in latest)
comparisons=[]
for category,name,script,extra in [('core','Core determinism','crates/oh_core/tools/check_determinism.py',[]),('m0','Simulation determinism','crates/oh_sim/tools/check_sim_determinism.py',[]),('m1','Simulation determinism','crates/oh_sim/tools/check_sim_determinism.py',['--m1']),('save','Save determinism','crates/oh_save/tools/check_save_determinism.py',[])]:
 run=next(x for x in latest if x['name']==name);rdir=OUT/'ci/899'/str(run['run']);folder=dest/category;folder.mkdir(exist_ok=True)
 prefix={'core':'core-hash-','m0':'sim-hash-','m1':'m1-sim-hash-','save':'save-'}[category]
 for art in run['artifacts']:
  if art['name'].startswith(prefix):shutil.copytree(rdir/art['name'],folder/art['name'],dirs_exist_ok=True)
 cmd=[sys.executable,str(ROOT/script),'compare','--root',str(folder),*extra]
 r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True);(dest/(category+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,(category,r.stderr)
 comparisons.append({'category':category,'command':cmd,'exit':r.returncode,'result':r.stdout.decode().strip()})
for runner in ['ubuntu-latest','windows-latest','macos-latest']:
 result=json.loads((dest/'save'/('save-'+runner)/'server/result.json').read_text());assert result['head'].startswith('899') and result['server_exit']==result['query_exit']==0
 assert result['served_js_sha256']==json.loads((OUT/'gui/identity.json').read_text())['assets'][0]['sha256']
saved=[json.loads((dest/'save'/('save-'+r)/'result.json').read_text()) for r in ['ubuntu-latest','windows-latest','macos-latest']]
png_audits=[]
p05=ROOT.parent/'WP-08-M1-r3-verify/target/m1-r3-p05/e2e/m1/oh_map_dpr_evidence'
ci_run=next(x for x in latest if x['name']=='CI');linux=OUT/'ci/899'/str(ci_run['run'])/'wp05-protocol-browser-evidence/target/wp08/dpr'
prior=next(x for x in summary if x['name']=='CI' and x['head'].startswith('c316'));linuxprior=OUT/'ci/c316'/str(prior['run'])/'wp05-protocol-browser-evidence/target/wp08/dpr'
for label,folder in [('p05-windows',p05),('899-linux',linux),('c316-linux',linuxprior)]:
 counters=collections.Counter();rows=[]
 for path in sorted(folder.glob('*.json')):
  obs=json.loads(path.read_text());assert obs['errors']==[] and obs['resources']=={'media':0,'listeners':0,'observers':0,'rafs':0} and obs['surface']['canvas'] is None
  stem=path.stem
  for i,s in enumerate(obs['steps']):
   counters[s['backend']]+=1
   png=folder/f'{stem}-dpr{s["dpr"]}-{i}.png';im=Image.open(png).convert('RGB');assert [im.width,im.height]==[s['image']['width'],s['image']['height']]
   c=s['camera'];b=s['box'];x=(1-c['x'])/c['width']*b['width']+b['width']/2;y=(1-c['y'])/c['height']*b['height']+b['height']/2
   if s['image']['capture'].startswith('native full'):
    v=s['epoch']['before']['viewport'];x=(b['x']+x)*im.width/v['width'];y=(b['y']+y)*im.height/v['height']
   else:x=x*im.width/b['width'];y=y*im.height/b['height']
   pixel=list(im.getpixel((int(x),int(y))));assert s['expected']==[77,111,155] and all(abs(a-e)<=1 for a,e in zip(pixel,s['expected']))
   assert s['actual']==pixel
   if s['gpu'] is not None:assert s['gpu']['error']==0 and s['gpu']['lost'] is False and all(abs(a-e)<=1 for a,e in zip(s['gpu']['pixel'],s['expected']))
   before=s['epoch']['before'];after=s['epoch']['after']
   for o in [before,after]:
    assert o['hostCount']==o['canvasCount']==1 and o['current'] and o['hostCurrent'] and o['connected']
    assert o['dpr']==s['dpr'] and o['backend']==s['backend'] and o['camera']==c and o['box']==b
   assert s['buffer']['width']==s['buffer']['expectedWidth'] and s['buffer']['height']==s['buffer']['expectedHeight']
   assert s['resources']['listeners']==6 and s['resources']['observers']==1
   rows.append({'file':str(png),'rgb':pixel,'backend':s['backend'],'dpr':s['dpr'],'authority':s['authority']})
  assert len({json.dumps(x['authority'],sort_keys=True) for x in obs['steps']})==1
 png_audits.append({'scope':label,'steps':len(rows),'backends':dict(counters),'rows':rows})
log=(OUT/'ci/899'/str(ci_run['run'])/'run.log').read_text(encoding='utf-8')
passed=[line for line in log.splitlines() if line.startswith('client\t') and re.search(r'\b(36|82|1|41) passed\b',line)]
assert len(passed)==4,passed
(dest/'browser-pass-extract.txt').write_text('\n'.join(passed))
result={'exact_ci_runs':latest,'comparisons':comparisons,'save_results':saved,'saved_server_3os_exit0':True,'dpr_png_audits':png_audits,'browser_pass_extract':passed}
(dest/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({'comparisons':comparisons,'dpr_scopes':[{k:x[k] for k in ['scope','steps','backends']} for x in png_audits],'browser_pass_extract':passed},indent=2));check('after-artifact-content-compare')
