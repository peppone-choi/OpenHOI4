import os,json,hashlib,subprocess,sys,time
from pathlib import Path
ROOT=Path('E:/openhoi/.orchestrator/wt/M1-M1-r3-P12')
OUT=ROOT/'target/m1-r3-gate'
BASE=Path('E:/openhoi/.orchestrator/evidence/M1.M1-r3.P12.before.json')
os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*args):
 return subprocess.check_output(['git','-C',str(ROOT),*args],env=os.environ)
def check(label,record=True):
 b=json.loads(BASE.read_text())
 raw=Path(git('rev-parse','--git-path','index').decode().strip()).read_bytes()
 current={'head':git('rev-parse','HEAD').decode().strip(),'raw_index_sha256':hashlib.sha256(raw).hexdigest(),'semantic_index':git('ls-files','--stage','-z').decode(),'tracked_list':git('ls-files','-z').decode().split('\0'),'status':git('status','--porcelain=v1','--untracked-files=no').decode(),'diff':git('diff','--binary').decode(),'cached_diff':git('diff','--cached','--binary').decode()}
 current['files']=[[p,hashlib.sha256((ROOT/p).read_bytes()).hexdigest()] for p in current['tracked_list'] if p]
 mismatch=[k for k,v in current.items() if v!=b[k]]
 if raw!=BASE.with_suffix('.index').read_bytes(): mismatch.append('raw bytes')
 result={'label':label,'time':time.time(),'head':current['head'],'raw_index_sha256':current['raw_index_sha256'],'tracked_files':len(current['files']),'mismatch':mismatch,'baseline_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest()}
 if record:
  with (OUT/'invariance.jsonl').open('a') as f:f.write(json.dumps(result)+'\n')
 print(json.dumps(result),flush=True)
 if mismatch: raise RuntimeError('INVALID '+str(mismatch))
 return result
def environment():
 env=os.environ.copy()
 env['GIT_OPTIONAL_LOCKS']='0'
 env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH']
 env['PYTHONIOENCODING']='utf-8'
 env['CARGO_TARGET_DIR']=str(ROOT/'target')
 env['TMP']=env['TEMP']=str(OUT/'tmp')
 env['npm_config_cache']=str(OUT/'npm-cache')
 env['PWTEST_CACHE_DIR']=str(OUT/'pw-cache')
 for key,name in [('OH_E2E_EVIDENCE','localization'),('OH_MALFORMED_EVIDENCE','malformed'),('OH_MAP_EVIDENCE','map'),('OH_MAP_REDIRECT_EVIDENCE','redirect'),('OH_MAP_CAPABILITY_EVIDENCE','capability'),('OH_MAP_RESIZE_EVIDENCE','resize'),('OH_MAP_PIPELINE_EVIDENCE','pipeline'),('OH_MAP_DPR_EVIDENCE','dpr')]:env[key]=str(OUT/'e2e'/name)
 for p in [OUT/'tmp',OUT/'npm-cache',*[Path(v) for k,v in env.items() if k.startswith('OH_') and k.endswith('EVIDENCE')]]:p.mkdir(parents=True,exist_ok=True)
 return env
if __name__=='__main__':
 check(sys.argv[1] if len(sys.argv)>1 else 'check')
