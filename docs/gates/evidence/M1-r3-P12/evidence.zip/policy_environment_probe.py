import subprocess,json,sys
from gate_guard import ROOT,OUT,environment,check
env=environment();temp=OUT/'policy-isolated-temp';temp.mkdir(exist_ok=True)
# Only an ignored, empty outer workspace boundary for unmodified temp fixtures.
# No repository manifest or policy/test code changes.
(temp/'Cargo.toml').write_text('[workspace]\nmembers=[]\nexclude=["*"]\n')
env['TMP']=env['TEMP']=str(temp)
cmd=[sys.executable,'-m','unittest','discover','-s',str(ROOT/'tools/tests'),'-p','test_wp01.py','-k','test_req_leg_03_cargo_gpl_and_bincode_fail','-v']
check('before-isolated-policy-fixture')
with (OUT/'policy-isolated-fixture.log').open('wb') as log:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':cmd,'cwd':str(ROOT),'env':{'TMP':env['TMP'],'TEMP':env['TEMP'],'GIT_OPTIONAL_LOCKS':'0'},'exit':r.returncode,'reason':'Initial original test fixture beneath repository TMP discovers repository Cargo workspace; ignored empty boundary excludes temp child packages. Exact test/policy unchanged; original 31 other tests already pass; first FAIL retained.'}
(OUT/'policy-isolated-fixture-result.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));print((OUT/'policy-isolated-fixture.log').read_text(encoding='utf-8'));check('after-isolated-policy-fixture')
