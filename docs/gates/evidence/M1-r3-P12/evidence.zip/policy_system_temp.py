import os,tempfile,sys,subprocess,json,hashlib
from pathlib import Path
from gate_guard import ROOT,OUT,environment,check,git
system=Path(tempfile.gettempdir()).resolve()
dedicated=Path(tempfile.mkdtemp(prefix='OpenHOI4-M1-r3-P12-',dir=system)).resolve()
ancestors=[dedicated,*dedicated.parents]
assert all(not (p/'.git').exists() and not (p/'Cargo.toml').exists() for p in ancestors)
env=environment();env['TMP']=env['TEMP']=str(dedicated)
source=ROOT/'tools/tests/test_wp01.py';before=hashlib.sha256(source.read_bytes()).hexdigest()
check('before-system-temp-policy')
observe=[sys.executable,'-c','import os,tempfile,json;print(json.dumps({"cwd":os.getcwd(),"actual_gettempdir":tempfile.gettempdir(),"TMP":os.environ["TMP"],"TEMP":os.environ["TEMP"],"GIT_OPTIONAL_LOCKS":os.environ["GIT_OPTIONAL_LOCKS"]}))']
actual=json.loads(subprocess.check_output(observe,cwd=ROOT,env=env));assert Path(actual['actual_gettempdir']).resolve()==dedicated
cmd=[sys.executable,'-m','unittest','discover','-s',str(ROOT/'tools/tests'),'-p','test_wp01.py','-k','test_req_leg_03_cargo_gpl_and_bincode_fail','-v']
r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True);(OUT/'policy-system-temp.log').write_bytes(r.stdout+r.stderr)
assert hashlib.sha256(source.read_bytes()).hexdigest()==before
record={'command':cmd,'cwd':str(ROOT),'exit':r.returncode,'actual_python_temp':actual,'ancestors_checked':list(map(str,ancestors)),'no_git_or_cargo_ancestor':True,'source_sha256':before,'source_git_bytes_equal':git('show','HEAD:tools/tests/test_wp01.py')==source.read_bytes(),'reason':'Original unmodified single test in system-temp dedicated standalone fixture environment; original in-repository parent-workspace error and outerworkspace failed attempt both retained','temp_remaining':list(map(str,dedicated.iterdir()))}
(OUT/'policy-system-temp-result.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));print((r.stdout+r.stderr).decode('utf-8',errors='replace'));check('after-system-temp-policy')
assert r.returncode==0
