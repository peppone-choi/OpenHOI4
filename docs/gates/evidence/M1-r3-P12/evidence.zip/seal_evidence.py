import json,hashlib,zipfile,subprocess,datetime,re
from pathlib import Path
from gate_guard import ROOT,OUT,BASE,check,git,environment
env=environment();check('preseal')
tracked={x for x in git('ls-files','-z').decode().split('\0') if x}
negative=[]
for rel in ['client/src/proto/protocol.ts','docs/worklog/evidence/WP-12','docs/worklog/evidence/WP-12/p06']:
 rejected=any(x==rel or x.startswith(rel+'/') for x in tracked)
 assert rejected
 negative.append({'candidate':str(ROOT/rel),'tracked_output_guard':'REJECT','producer_started':False})
(OUT/'output-negative-guard.json').write_text(json.dumps(negative,indent=2))
head=git('rev-parse','HEAD').decode().strip();main=git('rev-parse','refs/heads/main').decode().strip()
remote=json.loads(subprocess.check_output(['gh','api','repos/peppone-choi/OpenHOI4/git/ref/heads/main'],cwd=ROOT,env=env))['object']['sha']
assert head==main==remote
record={'head':head,'local_main':main,'remote_main':remote,'finished_kst':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),'raw_index_sha256':'6077990c30eac37851cab7b8c4bad07a8cb4c12df30069a137755fdc23b76d92','baseline_json_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'baseline_raw_sha256':hashlib.sha256(BASE.with_suffix('.index').read_bytes()).hexdigest(),'tracked_files':9722,'product_blobs_equal':248,'judgement':'PASS','AC':{f'AC-M1-{i:02}':'PASS' for i in range(1,8)},'REQ':{x:'PASS' for x in ['REQ-TIME-01','REQ-TIME-02','REQ-MAP-01','REQ-MAP-02','REQ-MAP-03','REQ-MAP-04','REQ-MAP-05','REQ-NAT-01','REQ-SAV-01','REQ-SAV-02','REQ-PLAT-03','REQ-NET-02','REQ-LOC-01','REQ-LOC-02']},'own_native_exit':json.loads((OUT/'gui/cleanup.json').read_text()),'known_limitations':['Historical Edge root cause unresolved','One green CI run does not prove all DPR intermittency resolved','P05 native PTY wrapper1 not nativeexit0 proof; current own manager separately collects nativeexit0','Original policy31PASS/1envFAIL and isolated outerworkspace envFAIL retained; original single test system-temp once exit0','Artifact read-only parser initial7 rather than4 matches retained; original product tests not repeated','No M2 work,save UI/autosave,real-world map,Safari hardware,public hosting/account/cost/deployment,AIbench proof']}
(OUT/'final-audit.json').write_text(json.dumps(record,indent=2))
manifest=[]
exclude={'tmp','npm-cache','pw-cache','policy-isolated-temp','proto-harness','latest-main-planning'}
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT)
 if rel.parts[0] in exclude or '__pycache__' in rel.parts or p.name in ['evidence-manifest.json','evidence.zip','ZIP-IDENTITY.json']:continue
 data=p.read_bytes();manifest.append({'path':rel.as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(OUT/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for item in manifest:z.write(OUT/item['path'],item['path'])
 z.write(OUT/'evidence-manifest.json','evidence-manifest.json')
with zipfile.ZipFile(OUT/'evidence.zip') as z:
 for item in manifest:
  data=z.read(item['path']);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
data=(OUT/'evidence.zip').read_bytes();identity={'manifest_entries':len(manifest),'ZIP_members':len(manifest)+1,'ZIP_bytes':len(data),'ZIP_sha256':hashlib.sha256(data).hexdigest()};(OUT/'ZIP-IDENTITY.json').write_text(json.dumps(identity,indent=2));print(json.dumps(record));print(json.dumps(identity));check('final-after-seal',record=False)
