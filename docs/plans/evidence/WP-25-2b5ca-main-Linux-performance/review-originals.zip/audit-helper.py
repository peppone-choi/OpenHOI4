import pathlib,json,hashlib,zipfile,stat,subprocess,tomllib,importlib.util,datetime
r=pathlib.Path('E:/openhoi');source=r/'.orchestrator/evidence/WP-25-2b5ca-Linux-range-download';d=r/'.orchestrator/evidence/WP-25-2b5ca-Linux-parent-audit';d.mkdir(exist_ok=False)
head='2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab';rid=37672486232;aid=11504339978
download=json.loads((source/'download-custody.json').read_text(encoding='utf-8'));assert download['head']==head and download['artifact_id']==aid and download['download_sha_verified']
def gh(name,endpoint):
 q=subprocess.run(['gh','api','repos/peppone-choi/OpenHOI4'+endpoint],cwd=r,capture_output=True);(d/(name+'.stdout')).write_bytes(q.stdout);(d/(name+'.stderr')).write_bytes(q.stderr)
 (d/(name+'.command.json')).write_text(json.dumps(dict(argv=['gh','api','repos/peppone-choi/OpenHOI4'+endpoint],cwd=str(r),native_exit=q.returncode,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8');q.check_returncode();return json.loads(q.stdout)
run=gh('run',f'/actions/runs/{rid}');jobs=gh('jobs',f'/actions/runs/{rid}/jobs?per_page=100');artifact=gh('artifact',f'/actions/artifacts/{aid}')
assert run['head_sha']==head and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert jobs['total_count']==1 and all(j['conclusion']=='success' for j in jobs['jobs'])
job=jobs['jobs'][0];assert any(s['name']=='Same Linux runner fixed baseline and current native library measurement' and s['conclusion']=='success' for s in job['steps'])
zp=source/'performance-linux.zip';h=hashlib.sha256()
with zp.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
assert artifact['workflow_run']['head_sha']==head and artifact['digest']=='sha256:'+h.hexdigest() and h.hexdigest()==download['sha256']
entries=[];small={}
with zipfile.ZipFile(zp) as z:
 infos=z.infolist();assert len(infos)==len({i.filename for i in infos})
 for i in infos:
  name=i.filename;pp=pathlib.PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts and ':' not in name and '\\' not in name and '\x00' not in name and not stat.S_ISLNK(i.external_attr>>16)
  if i.is_dir():continue
  h1=hashlib.sha256();size=0
  with z.open(i) as f:
   for b in iter(lambda:f.read(1024*1024),b''):h1.update(b);size+=len(b)
  assert size==i.file_size;entries.append(dict(path=name,bytes=size,sha256=h1.hexdigest(),CRC_checked=True))
  if name.startswith('performance/') and size<2_000_000:
   data=z.read(i);small[name]=data;p=d/'selected'/pp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def get(name):return small['performance/'+name]
env=json.loads(get('environment.json'));comparison=json.loads(get('comparison.json'))
git=lambda path:subprocess.check_output(['git','-C',str(r),'show',head+':'+path])
policy=tomllib.loads(git('bench/defines.toml').decode('utf-8'))
assert env['system']=='Linux' and env['gate_evidence'] is True and env['current_sha']==head and env['current_dirty']=='' and env['baseline_sha']==policy['baseline_sha']=='81deb803944cf6297f13b3f14ca454774cea141b'
assert env['policy']==policy and policy['steps']==240000 and policy['warmup_steps']==2400 and policy['pairs']==2 and policy['threshold_percent']==15 and policy['seed']==1000 and policy['scenario']=='m1' and policy['native_timeout_seconds']==240 and policy['build_timeout_seconds']==1200
driver=git('bench/driver.rs');assert env['driver_sha256']==hashlib.sha256(driver).hexdigest()
for label in ('baseline','current'):
 assert get(label+'-driver/src/main.rs')==driver
 for name in ('fetch','metadata','build','warmup','0','1'):
  receipt=json.loads(get(label+'-'+name+'.json'));assert receipt['native_exit']==0
 assert '--locked' in json.loads(get(label+'-fetch.json'))['command'] and '--offline' in json.loads(get(label+'-metadata.json'))['command'] and '--locked' in json.loads(get(label+'-build.json'))['command']
assert get('baseline-pack.json')==get('current-pack.json')
tar=[x for x in entries if x['path']=='performance/baseline-archive.stdout'];assert len(tar)==1 and tar[0]['bytes']==2006323200 and tar[0]['sha256']=='8ee7e2265bd41fbba2ffa76f8e25d112fd17fef4059428bc858957464dd756e1'
samples={label:[json.loads(get(f'{label}-{i}.stdout')) for i in (0,1)] for label in ('baseline','current')}
module=r/'.orchestrator/wt/WP-25-M2-r2/bench/compare.py';spec=importlib.util.spec_from_file_location('actual_wp25_compare',module);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert module.read_bytes()==git('bench/compare.py') and m.compare_samples(samples['baseline'],samples['current'],policy) is False
assert comparison==dict(regression=False,gate_evidence=True,baseline_ns=[x['elapsed_ns'] for x in samples['baseline']],current_ns=[x['elapsed_ns'] for x in samples['current']],hash=samples['baseline'][0]['hash'])
record=dict(head=head,run_id=rid,run_attempt=run['run_attempt'],job_id=job['id'],artifact_id=aid,artifact_path=zp.as_posix(),artifact_bytes=zp.stat().st_size,artifact_sha256=download['sha256'],members=entries,mismatches=0,actual_linux_benchmark_verified=True,policy=policy,environment=env,comparison=comparison,raw_samples_full_DTO_canonical_hash_equal=True,baseline_TAR_raw_equal_to_original_exact_prior=True,download_only_range_recovery_not_measurement_retry=True)
(d/'actual-Linux-parent-proof.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in record.items() if k not in ('members','environment','policy')}))
