"""One task's bounded Range206 recovery; credentials/redirects stay in memory."""
import pathlib,json,hashlib,subprocess,urllib.request,http.client,concurrent.futures,datetime,os
r=pathlib.Path('E:/openhoi');out=r/'.orchestrator/evidence/WP-25-2b5ca-Linux-range-download';out.mkdir(exist_ok=False)
aid=11504339978;head='2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab';endpoint=f'/repos/peppone-choi/OpenHOI4/actions/artifacts/{aid}'
token=subprocess.check_output(['gh','auth','token'],cwd=r).decode().strip()
def api(path,redirect=False):
 conn=http.client.HTTPSConnection('api.github.com',timeout=30)
 conn.request('GET',path,headers={'Authorization':'Bearer '+token,'User-Agent':'OpenHOI4-task-custody','Accept':'application/vnd.github+json'})
 resp=conn.getresponse()
 try:
  if redirect:
   if resp.status!=302:raise RuntimeError('artifact redirect status '+str(resp.status))
   return resp.getheader('Location')
  if resp.status!=200:raise RuntimeError('artifact metadata status '+str(resp.status))
  return resp.read()
 finally:resp.close();conn.close()
raw=api(endpoint);(out/'artifact-api.json').write_bytes(raw);a=json.loads(raw)
assert a['id']==aid and a['name']=='performance-linux' and not a['expired'] and a['workflow_run']['head_sha']==head
location=api(endpoint+'/zip',True)
with urllib.request.urlopen(urllib.request.Request(location,method='HEAD'),timeout=30) as response:total=int(response.headers['Content-Length'])
del location
chunk=16*1024*1024;count=(total+chunk-1)//chunk;assert 1<count<200
def fetch(i):
 start=i*chunk;end=min(total,start+chunk)-1;length=end-start+1
 for attempt in (1,2):
  dest=out/f'chunk-{i:03d}-attempt{attempt}.bin';assert not dest.exists();h=hashlib.sha256();n=0;started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  receipt=dict(index=i,attempt=attempt,start=start,end=end,expected_bytes=length,started_utc=started,redirect_not_logged=True)
  try:
   location=api(endpoint+'/zip',True)
   request=urllib.request.Request(location,headers={'Range':f'bytes={start}-{end}'})
   with urllib.request.urlopen(request,timeout=60) as response,dest.open('xb') as f:
    receipt['http_status']=response.status;receipt['content_range']=response.headers.get('Content-Range')
    if response.status!=206 or receipt['content_range']!=f'bytes {start}-{end}/{total}':raise RuntimeError('Range206 identity guard failed')
    while n<length:
     b=response.read(min(1024*1024,length-n))
     if not b:raise RuntimeError('short range body')
     f.write(b);h.update(b);n+=len(b)
    if response.read(1):raise RuntimeError('long range body')
   receipt.update(bytes=n,sha256=h.hexdigest(),passed=True)
   (out/f'chunk-{i:03d}-attempt{attempt}.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
   return dict(index=i,path=dest.name,bytes=n,sha256=h.hexdigest(),attempt=attempt)
  except Exception as exc:
   receipt.update(bytes=n,sha256=h.hexdigest(),passed=False,error_type=type(exc).__name__,http_error_code=getattr(exc,'code',None))
   (out/f'chunk-{i:03d}-attempt{attempt}.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
 if not receipt['passed']:raise RuntimeError(f'chunk {i} failed bounded two attempts; preserved partials')
records=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(fetch,i):i for i in range(count)}
 for future in concurrent.futures.as_completed(futures):
  records.append(future.result());print(json.dumps(dict(completed_chunks=len(records),chunks=count)),flush=True)
records.sort(key=lambda x:x['index']);dest=out/'performance-linux.zip';h=hashlib.sha256();n=0
with dest.open('xb') as f:
 for row in records:
  with (out/row['path']).open('rb') as src:
   for b in iter(lambda:src.read(1024*1024),b''):f.write(b);h.update(b);n+=len(b)
assert n==total and a['digest']=='sha256:'+h.hexdigest()
del token
record=dict(head=head,artifact_id=aid,bytes=n,sha256=h.hexdigest(),declared_digest=a['digest'],chunks=records,download_sha_verified=True,member_CRC_not_yet_checked=True,signed_redirect_not_logged=True,settings_changed=False)
(out/'download-custody.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in record.items() if k!='chunks'}))
