diff --git a/bench/test_compare.py b/bench/test_compare.py
index aba6866..34623be 100644
--- a/bench/test_compare.py
+++ b/bench/test_compare.py
@@ -12,9 +12,9 @@ class Boundary(unittest.TestCase):
     def test_full_native_evidence_rejection(self):
         # Independent known FNV1a64 for one zero byte.
         policy={'steps':100,'seed':1,'scenario':'m1','threshold_percent':15}
-        sample={'elapsed_ns':100,'steps':100,'tick':100,'seed':1,'scenario':'m1','ended':False,'dto':{'state':1},'canonical_hex':'00','hash':'af63bd4c8601b7df'}
+        sample={'pack_hash':'0000000000000001','pack_hash_after':'0000000000000001','elapsed_ns':100,'steps':100,'tick':100,'seed':1,'scenario':'m1','ended':False,'dto':{'state':1},'canonical_hex':'00','hash':'af63bd4c8601b7df'}
         self.assertFalse(compare_samples([sample,sample],[sample,sample],policy))
-        for field,value in [('elapsed_ns',0),('elapsed_ns',float('nan')),('elapsed_ns',None),('tick',99),('steps',0),('seed',2),('scenario','wrong'),('ended',True),('dto',None),('canonical_hex','xx'),('hash','0'*16)]:
+        for field,value in [('pack_hash',None),('pack_hash_after','0000000000000002'),('elapsed_ns',0),('elapsed_ns',float('nan')),('elapsed_ns',None),('tick',99),('steps',0),('seed',2),('scenario','wrong'),('ended',True),('dto',None),('canonical_hex','xx'),('hash','0'*16)]:
             with self.subTest(field=field,value=value):
                 broken=copy.deepcopy(sample); broken[field]=value
                 with self.assertRaises((ValueError,TypeError)): validate_sample(broken,policy)
