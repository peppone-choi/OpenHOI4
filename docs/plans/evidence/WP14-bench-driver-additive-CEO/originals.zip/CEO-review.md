# WP14 벤치 드라이버 실제 팩 identity 계측 — CEO 기술 인수

판정: docs/04 §2의 가역적·기존 REQ-PERF-03 검증 범위에서 **조건부 잠정 채택**한다. 새 게임 규칙·D/OPEN 확정·사용자 전용 범위·CI 설정 변경이 아니다. 기존 고정 입력 지시 중 드라이버 원 bytes를 유지한다는 조건에 대해서만 아래 최소 계측의 명시적 기술 예외를 둔다. 변경 전에 좁은 소유 범위 밖이었던 사실과 부모의 보류/원본 보존을 기록하며 소급 승인·기존 드라이버 bytes 동일이라고 쓰지 않는다.

## 실제 검토 기준

부모 working-review: base2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab, sourceHEAD5577ee08d38c7d08d271be5f37a5f9da2ac88a60의 dirty 후보. 3개 old/working-raw/diff 길이·SHA와 실제 base Git blob 원문을 CEO가 대조해 불일치0을 확인했다. proof: .orchestrator/ceo/WP14-bench-driver-additive-CEO-direct-review.json.

- bench/driver.rs: 원1711B SHA19f8b6c5f821575ea603a416ce80eccfe4976a0a742606fe0986330f1b172663 → 관측2076B SHA999502205cd0f75ff2db016b53c29166bb4b09ecbdefed4291aabbee61cd65f7.
- bench/compare.py: 원2165B SHA80db8f2bc8be5a34af7c716f8f9938700aa6051abb144a7972b7dc90c58f71ed → 관측2567B SHA65c1341f1ad2ac1df9bd30cc4a02fb97cdc24a2054448ba1cf746067ef4ae114.
- bench/test_compare.py: 원1768B SHA501e5e3dd308e05eec04a95d0ba9eb7e28a420c1aa5ee54fdc963794b04d3858 → 관측1918B SHAe712f6705ce4c7a72dfd1a39dd2f57bc4181ddee34d4bb3e1a85d28805bfbf29.

Instant 시작부터 원 측정 step 루프/elapsed 산출/zero·tick·ended 완료 검사까지 원 문자열 exact다. compare의 regression 함수 AST도 원 함수와 exact다. 이는 읽기 검토이며 native Linux 실측이나 독립 PASS가 아니다. 최종 source SHA는 아직 없다.

## 허용 소유와 조건

1. WP14 추가 소유는 bench/driver.rs·bench/compare.py·bench/test_compare.py의 이 팩 identity 계측·거부·검사에 한정한다. driver는 run_national 이전/Instant 이전의 실제 oh_save::pack_hash와 elapsed 산출·원 완료 검사 이후의 실제 pack_hash, 서로 불일치 거부, pack_hash/pack_hash_after 출력 필드만 추가한다. 측정 루프·타이머 경계·advance/완료 검사·DTO/canonical/state_hash 원 계산·시뮬레이션 상태/RNG/phase는 그대로 유지한다. 해시를 측정 시간에서 임의로 빼거나 보정하지 않는다.

2. baseline81deb 원 source·팩 전체·원 lock/registry와 current 실제 최종 source/library를 유지한다. 같은 새 driver bytes를 두 실제 라이브러리 각각에 빌드하고 두 src/main.rs SHA=기록한 새driver SHA를 확인한다. old-driver SHA/bytes와 새driver SHA/bytes·diff/수정 이유를 각각 보존한다. metadata/path dependency/linked source/binary SHA/환경과 actual source/workflow/run/attempt/job/artifact를 대응한다. 과거 원driver 실측 시간을 새driver 결과로 대체하거나 새판정의 baseline 표본으로 섞지 않는다.

3. 원 m1/seed1000/240000steps/warm2400/두 쌍/엄격 >15% 두 쌍 판정/native240s/build1200s/release/default features·7 workflow bytes/조건/한도·설정은 불변이다. 계측 전후의 해시 계산 비용은 타이머 밖이며 전체 native timeout에는 계속 포함된다. timeout·warmup·판정 임계값 또는 측정 횟수를 이 추가로 늘리지 않는다.

4. 출력 두 hash는 실제 API 반환값의 16자리 소문자 hex이고 before=after, warmup의 두 라이브러리 및 실제 두 쌍의 모든 표본에서 동일해야 한다. warmup prior-native hash를 measurement_pack_hash로 바인딩하고 current/실측 output이 그 값과 다르면 거부한다. 이는 기존 run.py의 전체 정렬 경로/크기/SHA·원 Git archive·실제 입력 path·load/warmup/측정 전후 immutable inventory를 보완한다. hash 문자열만 같다는 이유로 원 SHA/list/binary linkage 검사나 실제 loader/DTO 상태 검사를 지우지 않는다. 팩 subset/가짜 hash/새current 팩을 old처럼 편집하거나 current library를 prior로 바꾸지 않는다.

5. compare는 두 신규 필드의 필수 형식·동일성/두 쌍간 동일성 거부만 추가한다. 기존 whole DTO/canonical/state_hash/steps/seed/scenario/tick/ended·elapsed 검사와 15% predicate/원 negative는 유지한다. 새 필드가 없는 역사 출력은 그대로 역사 형식·원 도구/명령으로 보존한다. 필드를 나중에 채워 넣거나 기존 실측 원문을 수정해 새 형식 PASS로 만들지 않는다.

6. 기존 positive의 필드 추가는 실제 새 출력 계약 인수로 기록하고 원 negative를 제거하거나 약하게 바꾸지 않는다. 새 누락/null/잘못된 길이·hex(두 필드 각각), before-after 불일치, 각 표본 내부는 같은데 두 쌍/양쪽 사이 hash가 다른 경우, 두 쌍 전체가 같은 잘못된 hash지만 원 measurement input 바인딩과 다른 경우를 검사한다. 전체 pack extra/missing/mutation/참조 이탈·실제 current/baseline linkage 바뀜·완료 상태/exit 불일치 검사는 이전 지시 그대로다. 하나의 mock 표본 성공으로 실제 native load/hash/실측을 대신하지 않는다.

7. 부모는 위 예외·파일 소유·원/새driver 차이·아직 미실측을 contract/ADR/작업로그/P05에 명시한다. 최종 exact clean source·원 증거/최초 whole/raw 기준으로 새 독립 검증을 배정하고 실제 Linux 양 쌍과 full DTO/canonical/hash/pack identity·실제 3OS v5를 확인해야 한다. P05/local 작업과 CI가 병행돼도 원격 원증거 인수 전 formal 최종 PASS/통합은 없다. source 변경이 필요하면 원 판정/기준선을 유지하고 새 source의 새 독립 검증으로 인수한다.

8. 이 기술 예외는 현재 dirty 후보나 WP14/W2/전체 M2의 완료 승인이 아니다. 고정 m1 벤치는 신규 경제 활성 부하·M2/M3·UI 성능 증거를 대신하지 않는다. 실제 소비자 미완료·원 None/v1~v4 호환·기존 실패 및 CLI400·C02 두 묶음 종료 경계/noM3·사용자 D/OPEN·noCUA/focus·지리 원천 제한·후속 로드맵을 유지한다.

실행: 이 조건을 부모가 명시 반영하면 WP14의 세 파일 최소 변경과 필요한 거부 회귀를 계속 인수할 수 있다. 조건에 맞지 않는 추가 변경은 다시 기술 검토한다. CEO는 제품/공유 추적 파일을 수정하지 않는다.

