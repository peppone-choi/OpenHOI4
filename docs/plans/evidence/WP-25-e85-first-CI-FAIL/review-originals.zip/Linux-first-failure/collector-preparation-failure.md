# 원 collector 준비 오류

원 helper는 다운로드 native0와 API digest·원 ZIP/member CRC 및 selected raw bytes 검사를 수행한 후, 마지막 record의 `st_size()`를 정수 속성에 호출해 TypeError로 native1 종료했다. 원 helper는 collector-original-preparation-failed.py에 그대로 보존했다. 원 API/stdout/stderr/명령 receipt/ZIP·selected·preview를 변경하거나 제거하지 않았다. 이 native1을 전체 성공 또는 artifact 손상으로 기록하지 않는다.

별도 복구 helper가 기존 raw 자료를 읽어 전체SHA·memberCRC·selected/preview를 다시 검증하고 새 이름 failure-custody-recovered.json으로 결과를 기록한다. 재다운로드·원 source/index/ZIP 교체·판정 변경을 하지 않는다.
