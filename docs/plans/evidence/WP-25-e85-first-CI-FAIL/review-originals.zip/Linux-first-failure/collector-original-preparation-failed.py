import pathlib,subprocess,json,hashlib,zipfile,stat
r=pathlib.Path('E:/openhoi');out=r/'.orchestrator/evidence/WP-25-e85-Linux-first-failure';out.mkdir(exist_ok=False);head='e85ec5b7191604e7fb1903d2cea5fb6e49060a5b';rid=37654381217
def run(name,args,binary=False):
 path=out/(name+('.zip' if binary else '.stdout'));assert not path.exists()
 with path.open('xb') as stream:q=subprocess.run(['gh',*args],cwd=r,stdout=stream,stderr=subprocess.PIPE)
 (out/(name+'.stderr')).write_bytes(q.stderr);(out/(name+'.command.json')).write_text(json.dumps(dict(argv=['gh',*args],cwd=str(r),native_exit=q.returncode),indent=2)+'\n',encoding='utf-8');q.check_returncode();return path
runfile=run('run',['api',f'repos/peppone-choi/OpenHOI4/actions/runs/{rid}']);meta=json.loads(runfile.read_text(encoding='utf-8'));assert meta['head_sha']==head
jobfile=run('jobs',['api',f'repos/peppone-choi/OpenHOI4/actions/runs/{rid}/jobs?per_page=100']);jobs=json.loads(jobfile.read_text(encoding='utf-8'));assert jobs['total_count']==len(jobs['jobs'])
log=run('original-run-logs',['run','view',str(rid),'--log'])
artfile=run('artifacts',['api',f'repos/peppone-choi/OpenHOI4/actions/runs/{rid}/artifacts?per_page=100']);arts=json.loads(artfile.read_text(encoding='utf-8'));selected=[x for x in arts['artifacts'] if x['name']=='performance-linux'];assert len(selected)==1;item=selected[0];assert not item['expired'] and item['workflow_run']['head_sha']==head
zpath=run('performance-linux',['api',f"repos/peppone-choi/OpenHOI4/actions/artifacts/{item['id']}/zip"],True);sha=hashlib.sha256()
with zpath.open('rb') as stream:
 for b in iter(lambda:stream.read(1024*1024),b''):sha.update(b)
assert item['digest']=='sha256:'+sha.hexdigest()
entries=[]
with zipfile.ZipFile(zpath) as z:
 names=z.namelist();assert len(names)==len(set(names))
 for info in z.infolist():
  name=info.filename;pp=pathlib.PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts and ':' not in name and '\\' not in name and not stat.S_ISLNK(info.external_attr>>16)
  if info.is_dir():continue
  h=hashlib.sha256();size=0
  with z.open(info) as stream:
   for b in iter(lambda:stream.read(1024*1024),b''):h.update(b);size+=len(b)
  assert size==info.file_size;entries.append(dict(path=name,bytes=size,sha256=h.hexdigest(),outer_CRC_checked=True))
  if info.file_size<=2_000_000 and name.startswith('performance/'):
   dest=out/'selected'/pp;assert dest.resolve().is_relative_to((out/'selected').resolve());dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(info))
record=dict(head=head,run_id=rid,run_attempt=meta['run_attempt'],run_status=meta['status'],conclusion=meta['conclusion'],job_failures=[dict(id=j['id'],name=j['name'],run_attempt=j['run_attempt'],failed_steps=[s['name'] for s in j['steps'] if s['conclusion']=='failure']) for j in jobs['jobs']],artifact_id=item['id'],artifact_bytes=zpath.stat().st_size(),artifact_sha256=sha.hexdigest(),members=entries,mismatches=0,actual_linux_benchmark_verified=False,measured_regression_not_claimed=True)
(out/'failure-custody.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in record.items() if k!='members'}))
