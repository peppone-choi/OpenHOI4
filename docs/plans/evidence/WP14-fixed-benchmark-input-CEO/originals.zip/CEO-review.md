### WP14의 고정 성능 입력 기술 인수 — CEO 확인

동일 immutable prior pack을 두 실제 library에 입력하는 기술안을 기존 REQ-PERF-03 범위에서 채택한다. 새로운 게임 규칙·D/OPEN 확정·설정/CI 한도 변경이 아니다. WP23 새 콘텐츠 때문에 current 팩 전체와 prior 팩 전체가 달라지는 것과, 실제 측정 입력이 같은 것의 경계를 분리한다. W1 전체의 exact main CI/원증거 인수 전 W2 착수는 하지 않는다.

- 고정 prior81deb의 원 Git tree에서 가져온 **팩 전체**를 같은 입력으로 사용한다. m1 파일만 선택하거나 새current 팩을 편집해 prior처럼 만들지 않는다. 같은 pack path로 두 executable에 넘기거나, 별도 복사라면 정렬된 전체 상대경로/byte길이/SHA/실제packhash가 완전히 같아야 한다. extra/missing 파일·symlink/reparse·참조 이탈을 거부한다. 입력은 생성 후 immutable이며 load/warmup/측정 전후 identity를 다시 검사한다. 이 변경으로 기존 입력 차이/손상 guard를 삭제하지 않는다.
- baseline source/build는 계속81deb이고 current source/build는 새 실제 커밋이다. Cargo metadata의 path dependency/원lock·registry audit와 두 binary provenance를 보존한다. current를 prior library/binary로 대체하지 않는다. 수정자는 bench/run.py 및 관련 검사·README·ADR 소유에 한정하며 driver/policy/워크플로 설정을 조용히 바꾸지 않는다.
- 원driver/release/default features/m1/seed1000/240000steps/warm2400/two pairs/>15%/native240s/build1200s 및 동일 runner/native성공/fullDTO/canonical/hash/끝난 여부·미래queue 계약 유지. None/oldm1 입력을 새경제0상태로 바꿔 canonical/save/hash 호환을 깨거나 force/callerpurpose로 통과시키지 않는다. 신규경제 정의가 없는 원 m1도 새library가 정상 지원해야 한다.
- 실질적인 red→green 검사는 current pack에 새m2 파일이 추가됐어도 두 library의 **원동일입력**을 쓰는지, 고정 입력extra/missing/mutation·registry변경·current/baseline linkage 뒤바뀜·잘못된exit/state/hash·15% 양쌍 경계를 잡는지 검사한다. mock/metadata만으로 Linux 측정PASS를 쓰지 않는다. 신규콘텐츠 자체의 strictvalidate/native/query/save/repro·경제consumer 검증도 별도로 유지한다. 이 고정m1벤치는 신규경제가 활성화된 대규모 부하 성능을 증명하지 않으며 후속 M2/M3 부하·UI성능 요구를 면제하지 않는다.
- 실제 performance.yml은 workflow_dispatch 입력필드가 없고 checkout이 실행 ref를 사용한다. default main에 존재하는 기존 workflow를 **승인한 exact 후보 branch/ref로 한 번 dispatch**하고, ref가 가리키는 SHA를 직전/실제API·job runtime/env/artifact 신원에서 다시 일치 확인한다. 새 source_ref 입력이나 CI branch조건 변경을 전제하지 않는다. source workflow 검사와 통합 후 exact main7CI를 구분한다. 실패를 skip/한도증가/묵시적반복으로 지우지 않는다.

이는 향후 WP14 담당 인수 권한이며 현재 WP25 제품 변경이나 W1/REQ 완료 선언이 아니다. schema/ADR·범위파일/실제producer 입력 계약을 먼저 작성하고 새source의 독립검증·원증거·main판정으로 확인한다.
