# CEO 지시 — M2-r1 최신 유효본

이번 실행은 M2-r1, M2 시작, 전체 목표 M6다. M1-r3는 2026-10-07 09:40:36 KST actual idle/completed32·RUN_RESULT 완료로 종료했고 하위 P06/P05/P12도275/19/11 completed다. 고유 통합WP12·게이트2(M0/M1 PASS)·M1 AC6→7의 진전을 확인해 무진전0·사용량0을 유지한다. 부모/하위 채팅 실행 없음 확인 후 하나의 새 오케스트레이터만 생성한다.

최종 main428a53deb16f86e1400c063f67f74ad9d3af05e7 clean·fetch/원격0/0·check_docs 오류0/경고0·같은HEAD 일반37552576600/Core37552576493/Simulation37552576528/Save37552576539 및 모든 필수job/compare SUCCESS를 CEO가 직접 확인했다. gate899와제품248blob동일·최신원client ZIP3422015bytes/230members/APIdigest 및 원 Linux36/82/nativeFF1/headedFF41 PASS도 직접 확인했다. 독립gate AC7/REQ14/hold0, 최초9722/raw607799...·원문/봉인1567 전수 감사 유효하다.

오케스트레이터가 없는 창에서 REPORT만 검사·커밋·푸시했다. dispatch main은 227a971101338ba3195599bb042c8570dd0365e9, clean·원격0/0. 이 새 보고 커밋의 CI는 아직 대기이며 이전428 성공으로 새HEAD 성공을 기록하지 않는다. 시작할 때 현재HEAD 네CI를 대조하고, 진행 중이면 기획·프롬프트·문서 준비를 하면서 결과를 확인한다. 실패하면 원 실패를 보존하고 P06 우선으로 진행한다. 같은 실패 검사를 통과할 때까지 임의 반복하거나 테스트 강도를 바꾸지 않는다.

STATE·실제 사용자 답변과 최신 이 지시가 과거 프롬프트보다 우선한다. 이전 실행별 원문은 history/DIRECTIVES-before-M2-r1.md와 docs/ceo/REPORT.md/게이트/HANDOFF에 보존한다. 과거 임시진단 push/run 권한은 소진됐으며 새로 적용하지 않는다. CLI HTTP400은 별도 역사 실패로 보존한다.

## 실행·권한·종료

- 사용자 직접 승인 경로: CEO는 앱 create_thread로 오케스트레이터를 하나씩 생성하고 업무상 채팅 메시지를 교환한다. 구현·검증 채팅과 WP별 별도 Git worktree는 오케스트레이터가 만든다. CEO는 제품 코드나 구현·검증 채팅을 직접 다루지 않는다.
- CLI selftest의 모델/계정 HTTP400 실패를 보존한다. 모델·인증·샌드박스·승인·네트워크 설정을 바꾸거나 앱 실행을 CLI exit0으로 기록하지 않는다. 현재 앱 registry와 실제 앱 상태를 확인한다.
- 진행 중인 기존 WP 채팅은 실제 상태를 대조해 인계한다. 같은 WP 또는 오케스트레이터 RUN을 중복 생성하지 않는다. 모든 구현 명령은 전용 workdir, 독립 검증은 정확한 구현 커밋의 새 detached worktree다. 검증 전후 HEAD/index/추적 목록/파일SHA/diff/status 불변성을 부모도 확인한다.
- 제품은 구현 세션이 작성한다. 오케스트레이터는 통합·문서·프롬프트·결정 요청·증거를 맡는다. main 통합/문서 커밋·푸시 후 동일HEAD CI 성공을 확인한다. 실행 중 CEO 기록은 .orchestrator/ceo/에만 남긴다.
- C02 한 RUN 종료 조건은 게이트 판정, 묶음2개 통합, 결정 때문에 더 진행할 WP 없음 중 먼저 오는 것이다. P08 HANDOFF를 커밋/푸시하고 마지막은 RUN_RESULT. 종료 뒤 임의 다음 마일스톤을 실행하지 않는다.
- 초기 답변 뒤 사용자에게 추가 질문하지 않는다. 사용자가 요구한 OPEN 항목별 질문은 이미 모두 끝났다. 새 REQUEST는 결정과 무관한 작업을 진행하면서 CEO에 전달한다.
- 04§2: 기존 승인 범위의 가역적 추천안은 CEO 잠정 채택 가능. REQUEST 작성 자체로 사용자 전용이 되지 않는다. 상태 확정·범위 변경·복구 어려운 삭제·설정·비용·공개 배포/태그·법적 판단·절대 규칙 변경은 사용자 전용이다. 미완성 규칙을 코드로 먼저 옮기지 않는다.
- 사용자 전용 때문에만 불충족인 AC는 보류 규칙으로 분리한다. 그 외 AC/독립 검증/CI 실패를 보류로 숨기지 않는다. 테스트나 검사를 약하게 만들지 않는다.

## 실제 사용자 결정

D10: 코드 GPL-3.0-or-later, 직접 제작 데이터·에셋 CC BY-SA4.0. 외부 자료는 원래 허용 라이선스·고지 유지, 의존성은 02§14.3 허용 목록. D12: 공개 명칭 OpenHOI4. 실제 답변으로 01§2 확정 반영. 이름 선택을 법적 검증 완료나 공개 배포/태그/비용 승인으로 쓰지 않는다. 다른 잠정 D는 임의 확정하지 않는다.

| 식별자 | 실제 답변 방향 | 시점 |
|---|---|---|
| OPEN-01 | 차체·모듈 조합 장비 설계 포함 | M5 |
| OPEN-02 | 평화 회의 포함, HOI4보다 간소화 | M4 |
| OPEN-03 | 보급 차량 소모만 포함, 철도 궤간 변환 제외 | M4 |
| OPEN-04 | 전략 폭격·세부 공군 임무 포함 | M5 |
| OPEN-05 | 함대 전투 포함, 함선 설계는 이후 개발 | M5/후속 |
| OPEN-06 | 샌드박스 모드 스크립트 언어 도입 | M5 |
| OPEN-07 | 기상·계절 모두 포함 | M4 |
| OPEN-08 | 점령 저항·준수·첩보 모두 포함 | M4 |
| OPEN-09 | 검토한 AI 생성 이미지 배포물 포함 허용 | M3 |
| OPEN-10 | 현재 자가 호스팅·세션 코드·계정 없음, 공개 호스팅·계정은 이후 개발 | M6/후속 |
| OPEN-11 | 특수 무기 포함 | M5 |
| OPEN-12 | 업적만 포함, 아이언맨 제외 | M6 |

사용자 포함 범위는 기존 후순위 REQ라는 이유로 최종M6에서 누락하지 않는다. 필수REQ와 별도로 승인 확장 목록의 WP·독립 PASS·같은HEAD CI 증거를 대조한다. 함선 설계·공개 호스팅·계정은 영구 제외가 아니라 시점 미정 후속 로드맵이다. 실제 서비스 운영·비용은 승인하지 않았다. AI 이미지는 출처·도구·조건·에셋 매니페스트와 개별 배포 검토가 있어야 한다.

## 상세 후보·추천안

REQUEST0001(D10/D12)은 답변 반영됐다. REQUEST0002~0005의 A는 최소 구체 후보 준비 방식으로 잠정 채택했다. 차량 v2만 뒤의 한정 잠정 채택이 추가 유효하며 다른 미완성 공식·조건은 채택되지 않았다. .orchestrator/ceo/detail-draft-review.md의 계산 순서·권한·경계·만료·저장/되돌림 검토를 참고한다.

- M4 차량/기상/점령/첩보·간소화 평화 회의부터 입력→거부/수락→상태변경→출력·독립 기대값·define/콘텐츠 스키마·저장호환/되돌림 비용을 완성하고 CEO 권한 검토에 보낸다.
- 다음 M5 장비/공군/함대/특수무기 후보, 샌드박스 언어/런타임은 허용 라이선스와 ADR. 제품 모드 격리를 Codex 설정 변경으로 취급하지 않는다.
- M6 업적 후보는 서버 설치 공유 프로필이 다른 플레이어 기록을 합치는 한계와 기존 세션/국가 배정에서 개인별 표시·보존 대안까지 구체화한다. 공개 계정이나 아이언맨을 현재 범위에 넣지 않는다.
- 채택된 구체 규칙은 01에 잠정으로 기록하고 제작/검증 문서를 맞춘 다음 구현한다. 사용자 확정 방향과 세부 잠정 채택은 분리한다.

## 품질·실제 화면·플레이

- 별도 기준 계산·경계·잘못된 입력·실패 시 상태 보존, 단언의 실효성·모듈 책임·변경 경로·복잡도를 독립 검증에서 확인한다. 의견 요청만으로 전역 하네스/강제 기능을 활성화하지 않는다.
- architecture.py가 모든 float/시계/HashMap DR 위반을 자동 검사하지는 않는다. 소스 검토와 실제 새 상태 결정론 검사가 필요하다. M0 골든은 보존한다.
- WP09/11은 실제 국가·주·원장입력·RNG·예약큐 등 mutable M1 상태가 canonical hash/저장재개/3OS에 포함되는지 확인한다. M0 시간 hash를 M1 증거로 대신하지 않는다.
- WP12 malformed Snapshot 빈화면 최초 FAIL과 수정 새 독립 PASS를 보존한다. 새 프로토콜은 runtime 검증도 갱신하고 잘못된 MessagePack 구조/필드에서 정상 화면·상태 보존·연결 종료·입력 차단을 회귀 검사한다.
- WP08 실제 지도 연결이 열리면 M1 전체 게이트 전이라도 정확한 커밋·로컬URL·실행법·캡처와 미완료 범위를 CEO에 즉시 전달한다. 이 화면은 합성 Testland며 유럽/전세계 지도는 후속이다.
- M1 지도 모드/선택·호버/카메라/국가·주패널/시간5단계/언어/원장 직접 탐색. 저장UI가 구현된 후 저장·재시작·재개. M2 실제UI 평시→전쟁→항복, M3 기존7개국, M4/M5 확장/세계 회귀, M6 기존8인4시간 실제세션 요구로 확장한다.
- 자동E2E·헤드리스AI벤치·직접UI플레이를 구분한다. 정확한 커밋/시나리오/시드/날짜/환경/행동 이유/기대·실제/캡처/결함·재현을 기록한다. 원시상태 변조를 UI플레이로 쓰지 않는다. 플레이/검증 채팅은 오케스트레이터가 만든다. GUI조작 시 실제 사용할 computer-use 스킬을 먼저 읽는다.

## 지리·하천·고도 파일 생성

- 사용자 지시: 지리 원천을 웹에서 실시간으로 가져오지 말고 파일로 굽는다. 산맥/강/고도 자료를 프로빈스 생성에 반영한다.
- 취득 단계에서 필요한 원천을 버전/snapshot 고정 로컬 파일과 URL/일시/라이선스/SHA256으로 보존한다. 오프라인 생성기가 해당 파일에서 provinces PNG/정의/주/인접/지형을 생성한다. 같은 입력·도구 버전·옵션의 산출 hash2와 안정ID/정렬을 검증한다. 누락/해시불일치는 실패이며 자동 다운로드로 숨기지 않는다.
- 게임/브라우저는 동봉팩·자체HTTP만 읽고 외부지리 API/타일/CDN을 쓰지 않는다. 기존 로컬HTTP/게임WS는 유지한다. 시스템 네트워크·샌드박스 설정을 바꾸는 시험은 승인하지 않는다.
- NE 공식PD 버전 고정, OHM 기본CC0와 license태그/OSM수입해안·수역·하천 예외를 구분하고 검토된 요소만 쓴다. 실제 1936/1939 경계 충족은 WP32/45 조사/출처에 남긴다. NOAA ETOPO2022는 공식CC0 글로벌 DEM 후보일 뿐 아직 채택·취득한 것으로 쓰지 않는다. 독립DEM 추가는 사용자 고도 요청 범위다.
- DEM해상도·용량·NoData·단위·좌표/수직기준·지역능선/고개 정확도를 ADR로 비교한다. NE10m은1:10million 축척으로10미터격자가 아니다. 공식 하천 평활/위치조정·정렬문제/간헐하천 누락을 고려한다. .orchestrator/ceo/map-source-check.md 및 docs/research/M1-map-source-policy.md의 공식 출처를 참고한다.
- 독립 검수는 좌표계/그리드 정합, 고도·하천·프로빈스 확대 overlay의 능선/고개 보존·하천 연결/호수·해안진입·인접·좁은육지/해협·M5 dateline/극지역을 살핀다. 평균 고도 숫자만으로 대체하지 않는다. M3 알프스/피레네/카르파티아와 라인/다뉴브/비스와 표본 추천.
- 사용자 실제 확인 답: 공개 화면의 분할 원칙만 참고. 원작 공개 플레이 화면의 산맥/강/도시 주변 분할 원칙·밀도 비교만 한정 예외. 원작 경계 복사/트레이싱/지도파일 추출·사용/수치표는 금지. 실제 경계는 독립 원천에서 생성한다. 새 이동·전투 효과/수치를 이 지시만으로 만들지 않는다.

## 사용자 추가 지시 — 구현 전 스키마 기획 강화

사용자 직접 지시: 구현시에 스키마 기획 빡세게 돌릴 것. 위키 찾아보면 될거야.

- 국가/주를 포함해 이후 각 시스템의 신규 구현·스키마 변경 전에 구체 설계와 누락 대조를 수행한다. 기존 M1 기초 스키마를 최종 전체 스키마라고 기록하지 않는다. M1은 기초 모델이며 이후 모든 WP의 신규/변경 계약에 같은 기획 기준을 적용한다. 이미 얻은 독립 PASS를 임의 무효화하거나 검사를 완화하지 않는다.
- 설계 산출물에는 필드별 의미·타입·단위/정밀도·범위·기본값·필수/선택/null·ID 참조·수명·소유 시스템·변경 권한·근거 REQ/WP를 표로 남긴다. 정의 데이터/시나리오 초기값/가변 권위 상태/파생 원장·조회 표시를 분리한다. 초기 인구와 가용 인력, 주와 프로빈스, 소유와 통제처럼 의미가 다른 필드를 혼동하지 않는다.
- 참조 그래프·관계의 다중성·정렬/안정ID·중복/미존재/순환 참조 정책, 시스템 간 단일 기준 데이터와 갱신 명령/순서/실패 원자성을 설계한다. 데이터 팩의 임의 키·범위·잘못된 참조는 언제 어디서 거부하는지 명시한다.
- 현재/후속 마일스톤 필드의 구현 상태를 나누고 필드→REQ→WP 연결표로 누락을 찾는다. 아직 없는 구체 게임 규칙은 REQUEST/잠정 채택 절차를 거치며, 위키를 읽었다는 이유로 원작 규칙·수치나 미승인 효과를 구현하지 않는다.
- 모든 가변 상태/예약큐/RNG/보정치·만료의 저장·복원 및 canonical hash 포함 여부, 불변 정의/팩 identity, wire DTO·runtime shape 검사와 실제 UI 조회를 함께 대조한다. 포맷/팩 schema 변경은 버전·이전 데이터 처리·마이그레이션 또는 명시 거부·독립 호환 fixture를 계획한다(02§7.2).
- 유효·경계·오류·누락·비연속ID·관계 불일치·상태 변경 실패·저장 재개 예제를 설계 단계에 만들고 독립 검증에 전달한다. 필드와 규칙을 선언만 하고 실제 게임/원장/해시/저장에 연결하지 않은 부분은 미완료로 표시한다. 구현·독립 검증 프롬프트는 이 설계 산출물과 검사할 불변성을 명시한다.
- 위키는 공개 시스템/필드 분류와 빠진 개념을 찾는 조사 참고다. 출처 URL·확인일·열람 가능 여부·참고 범위를 기록하고 OpenHOI4 자체 문장·식별자·스키마로 설계한다. AGENTS의 위키 문장/원작 수치표·파일·스크립트 금지와 공개 지도 분할 원칙만의 한정 예외는 유지한다. 원작을 복제한 코드/데이터 저장소·수치표를 검색 대체 자료로 가져오지 않는다.
- CEO 웹 도구로 공식 Paradox wiki Countries/State/Politics/Production/Logistics를 직접 열었으나 401/접근 실패였다. 내용을 읽었다고 기록하지 않는다. 다른 정상 접근 경로로 해당 공개 문서의 열람이 가능한지 오케스트레이터가 확인하고, 불가하면 그 제한을 남긴 채 기존01/02와 확인 가능한 공식 자료에서 설계·검토를 진행한다. 네트워크/권한 설정을 바꾸거나 조사 대기 때문에 독립 작업을 중단하지 않는다.

참고 대상(이번 CEO 도구는 내용 열람 실패):
- https://hoi4.paradoxwikis.com/Countries
- https://hoi4.paradoxwikis.com/State
- https://hoi4.paradoxwikis.com/Politics
- https://hoi4.paradoxwikis.com/Production
- https://hoi4.paradoxwikis.com/Logistics




## 이번 M2 실행의 우선 작업

1. P09 실제 상태 확인과 P02/P04로 docs/plans/M2.md를 만든다. 현재 이전 마일스톤 M0·M1 PASS, M2 제품은 미착수다. 02§12.2의 W1 WP13(트리거/효과/종료조건), WP17(이동/경로), WP24(팩·validate·현지화), WP25(재현·성능 기준/CI)의 선행 의존과 REQ·필드/파일 소유를 명확히 한다. 동시에 구현3~4개 이하, 구현마다 전용 worktree, exact 독립 검증 새 앱/별도 detached다. 공통파일·registry·큐/상태/hash/save/wire의 단일 소유와 통합 순서를 구체 설계하고 작업 충돌을 방치하지 않는다. 제품은 구현 채팅이 쓴다.
2. 모든 신규/변경 스키마 전에 docs/plans/schema-planning.md의 필드 의미/단위/형/범위/null/default/참조/수명/권위/REQWP, 정의/초기/가변/파생, 관계 그래프, 갱신/실패 원자성, hash/save/wire/runtime/UI·버전/호환·독립 경계 기대값을 계획하고 P03/P05에 정확 경로를 지정한다. 위키는 범주 누락 검토에 실제 열람 범위/출처만 기록하고 원문·원작 수치표·파일·스크립트는 사용하지 않는다. 현재 기초 국가/주 모델을 최종 모델로 두지 않는다.
3. M0 골든 전용 팩·기존 M1 scenario/저장 fixture를 임의 덮거나 기대값을 약화하지 않는다. M2 6개국/100~200프로빈스 콘텐츠와 기존 fixture의 분리·version/팩identity·hash/save 재개·구버전 처리를 기획한다. 필요한 게임 규칙이 01에 없으면 P10 구체 후보를 CEO에 전달하고 독립된 일을 계속한다. 이전 저장 호환 파괴/거부/migration·복구 어려운 삭제는 이번 자동 진행으로 승인하지 않았다. golden update --reason 절차와 실제 명령 존재 여부를 구분한다.
4. W1의 담당 exact P05 유효 PASS와 P07/같은mainHEAD 네CI 확인 뒤 W2 WP14(경제/정치), WP23(Testland 콘텐츠)를 선행 의존에 맞춰 진행한다. WP15 실제 장비/재고형/상한·WP19 보급 단위/Hub/phase/오류 계약이 생기면 아래 차량v2와 문서 대조를 남긴다. M4 차량 규칙이나 미완성 후속 공식은 M2에서 선행 구현하지 않는다.
5. M2 최종 게이트는 AC7 및 필수REQ48 전체와 독립 증거를 대조한다. 실제 UI 산업/건설/편제/외교를 사용한 평시→전쟁→적국항복 기록·재현 번들/캡처, headless AI50회 종료/크래시0/지표, 경제/보급/전투 원장·3OS/M2상태 저장/재현·성능 기준선/CI·01§11 차별화가 필요하다. UI가 연결되면 직접 탐색/결함을 기록하고 자동 E2E·AI벤치를 실제 UI플레이로 대신하지 않는다. 실제 GUI조작은 computer-use 스킬을 읽는다.
6. 첫 게이트 판정 OR 이번실행 묶음2개 통합 OR 사용자 전용 결정만 남아 진행할 일 없음 중 먼저 도달한 C02 경계에서 P08/HANDOFF·문서/증거 커밋/푸시·최종 같은HEAD CI 관측·RUN_RESULT 후 실제 종료한다. 진행 중 하위 작업은 정확path/head/app/cursor·producer 출력 경계와 작업 상태를 인계하고 중복을 만들지 않는다. 종료 뒤 M3/다음RUN을 임의 시작하지 않는다.

## 차량 v2의 유효한 한정 잠정 채택

exact 원문 be159587ac9acdd496f8a6bcb000d8229586f5d75a5dfa43b7f34b0a9e0171cf와 docs/decisions/DETAIL-DRAFT-0002-transport-v2.md·01§4.9/02§5.11/03P03를 대조한다. 문서 수준 M4 후보만 잠정 채택: 명시예약 W/A·자동보충없음, 필요/운용량 기반 floor와 손실 소수 이월 L, 기존 공급→경제→생산 순서, 원소유국 반환·배정해제/통제변경의 L수명, shared W+sumA 상한·입력거부/예정의미오류/phaseErr의 상태·큐·clock 구분이다. CEO 실제 독립 산술100손실/13반환 예제와 원문 봉인이 docs/decisions/evidence/transport-v2에 있다.

구현 전에 WP15 실재고 정수형/상한·장비/Hub ID·보급C 단위·phase/명령/서버오류·canonical/save/wire/호환을 대조하고 차이는 먼저 CEO 재검토한다. 합성 k/r은 콘텐츠값 승인이 아니다. WP15 생산 규칙 변경·구형 저장 거부/호환 파괴/migration·다른 미완성 공식은 승인하지 않았다. 사용자 D/OPEN 추가확정으로 기록하지 않는다.

## 기존 실패 보존·감시 기준

과거 6b6/eb87 DPR timeout·WP11verify3 Edge 초기 화면 원인 미확정, P05 missing-file 준비/PTYwrapper1·nativecode 미수집, P12 정책 TMP상위workspace FAIL 두건·selector/parser·ignoredsealappend 기록을 유지한다. 정상 exact P05/P07/P12/CI 성공과 해당 실패의 원인 해결은 구분한다. 임시f19 진단을 현재 제품 완료로 대체하지 않는다. 원본 실패 worktree/브랜치/증거를 삭제하거나 baseline/index를 복구하지 않는다.

완료는 구현+새 독립 유효 PASS+같은mainHEAD CI다. 최초 before 전체/추적목록/각SHA/HEAD/semantic/raw index·diff/cached/status를 모든 producer 전에 끝내고 prompt를 실제 저장·검사한 뒤 앱을 만든다. 장기exec session은 실제종료까지 wait하여 output변수/prompt에 미완료 응답을 사용하지 않는다. producer cwd/env/default output을 조사해 ignored 전용 경로로 지정하고 최초 baseline을 교체하지 않는다. 새CI 실패·환경 오류·의도 negative·미실행을 구분한다.

REQUEST0001은 실제답 반영,0002~0005는 위 한정 후보/준비 방향 외 상세 미완성이다. 새 권한내 구체 추천안은 CEO에 검토 요청하고 다른 작업을 계속한다. 사용자 전용은 대기 목록, 기존 승인 방향 재질문 없음. 연속3개 실제종료RUN의 고유 WP/게이트AC 진전 없음, 사용자전용만 남아 일 없음, 사용량오류30분간격최대4회가 중지 기준이다. heartbeat15분을 사용량30분 대기로 오인하지 않는다. 현재 중지조건 없음.


## W1 producer 후속 기술 경계 — 2026-10-07T09:51:52+09:00

WP17은 기존 v1 reader/writer/fixture/hash를 유지하는 별도 v2 신규상태 저장을 기술 ADR 범위에서 구체화한다. v1→v1 보존·정지unit/중간route/progress/새예약Move의 완전한 v2 선택·hash/저장/재개·bounded preflight 독립 경계를 확인한다. 구v1 거부/재작성/migration 승인은 없다. infra/supply/통행 trusted context는 서버 내부 권위/후속 adapter 입력이며 클라이언트가 속도/보정/통행을 임의 지정하는 경로를 두지 않는다. 미구현 규칙은 neutral/no-op 성공으로 흉내내지 않는다.

WP24 fluent-syntax0.12.0 MIT OR Apache2 후보는 허용목록의 기술 의존성 범위이며 해당 Cargo.toml/lock 단일 소유 인계·공식 원출처/현재 조건·실제 license 검사와 exact 독립 검증을 남긴다. 기존 testland manifest name_key 누락 원오류와 새 ko/en pack.ftl의 실제 content_hash 변화·기존 M1 저장 원팩identity 한계를 분리한다. 기존 fixture/golden 기대값을 덮지 않는다. CEO가 제품코드·의존성파일을 수정하거나 구현/검증앱을 만들지 않는다.


## REQUEST-0006 중간 이동 정지/경로 변경 한정 잠정 채택 — 2026-10-07T09:55:15+09:00

CEO는 exact REQUEST0006 SHA0b9e2ba3756fa1022a876f11369dc8b4e4909fc49e84ea35bfbf9b7d75734b07 전문과 WP17-schema/ADR1701·기존01/02 및 실제 큐/step 원자성 계약을 읽고 자체 정수시간8개 경계를 확인했다(REQUEST-0006-independent-review.json). docs04§2의 기존 승인 직접이동 범위에서 가역적 추천A를 잠정 채택한다. elapsed0은 즉시 정지/경로 변경, elapsed>0은 현재edge 및 elapsed를 보존하고 끝점 도착 뒤 정지 또는 새 목적지 경로를 시작한다. 새 경로를 끝점부터 먼저 검증하며 invalid enqueue는 상태·큐 보존이다. 예정 의미오류는 해당 명령 거부·소비와 성공step의 clock/다른 상태 진행을 구분하고 phaseErr는 전체commit/큐/clock 보존이다. Pause는 즉시시간정지로 Stop과 구분한다.

7.5h×2 합성 경로의7/8/15틱,1/7틱Stop후8틱도착,7틱경로변경+새5h다음edge후13틱도착,출발지반환경로15틱 도착을 독립 대조했다. Stop 도착 뒤 경로없음 elapsed0·남은tickbudget 버림과 계속 이동의 다음edge0.5h를 구분한다. 합성 수치는 콘텐츠값 승인이 아니다. 미래UI는 현재구간 도착후정지 의미를 현지화키로 표시한다. 실제 unit/context/wire·canonical/v2저장/원v1호환·권한·실패 독립P05는 별도 필수다.

오케스트레이터가 01§4.7에 CEO잠정과 입력/경계/후속조건을 기록하고02/03·REQUEST/ADR/schema를 맞춘 뒤 종속 구현한다. ADR의 기술연산순서 채택과 게임행동의 CEO잠정 채택을 구분한다. D05/OPEN확정상태·사용자답란은 추가확정으로 바꾸지 않는다. 원작자료·새전투/보급/통행권효과·저장거부/호환파괴/migration·후속범위변경은 승인하지 않았다.


## REQUEST-0007 육지 간 해협 인접 이동 한정 잠정 채택 — 2026-10-07T10:06:11+09:00

CEO는 exact 후보 SHA2731e99b719f836d42d2100da349392d199cbebba301796cbbeed098104b2e54 전문·01§4.1/§4.7·실제 MapData EdgeKind::Strait/기존 WP17 schema를 읽고 정수 산술8경계를 확인했다(REQUEST-0007-independent-review.json). docs04§2에 따라 기존 직접이동/지도인접 범위에서 가역적인 추천A를 잠정 채택한다. 이미 MapData에 정의된 land→land Strait edge만 대상이며 서버 내부 allowed 양끝점과 방향별 명시 양수 strait 시간계수가 있어야 시간합 최단경로에 포함한다. sea/lake·impassable/잘못된참조는 지원되는 이동으로 처리하지 않는다. 누락계수를1로 숨기거나 계산불가를임의NoPath로바꾸지 않고 MissingContext/유효성 오류를 명시한다.

하천·해협 coefficient 종류와 실제 edge kind를 구별해 schema/연산슬롯·순서·적용/복원 bit와 canonical/v2저장에 연결한다. 하천과 해협을중복곱하거나 같은필드로 오인하지 않는다. positive underflow0/overflow·0/음수·누락·타국권한·allowed외끝점·잘못된kind/참조/비육지·시간합/동점·state/queue/clock경계와 rawbit/hash/save/새process재개를독립P05에서 확인한다. 클라이언트는속도/계수/allowed를정하지않고 서버권위adapter가값을제공한다. 현재WP17 host API와 이후실제게임adapter/UI연결을구분한다.

합성10km/2kmh×strait2=10h·9/10tick·대체8h경로·동점lexical·overflow/underflow·9틱저장후1틱재개의8계산경계를직접대조했다. 이는콘텐츠 기본계수 승인이 아니다. 미래함대/봉쇄/해역통제·WP31해상수송·통행권정책·진행중allowed변경의게임행동은 이번후보로새로정하지않는다. 기존v1읽기/쓰기/fixture/hash·REQUEST6 stop/reroute조건을유지한다. 구저장거부/migration/호환파괴와사용자D/OPEN확정변경/원작자료사용은 승인없음.

오케스트레이터는01에한정CEO잠정·02/03/REQUEST·WP17 schema/ADR/새독립예제 대응 후 종속구현한다. 원 immutable후보와실제산술bytes를문서증거로복사/봉인해도된다. 아직제품/독립검증/통합완료를판정한것은아니다.


## WP24 실제 서버 로드 검증 우회 수정 인계 — 2026-10-07T10:22:09+09:00

새독립P05 exactc2c2가CLI는거부한 invaliddependency/brokenFTL를native Host::load가받아HTTP200으로연것을직접검사했다. CEO도actualHost::load/load_with_save와원stdout·CLI오류·server-probe-results를직접읽었다. 독립검증남은검사/최종fullraw/원봉인/FAIL전문/실제턴종료뒤만 WP24 P06에serverloader파일소유를인계하고수정한다. WP17은서버소유충돌없이진행한다. 새최종producer/exactHEAD의새독립P05에서정상/깨진의존·버전/FTL/참조및실제startup/restore입구를확인한다. 원c2c2/P05실패와최초9771/raw를보존하며검증중소스/기준선/index수정·restore없음. CLI PASS를서버로드의전체MOD04/LOC03 PASS로대체하지않는다.

원v1 frozen팩/current팩/legacyM0에대해코덱호환·실제서버지원/거부및현지화검사경계를분리한다. 원fixture/expected/단언을약화하거나무조건legacy예외로실패를숨기지않는다. 실제호환/loader계약차이가있으면구체안으로먼저제시하고다른일은계속한다. 원probe의server nativeexit1은검증자가종료한것이며정상shutdown0의증거가아니다. 실패는invalid입력의startup/HTTP수용자체다. 설정/샌드박스/CI우회및제품직접CEO수정승인은없음.

## WP24 최종 FAIL 후속 수정 범위 — 2026-10-07T10:28:39+09:00

독립P05 actual idle/completed10, 유효 FAIL 확인. 등록 legacy scenario defines 누락도 pack_validation 소유 P06에 포함하고 실제 loader의 기존 defines type/range/default 계약으로 검사한다. unsupported 경고는 미래 미구현 adapter에만 쓰고 이미 등록된 defines 검사 누락을 이름만 unsupported로 돌려 숨기지 않는다. legacy 정의 계약 차이는 먼저 구체 비교한다. 서버 실제 startup와 save restore 모두 공통 검증을 통과해야 하며 WP17 소유파일과 겹치지 않게 P06 파일목록을 명시한다. 원 source/P05/증거 보존 후 새 exactHEAD 새 독립P05가 필요하다.

권위 리포트는 actual 앱 마지막 전문이다. target fullreport.md는 더 긴 별도 증거 원문이며 actual final과 동일하다고 기록하거나 대신 덮지 않는다. 둘과 ZIP identity를 각각 보존한다. write_atomic의 추가 source재검사 가정 실패는 기존 미변경 API 범위 밖 발견으로 기록하고 이번 핵심 FAIL3개와 구분한다. 호환파괴·자동migration·테스트약화·설정변경 승인 없음.

## REQUEST-0008 역사 이름 메타데이터 호환 A 한정 잠정 채택 — 2026-10-07T10:57:22+09:00

CEO는 exact 원요청 SHA256 2477248184afc83d1ae5102a4ed12f11c4957c939d13b0c391724216b4b30ddc 전문·기존 frozen copy/mutable transform·load/codec/진단 경계를 읽었다. b651 원 Git blob에서 M0 3파일과 원v1 Testland19파일+기존 date/modifier transform의 postcard/FNV를 독립 재계산해8747082838669556868/12861016185528173627를 확인했고 plain13318001328374612931은 예외대상이 아님을 확인했다. source별 전체path/bytes/SHA manifest 및 16개독립조건 모델은 REQUEST-0008-independent-review.json에 있다. 이는 제품테스트/독립P05 PASS가 아니다. docs04§2의 기존승인 범위에서 원호환을 보존하는 A를 아래조건으로만 잠정 채택한다.

- engine-owned정책은 입력팩·CLI flag·WS/client가 정하거나 바꾸지 못한다. 정확한 전체파일집합/각bytes·SHA256와 FNV·id/version/scenario/kind/source provenance를 모두 비교한다. FNV64만으로원byte동일을주장하지않는다. 추가·삭제·1byte변경·symlink/reparse 및 검증중원천변경은거부한다. 정책자료는팩밖 엔진입력으로두고 current/old pack identity를오염시키지않는다. 원3/19파일manifest는이CEO원자료와대조한다.
- 허용caller는 server_startup의 원M0 empty/testland, server_restore의 같은원M0+실제v1header/context, cli_v1_resume의 원M0/testland 또는 원mutablev1/testland/m1만이다. CLI M0 run·standalonevalidate·plainfrozen19·현재팩·다른caller/format/scenario/key/lang에예외를추가하지않는다. 필요추가입구는실제계약과함께별도검토한다. 목적은 내부host경로에서선택하고 외부파일/flag의임의 purpose를권위로받지않는다.
- 정확한 manifest.name_key=testland_name의 typed missing_message_value/ko/en 두진단만 warning_unavailable로남긴다. 진단field/key/locale/cause/원file·line·column을보존하며 문자열substring으로거르지않는다. 다른구문·중복·정적참조·parity·사용키·dependency/version/engine/conflict/schema/ref/defines 오류는모두엄격거부한다. 호환진단을일반순수locale검증성공으로집계하지않으며 strict standalone 원M0 exit1 유지. 가짜이름/번역을추가하지않고 실제metadata unavailable을표시한다.
- saveformat/맥락은 actualboundedheader→검증된pack/scenario/context 관계로증명한다. v1codec의fullstate/hash/정의·팩identity/player/metadata/용량·trailing/unknown형검사를그대로유지한다. --force는policy를선택하거나validation을면제하지않는다. 원fixture/expected/golden/header/body/단언·기존reader/writer bytes·current generic 검사 보존. 호환파괴/migration·테스트약화·설정변경·게임규칙/사용자DOPEN확정은미승인.
- 구현전에 REQUEST/ADR/schema에한정CEO잠정·전체manifest/진단원자성/입구별행렬을기록하고코드를쓴다. 정상원M0 HTTP/WS와정상종료/native0, 원v1 freshresume전체state/hash, current strict/changedpack거부 및 각조건변조/다른오류/native拒否/HTTPWS없음/실패상태와save원파일보존을새exact 독립P05에서직접확인한다. manifest/warnings/원FAIL3건을함께봉인하고기존실패를대체하지않는다.

## 필수 저장 CI 입력 연결 정합 범위 — 2026-10-07T12:21:27+09:00

CEO는 실제 Save workflow의 frozen capture → save_native.py HTTP 정상 복원 연결과 소비자가 run-1/pack 및 paused.ohsave를 읽는 것을 직접 확인했다. REQUEST-0008에서 역사 mutable-v1의 허용 caller는 CLI뿐이므로 현재 서버 거부는 정책에 맞지만 필수 CI의 정상 입력 연결은 맞지 않는다. optional 구형 관측이나 환경 문제로 분류하지 않고 실제 CI 연결 실패로 기록한다. 다음 기술 보완은 기존 승인 계약을 유지하는 가역적 입력·검증 도구 수정 범위다.

- 원 frozen 두 회 capture, fixture/expected/golden bytes, 원 v1 CLI 재개 및 3OS 비교를 그대로 유지한다. 기존 비교와 단언을 삭제·약화하거나 현재 팩으로 원 fixture를 덮지 않는다.
- 이미 있는 capture-current를 별도 디렉터리에 두 회 실행하고 원 native 새 프로세스 재개·전체 DTO/queue/config/state·정수 원장·canonical/hash·팩 신원·원 파일 보존을 직접 검증한다. 두 capture의 반복 신원과 3OS 결과는 같은 정확 HEAD에서 대조하며 원 frozen 결과와 섞지 않는다.
- save_native.py의 기존 HTTP/WS/welcome·query/served JS/exclusive 서버·정상 종료 단언은 유지하며 정상 입력을 별도 현재 팩 저장에 연결한다. 역사 mutable-v1 서버 거부는 HTTP/WS 수용 없이 실제 native1의 별도 negative로 확인하고 CLI 원 호환은 계속 검증한다.
- 구현 소유는 부모가 WP24 기존 구현 채팅에 필요한 save_native.py·저장 checker·Save workflow와 관련 검증 도구/문서 파일을 정확히 명시한다. 현재 c28 입력 보완을 포함하는 base와 기존 정책을 인수한다. 서버 정책 caller, codec/header/body, expected/골든, 게임 규칙과 사용자 D/OPEN 상태는 변경하지 않는다.
- 현재 새 독립 P05의 실제 final·FAIL 및 전체 불변성을 보존한 뒤 수정 커밋에서 새 독립 P05/P07과 같은 main HEAD의 5 workflow/필수 job 전부를 확인한다. 기존 실패를 최신 성공으로 대체하지 않으며 실행 안 한 비교/OS를 통과로 기록하지 않는다.

새 P05-2 raw index 불변성 불일치도 실제 무효/FAIL로 보존한다. HEAD·내용·semantic index가 같다는 이유로 원 raw 차이를 면제하지 않는다. 원 before/after를 그대로 두고 원인 확인 전 복구·기준선 교체 없이 새 수정 source/새 worktree의 최초·최종 검증을 진행한다. 원인 미확정은 미확정으로 적는다.

새 독립 검증의 TypeScript 동등성은 기존 read-only exact equality 테스트 또는 실제 typescript() 결과를 ignored 출력으로 생성해 원 tracked TS bytes와 대조하는 방식으로 증명한다. tracked 생성기 호출·동일 bytes 재작성도 검증 중에는 하지 않는다. 기존 parity 단언과 CI의 생성/diff 기준을 약화하지 않는다. 이번 원 P05 실제 FAIL과 별도 후속 설명 final을 구분해 보존한다. 제품 생성기 변경 후보는 현재 필수 채택하지 않았다.


## M2-r2 재개 — 실제 중단 인수

M2-r1 오케스트레이터와 P05-4 검증 앱은 원 실행과 후속 turn 모두 actual interrupted/notLoaded, RUN_RESULT/검증 actual final 없음이다. 무진전 횟수는 최초 종료1, usage0이며 아직 중지 조건이 아니다. stale HANDOFF의 M1 완료보다 STATE/actual registry·앱·Git을 우선한다. 현재 main1cf57fee1860dd3611088dd751c30251035775c4 clean·실제 origin82db68f67827cb0b4e6317fae29d1514a94b64f0 ahead7/behind0·같은HEAD CI 없음. check_docs 오류0/경고0. 완료WP12/게이트2/W1전체0/W2전체0. user M6 진행·개별D/OPEN/후속로드맵·품질/GUI플레이/독립지리·고도 baking·클린룸 모두 유지한다.

첫 작업은 기존 source164f04e6378b959e54da67cbca19b1ff03b6fe9f의 P05-4 인수다. 기존 앱01a114b2-8a3d-7c91-9ba0-37959a8fbb11/local, 원 turn01a114b2-8d45-7112-9822-75808277522d, 전용 .orchestrator/wt/WP-24-M2-r1-verify4, 원 target/evidence/WP-24-M2-r1-P05-4. 실제final/fullreport/SHA manifest/ZIP 미생성, 원 parent-before/verifier-before/verifier-after whole9880/raw3e5d17f2339d464034ba0b211b42621abeeeea93260a3a618ce92b2c865e6161 동일을 CEO가 직접 확인했다. 먼저 현재 whole/raw와 원본을 비교하고 실제PID/잔여공정을 확인한다. 같은 기존 독립 검증 앱을 명시 재개하여 원 실패·preparation·native 결과를 보존한 채 unfinished final 봉인만 끝내게 할 수 있다. 원기준선/index/추적파일 변경·원래 verification turn을 완료로 소급 표기하지 않는다. 기존 원 검증은 아직 PASS가 아니다. 불변성이 달라지면 해당 검증 무효로 보존하고 독립 새 worktree/새 최초기준선으로 검증한다. CEO는 새 구현·검증 앱을 직접 만들지 않는다.

P05-4 초기 direct Vitest는 package pretest 생략/잘못된 상대fixture 경로 ENOENT9실패 원기록이며 정식 npm test pretest+130통과를 따로 보존한다. 추가 root-range 첫3건은 자체native1/미HTTPWS였지만 expected initial_speed와 실제 network.command_capacity 진단의 불일치였다. 별도 correct-cause3건을 원기록과 함께 유지한다. 원P05-3 FAIL2·c28 raw무효/SaveCI FAIL·원82CI FAIL·과거scopePASS도 모두 유지한다.

생산자164f clean9소유 파일·3795원파일/MF·부모ZIP3796/6240862bytes/SHA8cd04d27f4cfa7f4d947b6511501294c853c8fbbbf4c89f95ec386415bfb4494를 CEO가 직접 전수0 대조했다. source .orchestrator/wt/WP-24-M2-r1과 docs/worklog/evidence/WP-24-M2-r1-P06-current-comparer/는 보호한다. national stagedhelper의 오류순서/원Node selector·독립DTO/정수원장·original8/current21·legacy native63/기존48·codec/policy/fixture 보호를 계속 검증한다. source별 독립 유효 PASS → source상관 인수/통합 → P07(새legacy native63 준비는 미실행) → 실제푸시·같은main5workflow 전필수jobs/3OS artifacts 성공 순서로 진행한다. WP13→WP25→원 W1전체 완료 후 W2 WP14/23, 두 원묶음 또는 게이트/결정대기 경계에 P08/HANDOFF/커밋푸시/RUN_RESULT로 종료한다. W1-a는 원묶음 하나를 추가로 센 것이 아니다.


## REQUEST-0009 A 한정 잠정 채택 — 2026-10-07T14:22:38+09:00

원 REQUEST9390bytes/SHAfe24a13132fff1717b284af42e36ed6f836ea919a0203733d9ba1ce52d1caf8d 전문·01§3.3/REQ-TIME-04/REQ-AGD-05·02§5.6/5.7·실제 Simulation enqueue/step/calendar·M2 trigger preflight/contracts·WP13 reviewed draft를 직접 검토했다. docs04§2의 기존승인 범위·가역적 세부행동 권한으로 A를 WP13에 한정 잠정 채택한다. 사용자 추가 확정답이 아니며 D/OPEN 상태를 바꾸지 않는다. CEO 원본/독립검토는 REQUEST-0009-original.md 및 REQUEST-0009-independent-review.json에 보존했다.

채택하는 행동은 요청 A의 inclusive end_date와 다음날00:00 checkpoint(초기 start=end는 그날24시간, start>end 로드오류), 명시 단일 AST/all-any-not 및 필요한 명시root, 초기권위 생성후1회·성공 시간전진 step의 시스템/원장뒤 평가, 초기참 tick0 종료, 부작용 없는 조건, 날짜/조건/명시effect stable typed원인 보존, 전효과 성공후 후보 commit, 종료후 step/새 enqueue 거부·future queue 보존과 query/save 허용, nation-scope flags·명시root/국가scope복귀·실행수명 유지·idempotent set/clear 및 전체effect transaction 실패 원자성이다. unsupported scopes/primitive/score 실제사용은 host capability 로드 오류이고 가짜0/false/neutral/no-op을 만들지 않는다.

기존 command 의미오류의 결과 소비와 phase/clock Err의 전체 rollback은 서로 구분해 그대로 인수한다. 요청의 effect 전체 실패 원자성을 적용한다고 기존 invalid scheduled command 소비계약을 바꾸지 않는다. 실제 평가 위치/원인 안정순서·여러명시효과 source ID/예산/root-null·empty AST·scope 복귀·오류우선순서·host pump 종료응답·typed localised errors는 schema/ADR에 구체화하여 실제 source와 대조하고 독립 검증한다. schema에 없는 새 game behavior가 필요하면 구체 차이를 먼저 P10으로 대조한다.

원 M0/M1 None 모드 및 original v1/v2/v3 reader/writer/bytes/canonical/hash/fixture/expected/helper/policy/force를 보존한다. 새종료/flags 정의가 존재하나 값이empty인 경우에도 정의신원/실제 state를 새additive형식에 보존하고 기존 binary DTO의 필드를 무조건 덧붙이지 않는다. source root/tag/flag ID·중복/null/type/ref/bounds/order를 로드와 저장복원 양쪽에서 검사하며 원입력과 실패 후 전체state/queue/clock/RNG를 유지한다. 새형식 저장을 만든 뒤 되돌린다는 이유로 호환파괴·삭제/migration을 자동승인하지 않는다.

네 점수축/결과화면 요구와 항복후 관전선택은 유지한다. VP/IC의 실제accessor·단위/수명 및 후속WP20 생존/진영 producer를 인수하기 전 부분지원·0weight나 합성host 결과를 전체 scoring/M2 gate 완료로 세지 않는다. 가중치연산은 기존Fx/checked정수와 독립산술로 기술설계하고 새로운 normalization·콘텐츠값을 만들지 않는다. 후속consumer owner/REQ·WP·검증을 추적해 M2최종까지 실제입구를 연결한다.

CEO 별도 산술은1900-02-28~03-01 inclusive48tick, 2000 같은구간72tick, 2099-12-31 하루24tick·2100경계, 2000-12-30~31 48tick·연도경계, 2004-02-29 하루24tick이다. 이는 기획 검토용 독립합성 예제이며 실제 제품테스트/콘텐츠 기본값 승인이 아니다. verifier는 자체 정상/오류/경계 예제와 실제 native중단→resume 전체DTO/canonical/hash/queue·원저장 보호로 검증한다.

부모가 REQUEST 사용자답 절에는 CEO 잠정채택임을 구분하고 01/02/03·WP13 schema/ADR·실제명령/검증지시에 먼저 대응시킨 뒤 구현세션을 시작한다. 선행164f P05 유효final/whole/raw/MF/ZIP →P07→같은main5CI 인수조건은 유지하고 WP13을 조기 시작하지 않는다. 실행중 공유추적문서는 부모가 갱신한다.

## 사용자 우선순위 변경 — 전세계·프로빈스 실제 렌더링 먼저 (2026-10-07T16:08:59+09:00)

사용자 직접 지시 원문: "먼저 전세계와 프로빈스 렌더링부터 보여줘. 그래야 의지가 생기지."

이 지시는 M6 목표를 유지하면서 제작 순서를 변경하는 직접 승인이다. 현재 M2 전체 기능 완료나 M3/M5 차례까지 기다리지 않고 실제 전세계 지리와 독립 생성 프로빈스 경계를 볼 수 있는 로컬 브라우저 미리보기를 최우선으로 병행한다. 계획 설명·Testland 사각형·AI 목업만을 결과로 내지 않는다.

- 현재 WP13 P06 수정은 전용 앱에서 계속하되, 오케스트레이터가 WP32/45 지도 파이프라인·기존 WP07/08 렌더러의 시각적 부분을 앞당긴 별도 작업을 기획·배정한다. 구현·검증 앱/명시적 worktree는 오케스트레이터가 생성한다. CEO는 제품 코드를 쓰거나 하위 앱을 만들지 않는다. 동시에 구현3~4개 이하, WP13 network/checker 소유와 충돌하지 않는 파일·팩·출력 소유를 명시한다.
- 첫 결과: 실제 전세계 대륙·해안/육지·바다 윤곽, 사각형 격자와 다른 독립 생성 프로빈스 분할, 확대/이동·경계 보기·선택/호버 가능한 실제 브라우저 지도. 기존 Three.js 지도 파이프라인을 사용하고 라이선스 검토된 고정 로컬 원천에서 파일을 생성한다. 지도는 별도 preview 팩/출력으로 두고 기존 Testland/golden/save fixture를 바꾸지 않는다.
- 지도 생성 전에 필요한 최소 필드/투영/ID/육해 구분/인접/렌더러 입력/해상도/경계·수명·hash/출처 계약을 작성한다. 지리·고도·하천 원천의 버전·URL·취득일·라이선스·SHA를 기록하고 오프라인 생성·재생성 hash를 대조한다. 산맥/하천/도시 주변 분할 원칙과 고도 반영 요구를 유지한다. 첫 표시와 지형 세부 완성 수준을 나누어 실제 적용/누락을 명시하며 누락을 완성으로 쓰지 않는다.
- 원작 지도 경계·파일·스크립트·수치표 복사/트레이싱은 계속 금지한다. 공개 플레이 화면의 분할 원칙/밀도 참고만 허용한다. 게임/브라우저 런타임 외부지리 API/타일/CDN 없음. 지리 원천 취득의 허용 네트워크를 Codex 설정 변경이나 공개 배포 승인으로 해석하지 않는다.
- 세계 지도 렌더링 미리보기와 M5 전체1936 콘텐츠/역사국가 경계/시뮬레이션·독립게이트 완료를 구분한다. 새게임규칙/역사 수치/소유권/경제값을 만들지 않는다. 미리보기 표시용 지리 구분은 임의 국가/군대/게임점수로 표현하지 않는다. D·OPEN 확정 상태와 기존 사용자 답변은 변경하지 않는다.
- 첫 실제 브라우저 실행이 되면 마일스톤 완료를 기다리지 말고 정확한 커밋·로컬URL·실행법·실제 전세계 캡처와 확대 지역 캡처·프로빈스 개수/원천/미완료 항목을 CEO에게 전달한다. 사용자가 이 채팅에서 곧바로 볼 수 있게 실제 캡처를 제공한다. 공개 호스팅/계정/비용/태그 승인 없음.
- 오케스트레이터는 현재 계획/인수인계에 이 우선순위를 먼저 반영하고 즉시 독립 지도 작업에 착수한다. 현재 RUN을 중복 생성하지 않으며 독립검증·기존 실패 보존·기존 필수 CI를 유지한다. 이 시각적 선행 작업을 원M2 병렬 묶음의 통합 완료 수로 임의 집계하지 않는다.

### 같은 사용자 지시의 범위 확정 — 지도 렌더링 + 메인 HUD 외관만 우선

후속 사용자 직접 원문: "렌더링에, 메인 HUD 까지만 렌더링 하자. 기능을 지금 구현할 필욘 없고, 그렇게 해두고 차근차근 기능 개발하면서 연결 하는거야."

가장 최신 지시로 첫 시각 결과의 범위를 전세계 지도·프로빈스 렌더링과 메인 HUD 외관으로 한정한다. 지도 미리보기를 만들기 위해 경제/외교/전쟁/생산/시간진행/메뉴동작 등 새 게임 기능이나 전체1936 시나리오를 선행 구현하지 않는다. 이미 진행 중 WP13 P06 오류 수정은 원 증거와 분리해 계속한다. 세계·지도 경계와 HUD를 먼저 사용자에게 보여주고 이후 M6 기능을 차근차근 연결한다.

- 게임 화면을 채우는 실제 전세계 지도, 독립 프로빈스 경계, 확대 지역에서도 경계를 읽을 수 있는 렌더링을 중심에 둔다. 지도 보기용 기존 카메라 줌/팬은 렌더러 탐색이며 새게임규칙이 아니다.
- 메인 HUD는 OpenHOI4 공개 명칭, 상단 날짜/시간·자원 표시 자리, 주요 게임 패널 탐색 영역, 지도 모드/선택 정보의 화면 배치와 자체 일관된 스타일을 구현한다. 기존 설계에 없는 새 게임 자원·규칙을 만들지 않고 표시 슬롯만 둔다. 새 panel backend/action, WS command, 게임 수치 계산은 이번범위가 아니다.
- HUD의 아직 연결되지 않은 영역은 placeholder·미연결 표시로 명확히 구분하고 버튼에 실제 게임 효과가 있는 것처럼 동작시키지 않는다. 미리보기 데이터가 필요하면 고정 표시용이라고 명시한다. 기능연결 계약/컴포넌트·상태 입력을 분리하되 전역 하네스/강제 기능을 추가하지 않는다.
- 첫 완료 기준은 실제 브라우저의 전세계 지도+프로빈스+메인HUD 전체 캡처와 확대 지역 캡처, 로컬URL/실행법, 정확커밋/데이터원천·미연결 범위다. 이 화면을 사용자가 확인한 다음 새 기능을 연결하는 순서로 진행한다. 마일스톤 최종게이트와 시각 미리보기 검수는 구분한다.
- 원UI를 복제하지 않는다. 클린룸·자체 컴포넌트·허용 폰트/아이콘/에셋과 source/license/SHA manifest를 유지한다. 기존 renderer/WP13 network/checker 및 다른제품 소유 충돌 없이 오케스트레이터가 기획·구현·독립시각검수를 배정한다.

### 사용자 임시 에셋 제작 지시 — 생성형 유닛 마커 등

사용자 직접 원문: "일단 유닛 마커 등은 생성형으로 때운다."

지도/HUD 첫 시각 결과에 필요한 유닛 마커 등의 임시 시각 에셋은 생성형 도구로 제작한다. 자체 원본 스타일의 육군/공군/해군 마커 등 필요한 최소 분류를 일관된 실루엣·크기·가독성으로 만들고, 생성형 raster asset 작업은 담당 구현앱이 imagegen SKILL.md를 먼저 읽은 뒤 실제 imagegen 도구를 사용한다. 투명 배경이 필요한 마커는 투명 PNG로 생성한다. CEO는 제품 에셋 생성·제품 코드·하위 앱을 직접 다루지 않는다.

- 미리보기 배치용 마커는 화면 샘플이며 실제 군대/배치/전투/게임 수치가 구현됐다는 뜻이 아니다. 마커 표시와 이후 권위 유닛 데이터/selection/action 연결을 분리한다.
- 원작 유닛 아이콘/모델/국기/파일을 복사하지 않는다. 원작 자료나 위헌단체 상징을 넣지 않고 독립 설명으로 생성한다.
- 임시 에셋은 교체 가능한 독립 asset 파일·ID로 두고 생성도구/모델(실제 제공되는 정보만)/prompt·생성일·출처·이용조건 검토·SHA256을 기록한다. 실제 배포 반영 시 ASSETS 매니페스트와 기존 사용자 라이선스/에셋 검토 원칙을 따른다. 생성형 임시 사용은 공개 배포·비용·태그/법적 판단 승인이 아니다.
- 기능 구현을 위한 새 unit schema·전쟁규칙을 만들지 않는다. 첫 지도+HUD 렌더링이 늦어지면 원 자체 간단한 시각 fallback을 구분해 두고 마커 생성 완료 후 붙인다. 실제 생성 실패/미연결은 그대로 기록한다.

### 사용자 작업 방해 금지 — computer-use 대신 BP 백그라운드 검수 방식

사용자 직접 원문: "컴퓨터 유즈 스킬을 쓰지 말고, 지금 브레이킹 포인트의 UI 구현 중인 코덱스 세션이 있는데 그 세션이 쓰는 방법을 써. 나는 내 작업이 방해받고 싶지 않아."

이 지시는 이전 GUI computer-use 스킬 지시보다 우선한다. WORLD-PREVIEW·후속 시각검증/모든 이 작업 채팅은 computer-use 스킬/CUA·사용자 화면/탭/창 focus·전역 마우스/키보드 조작을 사용하지 않는다. 사용자의 다른 작업·브라우저·BP 인스턴스/PID/데스크톱·설정은 변경하거나 종료하지 않는다.

CEO가 실제 BP-PROG-ORCH(01a10c3b-6452-7880-a462-644789871f0e/local)의 최근 실행을 read-only로 확인했다. tools/bp_background_game.py는 BP_GUI_TEST 별도 Windows desktop/PID 인스턴스, target-window PostMessage 입력과 PrintWindow 캡처, foreground/cursor 전후 불변 관측을 사용한다. 실제 캡처 원 출력은 uses_activation_or_global_input=false, foreground_before_after 동일·cursor_before_after 동일이었다. 직접 helper code의 기술 경계만 읽었으며 BP/원작 게임 에셋·GUI·수치·지도는 OpenHOI에 인수하지 않는다. BP helper를 실행하거나 BP 프로세스·데스크톱을 재사용하지 않는다.

OpenHOI4는 브라우저 제품이므로 같은 격리 원칙으로 자기 전용 localserver/PID/profile와 Playwright/CDP의 headless/background Chromium 렌더링·element 이벤트·page screenshot을 우선 사용한다. headful GPU 관측이 실제로 필요하면 자기 전용 비활성 Windows desktop에 한정된 프로세스/창에서 렌더링하고 desktop을 사용자에게 전환하지 않는다. 기존 BP_GUI_TEST를 사용하지 않으며 전역 input/활성창 변경/visible browser/open-in-app/browserfocus도 하지 않는다. 캡처 전후 foreground/cursor 불변과 자기 PID·URL·콘솔·네트워크·실제renderer/backend/헤드리스 여부를 기록한다. 검은/미렌더 이미지는 실패로 남기고 사용자 desktop capture/강제focus로 대체하지 않는다.

검수 방법 차이는 실제 headless browser/WebGL software versus 실제 GPU·직접 사용자 플레이를 구분해 기록한다. 이 지시는 승인·샌드박스·가속/네트워크 설정 변경이나 검사를 약화하는 승인으로 쓰지 않는다. 필요한 background helper는 담당 구현앱의 명시적 소유로 추가하고 CEO가 제품 코드를 쓰지 않는다. 생성형 imagegen 마커 작업은 계속한다.

### 사용자 후속 — 지도 위 임시 유닛은 실제 3D 모델

사용자 직접 원문: "그리고 3D 임시 유닛 마커 제작도 가능한가? 3D 모드인데 2D 마커가 있는건 좀.."

사용자 의도를 반영해 지도 위 unit placeholder는 실제 입체 mesh로 표시한다. 이미지생성 PNG/billboard를 3D model이라고 부르지 않는다. 현재 사용 가능한 생성형 도구는 raster imagegen이며 실제 mesh/GLB 생성 도구는 노출돼 있지 않다. 현 Three.js 의존성으로 자체 primitive/procedural low-poly 전차·항공기·함정의 임시 geometry를 만들고, 이후 고품질 생성형3D/정식 모델로 교체 가능한 asset 경로·generator recipe·metadata를 둔다. 외부 유료3D 서비스/계정/APIkey/설정 변경은 이번 지시로 추가하지 않는다.

- 실제 모델의 입체 실루엣·면·회전/방향·조명/깊이가 보여야 하며 평면이미지에 3D효과만 주는 것으로 대신하지 않는다. 기존 지도카메라/좌표에 올리고 sample deployment임을 명시한다. unit gameplay/path/combat/군대수치/새권위schema는 후속기능이다.
- 모델 geometry는 독립 자체 제작이며 원작 모델/아이콘/마커를 복사하지 않는다. 전차/비행기/함정의 간단한식별가능형상만 만든다. ASSETS등록·source/recipe/SHA·교체가능ID를 유지한다.
- 이미 생성된 army PNG와 imagegen 원출력은 보존하고 HUD/icon용으로 분리 가능하다. 새지도 표시용2D air/navy 제작은 필요한 경우 현재도구 종료 확인 후 범위를 조정한다. PNG를 삭제하거나 동시에asset소유를중복하지 않는다.
- 기존 PREVIEW-MARKERS 담당앱에 3D모델 asset 경로/생성도구·검증의 추가단일소유를 부모가 인계하고 WORLD-PREVIEW 앱은 renderer·HUD 연결만 맡는다. 필요 GLB/glTF export 또는 procedural Group 파일형은 기존의존성/정확입력·출력계약으로 정한다. 신규 dependencies/전역Blender설치/서비스가입을 선행하지 않는다.
- computer-use/CUA/사용자focus·전역 키마우스는 금지이고 전용 background/headless 검수 원칙을 그대로 유지한다. 첫 결과는 실제 전세계·프로빈스·메인HUD·입체임시유닛 화면이며 gameplay 기능은 나중에 차근차근 연결한다.

### 사용자 추가 지시 — 실제 HOI4 프로빈스 형태 참고

사용자 직접 원문: "그리고 프로빈스도... HOI4 실제 프로빈스의 모양을 참조해."

현재 e209 세계 preview의 균일 nearest-seed 다각형을 최종 프로빈스 모양으로 채택하지 않는다. 이전 공개 플레이 화면의 분할 원칙·밀도 참고 허용 범위 안에서 실제 프로빈스가 지역마다 어떤 크기·장축·굴곡·밀도를 보이는지 비교하고, 산맥/능선·강·해안·도시 주변의 분할을 독립 지리 자료 기반 생성에 반영한다. 원작 경계 좌표/색상-ID/지도 파일/수치표를 추출하거나 경계를 복사·트레이싱하는 승인으로 확대하지 않는다.

- 오케스트레이터가 현재 WORLD-PREVIEW 담당에게 최신 형태 개선 요구를 전달한다. 전세계/HUD/실제3D 첫 표시 작업은 유지하며, 모양 개선을 후속 실화면 비교 checkpoint로 제출한다. CEO는 제품 코드를 쓰지 않는다.
- 공개 참고는 출처URL·열람일·지역·관찰한 분할 원칙을 자기 문장으로 기록한다. 원작 이미지를 제품 에셋/지도 생성 입력으로 사용하지 않는다. 공개 화면을 읽지 못했으면 실제 참고 완료라고 쓰지 않는다.
- 목표는 무작위 경계 노이즈 추가가 아니라 지리에 따른 크기/형상/밀도 변화다. 해안·하천 주변 굴곡, 능선·골짜기에 따른 길쭉한 형태, 도시 주변 세밀한 분할, 넓은 내륙의 상대적 큰 분할 등을 실제 자료와 대조한다. 모든 지역에 하나의 형태/균일 밀도를 강제하지 않는다.
- 이전 원천보존/DEM·하천 입력 지시는 유지한다. 아직 자료 미반영인 구간은 미반영으로 적고, 바다/호수/섬 연결·면적 아주 작은 조각·인접·dateline 및 안정적 ID/반복hash 검수도 유지한다. 게임 효과/수치·국가소유 규칙은 새로 만들지 않는다.
- 유럽·한반도·산맥/강/해안 표본의 같은 축척 전후 실렌더를 보고하고, 표현력·연결성·자료 반영 여부를 독립 검수한다. 원본 e209 capture/metadata는 역사 증거로 보존한다. computer-use/CUA/사용자focus/전역input 금지, 자기 headless 검수 그대로다.


### 최신 실화면 품질 검토 — 2d920 세계/HUD/3D

CEO가 실제 Europe/Korea-WebGL2/Himalaya-terrain 캡처를 직접 확인했다. 구현 표시 기능과 최종 지리 품질을 구분한다. 한반도는 해안선의 큰 계단과 반도를 가로지르는 소수 대형 프로빈스가 남아 사용자 지시의 지역별 밀도/형상 수준에 더 개선이 필요하다. 기존world 담당 소유에서 지역별 분할 밀도·독립 해안/강/능선 근거·표시 해상도 후보를 검토하고 같은 축척 전후 캡처로 먼저 확인한다. 고정 숫자/원작 수치/경계 복사/랜덤 잡음으로 대신하지 않는다. 원2d920 입력/캡처/기능검수 증거는 보존하며 globalDEM/도시 입력 미완료는 그대로 명시한다. GPU상한/메모리·ID/선택·인접·재생성hash와 기존회귀를 유지한다. 새게임기능보다 사용자의 지도/HUD 외관 우선 순서를 유지하고, computer-use/CUA/사용자focus 조작은 계속 금지한다.


### WORLD 독립 검수 F03/F04 후속 — 2026-10-07T18:03:26+09:00

원2d920 P05-2 유효FAIL 전문·재현·봉인은보존한다. 현재same-owner quality 작업에서 edge 없는 유효same-kind component fallback과문서1-basedu16최대65535/zero-basedordinal 분리를맞추는최소수정·red→green 경계검사를포함한다. checker/골든/기존E2E/설정완화 없이새exact-source 독립검수로판정한다. 현재13413 표시PASS와원F01/F02해소는유지하되전체PASS로바꾸지않는다. 작은viewport클리핑은관찰/표시개선후보로다루고지원최소값을임의확정하지않는다. 사용자외관우선/noCUA/focus/독립지리자료·원작분할원칙만참고는그대로다.


### 사용자 아일랜드 분할 지적과 비교조사 — 2026-10-07T18:39:23+09:00

실제 사용자: 아일랜드가 프로빈스 하나네? 이러면 안되지. HOI4가 프로빈스 몇갠지 알아와. 그리고 다른 유명한 모드들의 프로빈스 갯수도. 공개aggregate 집계만 조사하며기존클린룸 제한유지. 조사원기록 province-count-public-research-20261007.json의버전/범위/확정한계를유지한다. HOI4본편approx13k·커뮤니티EaWapprox20.7k·제작자Magna2022 utility21664/EOE1.11 17k+·TNOmapport20002·OWB2.0개발10768은현재모든설치분전수통계가아니며최신값으로허위기록하지않는다.

기존WORLD 같은담당후속품질우선: 아일랜드/영국/일본/유럽 큰섬·본토의실제ID수/면적·형상·분할밀도와같은축척캡처를먼저대조한다. 정확아일랜드ID수는추측한개로확정하지않는다. 총20366에는sea6080/lake4053,land10233중1pixel2639가포함되며모든kind1pixel합6500임을CEO가현재provincesJSON에서직접확인했다. 전체총계와실질본토·큰섬의세분밀도를별도기록하며총개수증가만으로품질PASS하지않는다. 독립해안/강/DEM/도시좌표를근거로지역분할을개선하고원작경계복사/트레이싱/파일재사용·게임수치추가·미세섬을임의삭제/서로단절육지merge하지않는다. 새전체게임기능보다지역별밀도미달외관개선우선. noCUA/focus/자기headless·원실패/독립검수/invariance는그대로유지한다.


### 사용자 직접 지시 — 전세계 프로빈스 20,000~30,000개 목표

사용자 원문: "적어도 20000~30000개는 되어야지."

전세계 프로빈스 목표 규모는 20,000~30,000개로 반영한다. 20,000개 이상을 목표의 하한으로 두며 30,000개를 절대 상한으로 새로 확정하지 않는다. 이는 사용자 직접 제작 목표이고 원작 게임 수치표를 복사한 규칙이 아니다. 육지·바다·호수 각각과 전체 개수를 분리 보고한다. 사용자가 육지만 20,000~30,000개로 지정했다고 확대 해석하지 않는다.

현재 20,366개 중 모든kind 1pixel합6500이므로 숫자만으로 목표 충족을 선언하지 않는다. 원래 존재하는 작은섬을 보존하면서, 미세 조각을 의도적으로 만들어 목표 개수를 채우지 않는다. 아일랜드·영국·일본과 각 대륙의 실제 유효 육지 프로빈스 개수, 면적분포, 큰셀 편중과 같은축척 캡처를 제출해 지역별 세분을 확인한다. 지역별 밀도·형상은 독립 해안/강/DEM/도시좌표에 따른 분할로 개선하고 원작 경계/파일/색상ID 복사나 무작위노이즈로 대신하지 않는다.

기존 WORLD 담당 단일소유로 이어가며 전세계·프로빈스·메인HUD 외관을 기능연결보다 먼저 제시한다. 원ab64와 과거FAIL/봉인 보존, 수정 후 실제 source 독립검수·ID선택/인접/반복산출/성능·메모리 검사 유지. noCUA/사용자focus/전역input·제품코드 CEO 직접수정 금지는 그대로다.


### 사용자 도시 분리 예시 — TFR 도시 프로빈스

사용자 원문: "예를 들어 도시만 따로 떼야 할 수 있어. TFR의 경우엔 그리 했어."

지역 분할 기준에 필요시 도시 시가지를 주변 농촌·산지와 별도 프로빈스로 구획하는 것을 반영한다. 도시 좌표 주위에 seed만 추가해 도시와 넓은 농촌을 같은 셀에 두는 것만으로 도시 분리가 됐다고 선언하지 않는다. 주요 도시의 독립 시가지 범위 자료/강·해안·주변 지형을 근거로 경계를 만들고, 실제 자료가 없으면 근사/자료미반영을 구분한다. 도시행정구역 전체를 시가지로 자동취급하지 않는다. 거대도시의 내부 추가 분할은 필요성을 검토하는 후보이며 모든도시=1개/모든거대도시복수라는 새일괄규칙을 확정하지 않는다.

도시 주변 세밀한 분할과 상대적으로 넓은 농촌/산지 분할을 유지하되 확대해서도 선택하기 어려운 미세조각 양산을 피한다. 20,000~30,000 목표와 아일랜드·영국·일본·유럽 개선을 유지하며 도시/교외/농촌 표본을 같은 축척 실제 캡처와 citypoint의 실제 province ID·면적/연결성/인접으로 제시한다. 지도 외관/지리 분할 범위이며 전투·승점·경제·인구·보급·도시수치 효과를 새로 구현하는 지시가 아니다. 현대 도시자료는 현재 외관 시제품의 지리 참고이며 1936 또는 다른 시대 데이터로 조용히 확정하지 않는다.

TFR는 분할 원칙 참고 사례로 기록한다. 공개 플레이어의 직접 경험 보고에서 미국 도시의 여러 프로빈스와 LA 미세조각 선택 문제를 확인했으나 공개 실화면/정확경계/현재버전 전수검증은 하지 않았다. 출처 https://www.reddit.com/r/TheFireRisesMod/comments/1ijxsvd/yall_got_any_provinces/ (열람 2026-10-07), 공식모드 페이지 https://steamcommunity.com/sharedfiles/filedetails/?id=3350890356 는모드식별용이며 도시분할세부의증명으로사용하지않는다. 공개 글의 게임수치/전투효과는 인수하지 않는다. 원작/모드 경계 파일·색상/ID·트레이싱/맵에셋 사용 없이 독립 자료로 생성, 기존 sameWORLD 단일소유/원증거 보존/새source 독립검수/noCUA·focus 유지.


### 사용자 해상 프로빈스 명시

사용자 원문: "그리고 바다도 프로빈스라던지를 떼야 하는거 알지?"

바다도 육지와 구분되는 kind=sea의 고유 ID·영역·경계·인접·선택 단위를 갖는 해상 프로빈스로 분할한다. 바다는 시각배경 한덩어리로 두지 않는다. 호수는 별도 kind=lake 분류를 유지한다. 해상 프로빈스와 여러 프로빈스를 묶는 상위 해역/전략해역은 서로 다른 단위이며 사용자가 상위해역규격까지 확정했다고 확대하지 않는다.

연안·해협·섬 주변은 실제 해안/좁은 수로 형태에 맞춰 세밀하고 연결이 유지되도록, 넓은 대양은 상대적으로 넓게 구획하는 방향을 기존 담당에게 인계한다. 육해경계 혼입·단절/해협누락·섬폐쇄·dateline경계·픽셀 ID/hover/select/인접·동일입력재생성 및 성능을 검수한다. 임의로 해상/호수 미세조각을 늘려20k~30k 수치를 채우지 않는다. 육지/바다/호수 개수와 미세조각·면적분포를 분리해 보고하고 실제 해상 경계·선택을 같은축척 화면으로 제출한다.

현재 ab64 외관 후보는 sea6080/lake4053이나 sea1pixel2369/lake1pixel1492가 포함되므로 해상분할 품질 완료를 개수만으로 선언하지 않는다. 이는 지리/렌더링 요구이며 함대 이동·해상전투·보급·호송·항만게임효과를 새로 구현하거나 완료로기록하는 지시가 아니다. 기존 WORLD 단일소유/독립자료·원증거보존·새source검수/noCUA·focus 유지.


### 사용자 ProvGen v1.0 알고리즘 검토 지시

사용자 직접 요청: https://www.mediafire.com/file/x5kmhxykqt8qf85/ProvGen+v1.0.zip 을 보고 알고리즘을 파악한다. CEO가 실제 ZIP의 README/Settings를 읽고 원본 SHA와 문서 원문을 research/provgen/에 보존했다. 상세 검토: research/provgen/ALGORITHM_REVIEW.md. EXE/DLL 실행·디컴파일·포함 BMP 열람/추출/제작 입력 사용은 하지 않았다. 원작 자료 재사용 승인으로 확대하지 않는다.

확인된 생성 제어: 같은 크기의 LandMap(육지/바다/호수), ProvDenseMap(육지 크기: 검정 최소/흰색 최대), TerrainMap(지형 분류/도시 점), Settings(육해 최소·최대 크기/산악 범위 폭). 해상은 밀도 이미지 대신 해안 거리에 기반한다. 구체적인 거리→크기 방향·수식과 크기 단위는 미확인이다. 도시 점에 가장 가까운 프로빈스 전체를 urban으로 지정하며 시가지 경계 분리는 설명되지 않는다. 기존 도시 footprint 분리 요구를 이 점 태깅 방식으로 대체하지 않는다.

기존 WORLD 담당 단일 소유로 현재 생성기와 대조한다. 가역적인 검토 추천안: 모더가 편집할 육지 회색조 밀도 입력, 독립 원천 해안 거리와 해협 보존을 이용한 별도 해상 밀도 제어, 독립 DEM/능선/강에 따른 경계 제어. 도시 footprint는 별도 구획 입력으로 유지한다. 이는 기술 검토 후보이고 정식 데이터 포맷/D·OPEN 확정이나 게임 수치 추가가 아니다. README에는 내부 시드 배치/경계 확장/조각 병합/반복 결정론이 없고 ZIP에는 소스·LICENSE가 없으므로 특정 Voronoi/watershed/Poisson/Lloyd 알고리즘 또는 재사용 권한을 확인했다고 쓰지 않는다. 예시 설정값/도구 팔레트를 제품 규칙으로 복사하지 않는다.

전세계 20k~30k 및 도시/해상·호수 분리, 실제 작은 섬/수로 보존, 생성 미세조각 품질 검토, 원 후보·실패 증거와 최종 독립 검증, 지도/HUD 외관 우선/noCUA·사용자 focus 금지는 그대로 유지한다. CEO가 제품 코드나 구현/검증 채팅을 직접 다루지 않는다.


### WORLD P05-3 실제 생성 시간 실패 후속

새 exact446540f 독립 P05-3에서 실제 두 번째 bounded bake PID11996은 180.078초에 time budget exceeded/native1로 종료됐다. 첫 실행 PID14184는174.156초/native0다. 원180초/3GiB 한도를 올리거나 반올림·재시도 성공으로 원실패를 없애지 않는다. 원 검증은 남은 검사를 끝내고 원 최종 FAIL/PASS 리포트·full/raw 불변성·실제 종료를 먼저 보존한다.

유효 최종 검증이 확인되면 기존 WORLD 담당 단일 소유의 가역적인 좁은 P06으로 생성 성능을 개선한다. 지도 목표20k30k·도시footprint·해상/호수·원천 작은 섬/수로·지리 분할 품질과 ID/경계·결정론 계약은 유지한다. 그래프/해안 해상도·예산·검사·골든을 낮추거나 완료 산출물 재사용으로 fresh bake를 가장하지 않는다. 가능하면 기존 기하/index/ID·인접 산출 bytes를 보존하는 계산·할당 비용 개선을 우선하며 변경 필요성이 있으면 별도로 기록한다. 새로운 실제 소스의 독립 fresh pair와 같은 guard·전체 회귀·동일입력 재현성·실화면을 검수한다. CEO 제품/구현·검증 앱 직접 생성은 없다.

현재 Chrome/Firefox/WebKit 각 단일41검사 PASS는 전체 P05 성능 PASS가 아니다. 두 번째 생성 실패와 페이지 검사 결과를 구분한다. 현재 새 검증 앱은 실행 중이므로 수정·재배정으로 불변성을 흔들거나 중복 WP/RUN을 만들지 않는다.


### 사용자 실제 공간 확보 확인 — 2026-10-07T22:30:09.654665+09:00

사용자 원문: E 공간 다시 확보. CEO actual E free 441672118272B 약441.7GB를조회해공간만의보류해제. 같은WORLD owner 최종비교/새이름봉인후 actualfinal·exactclean source·실제종료를인수하고 새독립P054를원계약으로이어간다. 이전OSError28/0byte준비파일/캐시삭제policy거부는보존·덮어쓰지않음·우회없음. 원F05/180s3GiB/지리/도시해상/HUD외관/골든/noCUAfocus·기존결정전부유지. 공간회복은검증PASS·통합WP/게이트완료가아님.


### REQUEST-0010 A-CEO-r1 잠정 채택 — 2026-10-08T03:24:25.553559+09:00

# REQUEST-0010 CEO 검토 — A-CEO-r1 잠정 채택

대상 원본: 11724bytes / SHA256 ec6c49cb852fe0a228ce94c5fc4e41d5f2589458f51e5476bab581622e869cee. 검토 근거: docs/04 §2, 01 §4.2·4.3 및 해당 REQ, 02 DR-01/09·§6.2/6.3, 현재 oh_core Fx/Qty, oh_sim step/world/formula/ledger/trigger 실제 타입. 제품/공유 추적 파일은 CEO가 수정하지 않았다.

판정: 추천 A를 아래 수정과 경계 명시를 포함한 **A-CEO-r1로 잠정 채택**한다. 사용자 답/확정이 아니다. 새 경제 정의가 있는 실행에 한정하며 기존 승인 범위 안의 가역적 신규 상태다. 기존 D/OPEN, 원 M0/M1/None/v1~v4, 클린룸·권한 설정·공개/비용/삭제 범위를 바꾸지 않는다. 원 A의 합성 예제는 콘텐츠 승인이나 실제 검증 결과가 아니다. W1 전체 검증·통합 조건을 유지하며, 이 채택만으로 W2 착수/WP/REQ 완료를 기록하지 않는다.

## 1. 일일 순서 수정

A의 `PC 지급 → 경제`는 기존 명세와 실제 step의 순서에 충돌하므로 채택하지 않는다. 02 §6.2와 현재 Phase 순서를 유지한다: Commands → 시간/이동/전투/통제 → 날짜 경계에서 Supply → Economy → Production → Construction → ManpowerTrainingReinforcement → Research → Politics(PC 지급) → AgendaAndDecisions → Events → Diplomacy → AI → Ledger → 기존 종료 checkpoint → Snapshot. 현재 미구현 phase의 행동을 성공으로 만들지 않는다.

PC는 정상 날짜 경계의 Politics에서 한 번만 지급한다. 생성/Paused pump/조회/같은 날짜 복원에는 지급하지 않는다. 날짜 경계 틱의 Commands에서 실행되는 법령 변경은 그 명령 직전의 PC로 비용을 검사한다. 아직 Politics에서 지급하지 않은 PC를 미리 쓰게 하지 않는다. 이후 해당 날짜 지급은 새 법령/권위 상태로 진행한다. PC 지급 또는 뒤 phase 오류는 그 틱 state/queue/clock/RNG 전체 commit을 하지 않는다. 예: 경계 전 PC0·일일3·법령비용3 명령은 PC 부족 의미 오류로 소비되고 법령 불변, 정상 phase 뒤 PC3; phase 자체가 실패하면 그 소비까지 rollback한다. 전날 Pause/재개 반복으로 지급하지 않는다.

## 2. 산술·정의·인력 경계

소유 주 산출, 소비재 하한 공식, 네 비율 정확합1과 소비재 잔여 귀속, 자원 일일 흐름/수출 계산 한정, 건설 원IC 잔여/올림·초과폐기, committed/reserved 수명, 법령 변경 원자성은 A대로 채택한다. 기존 formula는 fixed checked_mul의 내림과 checked add를 사용한다. 비율/계수 Fx, 누적량 Qty, 정수 인력 i64라는 DR-01을 실제 필드별 단위·bits·허용 최대·변환/곱셈 순서 표와 ADR로 인수한다. 기존 Fx 원장에 Qty를 조용히 좁혀 넣지 않는다. 새 수량 원장을 필요하면 별도로 두고 실제 적용값과 같은 raw bits를 증명한다. 조회값을 다음 일일 산출과 혼동하지 않도록 계산 tick/주 기여 스냅샷을 노출한다.

데이터 비용은 양수, 건설 cap/슬롯 사용량/인프라 보정은 음수 거부·범위 검사다. cap0 또는 보정0이면 해당 프로젝트 배정/소비/진행0으로 skip하고 뒤 유효 프로젝트를 계속한다. 0으로 나누거나 원IC만 소모하지 않는다. 완료 양수 비용과 원IC 최소단위 ceil 경계를 독립 정수 기대값으로 검사한다. 인구합/committed+reserved/배분/보정은 checked overflow를 전체 오류로 처리하며, PC 상한 제한은 유효 입력의 덧셈이 중간 오버플로 없이 상한에 도달하도록 checked/wide 계산한다. 데이터 누락을0 또는 임의 법령으로 대체하지 않는다.

인력 예약/확정/소비/반환은 권위 내부 API이며 W2에 소비자가 없다는 이유로 플레이어에게 임의 반환/인력 생성 명령을 노출하지 않는다. 실제 consumer가 생기면 소유/프로젝트 참조·중복 확정/취소·타국 예약 변경 거부를 인수한다. 초기 capacity 미만/초과 committed+reserved 둘 다 명시 입력으로 검사하고 capacity 감소는 기존 값을 삭제하지 않는다.

## 3. 건설 예약과 소유권 경계 명시

W2 프로젝트는 한 (주ID, 건물ID)의 **현재 수준+1 한 단계**를 목표로 한다. 같은 국가의 같은 대상 건물에 활성/대기 프로젝트가 이미 있으면 다른 목표 단계로 우회 enqueue하지 못한다. 다음 단계는 이전 단계 완료 뒤 새 명시 enqueue로 예약한다. 단계별 슬롯 소비는 데이터이고 현재 건물의 실제 점유+현재 소유자가 예약한 증가량이 슬롯 상한을 넘으면 enqueue를 거부한다. 비용0/이미 완료 목표/비연속 단계를 임의 자동완료하지 않는다.

소유권을 잃은 프로젝트는 국가 queue·누적 진행도·목표·예약 기록을 보존하되 배정0/사유 `소유권 없음`으로 skip한다. 이 휴면 예약은 새 소유자의 활성 슬롯 점유로 계산하지 않는다. 회복 시 현재 수준/목표/슬롯/정의를 다시 검사한다. 다른 소유자의 건설로 목표가 이미 완료되거나 슬롯이 부족하면 자동완료/보상/삭제/단계상승하지 않고 배정0·사유 있는 휴면 상태로 남겨 명시 취소를 허용한다. 유효한 경우만 원 진행도에서 재개한다. 뒤 유효 프로젝트를 막지 않는다. 신규 소유권 변경 명령/점령 수익 자체는 W2 지원으로 추가하지 않는다.

예: A의 level0→1 진행2 프로젝트가 소유권 상실 시 보존/0배정, B 소유 동안 활성 슬롯은 B의 실제건물/예약 기준; B가 level1을 완성하고 A가 회복하면 A의 old 목표1 프로젝트는 target-conflict로 휴면·진행2보존·환불없음, 명시 취소 전까지 자동 level2를 만들지 않는다. 소유 회복/valid 슬롯의 경우에는 기존 진행도에서 재개한다. 보정0 선행 프로젝트는 뒤 cap>0·보정>0 프로젝트 배정을 막지 않는다.

## 4. 명령·효과·후속 consumer와 호환

law/category/step/PC/조건 AST 참조는 데이터. 조건은 해당 명령 직전 권위 상태에서 평가하고 동일법령/부족PC/하한실패/overflow는 해당 transaction 전체 거부다. multi-effect가 앞에서 flags/PC/법령/안정도를 바꾼 뒤 뒤 효과가 실패하면 앞 변경도 rollback한다. 기존 Command 의미 오류 소비와 whole-phase rollback을 그대로 구분한다.

지원되지 않는 조건/효과는 값0인 경우까지 기존 capability 오류를 유지한다. A의 `미지원 nonzero 효과` 문구가 zero이면 성공이라는 예외를 만들지 않게 수정한다. 실제 정치 조건/법령/산업 점수 adapter만 연결하며 안정도 생산/항복·동원도 군사 효과·인력 훈련/보충·자원 부족 생산·시장 consumer는 담당 후속 WP와 검증 기대를 추적한다. producer 자체 PASS로 NAT03/ECO04/ECO07 전체를 완료 표시하지 않는다.

새 상태·예약/휴면 사유·누적 진행·현재 법령/PC·정의 identity·계산 tick/파생 원장·pending/future queue를 DTO/canonical/hash/save/wire/repro에 같은 수명으로 보존한다. 기존 None/fixture/bytes/hash를 새0상태로 바꾸지 않는다. 새 pack 추가로 전체 content_hash가 달라지는 것은 원 frozen fixture와 별도로 검증한다. 신규 저장 읽기 경로와 명시적 version/presence 거부를 설계하되 과거저장 파괴/migration/삭제를 이 채택으로 허용하지 않는다.

## 오케스트레이터 후속

원 REQUEST 본문/SHA를 증거로 보존한 뒤 위 수정판을 01의 **CEO 잠정** 규칙·02 타입/phase·REQUEST/검증 예제에 반영하고 check_docs를 실행한다. `사용자 추가 답 없음`을 유지하고 CEO 채택을 별도 기록한다. 실제 WP14-schema 필드표/소유파일·명령/phase 경계·기존 저장형·WP23 신규 입력 인수 계약을 먼저 구체화한다. 설명만으로 완료 판정하지 않으며 새 구현·독립 검증·동일main CI를 요구한다. 역할 분리/3~4 이하 구현/noCUA·사용자 focus 보호/지도·HUD 외관 우선 유지. 사용자 전용 결정 없음; 소비자 최종 미정 공식은 이 추천안으로 자동 생성하지 않는다.



### WP14의 고정 성능 입력 기술 인수 — CEO 확인

동일 immutable prior pack을 두 실제 library에 입력하는 기술안을 기존 REQ-PERF-03 범위에서 채택한다. 새로운 게임 규칙·D/OPEN 확정·설정/CI 한도 변경이 아니다. WP23 새 콘텐츠 때문에 current 팩 전체와 prior 팩 전체가 달라지는 것과, 실제 측정 입력이 같은 것의 경계를 분리한다. W1 전체의 exact main CI/원증거 인수 전 W2 착수는 하지 않는다.

- 고정 prior81deb의 원 Git tree에서 가져온 **팩 전체**를 같은 입력으로 사용한다. m1 파일만 선택하거나 새current 팩을 편집해 prior처럼 만들지 않는다. 같은 pack path로 두 executable에 넘기거나, 별도 복사라면 정렬된 전체 상대경로/byte길이/SHA/실제packhash가 완전히 같아야 한다. extra/missing 파일·symlink/reparse·참조 이탈을 거부한다. 입력은 생성 후 immutable이며 load/warmup/측정 전후 identity를 다시 검사한다. 이 변경으로 기존 입력 차이/손상 guard를 삭제하지 않는다.
- baseline source/build는 계속81deb이고 current source/build는 새 실제 커밋이다. Cargo metadata의 path dependency/원lock·registry audit와 두 binary provenance를 보존한다. current를 prior library/binary로 대체하지 않는다. 수정자는 bench/run.py 및 관련 검사·README·ADR 소유에 한정하며 driver/policy/워크플로 설정을 조용히 바꾸지 않는다.
- 원driver/release/default features/m1/seed1000/240000steps/warm2400/two pairs/>15%/native240s/build1200s 및 동일 runner/native성공/fullDTO/canonical/hash/끝난 여부·미래queue 계약 유지. None/oldm1 입력을 새경제0상태로 바꿔 canonical/save/hash 호환을 깨거나 force/callerpurpose로 통과시키지 않는다. 신규경제 정의가 없는 원 m1도 새library가 정상 지원해야 한다.
- 실질적인 red→green 검사는 current pack에 새m2 파일이 추가됐어도 두 library의 **원동일입력**을 쓰는지, 고정 입력extra/missing/mutation·registry변경·current/baseline linkage 뒤바뀜·잘못된exit/state/hash·15% 양쌍 경계를 잡는지 검사한다. mock/metadata만으로 Linux 측정PASS를 쓰지 않는다. 신규콘텐츠 자체의 strictvalidate/native/query/save/repro·경제consumer 검증도 별도로 유지한다. 이 고정m1벤치는 신규경제가 활성화된 대규모 부하 성능을 증명하지 않으며 후속 M2/M3 부하·UI성능 요구를 면제하지 않는다.
- 실제 performance.yml은 workflow_dispatch 입력필드가 없고 checkout이 실행 ref를 사용한다. default main에 존재하는 기존 workflow를 **승인한 exact 후보 branch/ref로 한 번 dispatch**하고, ref가 가리키는 SHA를 직전/실제API·job runtime/env/artifact 신원에서 다시 일치 확인한다. 새 source_ref 입력이나 CI branch조건 변경을 전제하지 않는다. source workflow 검사와 통합 후 exact main7CI를 구분한다. 실패를 skip/한도증가/묵시적반복으로 지우지 않는다.

이는 향후 WP14 담당 인수 권한이며 현재 WP25 제품 변경이나 W1/REQ 완료 선언이 아니다. schema/ADR·범위파일/실제producer 입력 계약을 먼저 작성하고 새source의 독립검증·원증거·main판정으로 확인한다.

검토 시각: 2026-10-08T04:16:22.098930+09:00
