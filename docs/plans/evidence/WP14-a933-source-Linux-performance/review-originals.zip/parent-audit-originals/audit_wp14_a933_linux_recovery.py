import pathlib,json,hashlib,zipfile,stat,subprocess,tomllib,importlib.util,datetime
r=pathlib.Path('E:/openhoi');source=r/'.orchestrator/evidence/WP14-a933-Linux-range-download';d=r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit-recovery';d.mkdir(exist_ok=False)
head='a9333419de89caf3ba95da5097ea2e3d0fa5f694';rid=37695537881;aid=11514894569
download=json.loads((source/'download-custody.json').read_text(encoding='utf-8'));assert download['head']==head and download['artifact_id']==aid and download['download_sha_verified']
def gh(name,endpoint):
 q=subprocess.run(['gh','api','repos/peppone-choi/OpenHOI4'+endpoint],cwd=r,capture_output=True);(d/(name+'.stdout')).write_bytes(q.stdout);(d/(name+'.stderr')).write_bytes(q.stderr)
 (d/(name+'.command.json')).write_text(json.dumps(dict(argv=['gh','api','repos/peppone-choi/OpenHOI4'+endpoint],cwd=str(r),native_exit=q.returncode,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8');q.check_returncode();return json.loads(q.stdout)
run=gh('run',f'/actions/runs/{rid}');jobs=gh('jobs',f'/actions/runs/{rid}/jobs?per_page=100');artifact=gh('artifact',f'/actions/artifacts/{aid}')
assert run['head_sha']==head and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert jobs['total_count']==1 and all(j['conclusion']=='success' for j in jobs['jobs'])
job=jobs['jobs'][0];assert any(s['name']=='Same Linux runner fixed baseline and current native library measurement' and s['conclusion']=='success' for s in job['steps'])
zp=source/'performance-linux.zip';h=hashlib.sha256()
with zp.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
assert artifact['workflow_run']['head_sha']==head and artifact['digest']=='sha256:'+h.hexdigest() and h.hexdigest()==download['sha256']
entries=[];small={}
with zipfile.ZipFile(zp) as z:
 infos=z.infolist();assert len(infos)==len({i.filename for i in infos})
 for i in infos:
  name=i.filename;pp=pathlib.PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts and ':' not in name and '\\' not in name and '\x00' not in name and not stat.S_ISLNK(i.external_attr>>16)
  if i.is_dir():continue
  h1=hashlib.sha256();size=0
  with z.open(i) as f:
   for b in iter(lambda:f.read(1024*1024),b''):h1.update(b);size+=len(b)
  assert size==i.file_size;entries.append(dict(path=name,bytes=size,sha256=h1.hexdigest(),CRC_checked=True))
  if name.startswith('performance/') and size<2_000_000:
   data=z.read(i);small[name]=data;p=d/'selected'/pp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def get(name):return small['performance/'+name]
env=json.loads(get('environment.json'));comparison=json.loads(get('comparison.json'))
git=lambda path:subprocess.check_output(['git','-C',str(r),'show',head+':'+path])
policy=tomllib.loads(git('bench/defines.toml').decode('utf-8'))
assert env['system']=='Linux' and env['gate_evidence'] is True and env['current_sha']==head and env['current_dirty']=='' and env['baseline_sha']==policy['baseline_sha']=='81deb803944cf6297f13b3f14ca454774cea141b'
assert env['policy']==policy and policy['steps']==240000 and policy['warmup_steps']==2400 and policy['pairs']==2 and policy['threshold_percent']==15 and policy['seed']==1000 and policy['scenario']=='m1' and policy['native_timeout_seconds']==240 and policy['build_timeout_seconds']==1200
driver=git('bench/driver.rs');assert env['driver_sha256']==hashlib.sha256(driver).hexdigest()
for label in ('baseline','current'):
 assert get(label+'-driver/src/main.rs')==driver
 for name in ('fetch','metadata','build','warmup','0','1'):
  receipt=json.loads(get(label+'-'+name+'.json'));assert receipt['native_exit']==0
 assert '--locked' in json.loads(get(label+'-fetch.json'))['command'] and '--offline' in json.loads(get(label+'-metadata.json'))['command'] and '--locked' in json.loads(get(label+'-build.json'))['command']
assert get('baseline-pack.json')==get('current-pack.json')
tar=[x for x in entries if x['path']=='performance/baseline-archive.stdout'];assert len(tar)==1 and tar[0]['bytes']==2006323200 and tar[0]['sha256']=='8ee7e2265bd41fbba2ffa76f8e25d112fd17fef4059428bc858957464dd756e1'
samples={label:[json.loads(get(f'{label}-{i}.stdout')) for i in (0,1)] for label in ('baseline','current')}
local_module=r/'.orchestrator/wt/WP-14-M2-r2/bench/compare.py';blob=git('bench/compare.py');assert local_module.read_bytes().replace(b'\r\n',b'\n')==blob
module=d/'exact-source-compare.py';module.write_bytes(blob);spec=importlib.util.spec_from_file_location('actual_wp14_compare',module);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert module.read_bytes()==blob and m.compare_samples(samples['baseline'],samples['current'],policy) is False
assert comparison==dict(regression=False,gate_evidence=True,baseline_ns=[x['elapsed_ns'] for x in samples['baseline']],current_ns=[x['elapsed_ns'] for x in samples['current']],hash=samples['baseline'][0]['hash'])

measurement=json.loads(get('measurement-pack.json')); frozen=json.loads(get('baseline-pack.json'))
assert measurement['source_sha']==env['measurement_pack_source_sha']==policy['baseline_sha']
assert measurement['archive_sha256']==tar[0]['sha256'] and measurement['pack']==frozen
assert env['measurement_pack_path']==frozen['path'] and '/baseline-source/data/packs/testland' in frozen['path']
prior=policy['baseline_sha']
paths=subprocess.check_output(['git','-C',str(r),'ls-tree','-r','--name-only',prior,'--',policy['pack']]).decode().splitlines()
prefix=policy['pack']+'/'
expected=[]; directories=set()
for path in paths:
 data=subprocess.check_output(['git','-C',str(r),'show',prior+':'+path]); relative=path[len(prefix):]
 expected.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 directories.update(p.as_posix() for p in pathlib.PurePosixPath(relative).parents if p.as_posix()!='.')
assert frozen['files']==expected and frozen['directories']==sorted(directories)
assert len(expected)==21
assert env['profile']=='release' and env['features']=='default library features' and all(x is None for x in env['environment'].values())
remote_root=json.loads(get('current-head.json'))['cwd']
assert get('current-head.stdout').decode().strip()==head and not get('current-diff.stdout').strip()
assert env['measurement_pack_hash']=='3bde1bed90d3734e'
for label,source_sha,tree in [('baseline',prior,remote_root+'/target/performance/baseline-source'),('current',head,remote_root)]:
 manifest=tomllib.loads(get(label+'-driver/Cargo.toml').decode())
 for name in ('oh_cli','oh_core','oh_save'):
  assert manifest['dependencies'][name]=={'path':tree+'/crates/'+name}
 assert manifest['dependencies']['serde_json']=='=1.0.151'
 metadata=json.loads(get(label+'-metadata.stdout'))
 for name in ('oh_cli','oh_core','oh_save'):
  linked=[p for p in metadata['packages'] if p['name']==name]
  assert len(linked)==1 and linked[0]['source'] is None and linked[0]['manifest_path']==tree+'/crates/'+name+'/Cargo.toml'
 for p in metadata['packages']:
  if p['source'] is None: assert p['manifest_path'].startswith(tree+'/')
 source_lock=tomllib.loads(subprocess.check_output(['git','-C',str(r),'show',source_sha+':Cargo.lock']).decode())
 original={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in source_lock['package'] if p.get('source')}
 resolved=tomllib.loads(get(label+'-driver/Cargo.lock').decode())['package']
 for p in resolved:
  if p.get('source'): assert p.get('checksum') and original.get((p['name'],p['version'],p['source']))==p['checksum']
 build=json.loads(get(label+'-build.json'))['command']
 assert '--release' in build and '--locked' in build
 for name,steps in [('warmup',policy['warmup_steps']),('0',policy['steps']),('1',policy['steps'])]:
  receipt=json.loads(get(label+'-'+name+'.json')); argv=receipt['command']
  assert argv==[remote_root+'/target/performance/'+label+'-driver/target/release/oh_bench_driver',frozen['path'],policy['scenario'],str(policy['seed']),str(steps)]
  sample=json.loads(get(label+'-'+name+'.stdout')); m.validate_sample(sample,{**policy,'steps':steps})
  assert sample['pack_hash']==sample['pack_hash_after']==env['measurement_pack_hash']
 for key in ('dto','canonical_hex','hash','pack_hash','pack_hash_after'):
  assert json.loads(get('baseline-warmup.stdout'))[key]==json.loads(get('current-warmup.stdout'))[key]
assert env['baseline_binary_sha256']!=env['current_binary_sha256']
print('Full artifact member CRC/SHA and fixed prior pack/native hash/driver/linkage/registry/two pairs verified',flush=True)

record=dict(head=head,run_id=rid,run_attempt=run['run_attempt'],job_id=job['id'],artifact_id=aid,artifact_path=zp.as_posix(),artifact_bytes=zp.stat().st_size,artifact_sha256=download['sha256'],members=entries,mismatches=0,actual_linux_benchmark_verified=True,policy=policy,environment=env,comparison=comparison,raw_samples_full_DTO_canonical_hash_equal=True,baseline_TAR_raw_equal_to_original_exact_prior=True,download_only_range_recovery_not_measurement_retry=True, fixed_prior_pack_files=expected, fixed_prior_pack_directories=sorted(directories), native_pack_hash_before_after_bound=True, same_new_driver_explicit_CEO_exception=True, separate_library_linkage_and_registry_versions_verified=True, remote_binaries_not_uploaded_direct_physical_check=False)
(d/'actual-Linux-parent-proof.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in record.items() if k not in ('members','environment','policy')}))
