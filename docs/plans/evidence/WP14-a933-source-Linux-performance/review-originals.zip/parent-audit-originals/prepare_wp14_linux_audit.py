import pathlib, ast
r=pathlib.Path('E:/openhoi')
old=(r/'.orchestrator/audit_wp25_2b5ca_linux.py').read_text(encoding='utf-8')
s=old.replace('WP-25-2b5ca','WP14-a933').replace('2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab','a9333419de89caf3ba95da5097ea2e3d0fa5f694').replace('37672486232','37695537881').replace('11504339978','11514894569').replace('WP-25-M2-r2/bench/compare.py','WP-14-M2-r2/bench/compare.py').replace('actual_wp25_compare','actual_wp14_compare')
extra='''
measurement=json.loads(get('measurement-pack.json')); frozen=json.loads(get('baseline-pack.json'))
assert measurement['source_sha']==env['measurement_pack_source_sha']==policy['baseline_sha']
assert measurement['archive_sha256']==tar[0]['sha256'] and measurement['pack']==frozen
assert env['measurement_pack_path']==frozen['path'] and '/baseline-source/data/packs/testland' in frozen['path']
prior=policy['baseline_sha']
paths=subprocess.check_output(['git','-C',str(r),'ls-tree','-r','--name-only',prior,'--',policy['pack']]).decode().splitlines()
prefix=policy['pack']+'/'
expected=[]; directories=set()
for path in paths:
 data=subprocess.check_output(['git','-C',str(r),'show',prior+':'+path]); relative=path[len(prefix):]
 expected.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 directories.update(p.as_posix() for p in pathlib.PurePosixPath(relative).parents if p.as_posix()!='.')
assert frozen['files']==expected and frozen['directories']==sorted(directories)
assert len(expected)==21
assert env['profile']=='release' and env['features']=='default library features' and all(x is None for x in env['environment'].values())
remote_root=json.loads(get('current-head.json'))['cwd']
assert get('current-head.stdout').decode().strip()==head and not get('current-diff.stdout').strip()
assert env['measurement_pack_hash']=='3bde1bed90d3734e'
for label,source_sha,tree in [('baseline',prior,remote_root+'/target/performance/baseline-source'),('current',head,remote_root)]:
 manifest=tomllib.loads(get(label+'-driver/Cargo.toml').decode())
 for name in ('oh_cli','oh_core','oh_save'):
  assert manifest['dependencies'][name]=={'path':tree+'/crates/'+name}
 assert manifest['dependencies']['serde_json']=='=1.0.151'
 metadata=json.loads(get(label+'-metadata.stdout'))
 for name in ('oh_cli','oh_core','oh_save'):
  linked=[p for p in metadata['packages'] if p['name']==name]
  assert len(linked)==1 and linked[0]['source'] is None and linked[0]['manifest_path']==tree+'/crates/'+name+'/Cargo.toml'
 for p in metadata['packages']:
  if p['source'] is None: assert p['manifest_path'].startswith(tree+'/')
 source_lock=tomllib.loads(subprocess.check_output(['git','-C',str(r),'show',source_sha+':Cargo.lock']).decode())
 original={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in source_lock['package'] if p.get('source')}
 resolved=tomllib.loads(get(label+'-driver/Cargo.lock').decode())['package']
 for p in resolved:
  if p.get('source'): assert p.get('checksum') and original.get((p['name'],p['version'],p['source']))==p['checksum']
 build=json.loads(get(label+'-build.json'))['command']
 assert '--release' in build and '--locked' in build
 for name,steps in [('warmup',policy['warmup_steps']),('0',policy['steps']),('1',policy['steps'])]:
  receipt=json.loads(get(label+'-'+name+'.json')); argv=receipt['command']
  assert argv==[remote_root+'/target/performance/'+label+'-driver/target/release/oh_bench_driver',frozen['path'],policy['scenario'],str(policy['seed']),str(steps)]
  sample=json.loads(get(label+'-'+name+'.stdout')); m.validate_sample(sample,{**policy,'steps':steps})
  assert sample['pack_hash']==sample['pack_hash_after']==env['measurement_pack_hash']
 for key in ('dto','canonical_hex','hash','pack_hash','pack_hash_after'):
  assert json.loads(get('baseline-warmup.stdout'))[key]==json.loads(get('current-warmup.stdout'))[key]
assert env['baseline_binary_sha256']!=env['current_binary_sha256']
print('Full artifact member CRC/SHA and fixed prior pack/native hash/driver/linkage/registry/two pairs verified',flush=True)
'''
assert s.count('record=dict(')==1
s=s.replace('record=dict(',extra+'\nrecord=dict(')
s=s.replace('download_only_range_recovery_not_measurement_retry=True)', 'download_only_range_recovery_not_measurement_retry=True, fixed_prior_pack_files=expected, fixed_prior_pack_directories=sorted(directories), native_pack_hash_before_after_bound=True, same_new_driver_explicit_CEO_exception=True, separate_library_linkage_and_registry_versions_verified=True, remote_binaries_not_uploaded_direct_physical_check=False)')
ast.parse(s)
p=r/'.orchestrator/audit_wp14_a933_linux.py'
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(p)
