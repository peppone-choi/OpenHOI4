import pathlib,ast,json,hashlib
r=pathlib.Path('E:/openhoi'); p=r/'.orchestrator/audit_wp14_a933_linux.py'
s=p.read_text(encoding='utf-8').replace("d=r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit'", "d=r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit-recovery'")
old="module=r/'.orchestrator/wt/WP-14-M2-r2/bench/compare.py';spec=importlib.util.spec_from_file_location('actual_wp14_compare',module);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\nassert module.read_bytes()==git('bench/compare.py') and m.compare_samples(samples['baseline'],samples['current'],policy) is False"
new="local_module=r/'.orchestrator/wt/WP-14-M2-r2/bench/compare.py';blob=git('bench/compare.py');assert local_module.read_bytes().replace(b'\\r\\n',b'\\n')==blob\nmodule=d/'exact-source-compare.py';module.write_bytes(blob);spec=importlib.util.spec_from_file_location('actual_wp14_compare',module);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\nassert module.read_bytes()==blob and m.compare_samples(samples['baseline'],samples['current'],policy) is False"
assert s.count(old)==1;s=s.replace(old,new);ast.parse(s)
out=r/'.orchestrator/audit_wp14_a933_linux_recovery.py'
with out.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
receipt=dict(original_script=str(p),original_script_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_native_exit=1,original_log=str(r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit-native.log'),cause='local Git checkout CRLF bytes differ from LF Git blob; compare actual result false; execute preserved exact source Git blob in fresh audit namespace',source_or_policy_changed=False)
(r/'.orchestrator/evidence/WP14-a933-Linux-audit-recovery-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(out)
