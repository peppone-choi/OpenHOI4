import pathlib,ast,json
r=pathlib.Path('E:/openhoi'); old=r/'.orchestrator/audit_wp14_a933_linux_recovery.py'
s=old.read_text(encoding='utf-8').replace("d=r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit-recovery'", "d=r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit-recovery2'")
a="if p['source'] is None: assert p['manifest_path'].startswith(tree+'/')"
b="if p['source'] is None: assert p['manifest_path'].startswith(tree+'/') or (p['name']=='oh_bench_driver' and p['manifest_path']==remote_root+'/target/performance/'+label+'-driver/Cargo.toml')"
assert s.count(a)==1;s=s.replace(a,b);ast.parse(s)
with (r/'.orchestrator/audit_wp14_a933_linux_recovery2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
(r/'.orchestrator/evidence/WP14-a933-Linux-audit-recovery2-preparation.json').write_text(json.dumps(dict(original_native_exit=1,original_script=str(old),original_log=str(r/'.orchestrator/evidence/WP14-a933-Linux-parent-audit-recovery-native.log'),cause='parent audit omitted the separately built external driver manifest from allowed source-less Cargo packages; restore exact existing run.py external-root check',source_or_policy_changed=False),indent=2)+'\n',encoding='utf-8')
