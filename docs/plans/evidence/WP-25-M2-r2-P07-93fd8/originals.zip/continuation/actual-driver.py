import pathlib,json,subprocess,os,sys,re,hashlib,datetime
r=pathlib.Path('E:/openhoi');head='93fd8c5661bec3c153e6d0cd855e79e5c35f314b';old=r/'.orchestrator/evidence/WP-25-M2-r2-P07-93fd8';out=r/'.orchestrator/evidence/WP-25-M2-r2-P07-93fd8-continuation';out.mkdir(exist_ok=False)
prior=json.loads((old/'commands.json').read_text(encoding='utf-8'));assert len(prior)==42 and all(x['passed'] for x in prior[:-1]) and prior[-1]['name']=='wp25-native-repro' and prior[-1]['native_exit']==1
assert 'native evidence must remain inside this worktree target/evidence' in (old/'wp25-native-repro.stderr').read_text(encoding='utf-8')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head and not subprocess.check_output(['git','--no-optional-locks','status','--porcelain=v1'],cwd=r).strip()
native=r/'target/evidence/WP-25-M2-r2-P07-93fd8-native';assert not native.exists()
env=dict(os.environ);env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['PYTHONUTF8']='1';env['GIT_OPTIONAL_LOCKS']='0';py=sys.executable;cargo='C:/Users/user/.cargo/bin/cargo.exe'
commands=[('wp25-native-repro',[py,'-X','utf8','crates/oh_cli/tests/repro_native.py','--evidence-root',str(native)],0),('wp25-comparison-boundaries',[py,'-X','utf8','-m','unittest','discover','-s','bench','-p','test_compare.py','-v'],0),('wp25-metadata-guards',[py,'-X','utf8','-m','unittest','discover','-s','bench','-p','test_metadata.py','-v'],0)]
for i in (1,2):commands.append((f'wp25-native-bench-{i}',[cargo,'run','-p','oh_cli','--locked','--','bench','--pack','data/packs/testland','--scenario','m1','--seed','1000','--steps','240000'],0))
rows=[];outputs={x['name']:(old/(x['name']+'.stdout')).read_text(encoding='utf-8') for x in prior[:-1]};passed=True
for name,cmd,expected in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();q=subprocess.run(cmd,cwd=r,env=env,capture_output=True)
 (out/(name+'.stdout')).write_bytes(q.stdout);(out/(name+'.stderr')).write_bytes(q.stderr);outputs[name]=q.stdout.decode('utf-8')
 rows.append(dict(name=name,cmd=cmd,cwd=str(r),started_utc=start,native_exit=q.returncode,expected_exit=expected,passed=q.returncode==expected));(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(name,q.returncode,flush=True)
 if q.returncode!=expected:passed=False
checks={}
if passed:
 for name,expected in [('m0','b039d35666b77fc2'),('m1','b595dc2a1e5b4f8c')]:
  vals=[re.findall(r'^[0-9a-f]{16}$',outputs[f'{name}-hash-{i}'],re.M) for i in (1,2)];assert vals[0]==vals[1]==[expected];checks[name+'_hash']=expected
 for name,version in [('movement',2),('strait',3)]:
  vals=[json.loads((old/f'{name}-{i}/capture.json').read_text(encoding='utf-8')) for i in (1,2)];resume=json.loads(outputs[name+'-resume']);assert vals[0]==vals[1]==resume
  blob=(old/f'{name}-1/{name}-v{version}.ohsave').read_bytes();assert blob==(old/f'{name}-2/{name}-v{version}.ohsave').read_bytes();checks[name]=dict(full_dto_canonical_hash_equal=True,save_sha256=hashlib.sha256(blob).hexdigest(),split_hash=vals[0]['split']['hash'],continuous_hash=vals[0]['continuous']['hash'])
 samples=[json.loads(outputs[f'wp25-native-bench-{i}']) for i in (1,2)]
 for sample in samples:assert type(sample['elapsed_ns']) is int and sample['elapsed_ns']>0 and sample['steps']==240000 and sample['seed']==1000 and sample['scenario']=='m1' and sample['state']['hash']=='3b8853acbddce251' and sample['state']['ended'] is False
 assert samples[0]['state']==samples[1]['state'];checks['wp25_native_bench']=dict(full_dto_canonical_hash_equal=True,hash=samples[0]['state']['hash'],steps=240000,seed=1000,platform_scope='Local native CLI; actual fixed-library Linux15percent same-main CI remains separate')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head and not subprocess.check_output(['git','--no-optional-locks','status','--porcelain=v1'],cwd=r).strip()
(out/'actual-driver.py').write_bytes(pathlib.Path(__file__).read_bytes())
summary=dict(head=head,passed=passed,unique_planned_commands=46,first_driver_native_exit=1,first_successful_commands=41,first_path_guard_preparation_failure=True,continuation_commands=len(rows),actual_native_invocations=len(prior)+len(rows),native_repro_evidence=native.as_posix(),original_outputs_unchanged=True,product_source_unchanged=True,semantic_checks=checks)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary));sys.exit(0 if passed else 1)
