# M2-r2 부모 준비 오류 기록

- P07 driver의 새 legacy_nations_native.py 호출에 실제 필요한 --red-save 인자를 누락했다. exact2244의 첫24개 명령은 통과,25번째 준비 AssertionError1이었다. 원 driver/stdout/stderr/argv·그때 얻은 native receipts를 보존했고 같은 정상 save를 지정하여 남은14명령을 이어가 실제 통과했다. 제품 소스/단언 변경·기존 통과검사 반복은 없었다.
- 최초 실패 archive를 추적 대상 docs 아래에 만든 뒤 current clean capture를 준비하면서 자기 generated archive가 untracked 상태를 만들 수 있음을 실제 check_save_current.py의 git status --porcelain에서 확인했다. current capture가 시작되기 전에 archive를 explicit 경로 확인 후 ignored 부모 출력으로 가역 이동해 보존하고, 전명령 종료 뒤 원 bytes 그대로 docs로 복사했다. 실제 current capture의 원 status/dirty metadata와 local comparer 결과는 봉인한다. 진행 중 baseline/index나 source metadata를 고치지 않았다.
- git add가 존재하지 않는 docs/traceability.csv 및 .md를 지정해 pathspec 실패했다. 실제 trace는 tools/check_docs.py가 02 부록의 TRACE 표에 쓰며 변경 diff가 없었다. 정확 docs 경로를 다시 add/commit했다. 검사 실패로 꾸미거나 가짜 trace 파일을 만들지 않았다.
- 보조 탐색의 존재하지 않는 resume-before.json·current-save/capture.json은 실제 resumed-before.json·현재 checker의 파일목록으로 정정했다. 원 명령의 파일 열람 실패를 제품 test 실행으로 기록하지 않았다.
