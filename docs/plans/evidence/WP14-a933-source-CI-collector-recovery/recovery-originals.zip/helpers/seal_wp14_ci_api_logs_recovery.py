"""Task-local custody for exact main workflows and actual Save/Trigger artifacts."""
import argparse,hashlib,io,json,pathlib,re,stat,subprocess,sys,zipfile
p=argparse.ArgumentParser();p.add_argument('head');p.add_argument('summary');p.add_argument('label');p.add_argument('--worktree',required=True);a=p.parse_args()
r=pathlib.Path('E:/openhoi');summary=pathlib.Path(a.summary);s=json.loads(summary.read_text(encoding='utf-8'))
w=pathlib.Path(a.worktree).resolve();assert w.is_relative_to((r/'.orchestrator/wt').resolve()) and w!=r
assert re.fullmatch(r'[0-9a-f]{40}',a.head) and s['head']==a.head and subprocess.check_output(['git','--no-optional-locks','-C',str(w),'rev-parse','HEAD'],text=True).strip()==a.head
assert not subprocess.check_output(['git','--no-optional-locks','-C',str(w),'status','--porcelain=v1']).strip()
required=set()
for path in subprocess.check_output(['git','-C',str(r),'ls-tree','-r','--name-only',a.head,'--','.github/workflows'],text=True).splitlines():
 if path.endswith(('.yml','.yaml')):
  content=subprocess.check_output(['git','-C',str(r),'show',a.head+':'+path],text=True);m=re.search(r'^name:\s*(.+)$',content,re.M);assert m;required.add(m.group(1).strip().strip('\"\''))
assert {'CI','Core determinism','Simulation determinism','Save determinism','Localisation'}<=required
assert {x['workflowName'] for x in s['runs']}==required
assert all(x['headSha']==a.head and x['status']=='completed' and x['conclusion']=='success' and x['jobs'] and all(j['status']=='completed' and j['conclusion']=='success' for j in x['jobs']) for x in s['runs'])
out=r/'.orchestrator/evidence'/a.label;out.mkdir(parents=True,exist_ok=True)
def gh(name,*args):
 dest=out/(name+'.stdout');receipt=out/(name+'.command.json')
 if dest.exists() and receipt.exists():
  prior=json.loads(receipt.read_text(encoding='utf-8'))
  assert prior['argv']==['gh',*args] and prior['native_exit']==0
  return dest.read_bytes()
 actual=['gh',*args]
 if len(args)==4 and args[0]=='run' and args[1]=='view' and args[3]=='--log':
  actual=['gh','api',f'repos/peppone-choi/OpenHOI4/actions/runs/{args[2]}/logs']
 q=subprocess.run(actual,cwd=r,capture_output=True);dest.write_bytes(q.stdout);(out/(name+'.stderr')).write_bytes(q.stderr)
 if actual!=['gh',*args]:
  (out/(name+'.actual-api-command.json')).write_text(json.dumps(dict(argv=actual,cwd=str(r),native_exit=q.returncode,stdout_kind='original log ZIP bytes; GitHub CLI run log cache unused',global_settings_changed=False),indent=2)+'\n',encoding='utf-8')
  if q.returncode==0:
   with zipfile.ZipFile(io.BytesIO(q.stdout)) as logzip:
    assert logzip.testzip() is None
    names=set()
    for info in logzip.infolist():
     rel=pathlib.PurePosixPath(info.filename);assert info.filename not in names and not rel.is_absolute() and '..' not in rel.parts and ':' not in info.filename and '\\' not in info.filename and not stat.S_ISLNK(info.external_attr>>16);names.add(info.filename)
     if not info.is_dir():
      target=out/'actual-run-log-files'/name/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(logzip.read(info))
 receipt.write_text(json.dumps(dict(argv=['gh',*args],cwd=str(r),native_exit=q.returncode),indent=2)+'\n',encoding='utf-8');assert q.returncode==0,name
 return q.stdout
(out/'actual-summary.json').write_bytes(summary.read_bytes());records=[];compares={}
for row in s['runs']:
 rid=row['databaseId'];run=json.loads(gh(f'{rid}-run','api',f'repos/peppone-choi/OpenHOI4/actions/runs/{rid}'));assert run['head_sha']==a.head and run['conclusion']=='success'
 jobs=json.loads(gh(f'{rid}-jobs','api',f'repos/peppone-choi/OpenHOI4/actions/runs/{rid}/jobs?per_page=100'));assert jobs['total_count']==len(jobs['jobs']) and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs['jobs'])
 gh(f'{rid}-logs','run','view',str(rid),'--log');arts=json.loads(gh(f'{rid}-artifacts','api',f'repos/peppone-choi/OpenHOI4/actions/runs/{rid}/artifacts?per_page=100'));assert arts['total_count']==len(arts['artifacts'])
 names=set()
 if row['workflowName']=='Save determinism':names={f'{prefix}{os}' for prefix in ('save-','current-save-') for os in ('ubuntu-latest','windows-latest','macos-latest')}
 if row['workflowName']=='Trigger determinism':names={f'trigger-{os}' for os in ('ubuntu-latest','windows-latest','macos-latest')}
 selected=[x for x in arts['artifacts'] if x['name'] in names];assert {x['name'] for x in selected}==names and len(selected)==len(names)
 for artifact in selected:
  assert not artifact['expired'] and artifact['workflow_run']['head_sha']==a.head
  name=artifact['name'];blob=gh(name+'-zip','api',f"repos/peppone-choi/OpenHOI4/actions/artifacts/{artifact['id']}/zip");sha=hashlib.sha256(blob).hexdigest();assert artifact['digest']=='sha256:'+sha
  group='trigger' if name.startswith('trigger-') else 'current' if name.startswith('current-') else 'original';dest=out/group/name;dest.mkdir(parents=True,exist_ok=True);entries=[];seen=set()
  with zipfile.ZipFile(io.BytesIO(blob)) as z:
   for info in z.infolist():
    rel=pathlib.PurePosixPath(info.filename);assert not rel.is_absolute() and '..' not in rel.parts and ':' not in info.filename and '\\' not in info.filename and '\x00' not in info.filename
    assert info.filename not in seen;seen.add(info.filename);assert not stat.S_ISLNK(info.external_attr>>16)
    target=(dest/rel).resolve();assert target.is_relative_to(dest.resolve())
    if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
    data=z.read(info);target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==data
    else:target.write_bytes(data)
    entries.append(dict(path=info.filename,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
  records.append(dict(name=name,id=artifact['id'],run=rid,head=a.head,bytes=len(blob),ZIP_sha256=sha,members=entries))
for group,tool in [('original','crates/oh_save/tools/check_save_determinism.py'),('current','crates/oh_save/tools/check_save_current.py'),('trigger','crates/oh_sim/tools/check_trigger_determinism.py')]:
 if not (out/group).exists():continue
 cmd=[sys.executable,'-X','utf8',tool,'compare','--root',str(out/group)];q=subprocess.run(cmd,cwd=w,capture_output=True)
 (out/(group+'-compare.stdout')).write_bytes(q.stdout);(out/(group+'-compare.stderr')).write_bytes(q.stderr);(out/(group+'-compare.command.json')).write_text(json.dumps(dict(argv=cmd,cwd=str(w),head=a.head,native_exit=q.returncode),indent=2)+'\n',encoding='utf-8');assert q.returncode==0,group;compares[group]=q.returncode
identity=dict(head=a.head,required_workflows=sorted(required),all_jobs_success=True,actual_artifacts=records,actual_3OS_comparer_exits=compares)
(out/'parent-ci-custody.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');d=r/'docs/plans/evidence'/a.label;d.mkdir(parents=True,exist_ok=False);files=[]
with zipfile.ZipFile(d/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(out.rglob('*')):
  assert not path.is_symlink() and not (getattr(path.lstat(),'st_file_attributes',0)&0x400)
  if path.is_file():b=path.read_bytes();rel=path.relative_to(out).as_posix();z.writestr(rel,b);files.append(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(d/'originals.zip') as z:
 assert len(z.namelist())==len(files)
 for row in files:assert z.read(row['path'])==(out/row['path']).read_bytes()
identity.update(files=files,ZIP_sha256=hashlib.sha256((d/'originals.zip').read_bytes()).hexdigest(),mismatches=0)
(d/'custody.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(d/'README.md').write_text(f'# W2 exact source CI\n\n`{a.head}`의 실제 {len(required)} workflow 및 모든 필수 job, 원/current Save와 Trigger의 실제 3OS 원 artifact·API digest·ZIP bytes 및 이 exact source WT에서 실행한 comparer 결과를 보존한다. comparer native exits: {compares}. 새 v5 namespace의 검증은 실제 source comparer가 수행하며 부모가 그 coverage와 원 namespace를 따로 대조한다. 과거 원 실패/부분 다운로드를 최신 성공으로 지우지 않는다. 기본 main P07/CI와 독립 P05는 별도 조건이다. 상세 원문은 ZIP/custody.json에 있다.\n',encoding='utf-8')
print(json.dumps(dict(head=a.head,workflows=len(required),files=len(files),actual_artifacts=len(records),compare=compares,ZIP_sha256=identity['ZIP_sha256'],mismatches=0)))
