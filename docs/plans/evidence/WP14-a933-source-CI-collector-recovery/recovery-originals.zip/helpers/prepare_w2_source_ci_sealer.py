"""Prepare an ignored collector; do not execute any CI or source checks here."""
import pathlib,hashlib,ast,json
r=pathlib.Path('E:/openhoi')
src=r/'.orchestrator/seal_wp25_source_ci.py'
dst=r/'.orchestrator/seal_w2_source_ci.py'
assert not dst.exists()
original=src.read_text(encoding='utf-8')
text=original
old="p.add_argument('label');a=p.parse_args()"
new="p.add_argument('label');p.add_argument('--worktree',required=True);a=p.parse_args()"
assert text.count(old)==1
text=text.replace(old,new)
old="w=r/'.orchestrator/wt/WP-25-M2-r2'"
new="w=pathlib.Path(a.worktree).resolve();assert w.is_relative_to((r/'.orchestrator/wt').resolve()) and w!=r"
assert text.count(old)==1
text=text.replace(old,new)
old="assert s['head']==a.head=='d4433414870845f4e9013bf7114a628b2d3330ab' and"
new="assert re.fullmatch(r'[0-9a-f]{40}',a.head) and s['head']==a.head and"
assert text.count(old)==1
text=text.replace(old,new)
start=text.index("(d/'README.md').write_text(")
end=text.index('\nprint(json.dumps(',start)
text=text[:start]+"(d/'README.md').write_text(f'# W2 exact source CI\\n\\n`{a.head}`의 실제 {len(required)} workflow 및 모든 필수 job, 원/current Save와 Trigger의 실제 3OS 원 artifact·API digest·ZIP bytes 및 이 exact source WT에서 실행한 comparer 결과를 보존한다. comparer native exits: {compares}. 새 v5 namespace의 검증은 실제 source comparer가 수행하며 부모가 그 coverage와 원 namespace를 따로 대조한다. 과거 원 실패/부분 다운로드를 최신 성공으로 지우지 않는다. 기본 main P07/CI와 독립 P05는 별도 조건이다. 상세 원문은 ZIP/custody.json에 있다.\\n',encoding='utf-8')"+text[end:]
ast.parse(text)
dst.write_text(text,encoding='utf-8',newline='\n')
record=dict(original=src.as_posix(),originalSHA256=hashlib.sha256(src.read_bytes()).hexdigest(),derived=dst.as_posix(),derivedSHA256=hashlib.sha256(dst.read_bytes()).hexdigest(),pythonSyntaxChecked=True,executed=False,sourceHeadNotYetBound=True,CIOrProductChanged=False)
(r/'.orchestrator/evidence/W2-source-CI-collector-preparation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
