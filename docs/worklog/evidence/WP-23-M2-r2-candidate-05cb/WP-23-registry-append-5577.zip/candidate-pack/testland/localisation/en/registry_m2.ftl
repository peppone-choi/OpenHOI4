# New leaf only; registry has ID only, no invented name_key field.
resource-m2-steel = Steel
resource-m2-oil = Oil
resource-m2-aluminium = Aluminium
resource-m2-rubber = Rubber
resource-m2-rare-metals = Rare Metals
building-m2-infrastructure = Infrastructure
