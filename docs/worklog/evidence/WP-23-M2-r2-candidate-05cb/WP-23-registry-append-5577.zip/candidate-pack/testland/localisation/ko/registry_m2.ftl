# New leaf only; registry has ID only, no invented name_key field.
resource-m2-steel = 철강
resource-m2-oil = 석유
resource-m2-aluminium = 알루미늄
resource-m2-rubber = 고무
resource-m2-rare-metals = 희소금속
building-m2-infrastructure = 인프라
