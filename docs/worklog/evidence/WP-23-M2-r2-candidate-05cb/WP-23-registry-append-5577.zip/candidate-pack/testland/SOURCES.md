# WP-23 M2 가상 콘텐츠 준비 원천

역사 팩이 아니다. 원작 파일·지도·수치·문장·상징을 사용하거나 열람하지 않았다. 모든 기하·이름·팔레트는 직접 작성했다. 직접 제작 데이터의 기존 프로젝트 라이선스는 CC BY-SA 4.0(D-10)이다. 새 라이선스나 의존성을 선택하지 않았다. 확인일 2026-10-08.

| 항목 | 값/원천 | 상태 |
|---|---|---|
| 기하 | 384×288 RGB8, 12×12 자체 타일, 열 경계 ±2픽셀, 프로빈스 ID 1000+3i | 기하 준비 |
| 국가 | ARA/BEL/CER/DOR/ELA/FAR, ID 101..106, 자체 작명/색상, 국가당 24개 프로빈스 | 기존 nation 구조 준비 |
| 주 구획 | 12개 행, ID 101..112, 국가당 2개 | membership-plan.json 계획; states.toml 아님 |
| 지도 스케일 | 2km/픽셀 | 자체 합성 기술 값, 실제 loader 인수 전 |
| 정부/이념 | 시민 회의, 협력/자율 각0.5 | 구조 점검용 밸런스 잠정; 법령/징병/PC 효과 없음 |
| 지형 | 기존 plains/hills ID만 참조 | 새 registry 없음 |
| 인구/자원/건물/법령/PC/배분/슬롯 | 미작성 | WP14 실제 schema 및 별도 수치 인수 필요 |
| 날짜/종료 | 미작성 | 실제 m2 scenario 계약 인수 필요 |
| 장비/대대/의제/기술/전쟁/항복 | 미작성 | WP15/16/20/21/후속 producer 필요 |

이 디렉터리는 실행용 팩이 아니며 strict validate/run/save/repro 통과나 콘텐츠 수치 승인을 뜻하지 않는다. 기존 M0/M1·common·ASSETS master는 변경하지 않았다.

## 5577ee0 첫 producer 후보 인수 (2026-10-08)

이 후보만 주/경제/시나리오 입력을 추가했다. 원 준비물과 생산팩을 변경하지 않았다. 기존 공통 registry industry/steel만 사용한다. 나머지4자원과 추가 건물/장비/대대/생산/훈련/외교/항복/의제/연구는 작성하지 않았다. 첫 producer 계약은 아직 독립검증/통합/저장/host/repro 완료가 아니므로 Python 검사와 실제 Rust 실행을 구별한다.

| 값 범주 | 자체 합성 원천/값 | 승인·검증 경계 |
|---|---|---|
| 주 인구 | 120000..252000, 행마다12000 증가 | 가상 초기값·밸런스 잠정 |
| steel 일일 산출 | 반복3,5,7,9 | 비축 아님·생산 consumer 미구현 |
| industry 수준 | 반복1,2,3 | 기존registry 참조 |
| 인프라 | 반복1,2; 정확 factor0→0.5/1→1/2→1.25 | 첫 schema 계약의 명시값 |
| 건물 | industry4단계 비용48/80/112/144, 슬롯각1, cap8/IC단가8, 주슬롯6 | 실제 building 정의의 데이터값; 규칙 발명/수치승인 아님 |
| 법령 | 경제/징병2범주·각2단계, 비용16/24/12/20, civic/extended 징병1/16·1/8 | 자체 합성 잠정·기존 정치 조건 subset |
| 초기 정치 | PC32/cap128/daily2, 안정0.75/동원0.25 | 생성/조회 PC지급을 뜻하지 않음 |
| 초기 배분 | 소비재/건설/군수/수출0.375/0.375/0.125/0.125 | 군수·시장 실행 아님 |
| 인력 | committed0/reserved0 | 부대/훈련 생성 없음 |
| 시나리오 | 2000-01-01..2001-12-31,6국12주144프로빈스 | 가상 시간 context, 항복/점수 구현 아님 |
| defines | 기존m1 시간/network/display overlay의 byte동일 별도복사 | 새 gameplay define을 발명하지 않고 실제 경제정의 필드에 수치명시 |

첫 producer 테스트 fixture의 국가tag/숫자를 콘텐츠 default로 복사하지 않았다. authoring/content.toml/economy.toml은 ignored 후보 작성 원천이다. final actual producer 인수 뒤 strict/native/save/repro/hash/원M1 회귀를 다시 수행해야 한다.

## Registry append 별도 ignored 초안 (2026-10-08)

부모 추가소유 지시로 실제 common/resources.toml/buildings.toml 단일registry의 새ID append만 후보에 작성했다. 5자원·건설대상은 현행01 §4.3 ECO-4/6이다. 앞선 부모메시지의 §4.2는 정치 절 번호이며 후속메시지에서 번호만 정정됐다. 원메시지/첫후보/원실패를 덮지 않았다.

석유oil/알루미늄aluminium/고무rubber/희소금속rare_metals는 기존steel 뒤 ID레코드만 추가한다. 수량은 authoring/flows.toml의 자체합성 일일산출이며 비축/자원충족률/생산/시장 효과가 아니다. 기존industry 뒤 infrastructure ID레코드1개만 추가한다. 새경제정의는 IC0/cap6/costs24·40·56·72/슬롯각1/완성인프라1·2·3·4를 명시하고 초기주.infrastructure와 해당건물수준을 일치시킨다. 인프라완성 target은 전달5577 실제필드의 구조적표현 후보이며 native runtime 검증을 기다린다. industry와infrastructure의 정확factor0..4는0.5/1/1.25/1.5/1.75다.

보급거점/철도/항구/진지는 실제효과consumer가 없어 ID와빈필드로지원성공을 만들지 않았다. resource현지화키는 새leaf에만 두고 registry의미지원name_key필드를만들지않았다; resource표시resolver는 후속계약이다. 기존m0/m1/scenario/map/defines/locale·frozen·expected는 변경하지 않는다. 공유registry의실제trackedappend·최종producer·native/query/save/repro·새wholepackhash와현재m1hash/구호환·P05/P07/samemainCI는 별도후속이다.
