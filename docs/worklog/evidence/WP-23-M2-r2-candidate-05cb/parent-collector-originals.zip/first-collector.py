import pathlib,json,hashlib,zipfile,subprocess,shutil,stat,datetime
r=pathlib.Path('E:/openhoi');w=r/'.orchestrator/wt/WP-23-M2-r2';s=w/'target/evidence/WP-23-M2-r2'
head='05cb857e22a842351d84539c325435b0617bcdfb';base='2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab'
out=r/'.orchestrator/evidence/WP-23-candidate-05cb-parent';d=r/'docs/worklog/evidence/WP-23-M2-r2-candidate-05cb'
assert not out.exists() and not d.exists();out.mkdir();d.mkdir(parents=True)
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(w),*args])
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
changed=git('diff','--name-only',base,head).decode().splitlines()
assert changed==['docs/adr/ADR-2301-testland-m2-preparation.md','docs/worklog/WP-23.md']
api=r/'.orchestrator/evidence/WP-23-producer5577-candidate-actual-final-api.json'
a=json.loads(json.loads(api.read_text(encoding='utf-8'))['content'][0]['text'])
turn=next(t for t in a['turns'] if t['id']=='01a1180f-38ae-7142-a992-9f1817d04fc8')
assert turn['status']=='completed' and a['thread']['status']['type']=='idle'
finals=[x for x in turn['items'] if x['type']=='agentMessage' and x.get('phase')=='final_answer'];assert len(finals)==1
frozen=json.loads((s/'frozen-before.json').read_text(encoding='utf-8'));assert len(frozen)==70
for rel,row in frozen.items():
 b=(w/rel).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],rel
archive_records=[]
for folder,name,count,size,sha,candidate_count in [
 ('producer-5577-preparation','WP-23-candidate-5577.zip',54,467418,'f9f5e0ab5933910f8b294603f4e1eed684c6f6fa3542a9f95547cadf48c8afbc',39),
 ('registry-append-draft-5577','WP-23-registry-append-5577.zip',60,84991,'9158c1ae7d112b64b52bda7237deaf9679364ffb7662cac1c0cca604aa0f3a75',41)]:
 root=s/folder;zp=root/name;assert zp.stat().st_size==size and hashlib.sha256(zp.read_bytes()).hexdigest()==sha
 rows=[]
 with zipfile.ZipFile(zp) as z:
  infos=z.infolist();assert len(infos)==count and len({i.filename for i in infos})==count and z.testzip() is None
  for i in infos:
   pp=pathlib.PurePosixPath(i.filename);assert not pp.is_absolute() and '..' not in pp.parts and ':' not in i.filename and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr>>16)
   assert not i.is_dir();data=z.read(i);physical=root/pp;assert physical.resolve().is_relative_to(root.resolve()) and physical.read_bytes()==data
   rows.append(dict(member=i.filename,physical=physical.as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 inv=json.loads((root/'candidate-inventory.json').read_text(encoding='utf-8'));assert len(inv)==candidate_count
 for row in inv:
  physical=root/'candidate-pack/testland'/row['path'];b=physical.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 shutil.copyfile(zp,d/name)
 archive_records.append(dict(original=zp.as_posix(),copy=(d/name).as_posix(),bytes=size,sha256=sha,members=rows,candidate_files=candidate_count,CRC_mismatches=0,physical_mismatches=0))
reg=s/'registry-append-draft-5577'
for row in json.loads((reg/'registry-prefix-custody.json').read_text(encoding='utf-8')):
 original=(w/row['path']).read_bytes();blob=git('show',base+':'+row['path']);assert original==blob
 draft=(reg/'candidate-pack/testland'/pathlib.Path(row['path']).relative_to('data/packs/testland')).read_bytes()
 assert draft.startswith(original) and hashlib.sha256(original).hexdigest()==row['original_sha256'] and hashlib.sha256(draft).hexdigest()==row['draft_sha256']
 originals={'actual-final-api.json':api,'completed-poll.json':r/'.orchestrator/evidence/WP-23-producer5577-candidate-completed-poll.json','source-worklog.md':w/'docs/worklog/WP-23.md','source-ADR2301.md':w/'docs/adr/ADR-2301-testland-m2-preparation.md'}
 for name in ['WP-23-M2-r2-producer5577-send-payload.json','WP-23-M2-r2-producer5577-send-result.json','WP-23-registry-draft-ownership-send-payload.json','WP-23-registry-draft-ownership-send-result.json','WP-23-registry-section-correction-send.json']:
  originals['parent-instructions/'+name]=r/'.orchestrator/evidence'/name
 for folder in ['producer-5577-preparation','registry-append-draft-5577']:
  for p in (s/folder).glob('*'):
   if p.is_file() and p.suffix!='.zip':originals[folder+'/'+p.name]=p
 bodies={name:path.read_bytes() for name,path in originals.items()};bodies['actual-final.md']=(finals[0]['text']+'\n').encode('utf-8')
 with zipfile.ZipFile(d/'parent-originals.zip','x',zipfile.ZIP_DEFLATED) as z:
  for name,b in bodies.items():z.writestr(name,b)
 with zipfile.ZipFile(d/'parent-originals.zip') as z:
  assert z.testzip() is None
  for name,b in bodies.items():assert z.read(name)==b
 record=dict(source=head,base=base,changed_only_docs=changed,actual_completed_turn=turn['id'],actual_final_chars=len(finals[0]['text']),archives=archive_records,original_files70_equal=True,registry_original_raw_and_Git_equal=True,registry_original_prefix_exact=True,mismatches=0,ignored_candidate_only=True,product_pack_unchanged=True,actual_m2_native_not_verified=True,independent_PASS=False,WP23_integrated=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (d/'parent-custody.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');shutil.copyfile(d/'parent-custody.json',out/'parent-custody.json')
 (d/'README.md').write_text('# WP23 첫 경제·registry 후보 원본\n\n05cb의 실제 completed 후속 turn/문서2개 변경과 원 후보 ZIP54·60members, physical bytes/SHA/CRC 및 후보39·41파일을 전수 대조했다. 원70파일과 common registry raw/Git bytes·append prefix도 일치한다. 원4983 준비 ZIP과 첫producer5577은 별도로 보존한다. 현재 새m2 Rust 로드/실행/저장/repro는 미검증이며 생산팩 변경·독립PASS·통합/W2완료가 아니다. 최종 검증·통합된 WP14 producer 인수 뒤 같은 WP23 앱에서 실제 콘텐츠 작업을 계속한다. 원 준비·실패·수정 절 번호를 덮어쓰지 않았다. 모든 세부원문은 두ZIP·parent-originals.zip과 custody.json에 있다.\n',encoding='utf-8')
 registry=r/'.orchestrator/app-threads.json';j=json.loads(registry.read_text(encoding='utf-8'));poll=json.loads(json.loads((r/'.orchestrator/evidence/WP-23-producer5577-candidate-completed-poll.json').read_text(encoding='utf-8'))['content'][0]['text'])['polls'][0]
 row=next(x for x in j['sessions'] if x['threadId']==a['thread']['id']);row.update(status='ignored-economy-registry-candidate-sealed-final-producer-pending',appStatus='idle',turnStatus='completed',cursor=poll['cursor'],candidateSource=head,candidateCustody=d.relative_to(r).as_posix()+'/parent-custody.json')
 j.update(runningChildApps=1,lastObservedAt=record['utc']);registry.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:v for k,v in record.items() if k!='archives'},ensure_ascii=False))
