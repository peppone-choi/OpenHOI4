import pathlib,json,hashlib,zipfile,subprocess,datetime,shutil
r=pathlib.Path('E:/openhoi');w=r/'.orchestrator/wt/WP-23-M2-r2';s=w/'target/evidence/WP-23-M2-r2';d=r/'docs/worklog/evidence/WP-23-M2-r2-candidate-05cb'
head='05cb857e22a842351d84539c325435b0617bcdfb';base='2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab'
assert not (d/'custody-recovery.json').exists()
old=json.loads((d/'parent-custody.json').read_text(encoding='utf-8'))
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(w),*a])
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
assert git('diff','--name-only',base,head).decode().splitlines()==old['changed_only_docs']
for rel,row in json.loads((s/'frozen-before.json').read_text(encoding='utf-8')).items():
 b=(w/rel).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
total=0
for record in old['archives']:
 src=pathlib.Path(record['original']);copy=pathlib.Path(record['copy'])
 assert src.read_bytes()==copy.read_bytes() and src.stat().st_size==record['bytes'] and hashlib.sha256(src.read_bytes()).hexdigest()==record['sha256']
 with zipfile.ZipFile(src) as z:
  assert z.testzip() is None and len(z.infolist())==len(record['members'])
  for row in record['members']:
   b=z.read(row['member']);assert b==pathlib.Path(row['physical']).read_bytes() and len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];total+=1
 root=src.parent
 for row in json.loads((root/'candidate-inventory.json').read_text(encoding='utf-8')):
  b=(root/'candidate-pack/testland'/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
prefix=[];reg=s/'registry-append-draft-5577'
for row in json.loads((reg/'registry-prefix-custody.json').read_text(encoding='utf-8')):
 b=(w/row['path']).read_bytes();assert b==git('show',base+':'+row['path']) and hashlib.sha256(b).hexdigest()==row['original_sha256']
 draft=(reg/'candidate-pack/testland'/pathlib.Path(row['path']).relative_to('data/packs/testland')).read_bytes();assert draft.startswith(b) and hashlib.sha256(draft).hexdigest()==row['draft_sha256'];prefix.append(row['path'])
api=r/'.orchestrator/evidence/WP-23-producer5577-candidate-actual-final-api.json';a=json.loads(json.loads(api.read_text(encoding='utf-8'))['content'][0]['text']);t=next(x for x in a['turns'] if x['id']==old['actual_completed_turn']);assert t['status']=='completed'
finals=[x for x in t['items'] if x['type']=='agentMessage' and x.get('phase')=='final_answer'];assert len(finals)==1 and len(finals[0]['text'])==old['actual_final_chars']
with zipfile.ZipFile(d/'parent-originals.zip') as z:
 assert z.testzip() is None and z.read('actual-final-api.json')==api.read_bytes() and z.read('actual-final.md')==(finals[0]['text']+'\n').encode('utf-8')
 assert z.read('source-worklog.md')==(w/'docs/worklog/WP-23.md').read_bytes() and z.read('source-ADR2301.md')==(w/'docs/adr/ADR-2301-testland-m2-preparation.md').read_bytes()
 for name in z.namelist():
  if name.startswith(('producer-5577-preparation/','registry-append-draft-5577/')):assert z.read(name)==(s/name).read_bytes()
result=dict(source=head,originalCollector='preserve_wp23_candidate05cb.py',originalCollectorNativeExit=1,originalFailure='parent originals/custody block accidentally inside two-registry loop; second exclusive ZIP creation refused overwrite',originalScriptSHA256=hashlib.sha256((r/'.orchestrator/preserve_wp23_candidate05cb.py').read_bytes()).hexdigest(),originalOutputsPreserved=True,originalsOverwritten=False,archivesVerified=2,ownerZIPMembersVerified=total,registryPrefixesVerified=prefix,frozen70Equal=True,actualFinalChars=old['actual_final_chars'],mismatches=0,productPackUnchanged=True,actualM2NativeNotVerified=True,independentPASS=False,WP23Integrated=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(d/'custody-recovery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (d/'README.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n첫 부모 collector는 두 registry 반복문의 들여쓰기 오류로 두 번째 exclusive ZIP 저장을 거부(native1)했다. 첫 ZIP/custody/원 스크립트와 실패를 보존하고 덮지 않았다. 별도 recovery는 두 원/복사 ZIP·114 members·후보39/41 files·두 prefix와 원70파일·actual final/부모 원본을 다시 직접 대조해0을 확인했다. 최종 인수는 custody-recovery.json과 원 parent-custody.json을 함께 따른다. 이는 후보 원본 봉인이며 실제 m2 native/PASS/통합은 아니다.\n')
p=r/'.orchestrator/app-threads.json';j=json.loads(p.read_text(encoding='utf-8'));row=next(x for x in j['sessions'] if x['threadId']==a['thread']['id']);row['candidateCustody']=d.relative_to(r).as_posix()+'/custody-recovery.json';row['candidateFirstCollectorExit']=1;j['lastObservedAt']=result['utc'];p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
