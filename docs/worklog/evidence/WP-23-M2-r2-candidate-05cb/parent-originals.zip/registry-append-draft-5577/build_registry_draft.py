"""Prepare permitted ignored append draft; active files and native left alone."""
import hashlib
import json
import shutil
import subprocess
import tomllib
from pathlib import Path

HERE=Path(__file__).resolve().parent
EVIDENCE=HERE.parent
WT=HERE.parents[3]
assert Path.cwd().resolve()==WT.resolve()
assert subprocess.check_output(["git","branch","--show-current"],text=True).strip()=="codex/wp23-testland-m2r2"
FIRST=EVIDENCE/"producer-5577-preparation/candidate-pack/testland"
PACK=HERE/"candidate-pack/testland"
shutil.copytree(FIRST,PACK,dirs_exist_ok=True)
custody=[]
for name,kind in [("resources","resource"),("buildings","building")]:
    relative=f"data/packs/testland/common/{name}.toml"
    original=(WT/relative).read_bytes()
    git_data=subprocess.check_output(["git","cat-file","blob",f"2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab:{relative}"])
    assert original==git_data
    frozen=HERE/f"frozen-originals/common/{name}.toml"
    frozen.parent.mkdir(parents=True,exist_ok=True)
    frozen.write_bytes(original)
    appended=(HERE/f"authoring/{name}.append.toml").read_bytes()
    draft=original+b"\n"+appended
    (PACK/f"common/{name}.toml").write_bytes(draft)
    old=tomllib.loads(original.decode())[kind]
    new=tomllib.loads(draft.decode())[kind]
    assert new[:len(old)]==old
    custody.append({"path":relative,"base":"2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab","original_bytes":len(original),"original_sha256":hashlib.sha256(original).hexdigest(),"source_blob_equals_original":True,"draft_bytes":len(draft),"draft_sha256":hashlib.sha256(draft).hexdigest(),"original_prefix_exact":True,"original_records_equal":True,"active_written":False})
(HERE/"registry-prefix-custody.json").write_text(json.dumps(custody,indent=2),encoding="utf-8")
flows=tomllib.loads((HERE/"authoring/flows.toml").read_text())
state_path=PACK/"maps/m2/states.toml"
states=tomllib.loads(state_path.read_text())["state"]
text=state_path.read_text(encoding="utf-8")
for i,s in enumerate(states):
    old=f'resources = {{ steel = {s["resources"]["steel"]} }}'
    # Each repeated row has separate occurrence; source population anchors the
    # exact state block so equal steel amounts never select a different row.
    old_block=f'population = {s["population"]}\n{old}\nbuildings = {{ industry = {s["buildings"]["industry"]} }}'
    resources=f'steel = {s["resources"]["steel"]}, '+", ".join(f"{r} = {v[i]}" for r,v in flows.items())
    replacement=f'population = {s["population"]}\nresources = {{ {resources} }}\nbuildings = {{ industry = {s["buildings"]["industry"]}, infrastructure = {s["infrastructure"]} }}'
    assert text.count(old_block)==1
    text=text.replace(old_block,replacement)
state_path.write_text(text,encoding="utf-8",newline="\n")
economy_path=PACK/"common/economy/m2.toml"
econ=economy_path.read_text(encoding="utf-8")
needle='  { infrastructure = "2", factor = "1.25" },\n]'
replacement='  { infrastructure = "2", factor = "1.25" },\n  { infrastructure = "3", factor = "1.5" },\n  { infrastructure = "4", factor = "1.75" },\n]'
assert econ.count(needle)==1
econ=econ.replace(needle,replacement)+"\n"+(HERE/"authoring/infrastructure.economy.toml").read_text(encoding="utf-8")
economy_path.write_text(econ,encoding="utf-8",newline="\n")
keys=["resource-m2-steel","resource-m2-oil","resource-m2-aluminium","resource-m2-rubber","resource-m2-rare-metals","building-m2-infrastructure"]
names={"ko":["철강","석유","알루미늄","고무","희소금속","인프라"],"en":["Steel","Oil","Aluminium","Rubber","Rare Metals","Infrastructure"]}
for lang,values in names.items():
    text="# New leaf only; registry has ID only, no invented name_key field.\n"
    text+="".join(f"{key} = {value}\n" for key,value in zip(keys,values))
    (PACK/f"localisation/{lang}/registry_m2.ftl").write_text(text,encoding="utf-8",newline="\n")
with (PACK/"SOURCES.md").open("a",encoding="utf-8",newline="\n") as f:
    f.write("\n## Registry append 별도 ignored 초안 (2026-10-08)\n\n부모 추가소유 지시로 실제 common/resources.toml/buildings.toml 단일registry의 새ID append만 후보에 작성했다. 5자원·건설대상은 현행01 §4.3 ECO-4/6이다. 앞선 부모메시지의 §4.2는 정치 절 번호이며 후속메시지에서 번호만 정정됐다. 원메시지/첫후보/원실패를 덮지 않았다.\n\n석유oil/알루미늄aluminium/고무rubber/희소금속rare_metals는 기존steel 뒤 ID레코드만 추가한다. 수량은 authoring/flows.toml의 자체합성 일일산출이며 비축/자원충족률/생산/시장 효과가 아니다. 기존industry 뒤 infrastructure ID레코드1개만 추가한다. 새경제정의는 IC0/cap6/costs24·40·56·72/슬롯각1/완성인프라1·2·3·4를 명시하고 초기주.infrastructure와 해당건물수준을 일치시킨다. 인프라완성 target은 전달5577 실제필드의 구조적표현 후보이며 native runtime 검증을 기다린다. industry와infrastructure의 정확factor0..4는0.5/1/1.25/1.5/1.75다.\n\n보급거점/철도/항구/진지는 실제효과consumer가 없어 ID와빈필드로지원성공을 만들지 않았다. resource현지화키는 새leaf에만 두고 registry의미지원name_key필드를만들지않았다; resource표시resolver는 후속계약이다. 기존m0/m1/scenario/map/defines/locale·frozen·expected는 변경하지 않는다. 공유registry의실제trackedappend·최종producer·native/query/save/repro·새wholepackhash와현재m1hash/구호환·P05/P07/samemainCI는 별도후속이다.\n")
records="# Parent-only metadata updates for two EXISTING registered paths. Do not duplicate entries.\n"
for name in ("resources","buildings"):
    records+=f'\n[[asset]]\npath = "data/packs/testland/common/{name}.toml"\nauthor = "OpenHOI contributors"\nsource = "original"\nlicense = "CC-BY-SA-4.0"\nmodified = true\nai_generated = false\nnotes = "Original M1 record bytes retained as prefix; only new fictional M2 IDs appended in ignored draft. Tracked publication and producer native handoff pending."\n'
(HERE/"ASSETS-update-draft.toml").write_text(records,encoding="utf-8",newline="\n")
entries=(EVIDENCE/"producer-5577-preparation/ASSETS-entry-draft.toml").read_text(encoding="utf-8")
for lang in ("ko","en"):
    entries+=f'\n[[asset]]\npath = "data/packs/testland/localisation/{lang}/registry_m2.ftl"\nauthor = "OpenHOI contributors"\nsource = "original"\nlicense = "CC-BY-SA-4.0"\nmodified = false\nai_generated = false\nnotes = "New original M2 registry label leaf; no third-party text, actual presentation adapter and final producer handoff pending."\n'
(HERE/"ASSETS-entry-draft.toml").write_text(entries,encoding="utf-8",newline="\n")
inventory=[]
for p in sorted(PACK.rglob("*")):
    if p.is_file():
        relative=p.relative_to(PACK).as_posix()
        before=FIRST/relative
        data=p.read_bytes()
        inventory.append({"path":relative,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"first_candidate_present":before.exists(),"first_candidate_equal":before.exists() and before.read_bytes()==data})
(HERE/"candidate-inventory.json").write_text(json.dumps(inventory,indent=2),encoding="utf-8")
(HERE/"support-boundary.json").write_text(json.dumps({"producer":"5577ee08d38c7d08d271be5f37a5f9da2ac88a60","resource_ids":["steel","oil","aluminium","rubber","rare_metals"],"building_ids":["industry","infrastructure"],"native_verified":False,"tracked_append_authorized_now":False,"after_final_producer_authorization_required":True,"unsupported":["resource_shortage_production","market","stockpile","supply_hub_effect","railway_effect","port_effect","fort_effect","equipment","battalion","training","war","surrender"],"document_section_correction":{"original_parent_message":"01 section4.2","corrected_parent_message":"01 section4.3 ECO-4/6","meaning_changed":False}},indent=2),encoding="utf-8")
print(f"Ignored registry draft files={len(inventory)}; active writes=0; five daily-flow IDs and industry+infrastructure only. Original prefixes verified.")
