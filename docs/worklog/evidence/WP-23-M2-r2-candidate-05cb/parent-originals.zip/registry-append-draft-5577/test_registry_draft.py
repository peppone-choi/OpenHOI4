"""Append-only authoring checks; no Rust/native loader or runtime execution."""
import hashlib
import importlib.util
import json
import tomllib
import unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
EVIDENCE=HERE.parent
WT=HERE.parents[3]
PACK=HERE/"candidate-pack/testland"
FIRST=EVIDENCE/"producer-5577-preparation/candidate-pack/testland"


def doc(path):
    return tomllib.loads(path.read_text(encoding="utf-8"))


def validate_append(original,candidate,kind,expected):
    if not candidate.startswith(original):
        raise ValueError("original prefix changed")
    old=tomllib.loads(original.decode())[kind]
    parsed=tomllib.loads(candidate.decode())
    new=parsed[kind]
    if set(parsed)!={kind} or new[:len(old)]!=old:
        raise ValueError("original records/top level changed")
    if {e.get("id") for e in new}!=expected or len(new)!=len(expected):
        raise ValueError("duplicate/missing/unexpected ID")
    if any(set(e)!={"id"} for e in new):
        raise ValueError("unsupported registry field")


class RegistryDraft(unittest.TestCase):
    def test_req_gen_03_registry_exact_prefix_and_original_record(self):
        for name,kind,expected in [("resources","resource",{"steel","oil","aluminium","rubber","rare_metals"}),("buildings","building",{"industry","infrastructure"})]:
            original=(WT/f"data/packs/testland/common/{name}.toml").read_bytes()
            frozen=(HERE/f"frozen-originals/common/{name}.toml").read_bytes()
            candidate=(PACK/f"common/{name}.toml").read_bytes()
            self.assertEqual(original,frozen)
            self.assertTrue(candidate.startswith(original))
            old=tomllib.loads(original.decode())[kind]
            new=tomllib.loads(candidate.decode())[kind]
            self.assertEqual(new[:len(old)],old)
            self.assertEqual({e["id"] for e in new},expected)
            self.assertEqual(len(new),len(expected))
            self.assertTrue(all(set(e)=={"id"} for e in new))
            validate_append(original,candidate,kind,expected)

    def test_append_contract_rejects_destructive_and_unsupported_records(self):
        original=(HERE/"frozen-originals/common/resources.toml").read_bytes()
        good=(PACK/"common/resources.toml").read_bytes()
        cases=[
            ("prefix_edit",good.replace(b'id = "steel"',b'id = "iron"')),
            ("duplicate_id",good+b'\n[[resource]]\nid = "oil"\n'),
            ("missing_id",good.replace(b'[[resource]]\nid = "rubber"\n',b'')),
            ("unsupported_name_key",good+b'name_key = "resource-m2-rare-metals"\n'),
            ("invalid_id",good.replace(b'id = "oil"',b'id = "oil!"')),
        ]
        observed=[]
        for name,value in cases:
            try:
                validate_append(original,value,"resource",{"steel","oil","aluminium","rubber","rare_metals"})
            except ValueError as error:
                observed.append({"name":name,"input_toml":value.decode(),"rejected_by":"independent append authoring checker; not native loader","error":str(error)})
            else:
                self.fail(f"accepted {name}")
        (HERE/"negative-registry-inputs.json").write_text(json.dumps(observed,indent=2),encoding="utf-8")

    def test_req_gen_03_five_resource_daily_flows_and_locale_leaf(self):
        states=doc(PACK/"maps/m2/states.toml")["state"]
        scenario=doc(PACK/"scenarios/m2/scenario.toml")
        expected={"ARA":(8,1,1,0,1),"BEL":(16,2,2,2,0),"CER":(8,1,2,2,1),"DOR":(16,1,1,2,1),"ELA":(8,1,2,1,1),"FAR":(16,2,2,2,1)}
        resource_ids=["steel","oil","aluminium","rubber","rare_metals"]
        for state in states:
            self.assertEqual(set(state["resources"]),set(resource_ids))
            self.assertTrue(all(isinstance(v,int) and not isinstance(v,bool) and v>=0 for v in state["resources"].values()))
        for tag,values in expected.items():
            actual=tuple(sum(s["resources"][r] for s in states if scenario["ownership"][str(s["id"])]==tag) for r in resource_ids)
            self.assertEqual(actual,values)
        catalogs={}
        for lang in ("ko","en"):
            pairs=[line.split(" = ",1) for line in (PACK/f"localisation/{lang}/registry_m2.ftl").read_text(encoding="utf-8").splitlines() if " = " in line]
            self.assertEqual(len(pairs),6)
            catalogs[lang]=dict(pairs)
        self.assertEqual(set(catalogs["ko"]),set(catalogs["en"]))
        self.assertTrue(all(v.strip() for d in catalogs.values() for v in d.values()))

    def test_req_gen_03_actual_infrastructure_fields_only_and_stage_alignment(self):
        # Reuse only our prior authoring checker, never producer executable code.
        spec=importlib.util.spec_from_file_location("wp23_authoring",EVIDENCE/"producer-5577-preparation/test_candidate.py")
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.PACK=PACK
        states=doc(PACK/"maps/m2/states.toml")["state"]
        e=doc(PACK/"common/economy/m2.toml")
        n=[doc(p) for p in sorted((PACK/"scenarios/m2/nations").glob("*.toml"))]
        scenario=doc(PACK/"scenarios/m2/scenario.toml")
        module.validate_authored(e,states,n,scenario)
        infra=e["buildings"]["infrastructure"]
        self.assertEqual(infra["ic_per_level"],"0")
        self.assertEqual(infra["infrastructure_levels"],["1","2","3","4"])
        self.assertEqual(len(infra["infrastructure_levels"]),len(infra["costs"]))
        for s in states:
            level=s["buildings"]["infrastructure"]
            self.assertEqual(str(s["infrastructure"]),infra["infrastructure_levels"][level-1])
            self.assertLessEqual(sum(s["buildings"].values()),e["state_slots"][str(s["id"])] )
        self.assertEqual(set(e["buildings"]),{"industry","infrastructure"})
        self.assertFalse(any(k in e for k in ["production","stockpile","market","supply","combat"]))

    def test_original_preparation_and_first_candidate_preserved(self):
        checkpoints=[(EVIDENCE/"WP-23-preparation.zip",50627,"51c7fc654573ebbeab2e7def0cd322eaeadf8c14f0943d1913df4543712e37f6"),(EVIDENCE/"producer-5577-preparation/WP-23-candidate-5577.zip",467418,"f9f5e0ab5933910f8b294603f4e1eed684c6f6fa3542a9f95547cadf48c8afbc")]
        for path,size,sha in checkpoints:
            data=path.read_bytes()
            self.assertEqual(len(data),size)
            self.assertEqual(hashlib.sha256(data).hexdigest(),sha)
        changes={"common/resources.toml","common/buildings.toml","common/economy/m2.toml","maps/m2/states.toml","SOURCES.md"}
        for entry in json.loads((EVIDENCE/"producer-5577-preparation/candidate-inventory.json").read_text()):
            source=FIRST/entry["path"]
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),entry["sha256"])
            if entry["path"] not in changes:
                self.assertEqual((PACK/entry["path"]).read_bytes(),source.read_bytes())
        # Active M0/M1/registry/fixture/golden bytes are never appended here.
        for relative,record in json.loads((EVIDENCE/"frozen-before.json").read_text()).items():
            self.assertEqual(hashlib.sha256((WT/relative).read_bytes()).hexdigest(),record["sha256"])


if __name__=="__main__":
    unittest.main(verbosity=2)
