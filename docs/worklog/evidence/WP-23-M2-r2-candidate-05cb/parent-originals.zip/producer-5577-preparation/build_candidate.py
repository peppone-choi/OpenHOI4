"""Construct only an ignored candidate; never execute/copy producer code."""
import hashlib
import json
import shutil
import subprocess
import tomllib
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent
WT = HERE.parents[3]
assert Path.cwd().resolve() == WT.resolve()
assert subprocess.check_output(["git","branch","--show-current"],text=True).strip() == "codex/wp23-testland-m2r2"
PRODUCER = EVIDENCE / "planning/producer-5577"
handoff = json.loads((PRODUCER / "handoff.json").read_text())
observed = []
for item in handoff["files"]:
    data = (PRODUCER / item["path"]).read_bytes()
    git_bytes = subprocess.check_output(["git","cat-file","blob",handoff["source"]+":"+item["path"]])
    blob = hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
    assert blob == item["Git_blob"] and data == git_bytes
    observed.append(item)
(HERE / "producer-custody.json").write_text(json.dumps({"source":handoff["source"],"verified_files":len(observed),"mismatches":[],"producer_execution":False,"independent_PASS":False,"main_merged":False,"files":observed},indent=2),encoding="utf-8")
archive = EVIDENCE / "WP-23-preparation.zip"
assert len(archive.read_bytes()) == 50627 and hashlib.sha256(archive.read_bytes()).hexdigest() == "51c7fc654573ebbeab2e7def0cd322eaeadf8c14f0943d1913df4543712e37f6"
source = EVIDENCE / "prepared/data/packs/testland"
candidate = HERE / "candidate-pack/testland"
candidate.parent.mkdir(parents=True,exist_ok=True)
shutil.copytree(WT / "data/packs/testland",candidate,dirs_exist_ok=True)
shutil.copytree(source,candidate,dirs_exist_ok=True)
for entry in json.loads((EVIDENCE / "prepared-inventory.json").read_text()):
    original = EVIDENCE / "prepared" / entry["path"]
    assert len(original.read_bytes()) == entry["bytes"] and hashlib.sha256(original.read_bytes()).hexdigest() == entry["sha256"]


def write(path,text):
    dest = candidate / path
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(text,encoding="utf-8",newline="\n")


inputs = tomllib.loads((HERE / "authoring/content.toml").read_text())
membership = json.loads((EVIDENCE / "prepared/membership-plan.json").read_text())
states = "# Original M2 synthetic state inputs. Economy contract source 5577ee0.\n"
for row,state in enumerate(membership["states"]):
    states += f'\n[[state]]\nid = {state["id"]}\nname_key = "{state["name_key"]}"\nprovinces = {state["provinces"]}\npopulation = {inputs["population_by_row"][row]}\nresources = {{ steel = {inputs["steel_by_row"][row]} }}\nbuildings = {{ industry = {inputs["industry_by_row"][row]} }}\ninfrastructure = {inputs["infrastructure_by_row"][row]}\n'
write("maps/m2/states.toml",states)
tags = [tomllib.loads(path.read_text())["tag"] for path in sorted((candidate / "scenarios/m2/nations").glob("*.toml"))]
scenario = f'# Existing-map and first-producer candidate only.\neconomy = "{inputs["economy"]}"\nstart_date = "{inputs["start_date"]}"\nend_date = "{inputs["end_date"]}"\nmap = "{inputs["map"]}"\nnations = {json.dumps(tags)}\n[ownership]\n'
for state in membership["states"]:
    scenario += f'{state["id"]} = "{state["owner"]}"\n'
write("scenarios/m2/scenario.toml",scenario)
# Existing technical overlay is copied unchanged into its separate scenario.
shutil.copyfile(WT / "data/packs/testland/scenarios/m1/defines.toml",candidate / "scenarios/m2/defines.toml")
economy = (HERE / "authoring/economy.toml").read_text(encoding="utf-8")
for path in sorted((candidate / "scenarios/m2/nations").glob("*.toml")):
    nation_id = tomllib.loads(path.read_text())["id"]
    economy += f"\n[nations.{nation_id}]\n"
    for key,value in inputs["nation"].items():
        if isinstance(value,dict):
            rendered = "{ "+", ".join(f'{k} = {json.dumps(v)}' for k,v in value.items())+" }"
        else:
            rendered = json.dumps(value)
        economy += f"{key} = {rendered}\n"
economy += "\n[state_slots]\n"
for state in membership["states"]:
    economy += f'{state["id"]} = {inputs["state_slots"]}\n'
write("common/economy/m2.toml",economy)
translations = {"en":["Workshop","Civic Budget","Investment Budget","Civic Service","Extended Service"],"ko":["작업 시설","시민 예산","투자 예산","시민 복무","확대 복무"]}
keys = ["building-m2-workshop","law-m2-civic-economy","law-m2-investment-economy","law-m2-civic-service","law-m2-extended-service"]
for lang,names in translations.items():
    path=candidate/f"localisation/{lang}/m2.ftl"
    text=path.read_text(encoding="utf-8")+"\n# Initial economic definitions; no production/training/war consumer claim.\n"
    text += "".join(f"{key} = {name}\n" for key,name in zip(keys,names))
    write(f"localisation/{lang}/m2.ftl",text)
write("SOURCES.md",(source/"SOURCES.md").read_text(encoding="utf-8")+"\n## 5577ee0 첫 producer 후보 인수 (2026-10-08)\n\n이 후보만 주/경제/시나리오 입력을 추가했다. 원 준비물과 생산팩을 변경하지 않았다. 기존 공통 registry industry/steel만 사용한다. 나머지4자원과 추가 건물/장비/대대/생산/훈련/외교/항복/의제/연구는 작성하지 않았다. 첫 producer 계약은 아직 독립검증/통합/저장/host/repro 완료가 아니므로 Python 검사와 실제 Rust 실행을 구별한다.\n\n| 값 범주 | 자체 합성 원천/값 | 승인·검증 경계 |\n|---|---|---|\n| 주 인구 | 120000..252000, 행마다12000 증가 | 가상 초기값·밸런스 잠정 |\n| steel 일일 산출 | 반복3,5,7,9 | 비축 아님·생산 consumer 미구현 |\n| industry 수준 | 반복1,2,3 | 기존registry 참조 |\n| 인프라 | 반복1,2; 정확 factor0→0.5/1→1/2→1.25 | 첫 schema 계약의 명시값 |\n| 건물 | industry4단계 비용48/80/112/144, 슬롯각1, cap8/IC단가8, 주슬롯6 | 실제 building 정의의 데이터값; 규칙 발명/수치승인 아님 |\n| 법령 | 경제/징병2범주·각2단계, 비용16/24/12/20, civic/extended 징병1/16·1/8 | 자체 합성 잠정·기존 정치 조건 subset |\n| 초기 정치 | PC32/cap128/daily2, 안정0.75/동원0.25 | 생성/조회 PC지급을 뜻하지 않음 |\n| 초기 배분 | 소비재/건설/군수/수출0.375/0.375/0.125/0.125 | 군수·시장 실행 아님 |\n| 인력 | committed0/reserved0 | 부대/훈련 생성 없음 |\n| 시나리오 | 2000-01-01..2001-12-31,6국12주144프로빈스 | 가상 시간 context, 항복/점수 구현 아님 |\n| defines | 기존m1 시간/network/display overlay의 byte동일 별도복사 | 새 gameplay define을 발명하지 않고 실제 경제정의 필드에 수치명시 |\n\n첫 producer 테스트 fixture의 국가tag/숫자를 콘텐츠 default로 복사하지 않았다. authoring/content.toml/economy.toml은 ignored 후보 작성 원천이다. final actual producer 인수 뒤 strict/native/save/repro/hash/원M1 회귀를 다시 수행해야 한다.\n")
new_files = []
for path in sorted(candidate.rglob("*")):
    if path.is_file() and (not (WT/"data/packs/testland"/path.relative_to(candidate)).exists()):
        new_files.append(path)
records = "# Parent-only asset merge draft for first producer candidate.\n"
for path in new_files:
    if path.suffix == ".md":
        continue
    rel="data/packs/testland/"+path.relative_to(candidate).as_posix()
    records += f'\n[[asset]]\npath = "{rel}"\nauthor = "OpenHOI contributors"\nsource = "original"\nlicense = "CC-BY-SA-4.0"\nmodified = false\nai_generated = false\nnotes = "Original fictional WP-23 candidate; 5577ee0 first producer shape only, final native handoff pending."\n'
(HERE/"ASSETS-entry-draft.toml").write_text(records,encoding="utf-8",newline="\n")
inventory = [{"path":p.relative_to(candidate).as_posix(),"bytes":len(p.read_bytes()),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"new_m2_file":p in new_files} for p in sorted(candidate.rglob("*")) if p.is_file()]
(HERE/"candidate-inventory.json").write_text(json.dumps(inventory,indent=2),encoding="utf-8")
(HERE/"candidate-status.json").write_text(json.dumps({"producer_source":handoff["source"],"candidate_files":len(inventory),"new_m2_files":len(new_files),"producer_copied_into_working_tree":False,"native_load_run_save_repro":False,"independent_PASS":False,"main_merged":False},indent=2),encoding="utf-8")
print(f"Verified producer12 source files and preserved original prep16/ZIP; candidate files={len(inventory)}, new={len(new_files)}. No native producer execution.")
