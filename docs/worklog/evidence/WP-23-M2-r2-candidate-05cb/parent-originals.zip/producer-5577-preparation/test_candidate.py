"""Independent authoring checks against supplied JSON shape and stated contract.

No producer code is imported/executed. This is not Rust/native PASS evidence.
"""
import copy
import hashlib
import json
import re
import subprocess
import tomllib
import unittest
from datetime import date
from fractions import Fraction
from pathlib import Path
from jsonschema import Draft202012Validator

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent
WT = HERE.parents[3]
PRODUCER = EVIDENCE / "planning/producer-5577"
PACK = HERE / "candidate-pack/testland"


def document(path):
    return tomllib.loads(path.read_text(encoding="utf-8"))


def exact(text, bits, unit=False):
    if not isinstance(text, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", text):
        raise ValueError("invalid authored exact decimal")
    v = Fraction(text)
    raw = v * (1 << bits)
    # Authored values intentionally exactly representable; this does not attempt
    # to reproduce the Rust library's general decimal rounding/parser behavior.
    if raw.denominator != 1 or raw >= 1 << 63 or (unit and v > 1):
        raise ValueError("authored fixed-point range/precision")
    return v


def authored_condition(node, law_ids):
    if not isinstance(node, dict) or len(node) != 1:
        raise ValueError("condition shape")
    key, arg = next(iter(node.items()))
    if key in {"all", "any"}:
        for child in arg:
            authored_condition(child, law_ids)
    elif key == "has_law":
        if arg not in law_ids:
            raise ValueError("condition missing law")
    elif key in {"stability", "mobilization", "political_capital"}:
        if len(arg) != 1 or next(iter(arg)) not in {"gte", "lte", "eq"}:
            raise ValueError("comparison shape")
        exact(next(iter(arg.values())), 32 if key != "political_capital" else 16, key != "political_capital")
    else:
        raise ValueError("outside supplied authored condition subset")


def validate_authored(economy, states, nations, scenario):
    schema = json.loads((PRODUCER / "crates/oh_data/schema/economy.schema.json").read_text())
    Draft202012Validator(schema).validate(economy)
    Draft202012Validator(json.loads((PRODUCER / "crates/oh_data/schema/scenario.schema.json").read_text())).validate(scenario)
    building_ids = {b["id"] for b in document(PACK / "common/buildings.toml")["building"]}
    resource_ids = {r["id"] for r in document(PACK / "common/resources.toml")["resource"]}
    categories, steps = set(), set()
    for bid, building in economy["buildings"].items():
        if bid not in building_ids or not building["costs"] or len(building["costs"]) != len(building["slots"]):
            raise ValueError("building registry/stage count")
        if any(exact(c, 16) <= 0 for c in building["costs"]) or any(s < 0 for s in building["slots"]):
            raise ValueError("building positive cost/nonnegative slots")
        exact(building["daily_cap"], 16)
        exact(building["ic_per_level"], 16)
        factors = [exact(f["infrastructure"], 32) for f in building["infrastructure_factors"]]
        if not factors or len(factors) != len(set(factors)):
            raise ValueError("infrastructure factor keys")
        for f in building["infrastructure_factors"]:
            exact(f["factor"], 32)
    for lid, law in economy["laws"].items():
        category = law["category"]
        if (category, law["step"]) in steps:
            raise ValueError("duplicate law step")
        steps.add((category, law["step"]))
        categories.add(category)
        if exact(law["cost"], 16) <= 0:
            raise ValueError("law positive cost")
        for field in ("conscription_ratio", "consumer_base"):
            exact(law[field], 32, True)
        for field in ("ic_multiplier", "instability_slope"):
            exact(law[field], 32)
        authored_condition(law["condition"], economy["laws"])
    if economy["economy_category"] not in categories or economy["conscription_category"] not in categories:
        raise ValueError("category reference")
    if set(economy["nations"]) != {str(n["id"]) for n in nations} or set(economy["state_slots"]) != {str(s["id"]) for s in states}:
        raise ValueError("full actual ID coverage")
    if set(scenario["ownership"]) != {str(s["id"]) for s in states} or set(scenario["ownership"].values()) != {n["tag"] for n in nations}:
        raise ValueError("ownership coverage")
    if scenario["nations"] != [n["tag"] for n in nations] or scenario["economy"] != "m2":
        raise ValueError("scenario context")
    if date.fromisoformat(scenario["start_date"]) > date.fromisoformat(scenario["end_date"]):
        raise ValueError("date order")
    for n in economy["nations"].values():
        if set(n["laws"]) != categories:
            raise ValueError("selected category coverage")
        for cat, lid in n["laws"].items():
            if lid not in economy["laws"] or economy["laws"][lid]["category"] != cat:
                raise ValueError("selected law reference")
        pc, cap = exact(n["political_capital"], 16), exact(n["political_capital_cap"], 16)
        exact(n["political_capital_daily"], 16)
        if pc > cap or min(n["committed"], n["reserved"]) < 0 or n["committed"] + n["reserved"] >= 1 << 63:
            raise ValueError("PC/manpower initial bounds")
        stability = exact(n["stability"], 32, True)
        exact(n["mobilization"], 32, True)
        exact(n["ic_multiplier"], 32)
        ratios = [exact(r, 32, True) for r in n["allocation"]]
        law = economy["laws"][n["laws"][economy["economy_category"]]]
        minimum = min(1, exact(law["consumer_base"], 32, True) + exact(law["instability_slope"], 32) * (1 - stability))
        if sum(ratios) != 1 or ratios[0] < minimum:
            raise ValueError("allocation sum/minimum")
    for s in states:
        if s["population"] < 0 or s["infrastructure"] < 0 or not set(s["resources"]) <= resource_ids or any(v < 0 for v in s["resources"].values()):
            raise ValueError("state quantities/resource registry")
        occupied = 0
        for bid, level in s["buildings"].items():
            if bid not in economy["buildings"]:
                raise ValueError("missing economy building")
            building = economy["buildings"][bid]
            if not 0 <= level <= len(building["costs"]):
                raise ValueError("stage cap")
            occupied += sum(building["slots"][:level])
            if Fraction(s["infrastructure"]) not in {Fraction(f["infrastructure"]) for f in building["infrastructure_factors"]}:
                raise ValueError("missing exact infrastructure factor")
        if occupied > economy["state_slots"][str(s["id"])] or economy["state_slots"][str(s["id"])] < 0:
            raise ValueError("initial slot cap")


class Candidate(unittest.TestCase):
    def test_original_checkpoint_source_bytes_and_candidate_m1_preserved(self):
        archive = (EVIDENCE / "WP-23-preparation.zip").read_bytes()
        self.assertEqual(len(archive), 50627)
        self.assertEqual(hashlib.sha256(archive).hexdigest(), "51c7fc654573ebbeab2e7def0cd322eaeadf8c14f0943d1913df4543712e37f6")
        frozen=json.loads((EVIDENCE / "frozen-before.json").read_text())
        self.assertEqual(len(frozen),70)
        for relative,record in frozen.items():
            data=(WT/relative).read_bytes()
            self.assertEqual(len(data),record["bytes"])
            self.assertEqual(hashlib.sha256(data).hexdigest(),record["sha256"])
            if relative.startswith("data/packs/testland/"):
                self.assertEqual((PACK/relative.removeprefix("data/packs/testland/")).read_bytes(),data)
        for entry in json.loads((EVIDENCE / "prepared-inventory.json").read_text()):
            source=EVIDENCE/"prepared"/entry["path"]
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),entry["sha256"])
            if entry["path"].startswith("data/packs/testland/maps/m2/") or entry["path"].startswith("data/packs/testland/scenarios/m2/nations/"):
                self.assertEqual((PACK/entry["path"].removeprefix("data/packs/testland/")).read_bytes(),source.read_bytes())
        # Actual parent-supplied files remain inert source material, including
        # JSON schemas. Comparing git bytes never invokes producer programs.
        handoff=json.loads((PRODUCER/"handoff.json").read_text())
        self.assertEqual(len(handoff["files"]),12)
        for entry in handoff["files"]:
            data=(PRODUCER/entry["path"]).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(),entry["sha256"])
            self.assertEqual(data,subprocess.check_output(["git","cat-file","blob",handoff["source"]+":"+entry["path"]],cwd=WT))

    def load(self):
        e = document(PACK / "common/economy/m2.toml")
        s = document(PACK / "maps/m2/states.toml")["state"]
        n = [document(p) for p in sorted((PACK / "scenarios/m2/nations").glob("*.toml"))]
        sc = document(PACK / "scenarios/m2/scenario.toml")
        return e, s, n, sc

    def test_req_cnt_01_actual_six_nation_twelve_state_context(self):
        e, s, n, sc = self.load()
        self.assertEqual(len(n), 6)
        self.assertEqual(len(s), 12)
        self.assertEqual(len({p for state in s for p in state["provinces"]}), 144)
        Draft202012Validator(json.loads((WT / "crates/oh_data/schema/states.schema.json").read_text())).validate({"state": s})
        validate_authored(e, s, n, sc)
        for nation in n:
            own = {p for state in s if sc["ownership"][str(state["id"])] == nation["tag"] for p in state["provinces"]}
            self.assertIn(nation["capital"], own)

    def test_req_gen_03_supplied_economy_shape_and_exact_authored_values(self):
        e, s, n, sc = self.load()
        validate_authored(e, s, n, sc)
        expectations = {"ARA": (24, 252000, 8, 15750), "BEL": (32, 300000, 16, 18750), "CER": (40, 348000, 8, 21750), "DOR": (24, 396000, 16, 24750), "ELA": (32, 444000, 8, 27750), "FAR": (40, 492000, 16, 30750)}
        report = {}
        for nation in n:
            owned = [state for state in s if sc["ownership"][str(state["id"])] == nation["tag"]]
            ic = sum(state["buildings"]["industry"] * 8 for state in owned)
            population = sum(state["population"] for state in owned)
            steel = sum(state["resources"]["steel"] for state in owned)
            self.assertEqual((ic, population, steel, population // 16), expectations[nation["tag"]])
            input_n = e["nations"][str(nation["id"])]
            self.assertEqual(Fraction(input_n["political_capital"]), 32)
            self.assertEqual(Fraction(input_n["stability"]), Fraction(3, 4))
            self.assertEqual(input_n["committed"] + input_n["reserved"], 0)
            report[nation["tag"]] = {"authored_initial_expectation_only": True, "ic": ic, "population": population, "steel_daily": steel, "capacity": population // 16, "minimum": "0.3125", "allocation": [str(Fraction(ic) * Fraction(v)) for v in input_n["allocation"]]}
        (HERE / "independent-initial-expectations.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    def test_req_gen_03_independent_bad_input_rejections(self):
        original = self.load()
        mutations = [
            ("unknown_field", lambda e,s,n,sc: e.update(fake_production=True)),
            ("negative_cost", lambda e,s,n,sc: e["buildings"]["industry"]["costs"].__setitem__(0, "-1")),
            ("zero_law_cost", lambda e,s,n,sc: e["laws"]["civic_economy"].update(cost="0")),
            ("missing_nation", lambda e,s,n,sc: e["nations"].pop("106")),
            ("missing_state", lambda e,s,n,sc: e["state_slots"].pop("112")),
            ("missing_registry_building", lambda e,s,n,sc: e["buildings"].update(ghost=e["buildings"]["industry"])),
            ("unknown_resource", lambda e,s,n,sc: s[0]["resources"].update(ghost=1)),
            ("wrong_law", lambda e,s,n,sc: e["nations"]["101"]["laws"].update(economy="ghost")),
            ("wrong_category", lambda e,s,n,sc: e["nations"]["101"]["laws"].update(economy="civic_service")),
            ("allocation_sum", lambda e,s,n,sc: e["nations"]["101"]["allocation"].__setitem__(0,"0.5")),
            ("allocation_minimum", lambda e,s,n,sc: e["nations"]["101"].update(allocation=["0.25","0.5","0.125","0.125"])),
            ("pc_above_cap", lambda e,s,n,sc: e["nations"]["101"].update(political_capital="129")),
            ("nan", lambda e,s,n,sc: e["nations"]["101"].update(stability="NaN")),
            ("overflow", lambda e,s,n,sc: e["buildings"]["industry"].update(daily_cap="140737488355328")),
            ("duplicate_step", lambda e,s,n,sc: e["laws"]["investment_economy"].update(step=0)),
            ("negative_reserved", lambda e,s,n,sc: e["nations"]["101"].update(reserved=-1)),
            ("initial_slot_excess", lambda e,s,n,sc: e["state_slots"].update({"101":0})),
            ("missing_factor", lambda e,s,n,sc: s[0].update(infrastructure=3)),
            ("unsupported_at_war", lambda e,s,n,sc: e["laws"]["civic_economy"].update(condition={"at_war":False})),
            ("law_condition_missing_ref", lambda e,s,n,sc: e["laws"]["investment_economy"].update(condition={"has_law":"ghost"})),
            ("null", lambda e,s,n,sc: e["nations"]["101"].update(stability=None)),
        ]
        observations = []
        for name, mutate in mutations:
            args = copy.deepcopy(original)
            mutate(*args)
            try:
                validate_authored(*args)
            except Exception as error:
                observations.append({"name":name,"rejected_by":"independent authoring checker, not native loader","error":str(error),"input":{"economy":args[0],"states":args[1],"nations":args[2],"scenario":args[3]}})
            else:
                self.fail(f"accepted authored invalid case {name}")
        (HERE / "negative-input-observations.json").write_text(json.dumps(observations, indent=2), encoding="utf-8")

    def test_req_gen_03_ko_en_all_actual_key_references(self):
        e, s, n, sc = self.load()
        catalogs = {}
        for lang in ("ko", "en"):
            pairs=[]
            for path in (PACK / f"localisation/{lang}").glob("*.ftl"):
                pairs.extend(line.split(" = ",1) for line in path.read_text(encoding="utf-8").splitlines() if line and not line.startswith("#") and " = " in line)
            self.assertEqual(len(pairs),len({k for k,v in pairs}))
            catalogs[lang]=dict(pairs)
        self.assertEqual(set(catalogs["ko"]),set(catalogs["en"]))
        keys={v["name_key"] for v in e["buildings"].values()} | {v["name_key"] for v in e["laws"].values()} | {v["name_key"] for v in s}
        for nation in n:
            keys.update([nation["name_key"],nation["government_key"],*nation["ideology_support"]])
        self.assertTrue(keys <= set(catalogs["en"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
