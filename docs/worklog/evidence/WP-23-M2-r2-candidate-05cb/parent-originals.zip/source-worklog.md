# WP-23 작업 로그 — Testland M2 기하·6개국 준비

| 항목 | 값 |
|---|---|
| 상태 | 진행 — 5577 첫 producer 데이터 계약 인수; 최종 독립 검증·통합·host/save/repro 인수 대기 |
| 담당 | 구현 세션(콘텐츠) |
| 브랜치 | codex/wp23-testland-m2r2 |
| 대상 REQ | REQ-CNT-01 · REQ-GEN-03 (준비 범위만 검사) |
| 선행 WP | W1 exact main 2b5ca 인수; WP14 첫 producer 5577ee0 원문 인수, 최종 통합 미인수 |

## 계획

아래 최초 준비 기록은 커밋4983a8e 당시 증거다. 후속 첫 producer 인수는 맨 아래 별도 절에 기록하며 원 준비물·실패·ZIP·원명령을 대체하지 않는다.

- 모든 명령 cwd는 `E:/openhoi/.orchestrator/wt/WP-23-M2-r2`. 최초 HEAD `2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab`, tracked11805, 최초 status/diff/cached diff 없음. 부모 `parent-before.index`의 실제 SHA256은 배정 값 `7ef2c2d41fd1e3029590837a8b8cf921d1ca5b1a0604109f3275283789912770`과 일치한다. 별도 NUL ls-files stdout의 SHA는 직렬화가 다른 관찰값이며 부모 raw index와 혼동하지 않는다.
- `target/evidence/WP-23-M2-r2/planning/W1-actual-completion.json` 및 actual-prompt를 인수했다. W1 통합/P05/P07/main CI 원기록 인수이며 이 구현 세션이 CI를 새 실행한 것은 아니다.
- 기존 mapper/nation/locale 계약으로 6개국·144 프로빈스·12개 예정 주만 준비한다. 원 M0/M1/common bytes와 골든/fixture를 유지한다. REQUEST-0010 A-CEO-r1 수정판은 CEO 한정 잠정이다.
- actual StateDefinition의 필수 인구·자원·건물·인프라 때문에 부분 새 map은 제품 팩 전체 strict 실행을 막는다. 따라서 준비물을 증거 디렉터리에 두고 actual producer 인수 뒤 제품 경로에 반영한다. [ADR-2301](../adr/ADR-2301-testland-m2-preparation.md).

## 테스트 우선 기록

| REQ | 테스트 이름 | 구현 전 결과 | 구현 후 결과 |
|---|---|---|---|
| REQ-CNT-01 | test_req_cnt_01_geometry_coverage_connectivity | exit1: provinces.csv 없음 | exit0: 144개, RGB/ID 유일, 모든 pixel 매핑, 각 province 단일 4-connected 영역, 전체385 edge graph 연결, 예정12주 연결·중복 없이 전체 소속 |
| REQ-CNT-01 | test_req_cnt_01_six_nations_and_capital_membership | exit1: 0 != 6 | exit0: 6국 ID/tag 유일, 국가당24 province, 수도 자국 예정 구획, 정확 지지율 합1 |
| REQ-GEN-03 | test_req_gen_03_supported_names_only_and_locale_parity | exit1: m2.ftl 없음 | exit0: ko/en 동일21키·빈값/중복 없음, nation 참조 포괄, 미지원 경제/common·미완성 scenario 없음 |

원 테스트 소스는 `target/evidence/WP-23-M2-r2/test_preparation.py`, RED는 `preparation-red.log`, GREEN은 `preparation-green.log`. 이는 준비 구조 검사이며 actual Rust schema/전체 REQ/PT 판정이 아니다. generator 첫 실행은 worktree guard의 parent depth 오류로 실패했다. `preparation-first-attempt-failure.log`를 보존하고 올바른 지정 cwd로 수정했으며 준비 검사 기대값은 약화하지 않았다.

## 실행한 검증

아래 로그 루트는 `target/evidence/WP-23-M2-r2/`다. Windows native 출력이며 별도 Linux/source CI/main CI는 실행하지 않았다.

| 명령 | 종료 코드 | 출력 발췌 / 로그 경로 |
|---|---|---|
| python -X utf8 target/evidence/WP-23-M2-r2/prepare.py | 0 | prepare.log, 16파일 준비; 제품 pack 쓰기 없음 |
| python target/evidence/WP-23-M2-r2/test_preparation.py | 1→0 | RED/GREEN, 3 tests |
| 최초 Python subprocess cargo spawn | spawn 전 실패 | PATH cargo 부재 WinError2; 기존 C:/Users/user/.cargo/bin을 해당 process PATH에 추가, 설정/승인/네트워크 변경 없음 |
| cargo fmt --check | 0 | fmt.log |
| 최초 cargo clippy --workspace -- -D warnings | 101 | clippy.log; oh_server가 client/dist 부재를 거부 |
| 최초 cargo test --workspace | 101 | workspace-tests.log; 동일 client/dist 부재 |
| npm --prefix client ci | 0 | npm-ci.log; 기존 lock 사용 |
| npm --prefix client run build | 0 | npm-build.log; 실제 Vite dist 생성, chunk size warning 보존 |
| cargo clippy --workspace -- -D warnings (client build 후) | 0 | clippy-after-client-build.log |
| cargo test --workspace (client build 후) | 0 | workspace-tests-after-client-build.log; 원 national/map/movement/trigger/save/repro/호환 및 doc tests 통과 |
| python -X utf8 crates/oh_cli/tests/repro_native.py --evidence-root target/evidence/WP-23-M2-r2/repro-original-native | 0 | repro-original-native.log; 15 tests, 실제 v3 이동/v4 trigger·save 시작/fresh replay·futurequeue/phase rollback·적대 ZIP 회귀 |
| cargo run -p oh_cli -- validate --deny-warnings data/packs/testland | 0 | original-strict-validate.log; maps1/scenarios1/hash3bde1bed90d3734e |
| cargo run -p oh_cli -- run --scenario testland --days 365 --seed 1 --hash-out (2회) | 0/0 | original-testland-hash-1/2.log; b039d35666b77fc2 두 번 동일 |
| cargo run -p oh_cli -- run --scenario m1 --days 365 --seed 1 --hash-out --pack data/packs/testland (2회) | 0/0 | original-m1-hash-1/2.log; b595dc2a1e5b4f8c 두 번 동일 |
| cargo run -p oh_cli -- validate --deny-warnings target/evidence/WP-23-M2-r2/candidate-pack | 1 | candidate-strict-rejection.log; maps/m2/states.toml:1:1 os2, maps0/scenarios0; 성공으로 처리하지 않음 |
| python -X utf8 tools/check_docs.py (로그 작성 전) | 0 | docs-before.log; 오류0/경고0 |
| python -X utf8 tools/check_docs.py (로그/ADR 작성 후) | 0 | docs-after.log; 오류0/경고0 |
| 기존 pack/fixture/golden 파일 bytes/SHA custody | 일치 | frozen-before.json/frozen-after.json; 70파일 변경0 |

원 argv/native exit는 `commands.jsonl`에 있다. 그 파일의 최초 clippy/test101을 build 후 결과로 덮지 않았다. `run_checks.py`는 사용한 단일 배치 실행 기록이며 재시도/하네스/오케스트레이션/설정 변경을 추가하지 않는다.

## 증거

- E1: `prepared/` 원천16파일과 `prepared-inventory.json`의 상대경로/bytes/SHA256. `prepare.py`로 재생성 가능하며 원작 자료·외부 지도·이미지 생성 도구·추가 라이브러리를 쓰지 않았다.
- E2: `geometry-observation.json`: RGB8 384×288, 144 land provinces, 전체 graph 연결·385 edges. `prepared/membership-plan.json`: 예정12주·6국 소속의 기하 계획이며 loader 입력이 아니다. bitmap을 직접 열어 확인했다.
- E3: `prepared/data/packs/testland/SOURCES.md`는 가상 콘텐츠·직접 제작·잠정 구조수치/미작성 범주를 명시. `prepared/ASSETS-entry-draft.toml`은 향후 제품 경로용13개 asset 초안이며 master 변경/등록/공개 배포 승인을 뜻하지 않는다.
- E4: 실제 CLI strict 원팩0·불완전 후보1·원 M0/M1 해시2회, 기존70파일 SHA 보존. 원 M1 pack bytes와 content identity는 그대로다. 후보 pack identity를 실제 loaded identity나 원 frozen identity로 기록하지 않는다.
- E5: `planning/` 부모 원문, `parent-before.*`, 최초 인수관찰. 실제 source/구현 검증과 부모 인수·독립P05/CI의 증거 경계를 구분한다.
- 보존용 준비 묶음: `target/evidence/WP-23-M2-r2/WP-23-preparation.zip` (50627bytes, SHA256 `51c7fc654573ebbeab2e7def0cd322eaeadf8c14f0943d1913df4543712e37f6`). 준비16파일·생성/검사/배치 스크립트·RED/GREEN/최초실패·native 거부 로그를 포함한다. `target/`의 ignored 로컬 증거이며 제품 입력/독립 검증 리포트/추적파일은 아니다. 후속 작업 때 이 worktree와 증거를 보존해야 한다.

## 실제 기존 schema·필요한 producer 인수

| 경로/필드 | 현재 준비·단위/참조 | actual producer 이후 필요한 것 |
|---|---|---|
| maps/m2/provinces.csv/png | u16 ID1000+3i, RGB8, 기존 land/plains/hills, coastal=false, ID≠dense index | Rust map/national 전체 load 및 서버 index/선택/query; 실제 UI 후속 |
| maps/m2/regions.toml | 기존 정확 km_per_pixel=2 기하값 | 경제/이동 계수로 재해석하지 않기 |
| maps/m2/states.toml | 미작성; 예정 id101..112/name_key/provinces만 JSON 계획 | required population i64/resources BTreeMap<id,i64>/buildings BTreeMap<id,i64>/infrastructure i64의 actual economy 정의와 bounds·시나리오별 slots 경로 |
| scenarios/m2/nations/*.toml | NationDefinition 기존8필드, u16 id/capital, tag/name_key/color/government_key, exact decimal ideology_support | 경제 초기 법령/PC/안정도/동원도/배분/committed/reserved가 어느 actual 경로에 붙는지; 지원 law/condition/locale registry·범위 |
| localisation/ko,en/m2.ftl | 21키 자체 이름, 기존 나라/정부/이념/예정주 참조 | actual 경제 key 검증·ko/en 및 최종 부모 asset 합류 |
| scenarios/m2/scenario.toml/defines.toml | 미작성 | actual 날짜/종료/end_root·시간/display 기본값·경제presence 및 기존overlay 참조. 날짜/숫자 기본값 발명 없음 |
| common/resources,buildings,terrain | 기존bytes 유지; 새파일 없음 | 5자원/건물/law 범주의 pack전역 파일 충돌·새 지원경로·ID를 부모가 고정하고 변경 소유 인수 |
| 장비/대대/생산/훈련/전쟁/항복/의제/연구 | 미작성 | actual WP15/16/20/21 등 producer; unsupported 구문/no-op 성공 금지 |
| save/repro/hash/bench | 기존 경로만 회귀 | WP14 additive save/native query/repro 및 원 immutable performance 입력 WP14/WP25 인수 후 새m2 검사 |

REQ-GEN-03의 현재 준비는 데이터 지형·정부/이념 이름 참조뿐이다. 날짜·경제·자원·건물 최소세트는 producer 인수 대기, 장비/대대 등은 후속 미구현이다. 타입 선언/이름/준비 검사로 엔진 시대독립 전체 실행을 증명하지 않는다.

## ADR

- ADR-2301: 합성기하 준비·부분팩 게시 보류·실제 strict 거부와 기존 identity 보존. 경제/전투/정치 새 규칙을 정하지 않는다.

## 원작 대비 차별화 초안 (01 §11에 넣을 행)

- 가상 시나리오: 외부 원작 지도/수치 없이 만든144프로빈스·6개국, 비연속 typed ID·원천SHA·ko/en 데이터 참조. 기존M1 동결fixture와 별도 기하 준비. 산업·평시→전쟁→항복은 아직 실행 증거 없음.

## 결정 필요

| 식별자 | 내용 | 막는 범위 |
|---|---|---|
| REQUEST-0010 A-CEO-r1 | CEO 한정 잠정 유지; 합성 예제를 콘텐츠 기본값 승인으로 쓰지 않음. 실제 경제 수치 후보·지원 schema/refs 인수 필요 | 새 경제 콘텐츠 입력·검증 |
| REQ-GEN-03 | 장비/대대/정치 후속 효과 등 실제producer 없는 범주 | 해당 지원 데이터/전체 시대독립 실행 |

## 범위 밖 발견

- common/resources.toml/buildings.toml은 pack 전역 단일 registry이며 원 M1 bytes 보존 지시와5자원/건물 추가가 충돌할 수 있다. 새 경제 정의 경로/ID 및 최소 shared 변경은 부모가 실제 WP14 계약으로 고정해야 한다. 기존파일 변경하지 않았다.
- ASSETS master는 부모 소유다. 초안만 준비했다. 기존 판정·골든·fixture·01/02/03/HANDOFF·CI·bench 정책을 바꾸지 않았다.

## 못 한 부분과 이유

- WP14 actual schema/refs/source·통합 인수 미도착. 준비물을 제품 pack에 게시하거나 필수 주 경제입력/0대체·새 scenario/defines를 작성하지 않았다.
- 새m2 strict validate는 실제 후보에서 실패하며 run/query/save/freshnative/repro·canonical/hash와 완전한 평시→전쟁→항복 플레이를 실행 성공으로 기록하지 않는다. producer와 후속 WP가 필요하다.
- ai-bench는 현재 CLI USAGE가 후속 WP로 명시한다. 없는 명령 실행/성공을 보고하지 않는다.
- 이 checkpoint는 콘텐츠 준비 상태다. 새 독립P05·부모P07·같은main CI 및 M2 게이트 판정은 하지 않았다. merge/push/다른세션 생성/사용자 desktop 조작 없음.

## 수정 기록 (P-06)

- 최초 PATH spawn 실패·generator guard 오류·client dist 부재를 각각 보존하고 해당 준비만 교정했다. 제품 코드/기존테스트·기대값/설정 변경 없음.

## 통합 기록 (P-07)

- 해당 없음. 본 브랜치 준비 기록 checkpoint만 커밋한다. 실제 producer 인수 뒤 이 앱·worktree에서 계속한다.

## 첫 producer 5577ee0 후속 인수 — ignored 후보 작성

2026-10-08. 부모 후속 배정은 `5577ee08d38c7d08d271be5f37a5f9da2ac88a60`의 첫 실제 data 계약으로 **자기 ignored 후보**를 작성하는 범위다. producer는 독립P05·main통합·최종 save/host/repro를 아직 제공하지 않았다. source를 checkout/cherry-pick/병합하거나 제품 코드로 복사·실행하지 않았다. 본 작업 실행 HEAD는 문서 checkpoint `4983a8e341faaf5a56bc71a14ab7b0b8161ff9d9`이며 원 Rust 실행 회귀는 위의 최초2b5ca 증거다.

새 증거 루트 `target/evidence/WP-23-M2-r2/producer-5577-preparation/`을 사용한다. `planning/producer-5577/handoff.json`의12개 원문마다 길이/SHA256/Git blob 및 `git cat-file blob 5577...:path`의 실제 bytes를 대조했다. `producer-custody.json`은12개 불일치0이며 미검증/미통합 상태를 보존한다. Git 원문 읽기는 producer 실행이 아니다.

### 작성한 후보 입력과 현재 지원 경계

| 후보 경로 | 명시 입력·참조 | 실효 범위·원천 |
|---|---|---|
| candidate-pack/testland/maps/m2/states.toml | 예정12주 ID101..112·원144기하 소속, 인구120000..252000(행마다12000), steel산출3/5/7/9 반복, industry수준1/2/3 반복, infrastructure1/2 반복 | 기존 StateDefinition 필수 필드. 소유국당2주·수도 자국소속. 자원은 일일 흐름이고 비축/부대가 아님 |
| scenarios/m2/scenario.toml | economy="m2", map="m2",6개 원tag·12주 ownership, start2000-01-01/end2001-12-31 | 가상 날짜·context; 종료/점수/항복 runtime 실행 증거 없음 |
| scenarios/m2/defines.toml | 기존m1 time/network/display overlay의 별도byte동일복사 | M1 원본 수정 없음. 새로운 gameplay define 키를 발명하지 않음 |
| common/economy/m2.toml buildings | 기존registry industry만, 단계4/비용48·80·112·144 Qty문자열, 슬롯각1, cap8/IC단가8 Qty문자열 | 새 단계 수/정확 인프라0→0.5·1→1·2→1.25 Fx문자열; 산업건물에 infrastructure_levels를 가짜로 넣지 않음 |
| laws | 경제/징병2범주·각2단계, 비용16·24·12·20 Qty문자열, 기존 정치조건 stability/mobilization/political_capital/has_law/all | 범주step유일·조건law참조. 현재지원 subset 작성 검사; 일반AST/미지원primitive 전체를 자체checker가 증명하지 않음 |
| nations/state_slots | 실제6국 ID101..106 및12주 ID101..112 전체포괄; PC32/cap128/daily2, stability0.75/mobilization0.25, 네배분0.375/0.375/0.125/0.125, committed0/reserved0, 주슬롯6 | 단위: PC/비용Qty, 비율Fx, 슬롯/인구/인력i64. exact dyadic authored 값만 검증; 초기consumer하한0.3125·초기stage슬롯 범위 확인 |
| localisation/ko,en/m2.ftl | 원21키에 산업/4법령5키 추가, 새m2합26키 | 모두 직접 작성, 합성/시대독립 이름. 실제 Fluent native semantic 검사 미실행 |
| SOURCES.md·ASSETS-entry-draft.toml | 가상원천·합성수치잠정·첫source·미완료범주, 신규17asset 부모합류초안 | 최종수치승인/ASSETS master등록/공개배포 승인 아님 |

모든 새 수치는 producer의 실제 정의·기존 map 초기입력 필드에 명시했다. 새 gameplay define이 없다는 producer 계약을 따르며 코드상수로 게임량을 추가하지 않았다. `authoring/content.toml`과 `authoring/economy.toml`이 자체합성 원천이고 `build_candidate.py`는 그 데이터만 렌더한다. 전달된2국 fixture의 tag/숫자를 콘텐츠 기본값으로 복사하지 않았다. 초기 법령조건을 만족시키기 위해 숨은 플레이 효과를 넣지 않았다.

### 독립 작성 검사와 원명령

이 절의0은 **Python 프로세스/작성 검사 결과**다. producer Rust/native load/run/command/query/save/repro PASS나 독립P05가 아니다. 검사 코드가 producer Rust를 import/실행하지 않는다. 로컬 기존 jsonschema의 Draft202012Validator로 전달된 JSON shape를 검사하고, 별도 Fraction 계산과 직접 입력으로 작성 데이터 참조/한도/기대값을 대조한다. 일반 decimal→fixed 변환/전체 런타임 의미 검증을 대신하지 않는다.

| 명령 (지정WT cwd) | 종료 코드 | 증거·결과 |
|---|---|---|
| python -X utf8 .../producer-5577-preparation/test_candidate.py (작성 전) | 1 | candidate-red.log, economy 입력 부재로4tests 오류 |
| python -X utf8 .../producer-5577-preparation/build_candidate.py | 0 | build-candidate.log; producer12원문·원ZIP/준비16보존, 후보39파일(원21+새18) |
| python -X utf8 .../producer-5577-preparation/test_candidate.py (작성 후) | 0 | candidate-green-attempt1.log;4tests |
| 같은 test_candidate.py (custody 검사 추가 후) | 0 | candidate-green-with-custody.log;5tests, 별도오류입력21개 거부 |
| python -X utf8 tools/check_docs.py (후속 로그/ADR 작성 후) | 0 | docs-after.log; 오류0/경고0 |

실제 argv/cwd/exit·실행HEAD/source·한계는 `commands.json`에 있다. 테스트 이름은 `test_req_cnt_01_actual_six_nation_twelve_state_context`, `test_req_gen_03_supplied_economy_shape_and_exact_authored_values`, `test_req_gen_03_independent_bad_input_rejections`, `test_req_gen_03_ko_en_all_actual_key_references`, `test_original_checkpoint_source_bytes_and_candidate_m1_preserved`다. 추가 custody 검사를 위한 재실행이며 기존 검사를 약화하지 않았다.

`negative-input-observations.json`은21개 원변형입력 전체와 거부 이유를 남긴다: unknown필드/음수·0비용/국가·주누락/미등록building·resource/법령미존재·범주오류/배분합·하한/PC상한/NaN·Qtyoverflow/단계중복/음수reserved/초기슬롯초과/정확infra factor누락/at_war=false 미지원/조건law미존재/null. 실제 loader 거부라고 쓰지 않으며 이후 finalproducer에서 같은 입력을 독립native로 검사해야 한다.

`independent-initial-expectations.json`은 자체산술 기대이며 엔진 DTO가 아니다. ARA/BEL/CER/DOR/ELA/FAR의 초기 IC는24/32/40/24/32/40, 인구252000/300000/348000/396000/444000/492000, steel일산8/16/8/16/8/16, 징병1/16 capacity15750/18750/21750/24750/27750/30750이다. committed/reserved0으로 부대/훈련을 재현하지 않았다. 실제 producer의 같은 값·rawbits·원장/phase/save 일치는 후속 검증 항목이다.

### 보존·한계·부모에 필요한 후속

- 기존70파일과 candidate 안의 원팩21파일 bytes/SHA가 동일하다. 원 준비16파일·6국/기하 bytes·원ZIP50627B/SHA가 그대로이며 새locale는 후보복사에만5키를 추가했다. 원4983checkpoint·실패/native실패·골든/fixture/ASSETS master를 변경하지 않았다.
- 보존 묶음: `.../producer-5577-preparation/WP-23-candidate-5577.zip`, 467418bytes/54members/SHA256 `f9f5e0ab5933910f8b294603f4e1eed684c6f6fa3542a9f95547cadf48c8afbc`. 후보39파일·원authoring·builder/test·RED/GREEN·21원입력·source custody·command/manifest를 포함한다. producer 제품코드는 포함하지 않는다. `archive-manifest.json`과 `candidate-inventory.json`에서 원/새파일을 구별한다. 전체candidate content hash를 실제 engine identity로 산출하지 않았다.
- **최종 producer 인수 필요:** actual 최종schema/version·유효 독립P05/main통합 base·save/host/repro/query/command·조건capability 계약. 첫5577이 후속 변경되면 이 source계약/후보를 보존하고 새namespace에서 차이를 인수한다. 현재브랜치나 main에 미검증producer를 병합하지 않는다.
- **shared 최소변경 필요:** `common/resources.toml`의 기존steel1개 및 `common/buildings.toml`의 기존industry1개를 유지했다. 5자원 최소세트의 나머지4개/추가건물은 실제 `map.rs::registry`의 pack전역 경로와 충돌한다. 새지원경로나 전역등록file/ID변경 소유를 부모가 고정해 주어야 작성 가능하다. 임의추가/빈값·가짜별도registry로 우회하지 않는다.
- **REQ-GEN-03 누락:** 후보의 날짜/정부·이념이름/지형/현재resource·building/economy 입력은 data authored 단계다. 장비/대대·생산·훈련·외교·항복·의제·연구·AI/UI는 실제consumer 미인수이므로 작성/실행 성공으로 세지 않는다. 실제 새m2 strict/run/query/save/freshnative/repro/canonical/hash·기존회귀와 부모asset합류는 최종producer 인수 뒤 수행한다.
- 이번 후속은 문서checkpoint만 자기branch에 남긴다. 실제 source/native CI/mainCI·전체 W2/M2·독립PASS·통합을 선언하지 않는다.

## Registry append 추가소유 초안 — 앞선 후보 보존

2026-10-08 부모는 기존 단일registry 두 경로의 **ignored append 후보** 작성만 추가 인수했다. tracked 실제append 권한은 최종WP14 독립PASS/main통합 뒤의 producer 인수 프롬프트에서 따로 받는다. 새namespace는 `target/evidence/WP-23-M2-r2/registry-append-draft-5577/`다. 실행HEAD는 `4bfff62e9b123e42d63a2d55ded5cefa0e324cf8`, producer source는 계속5577 첫계약이며 native 미검증이다.

**절 번호 정정 기록:** 추가 지시 원메시지는 5자원/건설대상을01§4.2로 표현했다. 부모 후속메시지와 현행 문서 대조로 정확한 위치는 **01§4.3 ECO-4/6**이며 §4.2는 국가정치다. 뜻·승인범위는 바꾸지 않았다. 앞선메시지/4983준비/첫5577후보·원출력·ZIP은 덮지 않았고 이 절과 새SOURCES/support-boundary.json에 정정을 남긴다.

### 최소 파일 변경 후보

| 경로 | 원문·append/입력 | 실제지원·후속 |
|---|---|---|
| common/resources.toml | 원26B/SHA256 `514eee6a8dbc6835c6833c38dadbe5da7dae3d70d185aaecea73ba8dd62b61fc` + oil/aluminium/rubber/rare_metals의 ID-only4레코드 | steel 원레코드와 원문prefix 동일. 석유/철강/알루미늄/고무/희소금속5종. typed 일일흐름이며 비축/생산부족/시장 효과 아님 |
| common/buildings.toml | 원29B/SHA256 `23826071aeb8a2bc7a1f032ec2adcc23424e5f60ac579ca9ee18be5bd52816b8` + infrastructure ID-only1레코드 | industry 원레코드/prefix 동일. 미지원name_key 등의registry필드 추가 없음 |
| maps/m2/states.toml | 원12주/144기하/steel·industry·인구·infra 유지,4개추가resource값·초기infrastructure건물수준을별도 후보에 명시 | 주infra1/2와건물수준1/2 일치, 실제slot합3..5≤6. 원 M1 map/state/scenario/defines/locale는 변경 없음 |
| common/economy/m2.toml | infrastructure의 IC0/cap6/costs24·40·56·72/slots각1/infra_levels1·2·3·4; 두건물factor0..4=0.5/1/1.25/1.5/1.75 | actual5577 Building.infrastructure_levels 및 completion target 필드로표현. 실제건설명령/완성/효과검증은 finalproducer뒤. supplyhub/rail/port/fort ID·가짜0효과는 넣지 않음 |
| localisation/ko,en/registry_m2.ftl | 새leaf각6키:5자원명+인프라명 | 기존m2.ftl26키도 그대로. infrastructure name_key는actual경제참조. resource표시 ID→name resolver는미인수; registryname_key를발명하지않음 |
| SOURCES.md/ASSETS drafts | 새합성flows·infra 입력·절번호정정·native미완료; 새asset19초안+이미등록된공통2경로의metadata갱신초안 | master에동일path중복asset을추가하지않도록ASSETS-update-draft.toml을분리. 실제master수정은부모 |

`frozen-originals/common/*.toml`은 원rawbytes를 별도보존한다. `registry-prefix-custody.json`에서 두원문이 base2b5ca exactGitblob과같고 append후의prefix·원ID레코드가같음을확인했다. 초안registry의SHA는 resources `6a399bb96c7359531d5b4e99a9c7ddb4525dbca316574f4ad44055cb846e0d6e`, buildings `f4043e5d3855c4bb75b47769843f8f563d91d283a33c8a382a547655fbd1daaf`다. 생산팩 두file은원26/29bytes그대로다.

### 작성 검사·원명령·증거

| 명령 (전용WT cwd, 위namespace) | 종료 코드 | 원로그·대조 |
|---|---|---|
| python -X utf8 .../test_registry_draft.py (작성 전) | 1 | registry-red.log;4tests 입력부재 오류 |
| python -X utf8 .../build_registry_draft.py | 0 | build-registry.log;후보41files, activewrites0 |
| python -X utf8 .../test_registry_draft.py (작성 후) | 0 | registry-green.log;4tests |
| 같은 test_registry_draft.py (negative 추가) | 0 | registry-green-with-negatives.log;5tests, 원문변경·중복ID·누락ID·미지원name_key·잘못된ID5입력거부 |
| python -X utf8 tools/check_docs.py | 0 | docs-after.log; 오류0/경고0 |

`commands.json`에 실제argv/cwd/exit/HEAD/producer와native미실행을기록했다. `negative-registry-inputs.json`은5개원TOML과독립작성checker의거부이유를담는다. 기존작성checker의JSONshape/기본수치참조검사만재사용하고producerRust를import하거나실행하지않았다. 단계·infra값정렬 및주슬롯합은별도작성기대와대조했다. RED기대값·검사를약화하지않았다.

자원순서(steel/oil/aluminium/rubber/rare_metals)의 국가별 자체일산기대는 ARA(8,1,1,0,1), BEL(16,2,2,2,0), CER(8,1,2,2,1), DOR(16,1,1,2,1), ELA(8,1,2,1,1), FAR(16,2,2,2,1)이다. 기존IC 기대는24/32/40/24/32/40 그대로이며 새infraIC0에서추가산출이없다. 엔진조회DTO/생산충족률/실제게임효과를증명하는값은아니다.

보존묶음은 `.../registry-append-draft-5577/WP-23-registry-append-5577.zip`, **84991bytes/60members/SHA256 `9158c1ae7d112b64b52bda7237deaf9679364ffb7662cac1c0cca604aa0f3a75`**다. candidate41files·자체authoring4파일·build/test·RED/GREEN·원registry별도raw·prefixcustody·변형입력·지원한계·asset초안·원명령을담는다. 앞선첫candidate39files중5개만새복사에서변경하고새localeleaf2개를더했다. 원4983ZIP50627B·첫5577ZIP467418B 및해당source/원기하/70원파일이동일함을검사했다.

### 현재 한계·필요한 후속 인수

- **생산팩/sharedtracked 변경0.** 이 추가지시는ignored 후보권한이며 최종producer 뒤의명시tracked소유인수가필요하다. m0/m1/frozen·골든·expected·loader제품코드·설정/한도·CI·ASSETS master는바꾸지않았다.
- 실제append는같은pack의전체content_hash를바꾼다. resource/buildingregistry도새ID를포함하므로현재m1의실행·canonical/hash·저장context가원frozenfixture와같을것이라고가정하지않는다. 원동결identity/실행은원팩으로, 새currentm1과m2는새팩으로실제native 검사하고변화를별도기록해야한다. 골든재생성/기대값변경/가짜hash/force호환면제없음.
- 최종producer/P05/main통합/source인수→명시두file소유→actualstrict/run/query/건설infra완성·날짜/새save/freshrepro/canonicalhash→구호환/원M1회귀→새P05/P07/samemainCI가남아있다. 현재Python작성검사/JSONshape와docs checker로이절차를대신하지않는다.
- 보급거점·철도·항구·진지의실제효과/장비·대대·생산·시장·전쟁·항복·AI/UI는actualconsumer미인수다. 첫source문서의필드이름이나IC0으로가짜지원성공을선언하지않는다.
