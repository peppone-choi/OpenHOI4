# Original fictional names; no political mechanics implied.
nation-m2-ara = 아라벨
nation-m2-bel = 벨로라
nation-m2-cer = 세룬
nation-m2-dor = 도라벨
nation-m2-ela = 엘라라
nation-m2-far = 파룬
government-m2-assembly = 시민 회의
ideology-m2-cooperation = 협력
ideology-m2-autonomy = 자율
state-m2-01 = 아라벨 상부
state-m2-02 = 아라벨 하부
state-m2-03 = 벨로라 상부
state-m2-04 = 벨로라 하부
state-m2-05 = 세룬 상부
state-m2-06 = 세룬 하부
state-m2-07 = 도라벨 상부
state-m2-08 = 도라벨 하부
state-m2-09 = 엘라라 상부
state-m2-10 = 엘라라 하부
state-m2-11 = 파룬 상부
state-m2-12 = 파룬 하부

# Initial economic definitions; no production/training/war consumer claim.
building-m2-workshop = 작업 시설
law-m2-civic-economy = 시민 예산
law-m2-investment-economy = 투자 예산
law-m2-civic-service = 시민 복무
law-m2-extended-service = 확대 복무
