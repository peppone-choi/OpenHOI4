# Original fictional names; no political mechanics implied.
nation-m2-ara = Aravel
nation-m2-bel = Belora
nation-m2-cer = Cerun
nation-m2-dor = Doravel
nation-m2-ela = Elara
nation-m2-far = Farun
government-m2-assembly = Civic Assembly
ideology-m2-cooperation = Cooperation
ideology-m2-autonomy = Autonomy
state-m2-01 = Aravel Upper
state-m2-02 = Aravel Lower
state-m2-03 = Belora Upper
state-m2-04 = Belora Lower
state-m2-05 = Cerun Upper
state-m2-06 = Cerun Lower
state-m2-07 = Doravel Upper
state-m2-08 = Doravel Lower
state-m2-09 = Elara Upper
state-m2-10 = Elara Lower
state-m2-11 = Farun Upper
state-m2-12 = Farun Lower

# Initial economic definitions; no production/training/war consumer claim.
building-m2-workshop = Workshop
law-m2-civic-economy = Civic Budget
law-m2-investment-economy = Investment Budget
law-m2-civic-service = Civic Service
law-m2-extended-service = Extended Service
