import subprocess,sys,json,pathlib,hashlib,os,shutil
root=pathlib.Path.cwd(); out=root/'target/evidence/WP-13-P06-2'/sys.argv[1]; out.mkdir(parents=True,exist_ok=False)
cmd=sys.argv[2:]; executable=pathlib.Path(cmd[0]); executable=executable if executable.is_file() else pathlib.Path(shutil.which(cmd[0]) or cmd[0]); exe_sha=hashlib.sha256(executable.read_bytes()).hexdigest() if executable.is_file() else None; env=os.environ.copy(); env['CARGO_TARGET_DIR']=str(root/'target'); env['PYTHONIOENCODING']='utf-8'
(out/'command.json').write_text(json.dumps({'cmd':cmd,'cwd':str(root),'head':subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD']).decode().strip(),'status':subprocess.check_output(['git','--no-optional-locks','status','--porcelain']).decode(),'env':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}},ensure_ascii=False,indent=2),encoding='utf8')
with (out/'stdout.txt').open('wb') as stdout, (out/'stderr.txt').open('wb') as stderr:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr); pid=p.pid; code=p.wait()
(out/'result.json').write_text(json.dumps({'pid':pid,'exit':code,'executable':str(executable.resolve()),'executable_sha256_before':exe_sha,'executable_sha256_after':hashlib.sha256(executable.read_bytes()).hexdigest() if executable.is_file() else None}),encoding='utf8')
print(json.dumps({'cmd':cmd,'pid':pid,'exit':code,'out':str(out)})); print((out/'stdout.txt').read_text(encoding='utf8',errors='replace')[-1800:]); print((out/'stderr.txt').read_text(encoding='utf8',errors='replace')[-1800:]); sys.exit(code)
