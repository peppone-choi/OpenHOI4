import json,shutil,hashlib,zipfile
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/WP-13-P06-2';parent=Path('E:/openhoi/docs/plans/evidence/M2-r2-a652-Trigger-CI-FAIL')
runner=(root/'target/evidence/WP-13-P06-1/run.py').read_text()
(out/'run.py').write_text(runner.replace('WP-13-P06-1','WP-13-P06-2'),encoding='utf-8')
snapshot=(root/'target/evidence/WP-13-P06-1/snapshot.py').read_text()
(out/'snapshot.py').write_text(snapshot.replace('WP-13-P06-1','WP-13-P06-2'),encoding='utf-8')
custody=json.loads((parent/'custody.json').read_text(encoding='utf-8'))
digest=lambda raw:hashlib.sha256(raw).hexdigest()
assert digest((parent/'originals.zip').read_bytes())==custody['ZIP_sha256']=='5bf1e3a4c409a4e9157dfe33403d565377e00ee2d9b886a9b0acc53a636df1df'
original=out/'original-ci-fail-readonly';original.mkdir(exist_ok=False)
with zipfile.ZipFile(parent/'originals.zip') as archive:
    for entry in custody['files']:
        raw=archive.read(entry['path']);assert len(raw)==entry['bytes'] and digest(raw)==entry['sha256'],entry['path']
    for name in ('compare-job.log','exact-workflow.yml','parent-actual-three-OS-compare.receipt.json','parent-actual-three-OS-compare.stdout','parent-actual-three-OS-compare.stderr','artifacts.json','run.json','jobs.json'):
        (original/name).write_bytes(archive.read(name))
    receipt=json.loads(archive.read('parent-actual-three-OS-compare.receipt.json'))
    stdout=archive.read('parent-actual-three-OS-compare.stdout').decode()
    results={runner:json.loads(archive.read(f'actual-trigger-artifacts/trigger-{runner}/result.json')) for runner in ('ubuntu-latest','windows-latest','macos-latest')}
    assert {r['head'] for r in results.values()}=={'a652af2c7b1271edae58f76e7d09409b040059e4'}
    assert {r['platform'] for r in results.values()}=={'Linux','Windows','Darwin'}
    assert all(not r['dirty'] for r in results.values())
shutil.copyfile(parent/'custody.json',original/'custody.json')
shutil.copyfile(parent/'README.md',original/'README.md')
audit={'original_zip_sha256':custody['ZIP_sha256'],'all_original_files_verified':len(custody['files']),
       'mismatches':0,'parent_native_compare_receipt':receipt,'parent_native_compare_stdout':stdout,
       'actual_producer_platforms':{k:{'head':v['head'],'platform':v['platform'],'dirty':v['dirty']} for k,v in results.items()},
       'original_ci_remains':'FAIL; parent ignored-path native0 is a separate manual comparison'}
(out/'original-ci-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps(audit))
