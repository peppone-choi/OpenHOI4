import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/WP-13-P06-2';seal=root/'target/evidence/WP-13-P06-2-seal'
seal.mkdir(exist_ok=False)
digest=lambda raw:hashlib.sha256(raw).hexdigest()
before=json.loads((out/'final-source-before.json').read_text(encoding='utf-8'))
after=json.loads((out/'final-source-after.json').read_text(encoding='utf-8'))
assert before==after and before['status']==before['diff']==before['cached']==''
assert (out/'final-source-before.index').read_bytes()==(out/'final-source-after.index').read_bytes()
entries=[]
for path in sorted(out.rglob('*')):
    if not path.is_file():continue
    raw=path.read_bytes();entries.append({'path':path.relative_to(out).as_posix(),'bytes':len(raw),'sha256':digest(raw)})
manifest={'head':before['head'],'scope':'all original P06-2 evidence existing before seal; separate seal receipts/identity, no self hashes',
          'own_new_actual_3os_claim':False,'original_ci_fail_preserved':True,'files':entries}
manifest_path=seal/'SHA256SUMS.json';manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
zip_path=seal/'originals.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for entry in entries:archive.write(out/entry['path'],entry['path'])
    archive.write(manifest_path,'SHA256SUMS.json')
with zipfile.ZipFile(zip_path) as archive:
    assert len(archive.namelist())==len(entries)+1
    assert set(archive.namelist())=={x['path'] for x in entries}|{'SHA256SUMS.json'}
    assert archive.read('SHA256SUMS.json')==manifest_path.read_bytes()
    for entry in entries:
        raw=archive.read(entry['path']);assert len(raw)==entry['bytes'] and digest(raw)==entry['sha256'],entry['path']
identity={'head':before['head'],'files':len(entries),'zip_members':len(entries)+1,'zip_bytes':zip_path.stat().st_size,
          'zip_sha256':digest(zip_path.read_bytes()),'manifest_bytes':manifest_path.stat().st_size,
          'manifest_sha256':digest(manifest_path.read_bytes()),'all_member_bytes_sha_verified':True,
          'source_before_after_equal':True,'tracked_count':len(before['tracked']),'raw_index_sha256':before['raw_index_sha256'],
          'own_new_actual_3os_claim':False,'original_ci_fail_preserved':True}
(seal/'ZIP-IDENTITY.json').write_text(json.dumps(identity,indent=2),encoding='utf-8')
print(json.dumps(identity))
