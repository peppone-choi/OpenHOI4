import ast,hashlib,importlib.util,json,subprocess,shutil
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/WP-13-P06-2'
spec=importlib.util.spec_from_file_location('gate',root/'crates/oh_sim/tools/check_trigger_determinism.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
def load(relative):return json.loads((out/relative).read_text(encoding='utf-8'))
allowed={'.github/workflows/trigger-determinism.yml','crates/oh_sim/tests/test_trigger_evidence.py',
         'docs/plans/WP-13-schema.md','docs/adr/ADR-1301-trigger-end-state.md','docs/worklog/WP-13.md'}
base='de0e53058c92d91a6a0b6c30805a6b2ea77dde9d'
before=load('final-source-before.json');current=gate.identity();intake=load('intake-source.json')
assert current==before and current['status']==current['diff']==current['cached']==''
changed=set(gate.git('diff','--name-only',base,'HEAD').splitlines())
assert changed==allowed
assert intake['head']==base and set(intake['tracked'])==set(current['tracked'])
protected=[p for p in current['tracked'] if p not in allowed and current['tracked'][p]!=intake['tracked'][p]]
assert not protected
def old_file(relative):return subprocess.check_output(['git','--no-optional-locks','show',base+':'+relative],cwd=root)
workflow='.github/workflows/trigger-determinism.yml'
old=old_file(workflow)
expected=old.replace(b'          path: trigger-evidence',b'          path: target/trigger-evidence').replace(b'compare --root trigger-evidence',b'compare --root target/trigger-evidence')
assert (root/workflow).read_bytes().replace(b'\r\n',b'\n')==expected,'only two workflow paths may change'
assert (root/'docs/worklog/WP-13.md').read_bytes().replace(b'\r\n',b'\n').startswith(old_file('docs/worklog/WP-13.md'))
def test_bodies(source):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
old_tests=test_bodies(old_file('crates/oh_sim/tests/test_trigger_evidence.py').decode())
new_tests=test_bodies((root/'crates/oh_sim/tests/test_trigger_evidence.py').read_text())
assert len(old_tests)==12 and len(new_tests)==16 and all(new_tests[name]==body for name,body in old_tests.items())
commands={}
for folder in sorted(out.iterdir()):
    if not folder.is_dir() or not (folder/'command.json').is_file() or not (folder/'result.json').is_file():continue
    command=json.loads((folder/'command.json').read_text());result=json.loads((folder/'result.json').read_text())
    commands[folder.name]={'command':command,'result':result}
    if folder.name.startswith('final-'):
        assert result['exit']==0 and result['pid']>0,(folder.name,result)
        assert command['head']==current['head'] and command['status']=='',folder.name
        assert result['executable_sha256_before']==result['executable_sha256_after']
assert '233 passed' in (out/'final-client-test/stdout.txt').read_text(encoding='utf-8')
assert 'Ran 16 tests' in (out/'final-comparer-tests/stderr.txt').read_text(encoding='utf-8')
receipts={}
for path in sorted((out/'final-public-receipts').rglob('receipt.json')):
    r=json.loads(path.read_text());relative=path.relative_to(out/'final-public-receipts').as_posix();receipts[relative]=r
    assert r['source_before']==r['source_after'] and r['pid']>0 and len(r['executable_sha256'])==64
    assert r['synthetic_os_labels']
pair='test_public_workflow_download_keeps_source_clean/'
legacy=receipts[pair+'legacy/receipt.json'];new=receipts[pair+'workflow/receipt.json']
assert legacy['native_exit']==1 and new['native_exit']==0
assert legacy['source_before']['head']==new['source_before']['head']
assert legacy['source_before']['index_sha256']==new['source_before']['index_sha256']
assert legacy['source_before']['status']=='?? trigger-evidence/' and new['source_before']['status']==''
for name in ('test_public_all_same_stale_head_is_refused','test_public_dirty_current_source_is_refused','test_public_legacy_unignored_download_is_rejected','test_public_workflow_path_missing_os_is_rejected','test_public_workflow_path_resigned_invalid_save_is_rejected'):
    assert receipts[name+'/receipt.json']['native_exit']==1
v4,cases=gate.verify_folder(out/'final-trigger');assert v4['head']==current['head'] and not v4['dirty']
for version in ('v2','v3'):
    assert load(f'final-{version}-capture/stdout.txt')==load(f'final-{version}-resume/stdout.txt')
    assert commands[f'final-{version}-capture']['result']['pid']!=commands[f'final-{version}-resume']['result']['pid']
assert load('final-v2-original/stdout.txt')==json.loads((root/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json').read_text())
for name in ('final-frozen-v1','final-current-v1'):
    result=load(name+'/result.json');assert result['head']==current['head'] and not result['dirty']
import check_save_current
check_save_current.verify_folder(out/'final-current-v1')
servers={}
for path in sorted((out/'final-server').glob('*/result.json')):
    r=json.loads(path.read_text());servers[path.parent.name]=r
    assert r['head']==current['head'] and r['exit']==r['query_exit']==0 and r['http_status']==200
    assert r['save_preserved'] and r['pack_preserved']
assert len(servers)==4
for name,expected_hash in [('m0','b039d35666b77fc2'),('m1','b595dc2a1e5b4f8c')]:
    assert (out/f'final-{name}-1/stdout.txt').read_text().strip()==(out/f'final-{name}-2/stdout.txt').read_text().strip()==expected_hash
parent=Path('E:/openhoi/docs/plans/evidence/M2-r2-a652-Trigger-CI-FAIL')
digest=lambda raw:hashlib.sha256(raw).hexdigest()
assert digest((parent/'originals.zip').read_bytes())==load('original-ci-audit.json')['original_zip_sha256']
assert digest((root/'target/evidence/WP-13-P06-1/originals.zip').read_bytes())=='4967d3529a430049a5a264d885ee6e9b5b95bc03da5d80c6dc53649a38bdc5df'
source=out/'submitted-source';source.mkdir(exist_ok=False)
for relative in sorted(allowed):
    target=source/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/relative,target)
(out/'submitted-diff.patch').write_bytes(subprocess.check_output(['git','--no-optional-locks','diff','--binary',base,'HEAD'],cwd=root))
summary={'head':current['head'],'base':base,'branch':gate.git('branch','--show-current'),'clean':True,
         'tracked_count':len(current['tracked']),'raw_index_sha256':current['raw_index_sha256'],
         'source_before_equal':True,'changed_files':sorted(changed),'protected_files_verified':len(current['tracked'])-len(allowed),
         'protected_sha_mismatches':protected,'workflow_only_two_paths_changed':True,'original_test_bodies_preserved':len(old_tests),
         'worklog_append_only':True,'red_native_exit':1,'green_native_exit':0,'comparer_tests':16,'client_tests':233,
         'same_head_index_payload_relocation_asserted':True,'legacy_and_workflow_public_receipts':{'legacy':legacy,'workflow':new},
         'public_negative_receipts':receipts,'native_commands':commands,'actual_local_capture':v4,'actual_servers':servers,
         'legacy_v1_v2_v3_and_frozen_v2_equal':True,'original_ci_custody':load('original-ci-audit.json'),
         'original_ci_fail_preserved':True,'own_new_actual_3os_claim':False,'decision_needed':None,
         'pending':['new independent P05','P07 integration','new main6CI/actual3OS']}
(out/'final-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
assert gate.identity()==before
print(json.dumps({k:summary[k] for k in ('head','clean','tracked_count','raw_index_sha256','protected_files_verified','protected_sha_mismatches','workflow_only_two_paths_changed','original_test_bodies_preserved','comparer_tests','client_tests','own_new_actual_3os_claim')}))
