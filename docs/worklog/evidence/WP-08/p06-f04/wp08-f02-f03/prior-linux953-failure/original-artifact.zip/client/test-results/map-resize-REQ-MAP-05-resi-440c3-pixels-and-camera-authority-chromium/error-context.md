# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-resize.spec.ts >> REQ-MAP-05 resize and reset preserve presentation pixels and camera authority
- Location: e2e-m1/map-resize.spec.ts:7:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - heading "OpenHOI4" [level=1] [ref=e6]
      - paragraph [ref=e7]: Local scenario
    - generic [ref=e8]:
      - text: Language
      - combobox "Language" [ref=e9]:
        - option "English" [selected]
        - option "한국어"
  - status [ref=e10]: Connected
  - region "Time controls" [ref=e11]:
    - generic [ref=e12]:
      - generic [ref=e13]:
        - term [ref=e14]: Date
        - definition [ref=e15]: 2007-09-04
      - generic [ref=e16]:
        - term [ref=e17]: Hour
        - definition [ref=e18]: "19"
      - generic [ref=e19]:
        - term [ref=e20]: Tick
        - definition [ref=e21]: "67291"
      - generic [ref=e22]:
        - term [ref=e23]: Speed
        - definition [ref=e24]: "5"
    - generic [ref=e25]:
      - button "Resume" [ref=e26] [cursor=pointer]
      - button "Speed 1" [ref=e27] [cursor=pointer]: "1"
      - button "Speed 2" [ref=e28] [cursor=pointer]: "2"
      - button "Speed 3" [ref=e29] [cursor=pointer]: "3"
      - button "Speed 4" [ref=e30] [cursor=pointer]: "4"
      - button "Speed 5" [pressed] [ref=e31] [cursor=pointer]: "5"
  - generic [ref=e32]:
    - region "Province map" [ref=e33]:
      - navigation "Map modes" [ref=e34]:
        - button "Ownership" [ref=e35] [cursor=pointer]
        - button "Control" [ref=e36] [cursor=pointer]
        - button "Terrain" [ref=e37] [cursor=pointer]
        - button "States" [active] [pressed] [ref=e38] [cursor=pointer]
        - button "Reset view" [ref=e39] [cursor=pointer]
      - generic [ref=e42]:
        - generic [ref=e43]:
          - text: "Province:"
          - strong [ref=e44]: —
        - generic [ref=e45]: Click to select · Drag to pan · Scroll to zoom
        - button "Clear selection" [disabled] [ref=e46]
    - complementary [ref=e47]:
      - generic [ref=e48]:
        - region "Country" [ref=e49]:
          - heading "Country" [level=2] [ref=e50]
          - navigation [ref=e51]:
            - button "Northern Test Nation" [pressed] [ref=e52] [cursor=pointer]
            - button "Southern Test Nation" [ref=e53] [cursor=pointer]
          - heading "Northern Test Nation" [level=3] [ref=e54]
          - generic [ref=e55]:
            - generic [ref=e56]:
              - term [ref=e57]: Tag
              - definition [ref=e58]: NTH
            - generic [ref=e59]:
              - term [ref=e60]: Capital province
              - definition [ref=e61]: "10"
            - generic [ref=e62]:
              - term [ref=e63]: Government
              - definition [ref=e64]: Test Republic
          - heading "Ideology support (ratio)" [level=4] [ref=e65]
          - generic [ref=e66]:
            - generic [ref=e67]:
              - term [ref=e68]: Civic
              - definition [ref=e69]: "0.75"
            - generic [ref=e70]:
              - term [ref=e71]: Local
              - definition [ref=e72]: "0.25"
        - region "State" [ref=e73]:
          - heading "State" [level=2] [ref=e74]
          - navigation [ref=e75]:
            - button "Northern Test State" [pressed] [ref=e76] [cursor=pointer]
            - button "Southern Test State" [ref=e77] [cursor=pointer]
          - heading "Northern Test State" [level=3] [ref=e78]
          - generic [ref=e79]:
            - generic [ref=e80]:
              - term [ref=e81]: Owner
              - definition [ref=e82]: Northern Test Nation
            - generic [ref=e83]:
              - term [ref=e84]: Population
              - definition [ref=e85]: "1000"
            - generic [ref=e86]:
              - term [ref=e87]: Steel
              - definition [ref=e88]: "2"
            - generic [ref=e89]:
              - term [ref=e90]: Industry
              - definition [ref=e91]: "1"
          - group [ref=e92]:
            - generic "Show ledger for Infrastructure" [ref=e93] [cursor=pointer]:
              - text: Infrastructure
              - strong [ref=e94]: "1"
            - generic [ref=e95]:
              - heading "Value ledger" [level=2] [ref=e96]
              - paragraph [ref=e97]: "Tick: 67291"
              - generic [ref=e98]:
                - generic [ref=e99]:
                  - term [ref=e100]: Base value
                  - definition [ref=e101]: "1"
                - generic [ref=e102]:
                  - term [ref=e103]: Final value
                  - definition [ref=e104]: "1"
              - table [ref=e105]:
                - rowgroup [ref=e106]:
                  - row [ref=e107]:
                    - columnheader "Contribution" [ref=e108]
                    - columnheader "Operation" [ref=e109]
                    - columnheader "Value" [ref=e110]
                    - columnheader "Accumulated value" [ref=e111]
                - rowgroup [ref=e112]:
                  - row [ref=e113]:
                    - 'cell "Infrastructure Source: Base value" [ref=e114]':
                      - text: Infrastructure
                      - generic [ref=e115]: "Source: Base value"
                    - cell "Base value" [ref=e116]
                    - cell "1" [ref=e117]
                    - cell "1" [ref=e118]
          - table [ref=e119]:
            - rowgroup [ref=e120]:
              - row [ref=e121]:
                - columnheader "Province" [ref=e122]
                - columnheader "Owner" [ref=e123]
                - columnheader "Controller" [ref=e124]
            - rowgroup [ref=e125]:
              - row [ref=e126]:
                - cell "10" [ref=e127]
                - cell "Northern Test Nation" [ref=e128]
                - cell "Northern Test Nation" [ref=e129]
              - row [ref=e130]:
                - cell "20" [ref=e131]
                - cell "Northern Test Nation" [ref=e132]
                - cell "Southern Test Nation" [ref=e133]
  - link "Noto Sans KR · SIL Open Font License 1.1" [ref=e135] [cursor=pointer]:
    - /url: /fonts/OFL.txt
```