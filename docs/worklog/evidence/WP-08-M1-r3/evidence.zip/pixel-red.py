import subprocess,sys,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[2]
file=root/'client/e2e-m1/map-dpr.spec.ts'
source=file.read_bytes()
needle=b';for(let i=0;i<3;i++)expect(Math.abs(actual[i]-expected[i])).toBeLessThanOrEqual(1);'
assert source.count(needle)==1
fault=source.replace(needle,b';actual[0]=expected[0]+2'+needle)
out=root/'target/m1-r3-p06/negative-red'
out.mkdir(parents=True,exist_ok=True)
(out/'original.spec.ts.txt').write_bytes(source)
(out/'fault.spec.ts.txt').write_bytes(fault)
try:
    file.write_bytes(fault)
    code=subprocess.run([sys.executable,str(root/'target/m1-r3-p06/run.py'),'negative-red'],cwd=root).returncode
finally:
    file.write_bytes(source)
    (out/'restoration.json').write_text(json.dumps({'original_sha256':hashlib.sha256(source).hexdigest(),'fault_sha256':hashlib.sha256(fault).hexdigest(),'restored_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'scope':'single decoded PNG red channel observation +2; original unchanged Node assertion ±1; no renderer/backend/authority/wire/timeout change'},indent=2))
assert code==1, f'negative must fail assertions: {code}'
