import { defineConfig } from '../../client/node_modules/@playwright/test';
export default defineConfig({testDir:'../../client/e2e-m1',testMatch:'dpr-observation-negative.spec.ts',workers:1,projects:[{name:'chromium',use:{browserName:'chromium'}}]});
