import os,subprocess,json,hashlib,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'target/m1-r3-p06'
env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env)
baseline='688b3539e2df4ac5451e154e1d379a9ff21fa47b'
head=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain=v1').decode().strip()
assert head=='0ab691d958a96e79f5f421004801a72173870d58' and not status
names=git('diff','--name-only',baseline,head).decode().splitlines()
expected={'client/e2e-m1/map-dpr.spec.ts','client/e2e-m1/dpr-observation.ts','client/e2e-m1/dpr-observation-negative.spec.ts','docs/plans/WP-08-M1-r3-schema.md','docs/adr/ADR-0804-DPR-epoch-observation.md','docs/worklog/WP-08.md'}
assert set(names)==expected
source= json.loads((out/'source-assertion-audit.json').read_text(encoding='utf-8'))
for name,sha in source['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha
diff=git('diff','--binary',baseline,head)
(out/'EXACT-DIFF.patch').write_bytes(diff)
commands={p.parent.name:json.loads(p.read_text(encoding='utf-8'))['exit'] for p in out.glob('*/result.json')}
idx=Path(git('rev-parse','--git-path','index').decode().strip())
handoff={'role':'P06 implementation evidence, not independent PASS/gate','base':baseline,'commit':head,'branch':git('branch','--show-current').decode().strip(),'cwd':str(root),'status':status,'tracked_diff':names,'diff_sha256':hashlib.sha256(diff).hexdigest(),'raw_index_sha256':hashlib.sha256(idx.read_bytes()).hexdigest(),'commit_files_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in names},'test_source_matches_recorded_execution':True,'commands':commands,'results':'M0 full60/60 once; M1 full205/205 once; observer4/4; Edge valid body1/1; original RGB fault1FAIL then byte restoration; unit130/workspace108/fmt/clippy/typecheck/finalbuild/docsPASS; hashM0 b039d35666b77fc2 x2, actualM1 b595dc2a1e5b4f8c x2; proto content+rawindex identical','limitations':['source750 Edge1FAIL unresolved/unreproduced; no receiver/product fix','old exact6b6 M1 FAIL preserved; local Windows one pass cannot prove intermittent failure solved/Linux performance/GPU driver cause','initial observation/Edge preparation 0case errors, build stdout and docs decoding wrapper errors preserved; actual compiler/checker exits distinguished','fixed ignored target/wp05/default save artifacts use original paths, configurable all8 evidence absolute; collected browser copies explicit','no freshP05/P07/normal same-main CI/P12; no merge/push/new sessions/goals/global harness'],'evidence_root':str(out),'negative_reproduction':'ignored observation.config.ts runs tracked actual DOM guards; production suites unchanged. pixel-red.py shows temporary original PNG observation +2 and finally byte restore; do not run injection in verify worktree because P05 tracked writes invalidate verification. Inspect recorded red and run safe guards instead.'}
(out/'FINAL-HANDOFF.json').write_text(json.dumps(handoff,indent=2),encoding='utf-8')
files=[p for p in out.rglob('*') if p.is_file() and not any(part in ['tmp','temp','pwtest_cache_dir','__pycache__'] for part in p.relative_to(out).parts) and p.name not in ['SHA256SUMS.json','evidence.zip','ZIP-SHA256.json']]
manifest={'commit':head,'files':[{'path':str(p.relative_to(out)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]}
(out/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(out/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as zip:
    for p in files+[out/'SHA256SUMS.json']:zip.write(p,str(p.relative_to(out)).replace('\\','/'))
zipsha=hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest()
(out/'ZIP-SHA256.json').write_text(json.dumps({'sha256':zipsha,'bytes':(out/'evidence.zip').stat().st_size,'members':len(files)+1,'commit':head},indent=2),encoding='utf-8')
assert git('status','--porcelain=v1').decode().strip()==''
print(json.dumps({'commit':head,'tracked_files':len(names),'evidence_files':len(files),'zip_bytes':(out/'evidence.zip').stat().st_size,'zip_sha256':zipsha,'clean':True},indent=2))
