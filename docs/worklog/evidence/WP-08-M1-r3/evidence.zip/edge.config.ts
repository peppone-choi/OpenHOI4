import { defineConfig } from '../../client/node_modules/@playwright/test';
import original from '../../client/playwright.m1.config';
import { resolve } from 'node:path';
export default defineConfig({...original,testDir:'./edge-source',testMatch:'edge.spec.ts',webServer:{...original.webServer,cwd:resolve(__dirname,'../../client')}});
