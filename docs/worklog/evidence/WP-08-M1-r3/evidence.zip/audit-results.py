import json,math,hashlib,subprocess
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[2];out=root/'target/m1-r3-p06'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def cases(suites):
    result=[]
    for suite in suites:
        for spec in suite.get('specs',[]):
            for t in spec['tests']:
                result.append({'file':spec['file'],'title':spec['title'],'project':t['projectName'],'status':t['status'],'results':[(r['status'],r['retry'],r['duration']) for r in t['results']]})
        result.extend(cases(suite.get('suites',[])))
    return result
summary={}
for label,count in [('m0',60),('m1',205),('observation-guards',4),('edge-observed',1)]:
    r=load(out/label/'report.json');c=cases(r['suites'])
    assert len(c)==count and r['stats']['expected']==count
    assert all(t['status']=='expected' and len(t['results'])==1 and t['results'][0][0:2]==('passed',0) for t in c)
    assert all(r['stats'][k]==0 for k in ['unexpected','skipped','flaky'])
    assert all(p['timeout']==30000 and p['retries']==0 for p in r['config']['projects'])
    summary[label]={'stats':r['stats'],'cases':c,'projects':[p['name'] for p in r['config']['projects']],'workers':r['config']['workers']}
red=load(out/'negative-red/report.json');assert red['stats']['unexpected']==1
restoration=load(out/'negative-red/restoration.json');assert restoration['original_sha256']==restoration['restored_sha256']
summary['negative_red']={'stats':red['stats'],'restored':restoration}
dpr=out/'m1/oh_map_dpr_evidence';rows=[];backends={}
for file in sorted(dpr.glob('*.json')):
    state=load(file);project,force=file.stem.rsplit('-',1)
    assert len(state['steps'])==(6 if project in ['chrome','edge','chromium'] else 1)
    assert state['errors']==[] and state['surface']['canvas'] is None
    assert state['resources']=={'media':0,'listeners':0,'observers':0,'rafs':0}
    first=state['steps'][0]
    for i,step in enumerate(state['steps']):
        before,after=step['epoch']['before'],step['epoch']['after']
        for epoch in [before,after]:
            assert epoch['hostCount']==epoch['canvasCount']==1
            assert all(epoch[k] is True for k in ['hostCurrent','connected','current'])
            assert epoch['backend']==step['backend'] and epoch['dpr']==step['dpr']
            assert epoch['box']==step['box'] and epoch['camera']==step['camera']
        assert step['camera']==first['camera'] and step['box']==first['box'] and step['authority']==first['authority']
        b=step['buffer'];assert b['width']==b['expectedWidth'] and b['height']==b['expectedHeight']
        assert step['resources']['listeners']==6 and step['resources']['observers']==1
        expected=step['expected'];assert expected==[77,111,155]
        assert all(abs(a-b)<=1 for a,b in zip(step['actual'],expected))
        if step['backend']=='webgl2':
            gpu=step['gpu'];assert gpu['error']==0 and gpu['lost'] is False
            assert all(abs(a-b)<=1 for a,b in zip(gpu['pixel'][:3],expected))
        else:assert step['backend']=='webgpu' and step['gpu'] is None
        shot=dpr/f'{project}-{force}-dpr{step["dpr"]}-{i}.png'
        with Image.open(shot) as image:
            image.load() # Independent full PNG decode, before sampling.
            assert (image.width,image.height)==(step['image']['width'],step['image']['height'])
            camera,box=step['camera'],step['box']
            x=(1-camera['x'])/camera['width']*box['width']+box['width']/2
            y=(1-camera['y'])/camera['height']*box['height']+box['height']/2
            viewport=before['viewport']
            if project in ['chrome','edge','chromium']:
                px=math.floor((box['x']+x)*image.width/viewport['width']);py=math.floor((box['y']+y)*image.height/viewport['height'])
            else:
                px=math.floor(x*image.width/box['width']);py=math.floor(y*image.height/box['height'])
            pixel=list(image.convert('RGB').getpixel((px,py)))
            assert pixel==step['actual'] and all(abs(a-b)<=1 for a,b in zip(pixel,expected))
        key=step['backend'];backends[key]=backends.get(key,0)+1
        rows.append({'project':project,'force':force,'dpr':step['dpr'],'step':i,'backend':key,'pixel':pixel,'coordinate':[px,py],'file':str(shot.relative_to(out)),'sha256':hashlib.sha256(shot.read_bytes()).hexdigest()})
assert len(rows)==40
summary['dpr']={'cases':len(list(dpr.glob('*.json'))),'steps':len(rows),'backends':backends,'decoded_PNGs':rows,'scope':'independent Pillow12.1.1 full PNG decode + same documented original coordinate; original rawGL and DOM assertions executed by Playwright; native DPR2 outside Chromium, not a live DPR claim'}
net=subprocess.check_output(['netstat','-ano','-p','TCP']).decode(errors='replace').splitlines()
listeners=[r.strip() for r in net if 'LISTENING' in r and len(r.split())>1 and any(r.split()[1].endswith(':'+str(p)) for p in [19591,19592,19593,19594])]
assert listeners==[]
summary['own_ports_after']={'listeners':listeners,'ports':[19591,19592,19593,19594],'scope':'SDK teardown; no existing preview touched'}
summary['command_results']={p.parent.name:load(p)['exit'] for p in out.glob('*/result.json')}
summary['proto']=load(out/'proto-after.json')
(out/'RESULTS-AUDIT.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'case_counts':{k:len(summary[k]['cases']) for k in ['m0','m1','observation-guards','edge-observed']},'dpr_steps':len(rows),'backends':backends,'own_listeners':listeners},indent=2))
