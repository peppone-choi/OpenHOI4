from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[2]
out=root/'target/m1-r3-p06/edge-source';out.mkdir(parents=True,exist_ok=True)
source=(root/'client/e2e-m1/map.spec.ts').read_text(encoding='utf-8')
relocated=source.replace("from './", "from '../../../client/e2e-m1/").replace("from '../src/", "from '../../../client/src/")
relocated=relocated.replace("from '@playwright/test'", "from '../../../client/node_modules/@playwright/test'").replace("from '@msgpack/msgpack'", "from '../../../client/node_modules/@msgpack/msgpack'")
relocated=relocated.replace('import.meta.dirname',json.dumps(str(root/'client/e2e-m1').replace('\\','/')))
observer=r'''
import { createHash } from 'node:crypto';
import { isServerMessage } from '../../../client/src/network';
const wireEvents:unknown[]=[];
const stamp=()=>({at:performance.now(),sequence:wireEvents.length});
test.beforeEach(async({page})=>{
 page.on('websocket',socket=>{
  wireEvents.push({...stamp(),event:'ws-open',url:socket.url()});
  for(const kind of ['framesent','framereceived'] as const)socket.on(kind,frame=>{
   const bytes=typeof frame.payload==='string'?Buffer.from(frame.payload):frame.payload;
   let value:unknown=null,error:unknown=null;try{value=decode(bytes);}catch(e){error=String(e);}
   wireEvents.push({...stamp(),event:kind,base64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex'),value,decodeError:error,serverShape:kind==='framereceived'?isServerMessage(value):null});
  });
  socket.on('close',()=>wireEvents.push({...stamp(),event:'ws-close'}));
  socket.on('socketerror',error=>wireEvents.push({...stamp(),event:'ws-error',error}));
 });
 page.on('response',r=>wireEvents.push({...stamp(),event:'http',url:r.url(),status:r.status()}));
 page.on('requestfailed',r=>wireEvents.push({...stamp(),event:'request-failed',url:r.url(),failure:r.failure()}));
 page.on('console',m=>wireEvents.push({...stamp(),event:'console',kind:m.type(),message:m.text()}));
 page.on('pageerror',e=>wireEvents.push({...stamp(),event:'pageerror',message:e.message}));
});
test.afterEach(async({page},info)=>{
 const ui=await page.evaluate(()=>({body:document.body.innerText,connection:document.querySelector('[data-testid="connection"]')?.textContent,tick:document.querySelector('[data-testid="tick"]')?.textContent,date:document.querySelector('[data-testid="date"]')?.textContent,hour:document.querySelector('[data-testid="hour"]')?.textContent,hostCount:document.querySelectorAll('[data-testid="province-map"]').length,dataset:{...(document.querySelector<HTMLElement>('[data-testid="province-map"]')?.dataset)},canvases:document.querySelectorAll('[data-testid="province-map"] canvas').length,pauseDisabled:document.querySelector<HTMLButtonElement>('[data-testid="pause"]')?.disabled,country:document.querySelector('[data-testid="country-panel"]')?.textContent,state:document.querySelector('[data-testid="state-panel"]')?.textContent})).catch(error=>({captureError:String(error)}));
 writeFileSync(`${evidence}/edge-timeline.json`,JSON.stringify({project:info.project.name,status:info.status,events:wireEvents,ui,scope:'nonintercepting WS/HTTP observer; no browser apply callback timestamps or native adapter-call instrumentation'},null,2));
});
'''
# Module-level hooks run around the original selected body; that body is unchanged.
(out/'edge.spec.ts').write_text(relocated+'\n'+observer,encoding='utf-8')
(out/'source-contract.json').write_text(json.dumps({'original_sha256':hashlib.sha256(source.encode()).hexdigest(),'relocated_sha256':hashlib.sha256(relocated.encode()).hexdigest(),'observer_sha256':hashlib.sha256(observer.encode()).hexdigest(),'adapterReject_body_unchanged':True,'relocation':'imports resolve original dependencies; unselected baseline import.meta.dirname restored to original absolute origin'},indent=2))
