import json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'target/m1-r3-p06'
old=subprocess.check_output(['git','show','HEAD:client/e2e-m1/map-dpr.spec.ts'],cwd=root).decode('utf-8')
new=(root/'client/e2e-m1/map-dpr.spec.ts').read_text(encoding='utf-8')
old_dom=[line.strip() for line in old.splitlines() if 'await expect(' in line or 'await expect.poll(' in line or 'if(cdp){expect(await old!' in line or 'if(gpu){expect(gpu.error)' in line]
assert all(line in new for line in old_dom)
assert 'actual[0]=expected[0]+2' not in new
cfg=subprocess.check_output(['git','diff','--','client/playwright.config.ts','client/playwright.m1.config.ts','.github/workflows','tools/wp08-dpr-diag'],cwd=root).decode('utf-8')
assert not cfg
files=['client/e2e-m1/map-dpr.spec.ts','client/e2e-m1/dpr-observation.ts','client/e2e-m1/dpr-observation-negative.spec.ts','client/src/proto/protocol.ts','client/package-lock.json','target/debug/oh_server.exe']
x={'original_dom_assertion_lines_preserved':len(old_dom),'original_png_RGB_assertion_preserved':';for(let i=0;i<3;i++)expect(Math.abs(actual[i]-expected[i])).toBeLessThanOrEqual(1);' in new,'config_workflow_diag_diff':cfg,'files':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},'original_dpr_fixture_sha256':hashlib.sha256(subprocess.check_output(['git','show','HEAD:client/e2e-m1/map-dpr.spec.ts'],cwd=root)).hexdigest(),'strict_template_sha256':hashlib.sha256(Path('E:/openhoi/.orchestrator/wt/WP-08-diagnostic-M1-r2/tools/wp08-dpr-diag/candidate-template.ts').read_bytes()).hexdigest()}
(out/'source-assertion-audit.json').write_text(json.dumps(x,indent=2),encoding='utf-8')
print(json.dumps(x,indent=2))
