import os,sys,json,subprocess,time,hashlib,socket
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'target/m1-r3-p06'
label=sys.argv[1]
env=os.environ.copy()
env['PATH']=r'C:\Users\user\.cargo\bin;C:\Program Files\nodejs;'+env['PATH']
env['GIT_OPTIONAL_LOCKS']='0'
env['PYTHONIOENCODING']='utf-8'
env['OH_BROWSER_PRODUCTS']='1'
ports={'negative-red':'19591','edge':'19592','edge-cwd':'19592','edge-observed':'19592','m0':'19593','m1':'19594'}
env['OH_TEST_PORT']=ports.get(label,'19591')
for key in ['OH_MAP_CAPABILITY_EVIDENCE','OH_MAP_RESIZE_EVIDENCE','OH_MAP_PIPELINE_EVIDENCE','OH_MAP_EVIDENCE','OH_MAP_REDIRECT_EVIDENCE','OH_MALFORMED_EVIDENCE','OH_E2E_EVIDENCE','OH_MAP_DPR_EVIDENCE']:
    p=OUT/label/key.lower();p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
for key in ['TMP','TEMP','PWTEST_CACHE_DIR']:
    p=OUT/label/key.lower();p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
cargo=r'C:\Users\user\.cargo\bin\cargo.exe'
npm=r'C:\Program Files\nodejs\npm.cmd'
npx=r'C:\Program Files\nodejs\npx.cmd'
commands={
 'ci':([npm,'ci'],ROOT/'client'),
 'unit':([npm,'test'],ROOT/'client'),
 'typecheck':([npm,'run','typecheck'],ROOT/'client'),
 'build':([npm,'run','build'],ROOT/'client'),
 'build-final':([npm,'run','build'],ROOT/'client'),
 'native':([cargo,'build','-p','oh_server'],ROOT),
 'fmt':([cargo,'fmt','--check'],ROOT),
 'clippy':([cargo,'clippy','--workspace','--','-D','warnings'],ROOT),
 'workspace':([cargo,'test','--workspace'],ROOT),
 'proto':([cargo,'run','-p','oh_proto','--example','generate'],ROOT),
 'docs':([sys.executable,'tools/check_docs.py'],ROOT),
 'docs-final':([sys.executable,'tools/check_docs.py'],ROOT),
 'docs-seal':([sys.executable,'tools/check_docs.py'],ROOT),
 'm0':([npx,'playwright','test','--config','playwright.config.ts','--output',str(OUT/label/'test-results'),'--reporter','line,json'],ROOT/'client'),
 'm1':([npx,'playwright','test','--config','playwright.m1.config.ts','--output',str(OUT/label/'test-results'),'--reporter','line,json'],ROOT/'client'),
 'negative-red':([npx,'playwright','test','--config','playwright.m1.config.ts','--project','chromium','--grep','DPR surface.*preferred','--output',str(OUT/label/'test-results'),'--reporter','line,json'],ROOT/'client'),
 'observation':([npx,'playwright','test','--config',str(OUT/'observation.config.ts'),'--output',str(OUT/label/'test-results'),'--reporter','line,json'],ROOT/'client'),
 'observation-guards':([npx,'playwright','test','--config',str(OUT/'observation.config.ts'),'--output',str(OUT/label/'test-results'),'--reporter','line,json'],ROOT/'client'),
 'edge':([npx,'playwright','test','--config',str(OUT/'edge.config.ts'),'--project','edge','--grep','adapterReject','--output',str(OUT/label/'test-results'),'--reporter','line,json'],ROOT/'client'),
}
if label.startswith('hash-'):
    pack=['--pack','data/packs/testland','--scenario','m1'] if 'm1' in label else ['--scenario','testland']
    commands[label]=([cargo,'run','-p','oh_cli','--','run',*pack,'--days','365','--seed','1','--hash-out'],ROOT)
if label in ['edge-cwd','edge-observed']: commands[label]=commands['edge']
cmd,cwd=commands[label]
if label in ports:
    with socket.socket() as check:
        check.bind(('127.0.0.1',int(env['OH_TEST_PORT'])))
env['PLAYWRIGHT_JSON_OUTPUT_FILE']=str(OUT/label/'report.json')
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,env=env,text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,env=env,text=True).strip()
ignore=subprocess.run(['git','check-ignore',str(OUT)],cwd=ROOT,env=env,capture_output=True,text=True)
if ignore.returncode: raise RuntimeError('output root must be ignored')
meta={'label':label,'cwd':str(cwd),'root':str(ROOT),'head':head,'status_before':status,'command':cmd,'env':{k:v for k,v in env.items() if k.startswith('OH_') or k in ['TMP','TEMP','PWTEST_CACHE_DIR','PLAYWRIGHT_JSON_OUTPUT_FILE','GIT_OPTIONAL_LOCKS']},'ignore':ignore.stdout,'default_outputs_reviewed':'npm pretest: Rust wire_fixtures; proto generate: src/proto; build: client/dist; Playwright: all eight evidence env absolute, network M0 target/wp05/browser.json also ignored; original timeout30s/expect5s/retries0/skip0; no browser flags changed'}
out=OUT/label;out.mkdir(parents=True,exist_ok=True)
(out/'context.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
start=time.monotonic()
with (out/'command.log').open('w',encoding='utf-8') as log:
    result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
meta.update(exit=result.returncode,seconds=round(time.monotonic()-start,3),status_after=subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,env=env,text=True))
(out/'result.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps({'label':label,'exit':result.returncode,'seconds':meta['seconds'],'log':str(out/'command.log')}),flush=True)
raw=(out/'command.log').read_bytes()
try: printed=raw.decode('utf-8')
except UnicodeDecodeError: printed=raw.decode('cp949')
print('\n'.join(printed.splitlines()[-12:]),flush=True)
sys.exit(result.returncode)
