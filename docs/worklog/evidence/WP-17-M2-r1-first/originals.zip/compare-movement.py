from pathlib import Path
import json,hashlib
root=Path('target/evidence/WP-17')
a=json.loads((root/'movement-process-1/capture.json').read_text(encoding='utf-8'))
b=json.loads((root/'movement-process-2/capture.json').read_text(encoding='utf-8'))
c=json.loads((root/'movement-resume.json').read_text(encoding='utf-8-sig'))
assert a==b==c
bytes1=(root/'movement-process-1/movement-v2.ohsave').read_bytes();bytes2=(root/'movement-process-2/movement-v2.ohsave').read_bytes();assert bytes1==bytes2
assert a['split']['dto']['units'][0]['elapsed']==4294967296
assert a['split']['dto']['units'][0]['province']==10
assert a['continuous']['dto']['units'][0]['province']==10
assert a['continuous']['dto']['units'][0]['route']==[]
assert a['continuous']['dto']['units'][0]['elapsed']==0
result={'repeat_and_fresh_process_dto_canonical_hash_equal':True,'split_hash':a['split']['hash'],'continuous_hash':a['continuous']['hash'],'v2_save_sha256':hashlib.sha256(bytes1).hexdigest(),'split_elapsed_raw':4294967296,'final_province':10,'final_route':[],'commands_remaining':len(a['continuous']['dto']['queue'])}
(root/'movement-process-compare.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
for name in ['docs/plans/WP-17-schema.md','docs/adr/ADR-1701-movement.md']:
 p=Path(name);s=p.read_text(encoding='utf-8');s=s.replace('해상/해협 규칙은 WP-31이며','해상 수송은 WP-31, strait 통과 규칙/계수와 담당은 미정이며');s+='\nstrait 누락 대조: 01 §4.1의 인접 crossing kind와 WP31 항구 간 해상수송은 같은 개념으로 추정하지 않는다. 현재 solver는 strait를 탐색 후보에서 제외한다(그 경계만 이어지면 NoPath). strait 통과 정책/계수·담당 WP는 결정 필요이며 해상수송에 임의 위임하지 않는다. sea/lake unit 위치 및 직접 육지 목적지는 InvalidReference, 실제 고립/impassable만의 연결은 NoPath, 보정 context 누락은 MissingContext로 구분한다.\n';p.write_text(s,encoding='utf-8')
