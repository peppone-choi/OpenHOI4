from pathlib import Path
p=Path('crates/oh_sim/src/movement.rs');s=p.read_text();s=s.replace('#[derive(Clone, Debug, Eq, PartialEq, Serialize)]\npub struct Unit {','''/// Read-only authority. Only the simulation command/phase can change it.
/// ```compile_fail
/// fn overwrite(unit: &mut oh_sim::movement::Unit) { unit.speed = oh_core::Fx::ONE; }
/// ```
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct Unit {''');p.write_text(s)
