from pathlib import Path
p=Path('crates/oh_sim/src/movement.rs');s=p.read_text();s=s.replace('''        self.route.iter().try_fold(-self.elapsed, |sum, l| {''','''        let remaining = self.elapsed.checked_neg().ok_or(MovementError::Overflow)?;
        self.route.iter().try_fold(remaining, |sum, l| {''');s=s.replace('''        let mut heap = BinaryHeap::from([Reverse((0i64, vec![start]))]);''','''        let mut adjacency: BTreeMap<ProvinceId, Vec<ProvinceId>> = BTreeMap::new();
        for e in &map.edges {
            let (a,b)=(ProvinceId(e.a),ProvinceId(e.b));
            if self.allowed.contains(&a) && self.allowed.contains(&b) && usable(map,a,b) {
                adjacency.entry(a).or_default().push(b);
                adjacency.entry(b).or_default().push(a);
            }
        }
        let mut heap = BinaryHeap::from([Reverse((0i64, vec![start]))]);''');a=s.index('            for e in &map.edges {',s.index('let mut heap'));b=s.index('                let next = cost',a);s=s[:a]+'''            for &b in adjacency.get(&a).into_iter().flatten() {
                if path.contains(&b) { continue; }
'''+s[b:];s=s.replace('''    map.provinces
        .iter()
        .any(|p| p.id == id.0 && p.kind == ProvinceKind::Land)''','''    map.province_index(id.0)
        .is_some_and(|i| map.provinces[usize::from(i)].kind == ProvinceKind::Land)''');p.write_text(s)
p=Path('crates/oh_save/tests/movement.rs');s=p.read_text();s=s.replace('''|d| d.units[0].elapsed = -1,''','''|d| d.units[0].elapsed = -1,
        |d| d.units[0].elapsed = i64::MIN,''');p.write_text(s)
p=Path('crates/oh_sim/src/lib.rs');s=p.read_text();s=s.replace('''        f.write_str(match self {''','''        if let Self::Movement(error) = self { return error.fmt(f); }
        f.write_str(match self {''',1);p.write_text(s)
