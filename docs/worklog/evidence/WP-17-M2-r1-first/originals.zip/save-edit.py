from pathlib import Path
p=Path('crates/oh_save/src/bounds.rs');s=p.read_text();s=s.replace('pub fn body(bytes: &[u8], limits: &Limits) -> Result<()> {','''pub fn body(bytes: &[u8], limits: &Limits) -> Result<()> { body_version(bytes, limits, 1) }
pub fn body_version(bytes: &[u8], limits: &Limits, version:u16) -> Result<()> {''');idx=s.rfind('    r.end()');s=s[:idx]+'''    if version == 2 {
        for _ in 0..r.entries(limits.queue_max_entries)? {
            r.number(64)?; r.number(16)?; r.number(64)?;
            match r.tag(3)? {
                0 => { r.boolean()?; }, 1 => {r.byte()?;},
                2 => {r.number(32)?;r.number(16)?;}, 3 => {r.number(32)?;},
                _ => unreachable!(),
            }
        }
        for _ in 0..r.entries(limits.map_entries_max)? {
            r.number(32)?;r.number(16)?;r.number(16)?;r.number(64)?;
            for _ in 0..r.entries(65536)? {r.number(16)?;}
            for _ in 0..r.entries(limits.map_entries_max)? {
                r.number(16)?;r.number(16)?;
                for _ in 0..4 {r.number(64)?;}
            }
            for _ in 0..r.entries(limits.map_entries_max)? {r.number(16)?;r.number(16)?;r.number(64)?;}
            r.number(64)?;
        }
    }
''' +s[idx:];p.write_text(s)
p=Path('crates/oh_save/src/lib.rs');s=p.read_text().replace('save_state::{DateV1, SimulationSaveV1}','save_state::{DateV1, SimulationSaveV1, SimulationSaveV2}');s=s.replace('pub const FORMAT_VERSION: u16 = 1;','pub const FORMAT_VERSION: u16 = 1;\n/// Additive format; legacy writers still produce version 1.\npub const MOVEMENT_FORMAT_VERSION: u16 = 2;')
a=s.index('    let dto = sim.export_save()?;');b=s.index('    if candidate.state_hash()',a)
s=s[:a]+'''    let version = if sim.movement().is_some() { MOVEMENT_FORMAT_VERSION } else { FORMAT_VERSION };
    let (body, candidate) = if version == MOVEMENT_FORMAT_VERSION {
        let dto = sim.export_save_v2()?;
        (serialize(&dto)?, Simulation::from_save_v2(dto, &context.restore)?)
    } else {
        let dto = sim.export_save()?;
        (serialize(&dto)?, Simulation::from_save(dto, &context.restore)?)
    };
'''+s[b:]
s=s.replace('        format_version: FORMAT_VERSION,','        format_version: version,',1).replace('    let body = serialize(&dto)?;\n','',1)
s=s.replace('    bounds::body(&body, limits)?;','    bounds::body_version(&body, limits, version)?;',1).replace('    bytes.extend_from_slice(&FORMAT_VERSION.to_le_bytes());','    bytes.extend_from_slice(&version.to_le_bytes());',1)
s=s.replace('if version != FORMAT_VERSION {','if ![FORMAT_VERSION, MOVEMENT_FORMAT_VERSION].contains(&version) {')
s=s.replace('    deserialize(h)\n}', '''    let header:HeaderV1=deserialize(h)?;
    if header.format_version != version {return Err("MetadataMismatch: format".into());}
    Ok(header)
}''',1)
s=s.replace('    let warnings = check_header(&header, context, limits, force)?;','    if header.format_version != version {return Err("MetadataMismatch: format".into());}\n    let warnings = check_header(&header, context, limits, force)?;',1)
a=s.index('    bounds::body(&body, limits)?;');b=s.index('    check_players(&header, &simulation)?;',a)
s=s[:a]+'''    bounds::body_version(&body, limits, version)?;
    let (base, dto2) = if version == MOVEMENT_FORMAT_VERSION {
        let dto:SimulationSaveV2=deserialize(&body)?;
        (dto.base.clone(), Some(dto))
    } else { (deserialize::<SimulationSaveV1>(&body)?, None) };
    if header.scenario_id != base.state.scenario
        || header.game_date != base.state.date
        || header.tick != base.state.tick
        || header.seed != base.state.seed
        || header.definitions_hash != base.world.as_ref().map(|w| w.definitions_hash)
    { return Err("MetadataMismatch: header/body".into()); }
    context.verify_unchanged()?;
    let simulation=match dto2 {
        Some(dto)=>Simulation::from_save_v2(dto,&context.restore)?,
        None=>Simulation::from_save(base,&context.restore)?,
    };
'''+s[b:]
s=s.replace('    if h.format_version != FORMAT_VERSION {','    if ![FORMAT_VERSION, MOVEMENT_FORMAT_VERSION].contains(&h.format_version) {',1)
p.write_text(s)
