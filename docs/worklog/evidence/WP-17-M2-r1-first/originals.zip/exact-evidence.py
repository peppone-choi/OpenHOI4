from pathlib import Path
import hashlib,json,subprocess,datetime
root=Path.cwd();out=root/'target/evidence/WP-17';exe=root/'target/debug/examples/movement_fixture.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
commands=[['capture',str(out/'exact-movement-1')],['capture',str(out/'exact-movement-2')],['resume',str(root/'data/packs/testland'),str(out/'exact-movement-1/movement-v2.ohsave')]]
records=[];outputs=[]
for i,args in enumerate(commands,1):
 before=sha(exe);proc=subprocess.Popen([str(exe),*args],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8');stdout,stderr=proc.communicate();
 (out/f'exact-movement-{i}.stdout.json').write_text(stdout,encoding='utf-8');(out/f'exact-movement-{i}.stderr.log').write_text(stderr,encoding='utf-8');
 records.append({'command':[str(exe),*args],'cwd':str(root),'pid':proc.pid,'exit':proc.returncode,'exe_sha256':before});assert proc.returncode==0;assert sha(exe)==before;outputs.append(json.loads(stdout))
assert outputs[0]==outputs[1]==outputs[2]
save1=out/'exact-movement-1/movement-v2.ohsave';save2=out/'exact-movement-2/movement-v2.ohsave';assert save1.read_bytes()==save2.read_bytes()
record={'head':head,'dirty':False,'platform':'Windows','runs':records,'split_hash':outputs[0]['split']['hash'],'continuous_hash':outputs[0]['continuous']['hash'],'save_sha256':sha(save1),'dto_canonical_hash_equal':True,'checked_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()}
(out/'exact-movement-result.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
