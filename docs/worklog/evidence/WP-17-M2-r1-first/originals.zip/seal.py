from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'target/evidence/WP-17'
manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'worktree':str(root),'status':subprocess.check_output(['git','status','--porcelain'],text=True),'evidence':[]}
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='SHA256-MANIFEST.json':manifest['evidence'].append({'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'SHA256-MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps({'head':manifest['head'],'clean':manifest['status']=='','evidence_files':len(manifest['evidence']),'manifest':str(out/'SHA256-MANIFEST.json')}))
