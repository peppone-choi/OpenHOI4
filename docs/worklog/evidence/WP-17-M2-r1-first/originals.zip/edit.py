from pathlib import Path
p=Path('crates/oh_sim/src/lib.rs');s=p.read_text(encoding='utf-8-sig')
s=s.replace('use oh_core::{NationId, SerializationError};','use oh_core::{DivisionId, NationId, ProvinceId, SerializationError};')
s=s.replace('pub mod ledger;','pub mod ledger;\npub mod movement;')
s=s.replace('    InvalidWorld,','    InvalidWorld,\n    Movement(movement::MovementError),',1)
s=s.replace('            Self::InvalidWorld =>','            Self::Movement(_) => "movement command or phase failed",\n            Self::InvalidWorld =>',1)
s=s.replace('    SetSpeed(u8),','    SetSpeed(u8),\n    Move { unit: DivisionId, destination: ProvinceId },\n    Stop { unit: DivisionId },',1)
s=s.replace('    world: Option<world::World>,','    world: Option<world::World>,\n    #[serde(skip_serializing_if = "Option::is_none")]\n    movement: Option<movement::Movement>,',1)
s=s.replace('            world: None,','            world: None,\n            movement: None,',1)
s=s.replace('    /// Read-only resume boundary:', '''    /// Trusted host initialization only. No client supplies speed or context.
    pub fn with_movement(scenario: String, date: Date, seed: u64, config: TimeConfig,
        world: world::World, movement: movement::Movement) -> Result<Self, Error> {
        movement.validate(&world).map_err(Error::Movement)?;
        let mut sim = Self::with_world(scenario, date, seed, config, world)?;
        sim.movement = Some(movement);
        Ok(sim)
    }
    pub fn movement(&self) -> Option<&movement::Movement> { self.movement.as_ref() }
    fn apply_movement(command: &Command, nation: NationId, world: Option<&world::World>,
        movement: Option<&mut movement::Movement>) -> Result<(), Error> {
        let (unit, destination) = match command {
            Command::Move { unit, destination } => (*unit, Some(*destination)),
            Command::Stop { unit } => (*unit, None),
            _ => return Ok(()),
        };
        movement.ok_or(Error::Movement(movement::MovementError::MissingContext))?
            .command(world.ok_or(Error::InvalidWorld)?, nation, unit, destination).map_err(Error::Movement)
    }
    /// Read-only resume boundary:''')
s=s.replace('        self.queue.insert(key, command);','''        if matches!(command, Command::Move { .. } | Command::Stop { .. }) {
            let mut preview = self.movement.clone();
            Self::apply_movement(&command, nation, self.world.as_ref(), preview.as_mut())?;
        }
        self.queue.insert(key, command);''',1)
s=s.replace('        let mut next_world = self.world.clone();','        let mut next_world = self.world.clone();\n        let mut next_movement = self.movement.clone();',1)
s=s.replace('                Command::SetSpeed(speed) => {','''                c @ (Command::Move { .. } | Command::Stop { .. }) =>
                    Self::apply_movement(c, *nation, next_world.as_ref(), next_movement.as_mut()),
                Command::SetSpeed(speed) => {''',1)
s=s.replace('            phases.extend([Phase::Movement, Phase::Combat, Phase::RetreatAndControl]);','''            phases.extend([Phase::Movement, Phase::Combat, Phase::RetreatAndControl]);
            if let Some(movement) = next_movement.as_mut() {
                movement.advance().map_err(Error::Movement)?;
            }''',1)
s=s.replace('        self.world = next_world;','        self.world = next_world;\n        self.movement = next_movement;',1)
p.write_text(s,encoding='utf-8')
p=Path('crates/oh_sim/src/formula.rs');s=p.read_text();s+='''
/// REQ-MIL-04: time factors, in the exact ADR-1701 evaluation order.
pub fn movement_hours(distance: Fx, speed: Fx, factors: crate::movement::Factors)
    -> Result<Fx, crate::movement::MovementError> {
    use crate::movement::MovementError;
    if distance <= Fx::ZERO || speed <= Fx::ZERO { return Err(MovementError::InvalidValue); }
    factors.validate()?;
    let mut value = distance.checked_div(speed).ok_or(MovementError::Overflow)?;
    for factor in [factors.terrain, factors.infrastructure, factors.supply, factors.river] {
        value = value.checked_mul(factor).ok_or(MovementError::Overflow)?;
    }
    if value <= Fx::ZERO { return Err(MovementError::InvalidValue); }
    Ok(value)
}
''';p.write_text(s)
p=Path('crates/oh_sim/src/save_state.rs');s=p.read_text();s=s.replace('    pub fn export_save(&self) -> Result<SimulationSaveV1, String> {','''    pub fn export_save(&self) -> Result<SimulationSaveV1, String> {
        if self.movement.is_some() { return Err("MovementRequiresV2".into()); }
        self.export_legacy_base()
    }
    fn export_legacy_base(&self) -> Result<SimulationSaveV1, String> {''');s=s.replace('            world,\n        })','            world,\n            movement: None,\n        })');p.write_text(s)
p=Path('crates/oh_sim/src/movement.rs');s=p.read_text(encoding='utf-8-sig');s=s.replace('NotOwner }','NotOwner, PendingMidEdgePolicy }');s=s.replace('  let keep=u.elapsed>Fx::ZERO;','  if u.elapsed>Fx::ZERO {return Err(MovementError::PendingMidEdgePolicy)}\n  let keep=false;');p.write_text(s)
