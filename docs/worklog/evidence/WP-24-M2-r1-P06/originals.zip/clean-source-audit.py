from pathlib import Path
import json, hashlib, zipfile, tomllib, subprocess
root=Path.cwd(); out=root/'target/evidence/WP-24-P06'
parent=Path('E:/openhoi/docs/decisions/evidence/historical-load-policy')
policy=tomllib.loads((root/'crates/oh_data/policies/legacy-validation.toml').read_text())
identity=json.loads((parent/'identity.json').read_text())
sources={s['id']:s['files'] for s in identity['original_sources']}
checks=[]
with zipfile.ZipFile(parent/'source-originals.zip') as archive:
    assert set(archive.namelist())=={s+'/'+f['path'] for s,files in sources.items() for f in files}
    for source in policy['sources']:
        assert source['files']==sources[source['id']]
        for f in source['files']:
            raw=archive.read(source['id']+'/'+f['path'])
            assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
            checks.append(dict(source=source['id'],**f))
assert len(checks)==22
assert {e['caller'] for e in policy['entries']}=={'server_startup','server_restore','cli_v1_resume'}
assert len(policy['entries'])==4
for e in policy['entries']:
    assert int(e['pack_content_hash'],16)==int(identity['pack_fnv64'][e['source_id']])
old=root/'target/evidence/WP-24'
manifest=json.loads((old/'evidence-sha256.json').read_text())
assert len(manifest['files'])==2722
for f in manifest['files']:
    raw=(old/f['path']).read_bytes()
    assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'],f['path']
result=dict(originals_checked=checks,original_evidence_files=2722,original_evidence_mismatches=0,
            policy_sha256=hashlib.sha256((root/'crates/oh_data/policies/legacy-validation.toml').read_bytes()).hexdigest(),
            source_archive_sha256=hashlib.sha256((parent/'source-originals.zip').read_bytes()).hexdigest(),
            head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
(out/'clean-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('original source files=22; original evidence files=2722; mismatches=0; callers=3; entries=4')
