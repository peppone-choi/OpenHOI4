from pathlib import Path
import os,subprocess,json
root=Path.cwd();out=root/'target/evidence/WP-24-P06';env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target')
env['OH_WP24_EVIDENCE_ROOT']=str(out/'generated')
steps=[('fmt',['cargo','fmt','--check']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('workspace',['cargo','test','--workspace','--locked']),('build',['cargo','build','-p','oh_server','-p','oh_cli','--locked']),
 ('native',['python','crates/oh_server/tests/pack_startup_native.py','--out',str(out/'adopted-native')]),
 ('frozen',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(out/'adopted-frozen')]),
 ('current',['cargo','run','-p','oh_save','--locked','--example','save_fixture','--','capture-current',str(out/'adopted-current')]),
 ('restart',['cargo','run','-p','oh_save','--locked','--example','save_fixture','--','resume',str(out/'adopted-current/pack'),str(out/'adopted-current/saved.ohsave')]),
 ('source-audit',['python',str(out/'source-audit.py')]),
 ('localisation',['python','tools/check_localisation.py','--out',str(out/'adopted-client-uses.json')]),
 ('python',['python','-m','unittest','discover','-s','tools/tests','-p','test_localisation.py','-v']),
 ('architecture',['python','tools/check_architecture.py']),('license',['cargo','deny','check','licenses','bans']),
 ('assets',['python','tools/check_assets.py','--release']),('docs',['python','tools/check_docs.py']),
 ('validate',['cargo','run','-p','oh_cli','--locked','--','validate','--deny-warnings','data/packs/testland']),
 ('legacy-validate',['cargo','run','-p','oh_cli','--locked','--','validate','--deny-warnings','data/packs/examples/m0/testland'])]
for scenario,extra in [('m0',[]),('m1',['--pack','data/packs/testland'])]:
 for i in [1,2]:steps.append((scenario+'-hash-'+str(i),['cargo','run','-p','oh_cli','--locked','--','run']+extra+['--scenario','testland' if scenario=='m0' else 'm1','--days','365','--seed','1','--hash-out']))
results=[]
for name,args in steps:
 with (out/('adopted-'+name+'.stdout')).open('wb') as so,(out/('adopted-'+name+'.stderr')).open('wb') as se:
  r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se)
 receipt=dict(command=args,cwd=str(root),exit=r.returncode,target=env['CARGO_TARGET_DIR'],test_evidence=env['OH_WP24_EVIDENCE_ROOT'],
  head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dirty=bool(subprocess.check_output(['git','status','--porcelain'],text=True)))
 (out/('adopted-'+name+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 expected=1 if name=='legacy-validate' else 0
 results.append(dict(name=name,exit=r.returncode,expected_exit=expected))
 print(name+' exit='+str(r.returncode),flush=True)
(out/'adopted-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(int(any(r['exit']!=r['expected_exit'] for r in results)))
