from pathlib import Path
import os,subprocess,json,sys,hashlib
root=Path.cwd();out=root/'target/evidence/WP-24-P06';env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target')
env['OH_WP24_EVIDENCE_ROOT']=str(out/'generated')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
before=dict(head=git('rev-parse','HEAD'),status=git('status','--porcelain'),tracked=git('ls-files','-s'),diff=git('diff','HEAD'))
assert not before['status'] and not before['diff']
steps=[('build',['cargo','build','-p','oh_server','-p','oh_cli','--locked']),
 ('native',['python','crates/oh_server/tests/pack_startup_native.py','--out',str(out/'clean-native')]),
 ('frozen',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(out/'clean-frozen')]),
 ('current',['cargo','run','-p','oh_save','--locked','--example','save_fixture','--','capture-current',str(out/'clean-current')]),
 ('restart',['cargo','run','-p','oh_save','--locked','--example','save_fixture','--','resume',str(out/'clean-current/pack'),str(out/'clean-current/saved.ohsave')]),
 ('docs',['python','tools/check_docs.py'])]
results=[]
for name,args in steps:
 with (out/('clean-'+name+'.stdout')).open('wb') as so,(out/('clean-'+name+'.stderr')).open('wb') as se:
  r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se)
 receipt=dict(command=args,cwd=str(root),exit=r.returncode,target=env['CARGO_TARGET_DIR'],test_evidence=env['OH_WP24_EVIDENCE_ROOT'],head=git('rev-parse','HEAD'),dirty=bool(git('status','--porcelain')))
 (out/('clean-'+name+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 results.append(dict(name=name,exit=r.returncode));print(name+' exit='+str(r.returncode),flush=True)
assert all(r['exit']==0 for r in results),results
sys.path.insert(0,str(root/'crates/oh_save/tools'))
from save_reference import verify_capture,verify_ledger,canonical,fnv
capture=json.loads((out/'clean-current/capture.json').read_text())
restart=json.loads((out/'clean-restart.stdout').read_text())
verify_capture(capture);verify_ledger(restart['initial']);verify_ledger(restart['resumed'])
assert capture['pid']!=restart['pid']
assert restart['initial']==capture['split'] and restart['resumed']==capture['continuous']
assert fnv(canonical(restart['initial']))==restart['initial_hash']==capture['split_hash']
assert fnv(canonical(restart['resumed']))==restart['resumed_hash']==capture['continuous_hash']
state=dict(capture_pid=capture['pid'],restart_pid=restart['pid'],initial_full_state_equal=True,resumed_full_state_equal=True,
 initial_hash=restart['initial_hash'],resumed_hash=restart['resumed_hash'],canonical_sha256=hashlib.sha256(canonical(restart['initial'])).hexdigest(),independent_canonical_and_ledger=True)
(out/'clean-current-full-state.json').write_text(json.dumps(state,indent=2)+'\n')
after=dict(head=git('rev-parse','HEAD'),status=git('status','--porcelain'),tracked=git('ls-files','-s'),diff=git('diff','HEAD'))
assert before==after
(out/'clean-identity.json').write_text(json.dumps(dict(before=before,after=after,results=results,unchanged=True),indent=2)+'\n')
print('clean exact HEAD unchanged; fresh current full state/canonical/ledger/hash PASS',flush=True)
