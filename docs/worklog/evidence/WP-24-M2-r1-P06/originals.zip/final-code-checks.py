from pathlib import Path
import os,subprocess,json
root=Path.cwd();out=root/'target/evidence/WP-24-P06';env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target')
env['OH_WP24_EVIDENCE_ROOT']=str(out/'generated')
steps=[('fmt',['cargo','fmt','--check']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('workspace',['cargo','test','--workspace','--locked']),('build',['cargo','build','-p','oh_server','-p','oh_cli','--locked'])]
results=[]
for name,args in steps:
 with (out/('final-'+name+'.stdout')).open('wb') as so,(out/('final-'+name+'.stderr')).open('wb') as se:
  r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se)
 receipt=dict(command=args,cwd=str(root),exit=r.returncode,target=env['CARGO_TARGET_DIR'],test_evidence=env['OH_WP24_EVIDENCE_ROOT'],
  head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dirty=bool(subprocess.check_output(['git','status','--porcelain'],text=True)))
 (out/('final-'+name+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 expected=1 if name=='legacy-validate' else 0
 results.append(dict(name=name,exit=r.returncode,expected_exit=expected))
 print(name+' exit='+str(r.returncode),flush=True)
(out/'final-code-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(int(any(r['exit']!=r['expected_exit'] for r in results)))
