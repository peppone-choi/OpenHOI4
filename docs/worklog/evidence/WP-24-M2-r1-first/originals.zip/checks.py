import subprocess,json,os
from pathlib import Path
root=Path.cwd()
out=root/'target/evidence/WP-24'
env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH']
env['CARGO_TARGET_DIR']=str(root/'target')
def run(name,args):
    with (out/(name+'.log')).open('wb') as log:
        r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/(name+'.command.json')).write_text(json.dumps({'command':args,'workdir':str(root),'target':env['CARGO_TARGET_DIR'],'exit':r.returncode},indent=2)+'\n')
    print(name+' exit='+str(r.returncode),flush=True)
run('workspace-test',['cargo','test','--workspace','--locked'])
run('localisation-python',['python','-m','unittest','discover','-s','tools/tests','-p','test_localisation.py','-v'])
run('pack-validate',['cargo','run','-p','oh_cli','--locked','--','validate','--deny-warnings','data/packs/testland'])
run('legacy-validate',['cargo','run','-p','oh_cli','--locked','--','validate','data/packs/examples/m0/testland'])
run('base-validate',['cargo','run','-p','oh_cli','--locked','--','validate','data/packs/base'])
for scenario,extra in [('m0',[]),('m1',['--pack','data/packs/testland'])]:
    for i in (1,2):
        run(scenario+'-hash-'+str(i),['cargo','run','-p','oh_cli','--locked','--','run']+extra+['--scenario','testland' if scenario=='m0' else 'm1','--days','365','--seed','1','--hash-out'])
run('assets',['python','tools/check_assets.py','--release'])
run('docs',['python','tools/check_docs.py'])
