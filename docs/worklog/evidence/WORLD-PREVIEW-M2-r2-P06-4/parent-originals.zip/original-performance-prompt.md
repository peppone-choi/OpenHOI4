역할: 구현 세션. 기존 WORLD-PREVIEW 동일 단일 소유의 좁은 성능 P-06-4 준비 초안.

P05-3 actual idle/completed15·phase final_answer 전문9662chars/유효FAIL F05를 부모가 직접 인수하고 최초~부모최종10015 full/raw 전체동일·원861manifest/862ZIP 전수0를 확인한 뒤 재개한다. 기존 검증 worktree/baseline/index/원리포트는 수정하지 않는다.

출발 source446540f9755f6d381f789192f3576a8cc17aadd2, 기존branch codex/world-province-preview-m2r2/전용 E:/openhoi/.orchestrator/wt/WORLD-PREVIEW-M2-r2. 새 구현앱/세션 생성 없음. 부모01a114ca-469a-73c0-a9c4-9df475c37769/local. P05-3 유효FAIL은 F05 생성 시간/독립 repeat 미충족 한 건이다. 데이터·화면·3D/원3browser각단일41/정확성·F03F04/회귀는 통과했지만 이를전체PASS로바꾸지않는다.

현재 직접 관측된 실패: 새독립 source446의 bounded fresh bake1은174.156s/native0/4파일SHA shipped동일, bake2 PID11996은180.078s/time-budget/native1, 추가bake3은180.188s 같은FAIL. 예산180s/3GiB/index64MiB/8192×4096·4k graph·source7/defines·도시/해상/작은섬·수로·IDI/camera/골든/기존검사 유지. 0.078/0.188초를반올림면제하거나성공retry로원실패를지우지 않는다. 기존완성산출물복사/캐시를fresh bake로세지않는다. 별도newignoredout에완전한오프라인생성을실행한다.

단일 소유: tools/maps/world_preview.py·해당성능/정확성unit tests(새의미있는case추가)·필요하면same-scope profiling helper·자기 WORKLOG/schema/ADR·새ignoredtarget증거. 원tools/maps/bounded_bake.py의budget/감독/원검사·checkers/fixtures/expected·data/preview/world/defines.toml/source-manifest.json/7고정원천·client렌더러/locale/GLB/프로토콜/crates/locks/CI·게임팩·고유D/OPEN/원a28~446문서와실패를바꾸지않는다. 다른작업이있으며그수정을되돌리지않는다. 범위밖필요는기록만하고부모에전달한다.

목표는 같은기하/ID·sourceclass/urban/adjacency/provinces·metadata4파일을가능하면원446bytes exact로보존하는계산·할당비용절감이다. 프로파일을먼저보고기술선택/고정순서·dtype·overflow·메모리상한을짧은ADR에명시한다. sample/함수별 profiling은별도의대표입력과새파일로하고instrumentation overhead를전체생성결과와구분한다. syscall/환경/수치일부를바꿔구체예산검사를우회하지않는다. 의미변경이필요하면구체byte/ID차이와이유를별도기록하고앞서확정하지않는다.

구체적으로읽기전용확인한개선후보는 connected_ids의seed별parts전체bbox를각component마다다시비교·칠하는반복이다. 이반복을label→dense ordinal LUT/배열로한번처리해같은seed순서·ndimage component순서와원uint16 onebased1..65535/ordinal0..65534를보존할수있는지검토한다. 또repair_internal_fragments에서모든densebbox에argwhere를만들어firstcell하나만쓰는할당비용이실제병목인지프로파일한다. 이는후보이며측정없이효과를선언하지않는다. 원65535허용/65536거부·zero-edge/noanchor·mixedclass/방향·dateline·동률stable target·도시footprint/성능guard를유지한다. 3D/GPU·사용자프로세스/CPU설정을바꾸는방법은쓰지않는다.

원loop 의미의독립작은예제로단일seed의멀리떨어진여러component/seed값빈slot/원component번호순서·다른dtype/rowstride/overflow경계/F03F04를실제로검사하는실패→통과를기록한다. 단언·원테스트를지우거나약하게만들지않으며골든을업데이트하지않는다. 최적화후원446사전baked4파일과첫새fresh4파일·두번째새fresh4파일을각bytes/SHA대조한다. metadata에서도버전·stable record정렬·debug카운터·source/epoch/defines identity가같아야하며새코드라는이유로메타data를조용히바꾸지않는다.

새실제fresh두번에서원감독180s/3GiB/64MiB을전부관측하고elapsed/PeakCommit/WorkingSet/native/PID/argv/부분원FAIL을보존한다. 한도만간신히통과한1회로그를모든사용환경성능보장으로쓰지않으며여유와변동을정직하게보고한다. 전체33554432pixel sourcekind·actualurbanmask·eligibleclass/24889모든ID4connected/47554adjacency/bbox/area/대표DEM와fragment1278records/3435pixels·counter11840=427/11413/mixed38·sourcekind1px6125/전체1px6610를보존한다. raw/targetdebug는1based며targetordinary다른곳의<100km²미분리urban은허용된계약이다. Ireland17중13≥9/4tiny·GB68/Honshu+Kyushu173원천수로한계/Hokkaido16/Shikoku10·도시4sourcefraction1.0/sea도표와source한계를유지한다.

같은소스실제world/Ireland/도시/sea/지역/3D·same-camera446 비교와sourceartifactnative검사·client/Rust/docs/assets/Fluent/licenses/원M1단일전체41를직접끝까지수행한다. 새UI/경제·승점·상위해역·이동/전쟁효과없음. ProvGen확인된inputrole대조는읽기전용이며grayimporter/editor/canonicalformat/예시값·palette/sourcecopy/EXE/DLL/BMP/decompile 없음. noCUA/사용자focus/globalinput·visiblebrowser/OpenInApp/BPHelper/PID/desktop·설정/새dep/publichosting/push/tag/mainmerge금지. 자기localhost/profile/PID의최소4Chrome headless/CDP만사용한다.

마지막한국어짧은actualfinal: 변경파일/native검사/새정확clean commit/원4hash보존·freshpair·actualresources/원FAILED기록·critical/artifactmanifest/원ZIPidentity·결정필요/범위밖/미완료. 원커밋/프로필/데이터·실패/기준선 삭제금지. 독립PASS/전체WP·M5/mainCI/완료를구현자가선언하지않는다. 다음P05는새source·새worktree·새full/raw 최초기준선이며기존FAIL을새결과로바꾸지않는다.


실제권위리포트: E:/openhoi/docs/verify/WORLD-PREVIEW.M2-r2.attempt3.md (actualfinal9662chars). 원 producer446 source는 E:/openhoi/docs/worklog/evidence/WORLD-PREVIEW-M2-r2-P06-3/, originalCLI/debug errors preserved. 새 P05-3 원 ZIP155621367bytes/SHA7790c6b6043de851602e3d737f8e0d8d265935572cb981faa36d8cdd7276ac7e,861manifest/862member; parent ordered48MB parts4로보관한samebytes이고originalZIP은verify3/target/evidence/...에있다. 최초/최종raw b6dfe05f2c0d0bf3b7d72a2a3a30978088f59567338b6e6b0641613dba9ce07d·HEAD/각SHA/목록/diff/status동일. 원P05기준선을바꾸거나index를복구하지않는다.

타이밍조건을정확히기록한다. 원검증은일부기본회귀/E2E/화면작업병행부하를명시했다. 이를없던FAIL로바꾸지말고프로파일/새pair의자기작업병행·elapsed·peak를명시한다. 예산guard 자체는동일하다. 성능개선에서pixel/ID·4파일byte보존 우선이며line-ending/metadata source docs변경을기하변경과혼동하지않는다. 실제한도/새코드증거없이180s를늘리는ADR로대체하지않는다.
