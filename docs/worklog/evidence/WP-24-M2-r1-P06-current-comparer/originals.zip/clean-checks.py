from pathlib import Path
import os,subprocess,json,sys
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-comparer';env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target');env['OH_WP24_EVIDENCE_ROOT']=str(out/'generated')
sys.path.insert(0,str(root/'crates/oh_save/tools'))
from check_save_current import verify_folder,verify_servers,source_identity
before=source_identity();assert not before['status']
steps=[('build',['cargo','build','-p','oh_server','-p','oh_cli','--locked']),
 ('original',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(out/'clean-original')]),
 ('current',['python','crates/oh_save/tools/check_save_current.py','capture','--out',str(out/'clean-current')]),
 ('server',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'clean-current'),'--out',str(out/'clean-current/server')]),
 ('server-force',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'clean-current'),'--out',str(out/'clean-current/server-force'),'--force']),
 ('historical',['python','crates/oh_server/tests/save_historical_native.py','--capture',str(out/'clean-original'),'--out',str(out/'clean-original/server-rejected')]),
 ('legacy-native',['python','crates/oh_server/tests/legacy_nations_native.py','--out',str(out/'clean-legacy-native'),'--red-save',str(out/'red-native/syntax/restore.ohsave')]),
 ('startup-native',['python','crates/oh_server/tests/pack_startup_native.py','--out',str(out/'clean-startup-native')]),
 ('docs',['python','tools/check_docs.py']),('audit',['python',str(out/'audit-originals.py')])]
results=[]
for name,args in steps:
 with (out/('clean-'+name+'.stdout')).open('wb') as so,(out/('clean-'+name+'.stderr')).open('wb') as se:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=so,stderr=se);code=p.wait()
 receipt=dict(command=args,cwd=str(root),pid=p.pid,exit=code,head=source_identity()['head'],dirty=bool(source_identity()['status']))
 (out/('clean-'+name+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n');results.append(dict(name=name,exit=code));print(name+' exit='+str(code),flush=True)
assert all(r['exit']==0 for r in results),results
current=verify_folder(out/'clean-current');verify_servers(out/'clean-current',current)
original=json.loads((out/'clean-original/result.json').read_text());assert original['dirty'] is False and original['head']==before['head']
negative=json.loads((out/'clean-original/server-rejected/result.json').read_text());assert negative['dirty'] is False and negative['head']==before['head']
after=source_identity();assert before==after,'clean source/raw index changed'
(out/'clean-identity.json').write_text(json.dumps(dict(before=before,after=after,unchanged=True,results=results,
 verified_folder=True,verified_servers=True,actual_query_source_integer_ledger=True,actual_3os=False),indent=2)+'\n')
print('clean exact HEAD/raw index unchanged; actual normal/force query source ledger and legacy63/startup48 PASS; actual 3OS not run',flush=True)
