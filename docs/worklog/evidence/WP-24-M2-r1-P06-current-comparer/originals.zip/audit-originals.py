from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-comparer';checks=[]
for name,count in [('WP-24',2722),('WP-24-P06',6268),('WP-24-P06-current-CI',1017)]:
 base=root/'target/evidence'/name;path=base/'evidence-sha256.json';manifest=json.loads(path.read_text());assert len(manifest['files'])==count
 for f in manifest['files']:
  raw=(base/f['path']).read_bytes();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'],f['path']
 checks.append(dict(name=name,files=count,mismatches=0,manifest_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
e=Path('E:/openhoi/.orchestrator/wt/WP-24-M2-r1-verify3/target/evidence/WP-24-M2-r1-P05-3')
manifest=json.loads((e/'SHA256SUMS.json').read_text());assert len(manifest['files'])==3220
with zipfile.ZipFile(e/'evidence.zip') as archive:
 assert len(archive.namelist())==3221
 for f in manifest['files']:
  raw=archive.read(f['path']);assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
assert hashlib.sha256((e/'evidence.zip').read_bytes()).hexdigest()=='55a499e360c3425fbed784b12db91139bd177d8d30c7ac1e0ecd1b78197e49a2'
protected=['crates/oh_save/src','crates/oh_save/tests/fixtures','crates/oh_save/tests/support','crates/oh_save/examples',
 'crates/oh_save/tools/check_save_determinism.py','crates/oh_save/tools/save_reference.py','crates/oh_save/tests/test_save_evidence.py',
 'crates/oh_data/src/host_policy.rs','crates/oh_data/policies','crates/oh_data/src/m0.rs','crates/oh_sim','crates/oh_proto','client',
 'crates/oh_server/tests/save_native.py','crates/oh_server/tests/save_query.cjs','.github/workflows','Cargo.lock','assets/ASSETS.toml','data/packs']
changed=subprocess.check_output(['git','--no-optional-locks','diff','--name-only','3d5636192c75a48020fff31a6acc721e31db81a8','--',*protected],text=True).splitlines();assert not changed,changed
(out/'originals-audit.json').write_text(json.dumps(dict(original_evidence=checks,p05_3_members=3221,p05_3_manifest_files=3220,
 p05_3_zip_sha256='55a499e360c3425fbed784b12db91139bd177d8d30c7ac1e0ecd1b78197e49a2',mismatches=0,protected_paths=protected,protected_changes=changed),indent=2)+'\n')
print('original evidence2722/6268/1017 and P05-3 ZIP3221/manifest3220 verified; protected sources unchanged')
