from pathlib import Path
import shutil,json,subprocess
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-comparer';folder=out/'clean-synthetic-comparer'
for runner,platform in [('ubuntu-latest','Linux'),('windows-latest','Windows'),('macos-latest','Darwin')]:
 target=folder/('current-save-'+runner);shutil.copytree(out/'clean-current',target)
 p=target/'result.json';r=json.loads(p.read_text());r['platform']=platform;p.write_text(json.dumps(r))
def invoke(name,expected):
 args=['python','crates/oh_save/tools/check_save_current.py','compare','--root',str(folder)]
 p=subprocess.Popen(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate()
 (out/(name+'.stdout')).write_bytes(stdout);(out/(name+'.stderr')).write_bytes(stderr)
 (out/(name+'.command.json')).write_text(json.dumps(dict(command=args,cwd=str(root),pid=p.pid,exit=p.returncode,expected_exit=expected,
 scope='synthetic platform predicate; actual source is clean Windows native, never actual3OS'),indent=2)+'\n');assert p.returncode==expected
invoke('clean-synthetic-control',0)
d=folder/'current-save-windows-latest/server';q=json.loads((d/'query.stdout').read_text(encoding='utf-8'))
q['query']['world']['states'][0]['infrastructure']['tick']='49'
for message in q['messages']:
 if message.get('type')=='WorldResult':message['world']['states'][0]['infrastructure']['tick']='49'
(d/'query.stdout').write_text(json.dumps(q));p=d/'result.json';r=json.loads(p.read_text());r['query']=q;p.write_text(json.dumps(r))
invoke('clean-synthetic-ledger49',1)
print('clean HEAD synthetic control0/self-consistent raw+receipt+messages ledger49 mutant1; actual3OS not run')
