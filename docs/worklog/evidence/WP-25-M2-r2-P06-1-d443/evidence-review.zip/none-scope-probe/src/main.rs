use std::path::Path;
fn main()->Result<(),String> {
 let args:Vec<_>=std::env::args().skip(1).collect();
 let c=oh_save::SaveContext::m0(Path::new(&args[0]),"testland")?;
 let mut sim=c.simulation(7)?;
 sim.enqueue(99,oh_core::NationId(0),1,oh_sim::Command::Pause(true)).map_err(|e|e.to_string())?;
 std::fs::write(&args[1],oh_save::encode(&sim,&c,0,vec![])?).map_err(|e|e.to_string())?;
 println!("{}",serde_json::to_string(&oh_save::repro::report(&sim)?).map_err(|e|e.to_string())?);
 Ok(())
}