역할: 구현 세션. OpenHOI4 M2 W1-c WP-25 재현 번들 CLI·성능 CI.

세계지도/HUD/실제3D 한정 미리보기의 새 독립 P05-4, main P07, 정확한 통합 커밋의6CI25job 및 실제9 Save/Trigger 산출물 대조를 인수한 뒤 기존 승인된 W1-c를 배정한다. 아래 전용 worktree의 모든 명령은 그 경로에서 실행한다. 첫 앱 cwd E:/openhoi는 프로젝트 연결용일 뿐 제품 작업 cwd가 아니다.

base: 81deb803944cf6297f13b3f14ca454774cea141b
worktree: E:/openhoi/.orchestrator/wt/WP-25-M2-r2
branch: codex/wp25-repro-bench-m2r2
benchmark prior SHA: 81deb803944cf6297f13b3f14ca454774cea141b

소유: oh_cli repro/bench·lib/main, oh_save의 별도 재현 모듈, bench/, 새 성능 workflow·전용 tests/tools, WP25 로그/ADR/차별화 초안. 기존 save v1/v2/v3/flags·종료 checkpoint v4/codec·골든·checker·CI를 보존한다. WORLD renderer/data/GLB/새 게임 규칙/경제·콘텐츠/HUD 기능은 소유하지 않는다. 실제 게임중 recording에 별도 서버 호출 hook이 필요하면 구현 전에 현재 호출 경로·필요파일·최소 변경과 기존검사 보존을 부모에 보고하고 소유를 인수한다. 조용히 다른 제품파일을 바꾸지 않는다. 새 앱/다른 세션 생성·mainmerge/push 금지. 코드베이스에는 다른 작업의 변경이 있으므로 되돌리지 않고 인수한 실제 통합 타입에 맞춘다.

AGENTS/01·02·03 P03전문·WORKLOG_TEMPLATE, docs/plans/M2-repro-preflight.md와 실제 CLI/sim/save/server APIs를 먼저 읽는다. target REQ-SAV-05/REQ-PERF-03의 의미 있는 실패 테스트를 먼저 실행·원native/stdout/stderr로 보존한 뒤 구현한다. clock/hash/save/pending queue/이동 Stop/flag/종료 상태의 실제 통합 타입과 지원범위를 인수하며 미정 primitive/4score/게임 행동을 만들지 않는다. 새 숫자 예산·문자열은 적절한 정의/ko·en 현지화·ADR에 두고 공유 Cargo/locks/핵심문서 소유는 부모가 명시한 것만 바꾼다. 의존성 버전/라이선스는 공식 원천을 확인해 보고하고 bincode를 쓰지 않는다.

02 §7.3 ZIP bundle.toml(시나리오·팩/해시·seed·선택 시작저장·종료tick·기대hash), machine+human commands.log, 선택start.ohsave를 구현한다. oh repro record --out x.zip의 실제 입력원/host game 실행/기록 시작 snapshot·기존pending/새command enqueue/거부결과/pump·step 경계와 종료 상태를 코드 전 ADR에 구체화한다. seed-only나 fixture-only exporter를 실제 game record라고 쓰지 않는다. paused 같은tick의 여러pump·입력순서, 성공step 뒤 checkpoint/effect, phaseEnded 거부·미래queue 보존, semanticbad command 소비와 wholephaseErr rollback을 구분한다. pending을 snapshot/log 양쪽에서 중복enqueue하지 않는다. oh repro run x.zip은 새 native process에서 전체DTO/canonical/hash까지 원record와 비교하고 기대hash 불일치 native1을 직접 증명한다.

ZIP을 읽기만으로 재생할 수 있으면 unpack하지 않는다. absolute/drive/UNC/..·역슬래시별칭·NUL·중복정규화·symlink/reparse·zipbomb/잘림/CRC/선언길이·membercount/각/전체compressed+uncompressed bound·unknown/missing/future schema·참조/seed/context/hash 변조를 테스트한다. 실패시 원inputsave/pack·기존targetfile·sim/queue/clock의 보존을 실제native I/O로 대조한다. 호환purpose를 caller가 임의선택해 구save/팩 검증을 우회하지 않는다.

02 §14.1: Linux 동일runner에서 사전고정 기준commit과current를 연속측정하며 15% 초과가 두번 재현되면 FAIL. current를 자기baseline으로 삼거나 baseline에CLI가 없음을PASS로 처리하지 않는다. 필요시 동일외부driver로 각source의 실제library를 별도로 빌드하는 증거를 만든다. build/download/warmup은 측정에서 분리하고 compiler/profile/features/pack/seed/work량/nativeelapsed·실제종료workload/fullstate/hash와 원환경을 보존한다. 측정missing/0/비유한/실행실패를 오류로 처리한다. 정수 overflow 없이 baseline100/current115 경계PASS와116×2 FAIL·116/115 비재현 경계를 검증한다. 새 CI는 원6workflows/전체job과Save/Trigger 실제3OS 비교를 유지하고 실제Linux 비교·artifacts를 생성해야 한다. 원M3/M5 성능목표/세계미리보기를 이WP로 완료라고 하지 않는다.

각 실행은 지정worktree·GIT_OPTIONAL_LOCKS=0, Python -X utf8, 원설정/timeout/assertions 보존. 자기worklog에 실패→통과/실제cmd/native·hash2회/fmt/clippy/tests/docs/assets/license·미결정/범위밖/못한부분을 남긴다. 자기branch commit까지만 한다. 마지막 actualfinal은 한국어로 변경파일·검사결과·증거·결정필요/미완료를 짧게 보고하며 전체완료/독립PASS를 선언하지 않는다. CUA/사용자desktop·focus·전역input/기존PIDs·profiles·sandbox/network설정/LFS/공개host/tag/외부유료서비스를 다루지 않는다.

기준 SHA 81deb803944cf6297f13b3f14ca454774cea141b는 구현 전 고정한 실제 통합 제품 커밋이다. 최신 문서 인수 base와 제품 blob은 동일하다. benchmark 소스 조회는 git show/worktree의 분리된 읽기 전용 기준 checkout으로 하고 부모/타 worktree의 target·프로세스·추적 파일을 쓰지 않는다. baseline 현재의 CLI 부재는 통과가 아니다. 실제 Simulation/Host library를 각 소스에서 별도로 빌드하는 동일 workload 비교를 설계해 증명한다. new workflow/bench budget을 기존 CI 축소나 한도 변경으로 대체하지 않는다.
