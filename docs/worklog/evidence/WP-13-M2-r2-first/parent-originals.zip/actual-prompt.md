역할: 구현 세션. OpenHOI4 M2-r2 WP-13.
전용 worktree: E:/openhoi/.orchestrator/wt/WP-13-M2-r2
브랜치: codex/wp13-trigger-engine-m2r2
Base HEAD: f44e16e079cad68e21825a1d9c7bcf1745170412, 부모P07/같은HEAD CI5종·필수jobs/실제원current3OS 대조완료.

[이번 실행의 사용자 승인 및 역할 제한]
CEO/오케스트레이터/구현/검증 앱 채팅과 업무상 상호 메시지는 사용자 직접 승인이다. 새 채팅을 네가 만들지는 않는다. 오케스트레이터 threadId 01a114ca-469a-73c0-a9c4-9df475c37769, hostId local; 필요하면 상태/결정/소유 변경 요구를 메시지로 보낼 수 있다. 너는 기본 main을 수정/병합/푸시하지 않는다. 모든 파일/명령은 아래 전용 worktree에서 수행한다. 기본 cwd=E:\openhoi일 수 있으므로 모든 shell 호출 workdir=전용경로, git -C 또는 절대 파일경로를 강제한다. 전용 경로를 먼저 실제 확인하고 작업한다. 다른 세션의 변경을 되돌리지 않는다.

[먼저 읽기]
전용 worktree의 AGENTS.md, docs/01-game-design.md 해당 REQ/§4, docs/02-production-spec.md §3/해당 기술/§12.2/§15, docs/03-production-prompts.md P-03 전문, docs/plans/schema-planning.md, docs/plans/M2.md, docs/plans/M2-contracts.md, docs/templates/WORKLOG_TEMPLATE.md, docs/research/schema-source-review.md. 메인 .orchestrator/ceo/DIRECTIVES.md 최신 내용은 읽기만 한다. 사용자 실제 OPEN/D 방향과 차량v2 한정 문서 잠정을 지키며 후속 미완성 규칙을 구현하지 않는다. 위키 문장/원작수치/파일/복제 저장소를 쓰지 않는다.

[P-03 절차 — 빠뜨리지 말 것]
1. 코드 변경 전 docs/plans/WP-13-schema.md(자기 WP 번호)에 필드별 의미/타입/단위/범위/필수·null·default/참조/수명/변경권한/REQ와 정의·초기·가변·파생 분류, 관계 그래프/중복·미존재·순환 정책, 갱신 순서/실패 원자성, hash/save/wire/runtime/UI/버전·구버전 처리, 유효·경계·오류의 독립 입력/기대값을 구체화한다. 존재하지 않는 기능을 선언만으로 완료 표시하지 않는다.
2. 대상 REQ마다 실효성 있는 failing test를 먼저 쓰고 실행 실패 출력을 기록한 뒤 구현한다. 새 공식은 oh_sim::formula에 모은다. defines 누락을 숫자 기본값으로 숨기지 않는다. UI 문자열은 ko/en 현지화 키다. 미정 게임 규칙은 인터페이스/결정 필요로 적고 독립된 일을 계속한다.
3. 실제 cargo fmt --check, cargo clippy --workspace -- -D warnings, cargo test --workspace, M0 해시2회, 관련 M1 해시2회와 새 상태/경계/저장 테스트를 직접 실행하고 원문/exit/log를 기록한다. client 변경 시 npm ci/test/typecheck/build/TS generated no-diff와 runtime malformed negative를 실행한다. 로컬 원본 로그는 전용 target/evidence/WP-13 또는 지정 target 아래에 보존한다. CARGO_TARGET_DIR을 공유하지 말고 자기 target을 쓴다. oh_server build는 client/dist가 실제 있어야 하므로 필요 시 자기 client에서 npm ci/build를 먼저 수행한다.
4. 이미 존재하는 M0 golden/M1 scenario/저장 fixture·테스트를 지우거나 약화/기대값 교체하지 않는다. 없는 명령은 실행 성공했다고 적지 않는다. 새 의존성은 최신 공식 버전/라이선스 출처 확인 및 허용 목록 확인 뒤 부모에 파일 소유 요청한다. 샌드박스/모델/권한/네트워크/CI 우회 변경 금지.
5. 범위 외 발견·결정 필요·불가능한 부분·이유를 WORKLOG_TEMPLATE 전문으로 자기 docs/worklog/WP-13.md에 기록한다. 차별화 기록 초안은 작업로그에 쓰며 부모가 01§11을 갱신한다. 부모 소유 문서 01/02/03/HANDOFF/M2 계획은 수정하지 않는다. 기술 선택 ADR은 자기 WP 번호대만 사용한다.
6. 자기 브랜치 커밋까지만 하고 정확 HEAD/clean status·변경 파일·원증거 경로·실제 검증 결과·결정/범위외/미완료를 짧은 final로 보고한다. 전체 완료를 선언하지 않는다. 앱종료를 CLI exit0으로 쓰지 않는다.

[WP-13 범위와 실제 선행 인수]
대상은 REQ-AGD-05, REQ-TIME-04이며 01 §3.3/4.5, 02 §5.6/5.7을 따른다. 선행 WP-03/10와 WP-24/17은 실제 main P-07/같은 HEAD CI가 끝난 뒤 인수한다. 위 정확 base를 지정한 실행 프롬프트다. 실제 전용 worktree/브랜치부터 확인한다.

M2-trigger-preflight.md, M2-repro-preflight.md, M2-economy-content-preflight.md와 M2-evidence.md를 먼저 읽는다. WP-24-schema/ADR-2401의 resolve/validate_for_purpose, registered loader, DiagnosticCode 및 engine-owned 역사 정책을 인수한다. WP-17-schema/ADR-1701/1702의 typed Movement/StraitContext, SimulationSaveV1/V2/V3, 원 historical pack·current pack 구분을 인수한다. producer의 실제 함수와 필드를 읽고 설계한다. 미래 인터페이스 이름을 추측해 만드는 것은 인수가 아니다.

[설계와 결정 필요]
코드 전에 WP-13-schema/ADR-1301에 AST/registry/host capabilities/scope·ID 관계와 필드 표를 작성한다. immutable scenario/defs, initial flags, mutable flags·종료 상태·원인·시점·score inputs, derived result를 구분한다. 각 필드의 타입·단위·범위·누락/null/default·수명·변경 권한·hash/save/wire/runtime/UI를 기록한다.

종료일의 시간 경계, 복수 end_conditions의 root/결합, 초기 충족·동시 종료 원인, 종료 뒤 예약 명령·clock·관전, flag scope/수명과 점수 input의 실제 의미를 기존 문서에서 확인한다. 문서에 없는 게임 행동은 구체 입력→수락/거부→전후 상태→독립 기대와 추천안을 작업로그/ignored proposal에 기록해 부모에게 전달한다. 부모의 실제 채택 답을 받기 전에 그 행동을 코드에 넣지 않는다. 결정과 무관한 AST/registry·검증·독립 host 작업은 계속한다. 새로운 D/OPEN 확정, 실제 항복/진영 규칙의 선행 구현은 권한이 없다.

[실제 엔진]
단일 키 조건 AST의 all/any/not/primitive, 단일 키 effect 목록의 scope/if/primitive, 비교 인자·typed refs·scope 대상과 초기 원시 항목 전체를 스키마로 검증한다. 키 두 개, 잘못된 argument/null/type/range, 미존재 ID, 잘못된 context/미지원 키는 로드시 거부한다. root부터 깊이16/17과 실제 primitive effect 실행1000/1001 예제를 설계해 검사한다. 조건은 상태/RNG/queue를 바꾸지 않는다. chance는 M3 event 발동 context 외에서 거부하며 sim RNG만 사용한다.

registry의 문법 지원과 실제 host adapter 지원을 별도 표로 남긴다. 초기 원시 항목의 스키마·설명·예시는 구현하되 현재 Simulation에 없는 경제/장비/전쟁/법령 값을 0/false/neutral/no-op으로 성공시켜서는 안 된다. 실제 사용 팩의 해당 host capability가 없으면 로드에서 거부한다. 테스트용 host도 실제 상태를 읽고 바꾸며 중간 실패 원자성을 검사해야 한다. 현재 World에서 실제 존재하는 값의 조회와 종료일/지원 조건·flags/end_scenario의 실제 Simulation 실행을 각각 증명한다. 종료 상태가 parser에만 있고 step/hash/save에 연결되지 않으면 TIME-04 미완료다.

effect 실행의 전체 예산과 scope 복귀·반복/분기·실패 원자성, enqueue 거부와 예정 의미 오류·phaseErr의 state/queue/clock 경계를 구분한다. 이미 구현된 Pause/5speed/이동·Stop/reroute·해협·예약 queue/RNG·원장을 손상시키지 않는다. 실제 종료 snapshot과 재개를 fresh native process의 전체 DTO/canonical/hash로 확인한다.

[저장과 기존 source]
원 v1 fixture/expected/header/body/canonical·원97f v2 DTO/binary/expected·현재 v2/v3를 모두 보존한다. 기존 binary DTO에 새 field를 무조건 덧붙이지 않는다. 새 state의 additive 형식·version 선택·bounded preflight·legacy None mode를 코드 전에 설계하고 부모에게 인수한다. stopped units/empty route/explicit empty strait context·pending 새 명령만 있는 경우도 손실이 없어야 한다. migration·구 저장 거부·force/header/expected 교체는 승인 없다. M0와 기존 M1 시나리오/golden은 불변이며 새 M2 시험 팩은 자기 tests/fixtures 아래 둔다.

[단일 파일 소유]
oh_data trigger/registry/national/scenario/schema/pack validation 연결, oh_sim trigger/flags/end state/commands/phase/formula/save_state/world/lib 및 tests, 필요한 oh_save 새 상태/예산·codec·native example, CLI scenario startup adapter, 실제 필요한 oh_proto/server/생성TS/runtime shape와 회귀, 자기 WP13-schema/worklog/ADR-1301이 담당이다. 일반 pack/locale graph·역사 정책의 의미는 WP24 계약을 유지한다. 보호 frozen helper/fixture/원 expected와 M0/M1 data, root workspace/Cargo.lock, ASSETS/CI, 부모 01/02/03/HANDOFF/M2 계획은 변경하지 않는다. 새 dependency나 추가 공유파일 소유가 필요하면 부모에게 구체 경로·이유를 보고한 뒤 인계받는다. 새 화면 문자열은 ko/en 키이며 client는 게임 규칙을 계산하지 않는다.

원 executing evidence는 자기 target/evidence/WP-13/에 command/cwd/native exit/stdout/stderr/정확 source를 남긴다. 각 REQ red→green과 fmt/clippy/workspace·M0/M1 hash2·새 상태/restore/hash·직접 validate·등록된 실제 capability negative를 검사한다. 원 snapshot부터 기록한 native result와 원 SHA manifest를 봉인하고, 자기 clean branch commit까지만 제출한다. 독립 P-05·통합·main CI·완료 판정은 부모 소유다.

[REQUEST-0009 실제 채택 인수 — 제품 변경 전 필수]
REQUEST-0009 A는 CEO2026-10-07T14:22:38+09:00 docs04§2 한정 잠정이며 사용자D/OPEN 추가확정이 아니다. 실제01§3.3/02§5.7/03P03·docs/decisions/REQUEST-0009.md·evidence/scenario-end-policy 원3member를 읽는다. 새 행동은 해당A의 inclusive종료일·다음날00:00checkpoint·단일AST/필요명시root·초기1회/성공시간전진step뒤평가·초기참tick0·조건부작용없음·날짜조건명시effect typed안정원인·전체effect성공후commit·종료후step/새enqueue거부 및futurequeue보존/querysave허용·nationflags/idempotentsetclear/실행수명/scoperestore·전효과rollback범위다. 기존scheduled의미오류소비와phaseErr전체state/queue/clock보존을별도로유지한다. root-null/ID/type/range/ref/order, 원인순서·여러명시effectsourceID·effectbudget/rootdepth·오류우선순서·hostpump정상종료응답을 schema/ADR에서 실제source와대조하고 먼저기록한다. 새로운게임의미 차이가 필요하면 제품에 넣지말고 ignored구체후보·작업로그로 부모에P10요청한다.
None 및원v1/v2/v3 readerwriter/bytes/canonical/hash/fixture/helper/expected/policy/force를보존하고 empty신규정의도 definitionidentity/state를 additive새형식에보존한다. 지원되지않은primitive/scope/scoring의실제사용은capability로드오류이고0/false/neutral/noop으로성공하지않는다. 네점수축과결과화면·항복관전요구는 실제VP/IC/후속WP20생존진영/후속UI consumer를 표로추적하며 부분지원·0weight·합성host산술로전체M2완료를선언하지않는다. 독립예제에는1900/2000/2100윤일·연도·start=end/end<start·초기tick0·원인stableorder·scope복귀·effect1000/1001/깊이16/17·중간실패·종료futurequeue/nativefreshresume전체DTO/hash를추가한다.
[최종producer evidence 경계]
최종cleancommit 뒤 자기 exact HEAD·trackedclean·실제native freshPID/executableSHA/cmd/cwd/exit/stdout/stderr·원None/v1/v2/v3 및새끝상태 hash/저장/queue·실제readonly TS·오류source보존을 다시 얻고 SHAmanifest와원ZIP을봉인한다. 커밋전에 dirty결과를clean최종결과로바꾸지않는다. 자기로그와original결과를구분하며 부모가원bytes를확인할수있게한다.

[새 상태 actual 3OS evidence 추가 단일 소유]
이번 WP13 실제 flags/end/새queue/additive형의 mutable상태를M0시간hash나기존M1save증거로대신하지않는다. 추가 전용 ownership: 신규 .github/workflows/trigger-determinism.yml, crates/oh_sim/tools/check_trigger_determinism.py(또는동일책임의신규전용tool을먼저로그에명시), 해당host tool회귀와oh_save/oh_sim nativeexample·own새testsfixture. 기존 CI/Core/Simulation/Save/Localisation workflow/원checker/fixture/assert 강도는보호한다. 현재상태가고정될때 정확HEAD/clean·원capture/repeatbytes·별도freshPIDresume/fullDTO/canonical/hash·정의/팩신원·source/input보존을 actualWindows/Linux/macOS artifact로담고필수compare한다. emptyflags정의·pendingeffect/futurequeue·초기tick0·종료후거부 상태도검사한다. comparer negative는없는OS/dirty/다른HEAD·state/save/definitionidentity/hash조작·nativeexit/원stdout/PID누락을거부해야한다. local synthetic은predicate회귀이며실제3OS성공으로쓰지않는다. CI는구현자가만들고부모가통합후같은mainHEAD에직접관측/다운로드한다. 본인은mainpush/임시diagnosticpush를하지않는다. 새게임규칙/콘텐츠값·구save거부/migration을이검증소유로늘리지않는다.
