import subprocess, pathlib, json, time
root=pathlib.Path('target/wp11-p06'); cargo='C:/Users/user/.cargo/bin/cargo.exe'
commands=[
 ('fmt-final',[cargo,'fmt','--check']),
 ('clippy-final',[cargo,'clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('file-tests-final',[cargo,'test','-p','oh_save','--lib','file::tests','--locked','--','--nocapture']),
 ('workspace-tests-final',[cargo,'test','--workspace','--locked']),
 ('m1-corrected-hash-1',[cargo,'run','-p','oh_cli','--locked','--','run','--pack','data/packs/testland','--scenario','m1','--ticks','1000','--seed','1','--hash-out']),
 ('m1-corrected-hash-2',[cargo,'run','-p','oh_cli','--locked','--','run','--pack','data/packs/testland','--scenario','m1','--ticks','1000','--seed','1','--hash-out']),
]
results=[]
for name,args in commands:
 started=time.time()
 with (root/(name+'.log')).open('wb') as stream:
  result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
 record={'name':name,'argv':args,'exit':result.returncode,'seconds':time.time()-started,'log':str(root/(name+'.log'))}
 results.append(record); (root/'final-checks.json').write_text(json.dumps(results,indent=2),encoding='utf8'); print(json.dumps(record),flush=True)
