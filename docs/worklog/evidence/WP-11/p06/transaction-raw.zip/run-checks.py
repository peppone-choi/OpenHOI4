import subprocess, pathlib, json, time, os
root=pathlib.Path('target/wp11-p06'); root.mkdir(exist_ok=True)
cargo='C:/Users/user/.cargo/bin/cargo.exe'
commands=[
 ('fmt', [cargo,'fmt','--check']),
 ('clippy', [cargo,'clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('workspace-tests', [cargo,'test','--workspace','--locked']),
 ('m0-hash-1', [cargo,'run','-p','oh_cli','--locked','--','run','--scenario','testland','--days','365','--seed','1','--hash-out']),
 ('m0-hash-2', [cargo,'run','-p','oh_cli','--locked','--','run','--scenario','testland','--days','365','--seed','1','--hash-out']),
 ('m1-hash-1', [cargo,'run','-p','oh_cli','--locked','--','run','--scenario','m1','--ticks','1000','--seed','1','--hash-out']),
 ('m1-hash-2', [cargo,'run','-p','oh_cli','--locked','--','run','--scenario','m1','--ticks','1000','--seed','1','--hash-out']),
]
results=[]
for name,args in commands:
 started=time.time()
 with (root/(name+'.log')).open('wb') as stream:
  result=subprocess.run(args, stdout=stream, stderr=subprocess.STDOUT)
 record={'name':name,'argv':args,'exit':result.returncode,'seconds':time.time()-started,'log':str(root/(name+'.log'))}
 results.append(record); (root/'checks.json').write_text(json.dumps(results,indent=2),encoding='utf8')
 print(json.dumps(record),flush=True)
