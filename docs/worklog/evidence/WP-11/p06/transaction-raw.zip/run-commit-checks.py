import subprocess,pathlib,json
root=pathlib.Path('target/wp11-p06'); cargo='C:/Users/user/.cargo/bin/cargo.exe'
commands=[('fmt-commit',[cargo,'fmt','--check']),('clippy-commit',[cargo,'clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('file-tests-commit',[cargo,'test','-p','oh_save','--lib','file::tests','--locked','--','--nocapture']),('workspace-tests-commit',[cargo,'test','--workspace','--locked'])]
results=[]
for name,args in commands:
 with (root/(name+'.log')).open('wb') as stream: result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
 record={'name':name,'argv':args,'exit':result.returncode}; results.append(record); (root/'commit-checks.json').write_text(json.dumps(results,indent=2),encoding='utf8'); print(json.dumps(record),flush=True)
