"""Validate draft records in ignored scratch package, without editing master."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, tomllib
root=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('asset_checker',root/'tools/check_assets.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
evidence=root/'target/evidence/PREVIEW-UNITS3D'
scratch=evidence/'draft-package'
(scratch/'assets').mkdir(parents=True,exist_ok=True)
drafts=[root/'assets/preview/markers/ASSETS-entry-draft.toml',root/'assets/preview/units3d/ASSETS-entry-draft.toml']
allrecords=[]
for draft in drafts:
    allrecords.extend(tomllib.loads(draft.read_text('utf-8'))['asset'])
seen=set()
for r in allrecords:
    assert r['path'] not in seen;seen.add(r['path'])
    source=root/r['path'];assert source.is_file()
    if 'sha256' in r:assert hashlib.sha256(source.read_bytes()).hexdigest()==r['sha256']
    destination=scratch/r['path'];destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
(scratch/'assets/ASSETS.toml').write_text('\n'.join(p.read_text('utf-8') for p in drafts),encoding='utf-8')
basic=checker.check(scratch.resolve(),False)
release=checker.check(scratch.resolve(),True)
(evidence/'manifest-check.txt').write_text(json.dumps({'draft_records':len(allrecords),'duplicates':0,'digest_mismatches':0,'basic_errors':basic,'result':'PASS' if not basic else 'FAIL'},indent=2)+'\n',encoding='utf-8')
(evidence/'assets-release-pending.txt').write_text(json.dumps({'expected':'FAIL, raster human distribution review pending; no release approval claimed','errors':release},indent=2)+'\n',encoding='utf-8')
assert not basic
assert release and all('AI-generated asset' in e for e in release)
master=checker.check(root.resolve(),False)
(evidence/'assets-master.txt').write_text(json.dumps({'expected':'FAIL, master append belongs to parent/map-HUD app','errors':master},indent=2)+'\n',encoding='utf-8')
assert master and all(e.endswith('unregistered asset/data file') and ('assets/preview/' in e or 'client/public/preview/' in e) for e in master)
print(f'draft basic PASS: {len(allrecords)} records, unique paths and matching SHA; master expected FAIL {len(master)} pending registrations; release expected FAIL {len(release)} AI review omissions')
