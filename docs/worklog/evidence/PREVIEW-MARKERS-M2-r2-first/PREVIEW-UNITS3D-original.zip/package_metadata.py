"""Package producer provenance under owned leaves. No image/mesh editing."""
from pathlib import Path
from PIL import Image
import hashlib, json, datetime, shutil

root = Path(__file__).resolve().parents[3]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write_json = lambda p, obj: p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
names = ['army','air','navy']
raster = root/'assets/preview/markers'
checks=[]
for name in names:
    image = root/f'client/public/preview/markers/{name}.png'
    metadata = raster/f'metadata/{name}.json'
    record = json.loads(metadata.read_text('utf-8'))
    with Image.open(image) as im:
        assert im.mode == 'RGBA' and im.width == im.height
        alpha = im.getchannel('A'); hist = alpha.histogram()
        assert hist[0] > 0 and sum(hist[128:]) > 0
        assert all(alpha.getpixel(p)==0 for p in [(0,0),(0,im.height-1),(im.width-1,0),(im.width-1,im.height-1)])
        info=dict(name=name,bytes=image.stat().st_size,sha256=sha(image),size=list(im.size),mode=im.mode,alpha_extrema=list(alpha.getextrema()),transparent_pixels=hist[0],fully_opaque_pixels=hist[255],alpha_ge128_pixels=sum(hist[128:]),alpha_bbox=list(alpha.getbbox()),corners_transparent=True)
    assert sha(Path(record['source_local_path'])) == sha(image)
    record.update(info)
    record['purpose']='Preserved generated raster HUD/icon reference only after user requested actual 3D map units. Never a 3D model or billboard substitute.'
    record['scope_steering']='Received after all three raster outputs and navy edit had returned. No further imagegen calls were made.'
    record['terms_notes_path']='assets/preview/markers/LICENSE-NOTES.md'
    record['terms_notes_sha256']=sha(raster/'LICENSE-NOTES.md')
    record['scale_inspection']='Producer viewed actual 64/96px Chromium screenshot on dark/light/checkerboard backgrounds; silhouettes distinct. Not an independent review.'
    write_json(metadata,record);checks.append(info)
    dest=root/f'target/evidence/PREVIEW-MARKERS/originals/{name}.png';dest.parent.mkdir(exist_ok=True);shutil.copyfile(image,dest)
write_json(root/'target/evidence/PREVIEW-MARKERS/inspect.json',checks)

leaf=root/'assets/preview/units3d'
inspection=json.loads((root/'target/evidence/PREVIEW-UNITS3D/inspect-first.json').read_text('utf-8-sig'))
recipe=json.loads((leaf/'generate.json').read_text('utf-8'))
metadata={
 'schema':'openhoi4.preview.units3d.metadata.v1','created_date':'2026-10-07','timezone':'Asia/Seoul',
 'tool':'self-authored procedural Node.js generator; built-in fs/path/crypto only','node_version':'v24.4.0',
 'ai_generated':False,'authoring':'Codex authored explicit geometry recipe and deterministic generator; no generative image or 3D-model service creates these mesh bytes.',
 'source':'original procedural geometry; no original-game files, reference images, downloaded meshes, textures or third-party art',
 'model_or_service_version':'not applicable: local procedural geometry',
 'purpose':'temporary local 3D map-preview art, synthetic samples only; no actual units, deployments, statistics or gameplay schema',
 'replaceable':True,'units':'meter (art dimensions only)','up':'+Y','forward':'+Z','right':'+X','pivot':[0,0,0],
 'pivot_note':'Ground plane y=0; nominal horizontal model origin, not center of mass or game deployment coordinate.',
 'materials':'opaque PBR, single-sided, flat normals; no images/textures/raster planes/billboards',
 'recipe_path':'assets/preview/units3d/generate.json','recipe_sha256':sha(leaf/'generate.json'),
 'generator_path':'assets/preview/units3d/generate.mjs','generator_sha256':sha(leaf/'generate.mjs'),
 'reproduction':'node assets/preview/units3d/generate.mjs <separate-output-dir>; producer second generation exact bytes for all 3',
 'models':[{**m,'asset_id':'preview.units3d.'+m['name'],'source_path':f"assets/preview/units3d/{m['name']}.glb",'public_path':f"client/public/preview/units3d/{m['name']}.glb",'license':'CC-BY-SA-4.0','ai_generated':False} for m in inspection],
 'sample_transforms':recipe['samples'],
 'producer_render':{'three_revision':'186','browser_version':'154.0.8037.98','headless':True,'user_browser_or_focus':False,'camera_front':[16,17,28],'camera_back':[-16,18,-28],'depth':'real occluder front red [255,0,0,255], behind occluded by actual army metal [144,143,129,255]','lighting':'key intensity off changes render; restored render checksum exact','evidence':'target/evidence/PREVIEW-UNITS3D/render.json'},
 'asset_license':'CC-BY-SA-4.0 per D-10 for self-authored art/data, preserve attribution/share-alike to extent applicable',
 'generator_code_license':'GPL-3.0-or-later per D-10; ASSETS original label for source-code provenance does not relicense generator code',
 'independent_review':'pending','main_ci':'not run by producer','renderer_integration':'not implemented by producer; parent/map-HUD app owns','master_registration':'pending; parent/map-HUD app owns','public_distribution':'not approved',
 'raster_distinction':'Existing client/public/preview/markers/*.png are HUD/icon reference only; never described or used as these 3D meshes.'
}
write_json(leaf/'metadata.json',metadata)

# D-10 art license is distinct from generative-output rights and release review.
notes=raster/'LICENSE-NOTES.md'
text=notes.read_text('utf-8').replace('These assets are authorized temporary local preview samples only.','After the latest 3D steering these raster assets are preserved HUD/icon references only, not map-unit substitutes.').replace('Raw original PNG bytes and alpha are preserved in project copies.','Raw original PNG bytes and alpha are preserved in project copies. No new imagegen call followed the scope steering.')
notes.write_text(text,encoding='utf-8',newline='\n')
# Refresh referenced digest after scope note.
for name in names:
    p=raster/f'metadata/{name}.json'; obj=json.loads(p.read_text('utf-8'));obj['terms_notes_sha256']=sha(notes);write_json(p,obj)

def base_entry(path, ai=False, license='CC-BY-SA-4.0', note='Original preview provenance/data; no gameplay effect.'):
    return {'path':path,'author':'OpenHOI4 contributors','source':'OpenAI built-in image_gen__imagegen; independent text prompts' if ai else 'original','license':license,'modified':False,'ai_generated':ai,'notes':note}
def toml_value(value):
    if isinstance(value,bool):return str(value).lower()
    return json.dumps(value,ensure_ascii=False)
def write_entries(leaf, image_paths=None):
    draft=leaf/'ASSETS-entry-draft.toml'
    paths=[p.relative_to(root).as_posix() for p in sorted(leaf.rglob('*')) if p.is_file() and p != draft]
    paths.append(draft.relative_to(root).as_posix())
    paths.extend(image_paths or [])
    chunks=['# Append by master-ASSETS owner only. Draft includes provenance leaf files.\n# No public distribution approval; AI release review remains pending.\n']
    for path in paths:
        is_png=path.endswith('.png')
        is_generator=path.endswith('generate.mjs')
        note=('Generated PNG preserved for HUD/icon reference only, not a 3D map unit. See metadata and license notes; distribution review pending.' if is_png else
              'Self-authored procedural source code; GPL-3.0-or-later under D-10. original is source provenance, not a change of code license.' if is_generator else
              'Self-authored preview-art/data record; actual GLBs are synthetic geometry, not deployments. Master registration/integration and independent review pending.')
        entry=base_entry(path,is_png,'original' if is_generator else 'CC-BY-SA-4.0',note)
        if path != draft.relative_to(root).as_posix(): entry['sha256']=sha(root/path)
        chunks.append('[[asset]]\n'+'\n'.join(f'{k} = {toml_value(v)}' for k,v in entry.items())+'\n')
        if is_png:
            name=Path(path).stem;obj=json.loads((raster/f'metadata/{name}.json').read_text('utf-8'))
            chunks.append('[asset.ai_provenance]\n'+f'tool = "image_gen__imagegen"\nmodel = "not provided"\nusage_terms_path = "assets/preview/markers/LICENSE-NOTES.md"\nusage_terms_sha256 = "{sha(notes)}"\nprompt_path = "assets/preview/markers/prompts/{name}.txt"\nmetadata_path = "assets/preview/markers/metadata/{name}.json"\nasset_sha256 = "{obj["sha256"]}"\n'+'[asset.distribution_review]\nstatus = "pending"\n')
    draft.write_text('\n'.join(chunks),encoding='utf-8',newline='\n')

write_entries(raster,[f'client/public/preview/markers/{n}.png' for n in names])
write_entries(leaf,[f'client/public/preview/units3d/{n}.glb' for n in names])
print(json.dumps({'raster_checks':checks,'glb_models':inspection,'metadata':'assets/preview/units3d/metadata.json','drafts':'both owned leaves; master untouched'},indent=2))
