"""Read-only producer checks using independent Python GLB decoding, no mesh library."""
import hashlib, json, math, struct
from pathlib import Path

root = Path(__file__).resolve().parents[3]
results = []
for name in ['army', 'air', 'navy']:
    source = root / f'assets/preview/units3d/{name}.glb'
    raw = source.read_bytes()
    assert struct.unpack_from('<III', raw) == (0x46546c67, 2, len(raw))
    jl, jt = struct.unpack_from('<II', raw, 12)
    assert jt == 0x4e4f534a and jl % 4 == 0
    doc = json.loads(raw[20:20+jl])
    bl, bt = struct.unpack_from('<II', raw, 20+jl)
    binary = raw[28+jl:]
    assert bt == 0x004e4942 and bl == len(binary) == doc['buffers'][0]['byteLength']
    assert not doc.get('images') and not doc.get('textures')
    assert doc['extras']['forward'] == '+Z' and doc['extras']['up'] == '+Y'
    assert doc['extras']['pivot'] == [0, 0, 0]
    assert doc['extras']['aiGenerated'] is False
    def accessor(index):
        item = doc['accessors'][index]
        view = doc['bufferViews'][item['bufferView']]
        offset = view.get('byteOffset', 0) + item.get('byteOffset', 0)
        width = {'VEC3': 3, 'SCALAR': 1}[item['type']]
        kind, size = {5126: ('f', 4), 5123: ('H', 2)}[item['componentType']]
        count = item['count'] * width
        assert offset % size == 0 and offset+count*size <= len(binary)
        values = struct.unpack_from('<'+kind*count, binary, offset)
        assert all(math.isfinite(x) for x in values)
        return [values[i:i+width] for i in range(0, len(values), width)] if width > 1 else list(values)
    all_positions = []
    triangles = vertices = 0
    for mesh in doc['meshes']:
        for primitive in mesh['primitives']:
            assert primitive['mode'] == 4
            positions = accessor(primitive['attributes']['POSITION'])
            normals = accessor(primitive['attributes']['NORMAL'])
            indices = accessor(primitive['indices'])
            assert len(positions) == len(normals) and len(indices) % 3 == 0
            assert min(indices) >= 0 and max(indices) < len(positions)
            material = doc['materials'][primitive['material']]
            assert material['doubleSided'] is False and material['alphaMode'] == 'OPAQUE'
            assert material['pbrMetallicRoughness']['baseColorFactor'][3] == 1
            centroid = [sum(p[i] for p in positions)/len(positions) for i in range(3)]
            for normal in normals:
                assert abs(math.sqrt(sum(x*x for x in normal))-1) < 1e-5
            for j in range(0, len(indices), 3):
                ids = indices[j:j+3]
                a,b,c = [positions[i] for i in ids]
                u,v = [b[k]-a[k] for k in range(3)], [c[k]-a[k] for k in range(3)]
                cross = [u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
                length = math.sqrt(sum(x*x for x in cross))
                assert length > 1e-7
                for index in ids:
                    assert sum(cross[k]/length*normals[index][k] for k in range(3)) > 0.9999
                facecenter = [(a[k]+b[k]+c[k])/3 for k in range(3)]
                assert sum(cross[k]*(facecenter[k]-centroid[k]) for k in range(3)) > 0
            all_positions += positions
            vertices += len(positions)
            triangles += len(indices)//3
    minimum = [min(p[k] for p in all_positions) for k in range(3)]
    maximum = [max(p[k] for p in all_positions) for k in range(3)]
    extent = [maximum[k]-minimum[k] for k in range(3)]
    assert all(d > 0 for d in extent)
    assert abs(minimum[1]) < 1e-6
    public = root / f'client/public/preview/units3d/{name}.glb'
    assert public.read_bytes() == raw
    result = dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),parts=len(doc['meshes']),vertices=vertices,triangles=triangles,bbox_min=minimum,bbox_max=maximum,bbox_extent=extent,units='meter',pivot=[0,0,0],up='+Y',forward='+Z',textures=0,checks='binary decode/index bounds/finite vectors/unit normals/triangle area/outward CCW winding/materials/3D bounds/ground pivot/public exact-byte copy passed')
    results.append(result)
print(json.dumps(results, indent=2))
