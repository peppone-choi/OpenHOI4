"""Seal owned source and actual producer evidence. No tracked file mutations."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, zipfile
root=Path(__file__).resolve().parents[3]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=root).decode()
assert not status
base='ea63081e0b79369227c99384922db80c6ef09fb1'
files=subprocess.check_output(['git','diff','--name-only','-z',base,head],cwd=root).decode().split('\x00')
files=[f for f in files if f]
assert len(files)==23
rows=[]
for file in files:
    raw=(root/file).read_bytes()
    assert raw==subprocess.check_output(['git','show',f'{head}:{file}'],cwd=root)
    rows.append({'path':file,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
commit={'head':head,'base':base,'branch':subprocess.check_output(['git','branch','--show-current'],cwd=root).decode().strip(),'status':status,'owned_files':rows,'independent_review':'pending','master_registration':'pending','renderer_integration':'parent/map-HUD ownership','public_distribution':'not approved','created_kst':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()}
results=[]
for label in ['PREVIEW-MARKERS','PREVIEW-UNITS3D']:
    evidence=root/f'target/evidence/{label}'
    for file in files:
        include=(file.startswith(('assets/preview/markers/','client/public/preview/markers/')) if label=='PREVIEW-MARKERS' else file.startswith(('assets/preview/units3d/','client/public/preview/units3d/')))
        if include or file=='docs/worklog/PREVIEW-MARKERS.md':
            target=evidence/'source'/file;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/file,target)
    (evidence/'commit.json').write_text(json.dumps(commit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    archive=evidence/f'{label}.zip'
    manifest=evidence/'SHA256SUMS.json'
    selected=sorted(p for p in evidence.rglob('*') if p.is_file() and p not in [archive,manifest] and p.name!='seal-result.json')
    entries=[{'path':p.relative_to(evidence).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected]
    manifest.write_text(json.dumps({'source_head':head,'files':entries},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in selected+[manifest]:z.write(p,p.relative_to(evidence).as_posix())
    with zipfile.ZipFile(archive) as z:
        for item in entries:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
    result={'label':label,'zip_path':str(archive),'zip_bytes':archive.stat().st_size,'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'files':len(entries),'source_head':head,'source_commit_bytes_verified':len(rows)}
    results.append(result)
    (evidence/'seal-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(results,indent=2))
