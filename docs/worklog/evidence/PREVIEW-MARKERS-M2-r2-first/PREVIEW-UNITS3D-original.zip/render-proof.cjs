// Headless only; independent clean Chromium process. No user browser or GUI focus.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('E:/openhoi/client/node_modules/@playwright/test');
const root=path.resolve(__dirname,'../../..');
const server=http.createServer((req,res)=>{
 const pathname=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
 const base=pathname.startsWith('/three/')?'E:/openhoi/client/node_modules/three':root;
 const relative=pathname.startsWith('/three/')?pathname.slice(7):pathname.slice(1);
 const file=path.resolve(base,relative);
 if(!file.startsWith(path.resolve(base)+path.sep)){res.writeHead(403);return res.end();}
 try{const data=fs.readFileSync(file);res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.html')?'text/html':file.endsWith('.json')?'application/json':file.endsWith('.png')?'image/png':'application/octet-stream');res.end(data);}catch{res.writeHead(404);res.end();}
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
 const page=await browser.newPage({viewport:{width:1100,height:720},deviceScaleFactor:1});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${port}/target/evidence/PREVIEW-UNITS3D/render-proof.html`);await page.waitForFunction(()=>window.proofReady,{timeout:30000});
 const proof=await page.evaluate(()=>window.proof);await page.screenshot({path:path.join(__dirname,'front.png')});
 proof.back=await page.evaluate(()=>window.changeView());await page.screenshot({path:path.join(__dirname,'back.png')});
 proof.lighting=await page.evaluate(()=>window.lightCheck());proof.depth=await page.evaluate(()=>window.depthCheck());await page.screenshot({path:path.join(__dirname,'depth-behind.png')});
 proof.pageErrors=errors;proof.browserVersion=browser.version();proof.headless=true;proof.userBrowserUsed=false;
 fs.writeFileSync(path.join(__dirname,'render.json'),JSON.stringify(proof,null,2)+'\n');
 if(errors.length||!proof.checks.every(c=>c.depthTest&&c.depthWrite&&c.side===0&&c.hasPosition&&c.hasNormal)||proof.front.weighted===proof.back.weighted||proof.lighting.before.weighted===proof.lighting.dim.weighted||!proof.depth.frontRed||!proof.depth.behindOccluded)throw new Error('render/light/depth assertion failed');
 // Check already-generated raster samples at their intended scale, without editing them.
 await page.goto(`http://127.0.0.1:${port}/target/evidence/PREVIEW-MARKERS/scale-proof.html`);
 await page.waitForFunction(()=>Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0));
 await page.screenshot({path:path.join(root,'target/evidence/PREVIEW-MARKERS/scale-proof.png'),fullPage:true});
 console.log(JSON.stringify({result:'producer render checks passed',threeRevision:proof.threeRevision,browserVersion:proof.browserVersion,parts:proof.checks.length,front:proof.front,back:proof.back,lighting:proof.lighting,depth:proof.depth,errors},null,2));
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
