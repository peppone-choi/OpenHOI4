역할: 구현 세션(생성형 임시 에셋). OpenHOI4 전세계 지도+메인 HUD preview의 유닛 마커.
전용 worktree E:/openhoi/.orchestrator/wt/PREVIEW-MARKERS-M2-r2, branch codex/preview-marker-assets-m2r2, base ea63081e0b79369227c99384922db80c6ef09fb1.

사용자 직접지시 "일단 유닛 마커 등은 생성형으로 때운다." 첫 전세계/프로빈스/HUD rendering만 보여주고기능은후속연결하는우선순위다. 부모01a114ca-469a-73c0-a9c4-9df475c37769/local에게업무메시지는사용자승인,새세션생성/main병합푸시/공개배포금지. 모든cmd는위전용workdir/absolute/git-C. 다른세션의변경을되돌리지않는다. map/HUD 구현앱01a11536-8218-7c93-9082-70931a350875는별도files소유이며자기app의appcwd main을제품경로로쓰지않는다.

먼저 AGENTS.md,01§7/D10/OPEN09·02§14.3 및 ASSETS.toml등록형식, 최신main .orchestrator/ceo/DIRECTIVES.md 끝3개사용자원문을읽는다. C:/Users/user/.codex/skills/.system/imagegen/SKILL.md를전체읽고built-in image_gen__imagegen를실제로사용한다. 생성은CLI/APIkey/모델설정변경없음. references/prompting.md에서필요한sprite/icon자체스타일기준을읽는다. 이미지없는데임의SVG/code아이콘으로생성형요청을대체하지않는다.

단일소유는 client/public/preview/markers/{army.png,air.png,navy.png}, assets/preview/markers/의metadata/prompts/ASSETS-entry-draft.toml·LICENSE-NOTES.md, docs/worklog/PREVIEW-MARKERS.md. productcode/gameUnitSchema/renderer/HUD/net/proto/sim/data/Cargo/npm/모든원fixture/기존assets/01/02/03/HANDOFF를바꾸지않는다. ASSETS master 파일은 map/HUD 앱 단일소유다. 실제3개의원PNG·prompt/tool/time/모델제공정보만/이용조건근거/원bytesSHA·license조건의새entry초안을별도assets/preview/markers/ASSETS-entry-draft.toml로제출하며부모가map앱에인계해실제ASSETS등록후화면사용한다. 동시masterappend없음.

세distinct PNG를같은자체스타일로만든다. army: 읽기쉬운generic20세기육상유닛장비실루엣(helmet/fieldpack 또는간결trackedvehicle), air: 간결한genericpropaircraft실루엣, navy: 간결한genericship실루엣. 작은지도마커64~96px에쓰일선명한실루엣/절제된etchedmetal·neutral색·작은깔끔한counter형배지에맞출구도, trulytransparentbackground(alpha). 각asset마다separatebuiltincall, 동일구도/광원/윤곽/톤. 문구/숫자/국기/원작아이콘/상표/위헌상징없음. 원작reference이미지없으며독립설명으로생성. 프로빈스/세계지도나HUD를생성이미지로대신하지않는다.

tool호출은 functions.exec의firstline @exec yield_time_ms120000 및통상권장workflow를따르고base64를text로출력하지않으며generatedImage 결과를필요시보여준다. 내장tool출력의실제localpath를확인해원파일view_image로검토하고원alpha를preserve하며위전용projectleaf파일로copy한다. skill원칙상projectasset을기본CODEX_HOME에만두지않는다. tool이실패하면원오류를보존하고APIkey/CLI fallback를임의사용하지않으며나머지가능한assets를계속한다. 이미생성된asset의edit가필요하면imagegen으로target를명시하고투명alpha를보존하며원variant를삭제/overwrite하지않는다. 작게줄여보는렌더러사용은가능하지만imageediting을임의python으로대체하지않는다.

현재사용조건/출처를공식OpenAIterms에서확인해원link/확인일/실제제공모델정보/입출력의조건·배포검토미완료를기록한다. 사용자D10/직접제작에셋CCBYSA4와AI출력권리/3rdparty원천미사용을구별하고법적판단을새확정하지않는다. ai_generated=true·실제tool·prompt·date·SHA 및교체가능assetID,임시preview/syntheticmarker만·실제군대/배치가아님을metadata에기록한다. 모델정보없으면미제공이며추측하지않는다.

첫armyasset이준비되면부모에게정확path/SHA/actualPNGpreview·미완료를바로알리고air/navy계속한다. 최종3개실제PNG의readablealpha/실루엣/원크기/교체가능경로·sourceSHA와원생성prompt/resultmetadata·actualtool및time를target/evidence/PREVIEW-MARKERS에봉인한다. 작업로그에실제한것/실패/미실행을남기고자기cleanbranch에commit한뒤40charHEAD/파일·증거·부모인계·미완료를짧게final보고한다. 독립검수·mainCI/WP완료/공개배포완료를선언하지않는다.
