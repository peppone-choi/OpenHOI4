# Generated preview markers — license and provenance notes

Checked: 2026-10-07, Asia/Seoul. This is a provenance/terms summary, not a new legal determination or distribution approval.

Sources checked directly:
- https://openai.com/policies/terms-of-use/ (effective January 1, 2026), Content and Using our Services.
- https://openai.com/policies/service-terms/ (updated September 29, 2026), Image and Video Capabilities.

The terms assign OpenAI's rights, if any, in output to the user to the extent permitted by law. Input rights and lawful use remain the user's responsibility. Output can resemble other output; assignment excludes third-party output. AI origin must not be represented as human authorship. Output needs review for appropriateness. The service terms also govern image use and public sharing on OpenAI services.

No reference images, third-party assets, original-game material, or identifiable models were supplied. The navy edit references only this session's own generated navy output. This describes the supplied inputs, not proof of training-data provenance or third-party-rights clearance.

D-10 licenses directly authored project assets/data under CC BY-SA 4.0. The draft uses that intended project license only to the extent of rights the project can license. OpenAI output assignment is distinct from statutory copyrightability, exclusivity, and CC licensing; none is newly adjudicated here. Credit: OpenHOI4 contributors; disclose AI generation.

OPEN-09 permits only reviewed AI images in distribution. After the latest 3D steering these raster assets are preserved HUD/icon references only, not map-unit substitutes. Human distribution review, master ASSETS registration, independent visual review, main CI, public release/tag approval: pending. No actual military deployment, unit schema, combat data or historical accuracy claim.

Tool: built-in image_gen__imagegen. Returned keys: image_url and output_hint. Model/version/seed/hidden prompt: not provided; not inferred. Raw original PNG bytes and alpha are preserved in project copies. No new imagegen call followed the scope steering. No new imagegen call followed the scope steering. No new imagegen call followed the scope steering. Navy's first halo variant is kept as ignored evidence; final navy is a separate built-in edit output.
