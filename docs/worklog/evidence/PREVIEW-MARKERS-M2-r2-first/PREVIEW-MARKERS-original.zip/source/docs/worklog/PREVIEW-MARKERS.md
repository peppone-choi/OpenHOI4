# PREVIEW-MARKERS 작업 로그 — 임시 raster 참고 에셋과 실제 3D 유닛 원형

| 항목 | 값 |
|---|---|
| 상태 | 검증 대기, 부모 인계용 source |
| 담당 | 구현 세션, 앱 local 채팅 |
| 브랜치 | codex/preview-marker-assets-m2r2 |
| 작업 경로 | E:/openhoi/.orchestrator/wt/PREVIEW-MARKERS-M2-r2 |
| 착수 HEAD | ea63081e0b79369227c99384922db80c6ef09fb1 |
| 관련 REQ | REQ-LEG-02, REQ-LEG-03, REQ-LEG-06; 시각 미리보기 범위이며 마일스톤 기능 완료 아님 |
| 선행 조건 | 사용자 생성형 임시 에셋 지시, 이후 실제 3D 마커 지시; 부모가 소유 확장 |

## 계획과 사용자 범위 변경

- AGENTS.md, 01 §7/D-10/OPEN-09, 02 §14.3/14.4, ASSETS 등록 형식, worklog 양식, 최신 main의 .orchestrator/ceo/DIRECTIVES.md 마지막 사용자 원문 3개를 읽었다. 시작 경로/브랜치/base/clean을 직접 확인했다.
- imagegen SKILL.md와 references/prompting.md 전체를 읽고 built-in image_gen__imagegen을 실제 호출했다. CLI/API key/모델 설정 변경 없이 army/air/navy에 각각 별도 generate 호출, navy에만 후광 제거를 위한 별도 edit 호출을 했다. 정확 prompt, tool output_hint, UTC 시작/종료 시각, 실제 제공 정보는 assets/preview/markers/metadata 및 prompts에 보존했다. 모델/버전/seed 정보는 제공되지 않아 추측하지 않았다.
- 네 결과가 모두 돌아온 뒤 부모의 최신 사용자 지시 "3D 임시 유닛 마커 제작도 가능한가? 3D 모드인데 2D 마커가 있는건 좀.."를 받았다. 추가 imagegen 호출 없이 기존 PNG를 HUD/icon 참고용으로 보존하고 지도용 원형은 실제 low-poly GLB로 전환했다. PNG를 3D 또는 billboard 대체물이라고 표기하지 않는다.
- 부모가 assets/preview/units3d/{army.glb,air.glb,navy.glb,generate.*,metadata.json,ASSETS-entry-draft.toml}과 client/public/preview/units3d/ 원동일 GLB 소유를 확장했다. Node built-ins만으로 자체 procedural 메시를 저작했다. 임시 아트 recipe의 치수·색·샘플 transform은 generate.json 데이터에 있고 게임 수치/규칙이 아니다.
- master ASSETS, renderer/HUD/gameUnitSchema/net/proto/sim/data/Cargo/npm/원 fixture/01/02/03/HANDOFF는 수정하지 않았다. 새 앱/하위 세션/main 병합/push/공개 배포는 하지 않았다. 다른 세션 변경을 되돌리지 않았다.

## 테스트 우선 기록

| 대상 | 구현 전 | 구현 후 |
|---|---|---|
| 임시 raster 3종 | Test-Path 모두 MISSING, before.json 기록 | 실제 PNG 원 bytes 동일/SHA/RGBA/alpha/투명 코너 검사, 64/96px 실제 브라우저 캡처 확인 |
| 실제 3D 3종 | Test-Path 모두 MISSING, PREVIEW-UNITS3D/before.txt 기록 | Python 독립 GLB decode/index/normal/winding/material/bbox 검사 통과 |
| 클린룸/출처 | 원작·외부 reference/model/texture 입력 없음 | 독립 prompt 및 자체 procedural source/recipe, 이미지/모델 구분·SHA·조건·미검토 상태 기록 |
| 공개 배포 검토 | 승인 없음 | 그대로 pending; release 검사를 통과했다고 기록하지 않음 |

이는 producer 아티팩트 검사이며 독립 검증 세션 판정이 아니다. 게임 규칙 대상 REQ의 기능 테스트는 범위에 없다.

## 실제 산출물

| GLB | 원형 | 부품 | vertices / triangles | bbox extent (아트 m) | SHA256 |
|---|---|---:|---:|---|---|
| army | track/hull/turret/barrel/hatch | 6 | 480 / 160 | 3.40000010, 2.24000001, 5.65000010 | d630d499b5d44480ff4f9a081e671348a4bc9163dc19b210a1f0ba17c9268006 |
| air | fuselage/nose/wing/tailplane/fin/canopy/propeller/landing pad | 8 | 432 / 144 | 8, 1.64999998, 5.63999987 | 70724713e93c1338e930f99e1313d5049c85bc5936b39534f87ae83eaee5bf1f |
| navy | hull/deck/superstructure/bridge/funnels/mast/foredeck block | 8 | 456 / 152 | 3.125, 4.17000008, 9.32800007 | d1e5474298ca6f2e4686adbeb10dd38936fccabf36ea823949cf495e8602d128 |

- 原 GLB: assets/preview/units3d/*.glb. 브라우저 파일 client/public/preview/units3d/*.glb는 원 bytes와 동일하다. 교체 ID preview.units3d.army/air/navy.
- GLB 2.0 embedded geometry/buffer, POSITION/NORMAL/uint16 indices/opaque PBR materials, flat shade, outward CCW, single-sided, textures/images 0. units meter, +Y up/+Z forward/+X right, ground pivot [0,0,0], minY=0. 아트 치수는 실제 장비 제원·게임 단위가 아니다.
- 모든 원형의 세 축 extent가 양수다. 기본 샘플 transform은 recipe에 있고 위치/고도/yaw/scale은 시각 검사 예시이며 실제 배치가 아니다. 군대 스키마/전투 기능/렌더러 integration은 이 세션 소유가 아니다.
- PNG: client/public/preview/markers/{army,air,navy}.png, 각각 실제 built-in 출력의 1254×1254 RGBA/alpha 0..255. 원본 alpha/bytes를 그대로 copy했다. 생성 PNG는 직접 3D 저작물의 source가 아니다. 정상 PNG 3개와 navy 첫 halo 변형을 evidence에 보존했다.
- navy 첫 generate는 1536×1024 RGBA alpha 0..254지만 외부 halo와 다른 framing이 있어 채택하지 않았다. view_image 검토 후 imagegen edit로 후광 제거·정사각형 구도를 요청했다. 원 변형은 삭제/overwrite하지 않았다. 최종 원파일 역시 view_image로 직접 확인했다.

## 실행한 검증

| 명령/도구 | 종료 코드/결과 | 출력·증거 |
|---|---|---|
| built-in image_gen__imagegen generate ×3, edit ×1 | 도구 실제 결과 수신, failure 없음 | markers/metadata/*.json 및 prompts/*; 모델 정보 미제공 |
| view_image: 생성 원파일 4개, final 3D 앞/뒤, PNG scale proof | 실제 이미지 검토 | 원본 경로와 target/evidence/* 캡처 |
| python/Pillow read-only alpha inspection | 0 | PREVIEW-MARKERS/inspect.json, RGBA/크기/코너/source SHA |
| node assets/preview/units3d/generate.mjs | 0 | PREVIEW-UNITS3D/generate-first.json |
| python target/evidence/PREVIEW-UNITS3D/inspect_glb.py | 0 | inspect-first.json; binary/index/finite/unit normals/area/CCW/outward/material/bounds/pivot/copy |
| node target/evidence/PREVIEW-UNITS3D/render-proof.cjs | 0 | render-run.txt/render.json/front.png/back.png/depth-behind.png |
| node assets/preview/units3d/generate.mjs target/evidence/PREVIEW-UNITS3D/regenerated + 原 byte comparison | 0 | generate-second.json/repro.txt, 3종 EXACT REGEN |
| python target/evidence/PREVIEW-UNITS3D/package_metadata.py | 0 | package-run.json, 원본 PNG 보존 및 metadata/등록 초안 |
| python tools/check_docs.py | 0 | docs-check.txt, 오류 0·경고 0 |
| python target/evidence/PREVIEW-UNITS3D/check_manifests.py | 0 | manifest-run.txt, draft 22 unique records/해시 전부 일치/basic 오류 0 |
| 같은 inspector에서 master 기본 검사·draft release 검사 | 예상 FAIL 보존 | assets-master.txt: 미등록 22; assets-release-pending.txt: AI 인간 검토 누락 18. 통과로 면제하지 않음 |

- Headless 신규 Chromium 154.0.8037.98/SwiftShader, 기존 로컬 Three revision 186을 사용했다. 기존 dependency 파일은 읽기만 했고 새로운 의존성/설정 변경이 없다. CUA/컴퓨터 사용/Blender GUI/사용자 브라우저·화면·focus는 사용하지 않았다. 일회성 loopback proof 서버는 검사 후 종료했다.
- 실제 GLTFLoader가 GLB 3개·22개 part를 로드했다. 모든 material depthTest/depthWrite=true, FrontSide. 앞/뒤 카메라의 렌더 checksum이 다르고 실제 사진에서 3D 형태와 부품을 확인했다. key light off 시 checksum 변화, 복원 시 exact 일치.
- 실제 전차 앞에 red occluder를 놓으면 중심 pixel [255,0,0,255], 뒤로 옮기면 전차 metal [144,143,129,255]. 깊이 가림 검사 통과. raster/plane로 3D를 흉내 낸 검사가 아니다.
- PNG 실제 64/96px dark/light/checkerboard 캡처에서 세 실루엣 구별을 확인했다. 이미지 자체를 Python/코드로 수정하지 않았다. proof HTML·검사 스크립트/캡처는 ignored evidence이며 제품 renderer 변경이 아니다.
- 첫 staging에서 Git LF 정규화 안내를 확인해 Python provenance writer의 Windows 기본 CRLF를 명시 LF로 고쳤다. 변경 전 package/manifest 결과도 보존하고 LF source에서 다시 검사했다. 23개 staged blob과 실제 worktree byte SHA가 모두 동일함을 직접 대조했다(staged-bytes.json). 해시가 checkout마다 달라지는 등록 초안을 넘기지 않는다.
- 문서·등록 초안 형식·master 미등록/AI release pending 검사 결과는 같은 evidence의 docs-check.txt, manifest-check.txt, assets-master.txt, assets-release-pending.txt에 보존한다. master 변경은 부모/map-HUD 소유이므로 현재 master 미등록 실패는 예정된 인계 상태다.
- Rust fmt/clippy/workspace tests/시뮬레이션 결정론 해시/npm 제품 테스트/main CI/독립 검증은 실행하지 않았다. 제품 코드·게임 데이터 변경이 없으며 GLB generator의 원 byte 재생성은 별도로 실제 검사했다.

## 증거

- E1: target/evidence/PREVIEW-MARKERS/: 원PNG 3개·navy rejected 변형·prompt/call/alpha/scale proof.
- E2: target/evidence/PREVIEW-UNITS3D/: first/second GLB SHA·독립 binary inspector·headless render/light/depth proof·metadata/manifest 검사.
- 각 evidence 최종 SHA manifest와 ZIP은 같은 leaf의 seal 결과로 보존한다. target는 ignored이며 부모가 인수해야 한다. tracked provenance와 원 에셋은 자기 브랜치 커밋에 포함한다.

## ADR/원작 대비 차별화 초안

- 새 gameplay/공유 엔진 결정 없음. 자체 GLB art recipe 기술 계약은 generate.json과 metadata.json에 기록한다.
- 독립 synthetic 장비 원형, 실제 mesh/flat-shaded PBR/중립 색, 2D icon 참고와 3D 지도 원형 분리. 원작 아이콘/모델/국기/원천 파일·추적/위헌 상징 없음. 실제 지리/HUD는 이 생성물로 대체하지 않는다.

## 라이선스·결정 필요

- 2026-10-07 공식 OpenAI Terms of Use(2026-01-01 effective)와 Service Terms(2026-09-29 updated)를 직접 웹으로 확인했다. 정확 URL과 input/output 책임·권리 양도 범위·비고유 가능성·AI origin/검토 조건을 LICENSE-NOTES.md에 기록했다. OpenAI output 계약상 권리와 D-10 직접 제작 CCBYSA4를 구분하며 copyrightability/exclusivity/제3자 권리를 새 확정하지 않았다.
- 실제 3D GLB/recipe/data는 자체 procedural 저작, art license CC-BY-SA-4.0. generator source code는 D-10 GPL-3.0-or-later이며 draft의 original은 provenance 라벨이다. PNG ai_generated=true; GLB ai_generated=false(로컬 explicit geometry 생성, raster 모델서비스 미사용), 저작 과정은 metadata에 공개한다.
- master ASSETS 실제 등록, renderer integration, 새 독립 검수, 인간 AI 배포 검토와 공개 배포 승인은 부모/담당자의 후속 인계 범위다. D/OPEN 상태는 바꾸지 않는다.

## 범위 밖 발견·못 한 부분

- 기존 master의 이번 leaf 미등록을 직접 고치지 않았다(다른 앱 단일 소유). 두 entry draft에 에셋·recipe/source·metadata/prompt/조건 기록·draft 자체 항목도 제공한다.
- GLB는 정적 generic 저폴리 원형이다. rig/animation/LOD/실제 역사 정확도/게임 unit schema/시뮬레이션·selection/action 연결은 요청받지 않아 구현하지 않았다.
- Three proof는 생산자의 검사이며 독립 시각 검수·정식 게임 화면/깊이 pipeline 인수는 미완료다. main CI 또는 마일스톤/WP 완료를 선언하지 않는다.

## 인계 기록

- 첫 army PNG의 정확 path/SHA/실제 preview/미완료를 부모 채팅에 즉시 전달했다.
- 3D로 범위 변경 뒤 첫 army GLB의 정확 path/SHA/units/pivot/forward/triangles/bbox와 아직 남은 검사·통합 범위를 부모 채팅에 전달했다.
- 최종 자기 branch source 40자 HEAD, 모든 파일/증거 SHA와 원PNG 보존 및 GLB 3종을 부모에게 전달한다. 부모가 map-HUD 앱에 master 등록·renderer 사용을 인계한다.
