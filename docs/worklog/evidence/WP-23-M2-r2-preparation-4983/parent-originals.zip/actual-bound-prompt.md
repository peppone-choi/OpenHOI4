역할: 구현 세션. OpenHOI4 M2 W2 WP-23 Testland 콘텐츠.

준비 초안. W1 전체 통합 전에는 실행하지 않는다. 부모가 exact base/전용worktree/branch와단일파일소유를고정한다. WP14와병행할경우이미존재하는map/nation/locale계약의새가상기하·6국가만먼저준비할수있다. 경제·정치필드는WP14의실제schema/참조/지원범위커밋인수전에는작성하지않으며loader구문을추측해성공이라고하지않는다.

2026-10-08 인수: docs/plans/WP-14-M2-r2-contract.md와REQUEST-0010 A-CEO-r1 수정판은CEO한정잠정이다. 콘텐츠수치승인/사용자확정이아니다. producer통합뒤최신기준을이브랜치에명시인수하고새m2경제입력·strictvalidate/nativequery/save/repro·원팩hash변화를검사한뒤새독립P05를한다. shared제품파일·원M0/M1/common내용을이WP에서임의변경하지않는다. 새5자원/건물/법령등이기존팩전역정의와충돌하거나새명세가필요하면실제필드/경로와최소필요변경을부모에보고하고소유인수후진행한다.

P11/AGENTS·docs/plans/M2-economy-content-preflight.md·M2-contracts.md 및 01§6·REQ-CNT-01/REQ-GEN-03,02데이터스키마·실제loader를 따른다. 소유는 기존data/packs/testland의 새M2 시나리오/지도/common/localisation·SOURCES 및 새assetentry 초안/WP23 로그다. 원M0 examples/m0와 frozen/M1 compatibility 입력·현재M1 파일의기존bytes/expected·다른WP product/shared 01/02/03/HANDOFF/ASSETS master는 변경하지 않는다. 기존 testland와 겹치는 파일의 새기존시나리오 분리·참조/pack hash와 v1/v2/v3/v4 호환은 실제WP14/WP25계약으로 부모가 고정하며 조용한호환파괴는 금지한다.

가상6개국/100~200프로빈스·시대독립 장비/대대/건물/defines/날짜/자원/정부이념 최소세트를 작성하고 원작수치/파일/상징/지도trace를 쓰지않는다. 지원되는 실제스키마만 쓰며 미구현 장비/편제/생산/외교/항복/의제/연구를가짜데이터나no-op로재현됐다고하지않는다. 인터페이스자리와 후속담당을 기록하고 loader가 미지원구문을실제거부하는상태를보존한다. 역사pack이아닌가상콘텐츠임을SOURCES에명확히쓴다.

새필드·참조·중복/미존재ID·의존/locale·지도연결/선택/소유·시작context/날짜를먼저검사하고 실제CLI validate --deny-warnings를실행한다. REQ-GEN-03은 지원data driven범주/새schema와 실제로실행되지않는후속범주를 구분한다. 실제새시나리오 load/run/query/save/freshnative/repro재생·canonical/hash2회와 원M0/M1/기존newtrigger경제회귀를 검사한다. 완전한평시→전쟁→항복플레이는 UI/전투외교등후속producer 없이는완료로선언하지 않는다.

작업로그는P11/WORKLOG_TEMPLATE로 원명령/native·출처/라이선스·실패/미결정/범위밖/미완료를포함한다. 새수치는defines·새문자열ko/en, 새assetentry는부모가master에원문합류한다. 본브랜치commit만하며 mainmerge/push/새앱생성/설정변경/사용자desktop 조작을하지않는다. 다른작업의변경을되돌리지않고 실제producer계약을 인수한다. 최종메시지는한국어로변경/검사/증거/미완료를짧게보고하며독립PASS나전체완료를선언하지 않는다.

실제 배정: W1 전체 exactmain2b5ca의 독립PASS/P07/7CI26SUCCESS/actualSaveTrigger9/actualLinux 원증거를 인수했다. 위 준비초안의 실행보류는 해제한다.
base: 2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab
worktree: E:/openhoi/.orchestrator/wt/WP-23-M2-r2
branch: codex/wp23-testland-m2r2
최초tracked: 11805
최초rawindex: 7ef2c2d41fd1e3029590837a8b8cf921d1ca5b1a0604109f3275283789912770
planning 현재원문: E:/openhoi/.orchestrator/wt/WP-23-M2-r2/target/evidence/WP-23-M2-r2/planning
모든명령은이WT에서만실행한다. 앱초기E:/openhoi cwd는프로젝트연결용이다. 다른작업을되돌리거나mainmerge/push/세션생성하지않고담당branchcommit까지만한다. 실제규칙은REQUEST-0010 A-CEO-r1 수정판이며사용자확정으로쓰지않는다. technicalfixedinput추가CEO조건은프롬프트와planning계약에있고schema/ADR부터구체화한다. 병행WP는서로파일을고치지않는다. 원source/sourceCI/mainCI/동일제품docheadCI·원실패를구분한다.

당신은 WP14가실제경제field/refs를내기전까지기존mapper·국가·locale의가상6국/100~200기하만준비한다. 경제입력 추측/가짜호환/전투외교효과는금지다. 실제producer인수를기다리는시점엔원작업/증거를유지하고부모에필요필드와상태를보고한다. 아직producer가없다고원본패키지/골든을바꿔테스트를통과시키지않는다. 부모의WP14 actual schema commit후같은앱에추가계약을전달한다.
