# WP-23 작업 로그 — Testland M2 기하·6개국 준비

| 항목 | 값 |
|---|---|
| 상태 | 진행 — WP14 actual schema/커밋 인수 대기 |
| 담당 | 구현 세션(콘텐츠) |
| 브랜치 | codex/wp23-testland-m2r2 |
| 대상 REQ | REQ-CNT-01 · REQ-GEN-03 (준비 범위만 검사) |
| 선행 WP | W1 exact main 2b5ca 인수; WP14 actual producer 미인수 |

## 계획

- 모든 명령 cwd는 `E:/openhoi/.orchestrator/wt/WP-23-M2-r2`. 최초 HEAD `2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab`, tracked11805, 최초 status/diff/cached diff 없음. 부모 `parent-before.index`의 실제 SHA256은 배정 값 `7ef2c2d41fd1e3029590837a8b8cf921d1ca5b1a0604109f3275283789912770`과 일치한다. 별도 NUL ls-files stdout의 SHA는 직렬화가 다른 관찰값이며 부모 raw index와 혼동하지 않는다.
- `target/evidence/WP-23-M2-r2/planning/W1-actual-completion.json` 및 actual-prompt를 인수했다. W1 통합/P05/P07/main CI 원기록 인수이며 이 구현 세션이 CI를 새 실행한 것은 아니다.
- 기존 mapper/nation/locale 계약으로 6개국·144 프로빈스·12개 예정 주만 준비한다. 원 M0/M1/common bytes와 골든/fixture를 유지한다. REQUEST-0010 A-CEO-r1 수정판은 CEO 한정 잠정이다.
- actual StateDefinition의 필수 인구·자원·건물·인프라 때문에 부분 새 map은 제품 팩 전체 strict 실행을 막는다. 따라서 준비물을 증거 디렉터리에 두고 actual producer 인수 뒤 제품 경로에 반영한다. [ADR-2301](../adr/ADR-2301-testland-m2-preparation.md).

## 테스트 우선 기록

| REQ | 테스트 이름 | 구현 전 결과 | 구현 후 결과 |
|---|---|---|---|
| REQ-CNT-01 | test_req_cnt_01_geometry_coverage_connectivity | exit1: provinces.csv 없음 | exit0: 144개, RGB/ID 유일, 모든 pixel 매핑, 각 province 단일 4-connected 영역, 전체385 edge graph 연결, 예정12주 연결·중복 없이 전체 소속 |
| REQ-CNT-01 | test_req_cnt_01_six_nations_and_capital_membership | exit1: 0 != 6 | exit0: 6국 ID/tag 유일, 국가당24 province, 수도 자국 예정 구획, 정확 지지율 합1 |
| REQ-GEN-03 | test_req_gen_03_supported_names_only_and_locale_parity | exit1: m2.ftl 없음 | exit0: ko/en 동일21키·빈값/중복 없음, nation 참조 포괄, 미지원 경제/common·미완성 scenario 없음 |

원 테스트 소스는 `target/evidence/WP-23-M2-r2/test_preparation.py`, RED는 `preparation-red.log`, GREEN은 `preparation-green.log`. 이는 준비 구조 검사이며 actual Rust schema/전체 REQ/PT 판정이 아니다. generator 첫 실행은 worktree guard의 parent depth 오류로 실패했다. `preparation-first-attempt-failure.log`를 보존하고 올바른 지정 cwd로 수정했으며 준비 검사 기대값은 약화하지 않았다.

## 실행한 검증

아래 로그 루트는 `target/evidence/WP-23-M2-r2/`다. Windows native 출력이며 별도 Linux/source CI/main CI는 실행하지 않았다.

| 명령 | 종료 코드 | 출력 발췌 / 로그 경로 |
|---|---|---|
| python -X utf8 target/evidence/WP-23-M2-r2/prepare.py | 0 | prepare.log, 16파일 준비; 제품 pack 쓰기 없음 |
| python target/evidence/WP-23-M2-r2/test_preparation.py | 1→0 | RED/GREEN, 3 tests |
| 최초 Python subprocess cargo spawn | spawn 전 실패 | PATH cargo 부재 WinError2; 기존 C:/Users/user/.cargo/bin을 해당 process PATH에 추가, 설정/승인/네트워크 변경 없음 |
| cargo fmt --check | 0 | fmt.log |
| 최초 cargo clippy --workspace -- -D warnings | 101 | clippy.log; oh_server가 client/dist 부재를 거부 |
| 최초 cargo test --workspace | 101 | workspace-tests.log; 동일 client/dist 부재 |
| npm --prefix client ci | 0 | npm-ci.log; 기존 lock 사용 |
| npm --prefix client run build | 0 | npm-build.log; 실제 Vite dist 생성, chunk size warning 보존 |
| cargo clippy --workspace -- -D warnings (client build 후) | 0 | clippy-after-client-build.log |
| cargo test --workspace (client build 후) | 0 | workspace-tests-after-client-build.log; 원 national/map/movement/trigger/save/repro/호환 및 doc tests 통과 |
| python -X utf8 crates/oh_cli/tests/repro_native.py --evidence-root target/evidence/WP-23-M2-r2/repro-original-native | 0 | repro-original-native.log; 15 tests, 실제 v3 이동/v4 trigger·save 시작/fresh replay·futurequeue/phase rollback·적대 ZIP 회귀 |
| cargo run -p oh_cli -- validate --deny-warnings data/packs/testland | 0 | original-strict-validate.log; maps1/scenarios1/hash3bde1bed90d3734e |
| cargo run -p oh_cli -- run --scenario testland --days 365 --seed 1 --hash-out (2회) | 0/0 | original-testland-hash-1/2.log; b039d35666b77fc2 두 번 동일 |
| cargo run -p oh_cli -- run --scenario m1 --days 365 --seed 1 --hash-out --pack data/packs/testland (2회) | 0/0 | original-m1-hash-1/2.log; b595dc2a1e5b4f8c 두 번 동일 |
| cargo run -p oh_cli -- validate --deny-warnings target/evidence/WP-23-M2-r2/candidate-pack | 1 | candidate-strict-rejection.log; maps/m2/states.toml:1:1 os2, maps0/scenarios0; 성공으로 처리하지 않음 |
| python -X utf8 tools/check_docs.py (로그 작성 전) | 0 | docs-before.log; 오류0/경고0 |
| python -X utf8 tools/check_docs.py (로그/ADR 작성 후) | 0 | docs-after.log; 오류0/경고0 |
| 기존 pack/fixture/golden 파일 bytes/SHA custody | 일치 | frozen-before.json/frozen-after.json; 70파일 변경0 |

원 argv/native exit는 `commands.jsonl`에 있다. 그 파일의 최초 clippy/test101을 build 후 결과로 덮지 않았다. `run_checks.py`는 사용한 단일 배치 실행 기록이며 재시도/하네스/오케스트레이션/설정 변경을 추가하지 않는다.

## 증거

- E1: `prepared/` 원천16파일과 `prepared-inventory.json`의 상대경로/bytes/SHA256. `prepare.py`로 재생성 가능하며 원작 자료·외부 지도·이미지 생성 도구·추가 라이브러리를 쓰지 않았다.
- E2: `geometry-observation.json`: RGB8 384×288, 144 land provinces, 전체 graph 연결·385 edges. `prepared/membership-plan.json`: 예정12주·6국 소속의 기하 계획이며 loader 입력이 아니다. bitmap을 직접 열어 확인했다.
- E3: `prepared/data/packs/testland/SOURCES.md`는 가상 콘텐츠·직접 제작·잠정 구조수치/미작성 범주를 명시. `prepared/ASSETS-entry-draft.toml`은 향후 제품 경로용13개 asset 초안이며 master 변경/등록/공개 배포 승인을 뜻하지 않는다.
- E4: 실제 CLI strict 원팩0·불완전 후보1·원 M0/M1 해시2회, 기존70파일 SHA 보존. 원 M1 pack bytes와 content identity는 그대로다. 후보 pack identity를 실제 loaded identity나 원 frozen identity로 기록하지 않는다.
- E5: `planning/` 부모 원문, `parent-before.*`, 최초 인수관찰. 실제 source/구현 검증과 부모 인수·독립P05/CI의 증거 경계를 구분한다.
- 보존용 준비 묶음: `target/evidence/WP-23-M2-r2/WP-23-preparation.zip` (50627bytes, SHA256 `51c7fc654573ebbeab2e7def0cd322eaeadf8c14f0943d1913df4543712e37f6`). 준비16파일·생성/검사/배치 스크립트·RED/GREEN/최초실패·native 거부 로그를 포함한다. `target/`의 ignored 로컬 증거이며 제품 입력/독립 검증 리포트/추적파일은 아니다. 후속 작업 때 이 worktree와 증거를 보존해야 한다.

## 실제 기존 schema·필요한 producer 인수

| 경로/필드 | 현재 준비·단위/참조 | actual producer 이후 필요한 것 |
|---|---|---|
| maps/m2/provinces.csv/png | u16 ID1000+3i, RGB8, 기존 land/plains/hills, coastal=false, ID≠dense index | Rust map/national 전체 load 및 서버 index/선택/query; 실제 UI 후속 |
| maps/m2/regions.toml | 기존 정확 km_per_pixel=2 기하값 | 경제/이동 계수로 재해석하지 않기 |
| maps/m2/states.toml | 미작성; 예정 id101..112/name_key/provinces만 JSON 계획 | required population i64/resources BTreeMap<id,i64>/buildings BTreeMap<id,i64>/infrastructure i64의 actual economy 정의와 bounds·시나리오별 slots 경로 |
| scenarios/m2/nations/*.toml | NationDefinition 기존8필드, u16 id/capital, tag/name_key/color/government_key, exact decimal ideology_support | 경제 초기 법령/PC/안정도/동원도/배분/committed/reserved가 어느 actual 경로에 붙는지; 지원 law/condition/locale registry·범위 |
| localisation/ko,en/m2.ftl | 21키 자체 이름, 기존 나라/정부/이념/예정주 참조 | actual 경제 key 검증·ko/en 및 최종 부모 asset 합류 |
| scenarios/m2/scenario.toml/defines.toml | 미작성 | actual 날짜/종료/end_root·시간/display 기본값·경제presence 및 기존overlay 참조. 날짜/숫자 기본값 발명 없음 |
| common/resources,buildings,terrain | 기존bytes 유지; 새파일 없음 | 5자원/건물/law 범주의 pack전역 파일 충돌·새 지원경로·ID를 부모가 고정하고 변경 소유 인수 |
| 장비/대대/생산/훈련/전쟁/항복/의제/연구 | 미작성 | actual WP15/16/20/21 등 producer; unsupported 구문/no-op 성공 금지 |
| save/repro/hash/bench | 기존 경로만 회귀 | WP14 additive save/native query/repro 및 원 immutable performance 입력 WP14/WP25 인수 후 새m2 검사 |

REQ-GEN-03의 현재 준비는 데이터 지형·정부/이념 이름 참조뿐이다. 날짜·경제·자원·건물 최소세트는 producer 인수 대기, 장비/대대 등은 후속 미구현이다. 타입 선언/이름/준비 검사로 엔진 시대독립 전체 실행을 증명하지 않는다.

## ADR

- ADR-2301: 합성기하 준비·부분팩 게시 보류·실제 strict 거부와 기존 identity 보존. 경제/전투/정치 새 규칙을 정하지 않는다.

## 원작 대비 차별화 초안 (01 §11에 넣을 행)

- 가상 시나리오: 외부 원작 지도/수치 없이 만든144프로빈스·6개국, 비연속 typed ID·원천SHA·ko/en 데이터 참조. 기존M1 동결fixture와 별도 기하 준비. 산업·평시→전쟁→항복은 아직 실행 증거 없음.

## 결정 필요

| 식별자 | 내용 | 막는 범위 |
|---|---|---|
| REQUEST-0010 A-CEO-r1 | CEO 한정 잠정 유지; 합성 예제를 콘텐츠 기본값 승인으로 쓰지 않음. 실제 경제 수치 후보·지원 schema/refs 인수 필요 | 새 경제 콘텐츠 입력·검증 |
| REQ-GEN-03 | 장비/대대/정치 후속 효과 등 실제producer 없는 범주 | 해당 지원 데이터/전체 시대독립 실행 |

## 범위 밖 발견

- common/resources.toml/buildings.toml은 pack 전역 단일 registry이며 원 M1 bytes 보존 지시와5자원/건물 추가가 충돌할 수 있다. 새 경제 정의 경로/ID 및 최소 shared 변경은 부모가 실제 WP14 계약으로 고정해야 한다. 기존파일 변경하지 않았다.
- ASSETS master는 부모 소유다. 초안만 준비했다. 기존 판정·골든·fixture·01/02/03/HANDOFF·CI·bench 정책을 바꾸지 않았다.

## 못 한 부분과 이유

- WP14 actual schema/refs/source·통합 인수 미도착. 준비물을 제품 pack에 게시하거나 필수 주 경제입력/0대체·새 scenario/defines를 작성하지 않았다.
- 새m2 strict validate는 실제 후보에서 실패하며 run/query/save/freshnative/repro·canonical/hash와 완전한 평시→전쟁→항복 플레이를 실행 성공으로 기록하지 않는다. producer와 후속 WP가 필요하다.
- ai-bench는 현재 CLI USAGE가 후속 WP로 명시한다. 없는 명령 실행/성공을 보고하지 않는다.
- 이 checkpoint는 콘텐츠 준비 상태다. 새 독립P05·부모P07·같은main CI 및 M2 게이트 판정은 하지 않았다. merge/push/다른세션 생성/사용자 desktop 조작 없음.

## 수정 기록 (P-06)

- 최초 PATH spawn 실패·generator guard 오류·client dist 부재를 각각 보존하고 해당 준비만 교정했다. 제품 코드/기존테스트·기대값/설정 변경 없음.

## 통합 기록 (P-07)

- 해당 없음. 본 브랜치 준비 기록 checkpoint만 커밋한다. 실제 producer 인수 뒤 이 앱·worktree에서 계속한다.
