# ADR-2301 Testland M2 기하 준비와 producer 인수 경계

| 항목 | 값 |
|---|---|
| 상태 | 채택 |
| 날짜 | 2026-10-08 |
| 관련 WP·REQ | WP-23 · REQ-CNT-01 · REQ-GEN-03 |

## 맥락

배정 base는 `2b5ca827b80a61105c8c8b80b7516ff1c4f3ebab`, 전용 worktree는 `E:/openhoi/.orchestrator/wt/WP-23-M2-r2`다. WP14 actual 경제 schema/커밋은 아직 인수하지 않았다. 부모 지시는 기존 mapper·nation·locale의 가상 기하와 6개국만 먼저 준비하도록 한정한다. REQUEST-0010 A-CEO-r1은 CEO 한정 잠정이며 콘텐츠 수치 승인이나 사용자 확정이 아니다.

실제 `oh_data/src/map.rs::StateDefinition`은 `population/resources/buildings/infrastructure`를 필수로 요구한다. `pack_validation.rs::validate_content`는 팩 안 모든 map/scenario를 검사한다. 새 map을 제품 팩 안에 부분적으로 넣으면 기존 M1 host startup까지 실패한다. 경제 값0·빈 registry를 만들어 성공시키는 방법은 배정 계약을 만족하지 않는다.

## 결정

준비 파일은 `target/evidence/WP-23-M2-r2/prepared/`에 보존한다. 실제 제품 팩과 shared ASSETS master는 producer 인수 전 변경하지 않는다. 144개 프로빈스의 RGB8 384×288 합성 기하, 기존 plains/hills 참조, 기존 NationDefinition 필드의 6개국, ko/en 이름을 준비했다. geometry는 자체 12×12 타일의 열 경계를 ±2픽셀로 변화시킨 원천이며 외부 지도나 원작 자료를 쓰지 않았다. 국가 ID는 101..106, 프로빈스 ID는 1000+3i로 dense index와 구별한다.

주 101..112의 프로빈스 소속·예정 소유자는 `membership-plan.json`에만 기록한다. 이것은 loader schema나 초기 경제 입력이 아니다. `states.toml`, `scenario.toml`, economic common/defines를 아직 쓰지 않는다. 정부/이념 이름과 0.5/0.5 지지율은 기존 nation 구조 준비용 잠정 합성 입력이며 법령·정치 효과 또는 최종 밸런스 승인으로 해석하지 않는다. 지역 스케일2는 기존 regions geometry 계약의 자체 합성 기술값이다.

테스트는 독립 flood fill·인접 그래프·주 구획 연결성·6개국 수도·ID·ko/en 키를 검사한다. Rust strict validate는 별도 `candidate-pack`에 실제 기존 팩과 준비물을 복사해 실행하며 states 부재 오류를 보존한다. Python 준비 검사 통과를 Rust load/run/query/save/repro 성공으로 기록하지 않는다.

## 검토한 대안

| 대안 | 장점 | 버린 이유 |
|---|---|---|
| 필수 주 입력에0/빈 값 채우기 | 당장 loader에 연결 가능 | 경제 입력 추측·콘텐츠 기본값 승인 오인 |
| 제품 팩에 부분 map/nation 게시 | tracked 기하를 즉시 보관 | 모든 map strict 검사가 기존 실행을 막음 |
| 증거 디렉터리 준비 후 실제 producer 인수 | 기존 팩 bytes/identity 보존, 실제 거부 증거 | 채택; full m2 실행 검증은 후속 인수 때 수행 |

## 결과와 영향

시뮬레이션·저장 codec·wire·CI·성능 설정은 변경하지 않았다. 기존 팩 전체 content hash는 `3bde1bed90d3734e`로 실제 strict CLI에서 확인했다. 새 콘텐츠가 제품 팩에 들어간 뒤 변경되는 hash는 원 frozen identity와 구분해 다시 검사해야 한다. 새 의존성이나 라이선스 조건을 선택하지 않았으며 기존 D-10 직접 제작 CC BY-SA 4.0을 asset 초안에 그대로 기록했다.

경제 필드와 registry·locale·저장/호스트 actual 인수, 원팩 고정 성능 입력의 WP14/WP25 계약은 부모가 전달한다. 자세한 필요한 경로와 원명령·실패·증거는 [WP-23 작업 로그](../worklog/WP-23.md)에 있다. 이 ADR은 새 게임 규칙이나 WP 전체 완료 판정이 아니다.
