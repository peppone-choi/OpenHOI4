import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WT = Path.cwd().resolve()
assert WT == ROOT.parents[2].resolve()
os.environ["PATH"] = str(Path("C:/Users/user/.cargo/bin")) + os.pathsep + os.environ["PATH"]


def run(name, args):
    with (ROOT / f"{name}.log").open("wb") as output:
        result = subprocess.run(args, stdout=output, stderr=subprocess.STDOUT, cwd=WT)
    record = {"name": name, "argv": args, "exit_code": result.returncode, "log": f"{name}.log"}
    with (ROOT / "commands.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    print(json.dumps(record), flush=True)
    return result.returncode


paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=WT).decode().split("\0")
initial = {}
for relative in paths:
    if relative.startswith(("data/packs/", "crates/oh_save/tests/fixtures/", "tests/golden/")):
        data = (WT / relative).read_bytes()
        initial[relative] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
(ROOT / "frozen-before.json").write_text(json.dumps(initial, indent=2), encoding="utf-8")
index = subprocess.check_output(["git", "ls-files", "--stage", "-z"], cwd=WT)
(ROOT / "initial-index-observation.json").write_text(json.dumps({"tracked": len([p for p in paths if p]), "rawindex_sha256": hashlib.sha256(index).hexdigest()}, indent=2), encoding="utf-8")

run("fmt", ["cargo", "fmt", "--check"])
run("clippy", ["cargo", "clippy", "--workspace", "--", "-D", "warnings"])
run("workspace-tests", ["cargo", "test", "--workspace"])
run("original-strict-validate", ["cargo", "run", "-p", "oh_cli", "--", "validate", "--deny-warnings", "data/packs/testland"])
for scenario in ("testland", "m1"):
    for repeat in (1, 2):
        args = ["cargo", "run", "-p", "oh_cli", "--", "run", "--scenario", scenario, "--days", "365", "--seed", "1", "--hash-out"]
        if scenario == "m1":
            args.extend(["--pack", "data/packs/testland"])
        run(f"original-{scenario}-hash-{repeat}", args)
# This is intentionally an incomplete staged candidate. Preserve the native
# rejection instead of synthesizing economic defaults or weakening validation.
candidate = ROOT / "candidate-pack"
shutil.copytree(WT / "data/packs/testland", candidate, dirs_exist_ok=True)
shutil.copytree(ROOT / "prepared/data/packs/testland", candidate, dirs_exist_ok=True)
run("candidate-strict-rejection", ["cargo", "run", "-p", "oh_cli", "--", "validate", "--deny-warnings", str(candidate)])
changed = [p for p, expected in initial.items() if {"bytes": (WT / p).stat().st_size, "sha256": hashlib.sha256((WT / p).read_bytes()).hexdigest()} != expected]
(ROOT / "frozen-after.json").write_text(json.dumps({"checked": len(initial), "changed": changed}, indent=2), encoding="utf-8")
print(f"Original source-byte custody: checked={len(initial)} changed={changed}", flush=True)
