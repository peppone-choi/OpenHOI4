"""Produce only the existing geometry/nation/localisation contract drafts."""
import csv
import hashlib
import io
import json
import struct
import subprocess
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WT = Path.cwd()
assert WT.resolve() == ROOT.parents[2].resolve()
assert subprocess.check_output(["git", "branch", "--show-current"], text=True).strip() == "codex/wp23-testland-m2r2"
DRAFT = ROOT / "prepared"
PACK = DRAFT / "data/packs/testland"


def write(relative, text):
    path = DRAFT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


tags = ["ARA", "BEL", "CER", "DOR", "ELA", "FAR"]
names = [("Aravel", "아라벨"), ("Belora", "벨로라"), ("Cerun", "세룬"), ("Doravel", "도라벨"), ("Elara", "엘라라"), ("Farun", "파룬")]
colors = [(62, 122, 190), (185, 105, 65), (96, 165, 112), (154, 103, 184), (195, 162, 62), (62, 164, 173)]
province_ids = [1000 + 3 * i for i in range(144)]
palette = [(32 + (i % 6) * 36, 32 + (i // 6 % 6) * 36, 48 + (i // 36) * 44) for i in range(144)]
out = io.StringIO(newline="")
writer = csv.writer(out, lineterminator="\n")
writer.writerow(["id", "r", "g", "b", "kind", "terrain", "coastal"])
for i, pid in enumerate(province_ids):
    writer.writerow([pid, *palette[i], "land", "hills" if i % 12 in (5, 6) else "plains", "false"])
write("data/packs/testland/maps/m2/provinces.csv", out.getvalue())
# Original synthetic rectilinear tiling. Each row boundary is fixed. Within each
# row band, column boundaries zigzag by at most two pixels; no outside reference.
raw = bytearray()
for y in range(288):
    raw.append(0)
    row = y // 24
    shift = ((y % 24) // 4 + row) % 5 - 2
    bounds = [0] + [32 * c + shift for c in range(1, 12)] + [384]
    for col in range(12):
        raw.extend(bytes(palette[row * 12 + col]) * (bounds[col + 1] - bounds[col]))
png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 384, 288, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
(PACK / "maps/m2/provinces.png").write_bytes(png)
write("data/packs/testland/maps/m2/regions.toml", "# Synthetic geometry scale; no economic rule.\nkm_per_pixel = 2\n")
write("data/packs/testland/maps/m2/adjacency_overrides.csv", "a,b,kind\n")
states = []
for row in range(12):
    states.append({"id": 101 + row, "name_key": f"state-m2-{row + 1:02}", "provinces": province_ids[row * 12:(row + 1) * 12], "owner": tags[row // 2]})
write("membership-plan.json", json.dumps({"status": "geometry plan only; not loader input", "states": states}, ensure_ascii=False, indent=2) + "\n")
visuals = "# Display-only palette.\nneutral = [65, 105, 145]\n[terrain]\nplains = [130, 165, 95]\nhills = [155, 135, 95]\n[state]\n"
for row in range(12):
    visuals += f"{101 + row} = {list(colors[row // 2])}\n"
write("data/packs/testland/maps/m2/visuals.toml", visuals)
for i, tag in enumerate(tags):
    capital = province_ids[i * 24 + 5]
    nation = f'id = {101 + i}\ntag = "{tag}"\nname_key = "nation-m2-{tag.lower()}"\ncolor = {list(colors[i])}\ncapital = {capital}\ngovernment_key = "government-m2-assembly"\n[ideology_support]\nideology-m2-cooperation = "0.5"\nideology-m2-autonomy = "0.5"\n'
    write(f"data/packs/testland/scenarios/m2/nations/{tag}.toml", nation)
for lang, idx in (("en", 0), ("ko", 1)):
    text = "# Original fictional names; no political mechanics implied.\n"
    for i, tag in enumerate(tags):
        text += f"nation-m2-{tag.lower()} = {names[i][idx]}\n"
    text += "government-m2-assembly = " + ("Civic Assembly" if lang == "en" else "시민 회의") + "\n"
    text += "ideology-m2-cooperation = " + ("Cooperation" if lang == "en" else "협력") + "\n"
    text += "ideology-m2-autonomy = " + ("Autonomy" if lang == "en" else "자율") + "\n"
    for row in range(12):
        label = ("Upper" if row % 2 == 0 else "Lower") if lang == "en" else ("상부" if row % 2 == 0 else "하부")
        text += f"state-m2-{row + 1:02} = {names[row // 2][idx]} {label}\n"
    write(f"data/packs/testland/localisation/{lang}/m2.ftl", text)
write("data/packs/testland/SOURCES.md", "# WP-23 M2 가상 콘텐츠 준비 원천\n\n역사 팩이 아니다. 원작 파일·지도·수치·문장·상징을 사용하거나 열람하지 않았다. 모든 기하·이름·팔레트는 직접 작성했다. 직접 제작 데이터의 기존 프로젝트 라이선스는 CC BY-SA 4.0(D-10)이다. 새 라이선스나 의존성을 선택하지 않았다. 확인일 2026-10-08.\n\n| 항목 | 값/원천 | 상태 |\n|---|---|---|\n| 기하 | 384×288 RGB8, 12×12 자체 타일, 열 경계 ±2픽셀, 프로빈스 ID 1000+3i | 기하 준비 |\n| 국가 | ARA/BEL/CER/DOR/ELA/FAR, ID 101..106, 자체 작명/색상, 국가당 24개 프로빈스 | 기존 nation 구조 준비 |\n| 주 구획 | 12개 행, ID 101..112, 국가당 2개 | membership-plan.json 계획; states.toml 아님 |\n| 지도 스케일 | 2km/픽셀 | 자체 합성 기술 값, 실제 loader 인수 전 |\n| 정부/이념 | 시민 회의, 협력/자율 각0.5 | 구조 점검용 밸런스 잠정; 법령/징병/PC 효과 없음 |\n| 지형 | 기존 plains/hills ID만 참조 | 새 registry 없음 |\n| 인구/자원/건물/법령/PC/배분/슬롯 | 미작성 | WP14 실제 schema 및 별도 수치 인수 필요 |\n| 날짜/종료 | 미작성 | 실제 m2 scenario 계약 인수 필요 |\n| 장비/대대/의제/기술/전쟁/항복 | 미작성 | WP15/16/20/21/후속 producer 필요 |\n\n이 디렉터리는 실행용 팩이 아니며 strict validate/run/save/repro 통과나 콘텐츠 수치 승인을 뜻하지 않는다. 기존 M0/M1·common·ASSETS master는 변경하지 않았다.\n")
records = "# Parent merge draft only; paths apply after producer handoff/publication.\n"
for path in sorted(PACK.rglob("*")):
    if not path.is_file() or path.suffix == ".md":
        continue
    rel = "data/packs/testland/" + path.relative_to(PACK).as_posix()
    records += f'\n[[asset]]\npath = "{rel}"\nauthor = "OpenHOI contributors"\nsource = "original"\nlicense = "CC-BY-SA-4.0"\nmodified = false\nai_generated = false\nnotes = "WP-23 original fictional geometry/nation/locale preparation; no third-party material. Pending actual producer handoff."\n'
write("ASSETS-entry-draft.toml", records)
files = []
for path in sorted(DRAFT.rglob("*")):
    if path.is_file():
        data = path.read_bytes()
        files.append({"path": path.relative_to(DRAFT).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
(ROOT / "prepared-inventory.json").write_text(json.dumps(files, indent=2) + "\n", encoding="utf-8")
print(f"Prepared {len(files)} files; no production pack writes. Geometry=144, nations=6, planned states=12.")
