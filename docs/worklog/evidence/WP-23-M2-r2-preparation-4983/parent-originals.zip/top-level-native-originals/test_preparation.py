"""WP-23 preparation checks; NOT a replacement for actual Rust load/validate."""
import csv
import json
import struct
import tomllib
import unittest
import zlib
from collections import Counter, deque
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DRAFT = ROOT / "prepared"
PACK = DRAFT / "data/packs/testland"


def pixels():
    data = (PACK / "maps/m2/provinces.png").read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    offset, payload, size = 8, b"", None
    while offset < len(data):
        n = struct.unpack(">I", data[offset:offset + 4])[0]
        kind = data[offset + 4:offset + 8]
        chunk = data[offset + 8:offset + 8 + n]
        crc = struct.unpack(">I", data[offset + 8 + n:offset + 12 + n])[0]
        assert zlib.crc32(kind + chunk) & 0xffffffff == crc
        if kind == b"IHDR":
            w, h, bits, color, compression, filtering, interlace = struct.unpack(">IIBBBBB", chunk)
            assert (bits, color, compression, filtering, interlace) == (8, 2, 0, 0, 0)
            size = w, h
        elif kind == b"IDAT":
            payload += chunk
        offset += n + 12
    w, h = size
    raw = zlib.decompress(payload)
    assert len(raw) == h * (1 + w * 3)
    rows = []
    for y in range(h):
        row = raw[y * (1 + w * 3):(y + 1) * (1 + w * 3)]
        assert row[0] == 0
        rows.append([tuple(row[x:x + 3]) for x in range(1, len(row), 3)])
    return w, h, rows


class Preparation(unittest.TestCase):
    def test_req_cnt_01_geometry_coverage_connectivity(self):
        with (PACK / "maps/m2/provinces.csv").open(newline="", encoding="utf-8") as f:
            provinces = list(csv.DictReader(f))
        self.assertEqual(len(provinces), 144)
        ids = [int(p["id"]) for p in provinces]
        self.assertEqual(len(set(ids)), 144)
        palette = {tuple(int(p[c]) for c in "rgb"): int(p["id"]) for p in provinces}
        self.assertEqual(len(palette), 144)
        self.assertTrue(all(p["kind"] == "land" and p["terrain"] in {"plains", "hills"} for p in provinces))
        w, h, rows = pixels()
        self.assertEqual((w, h), (384, 288))
        counts = Counter(p for row in rows for p in row)
        self.assertEqual(set(counts), set(palette))
        # Independent flood fill: every RGB is exactly one 4-connected component.
        visited, components, graph = set(), Counter(), {i: set() for i in ids}
        for y in range(h):
            for x in range(w):
                here = rows[y][x]
                for nx, ny in ((x + 1, y), (x, y + 1)):
                    if nx < w and ny < h and rows[ny][nx] != here:
                        a, b = palette[here], palette[rows[ny][nx]]
                        graph[a].add(b)
                        graph[b].add(a)
                if (x, y) in visited:
                    continue
                components[here] += 1
                queue = deque([(x, y)])
                visited.add((x, y))
                while queue:
                    cx, cy = queue.popleft()
                    for nx, ny in ((cx - 1, cy), (cx + 1, cy), (cx, cy - 1), (cx, cy + 1)):
                        if 0 <= nx < w and 0 <= ny < h and (nx, ny) not in visited and rows[ny][nx] == here:
                            visited.add((nx, ny))
                            queue.append((nx, ny))
        self.assertEqual(set(components.values()), {1})
        reached, queue = {ids[0]}, deque([ids[0]])
        while queue:
            for adjacent in graph[queue.popleft()]:
                if adjacent not in reached:
                    reached.add(adjacent)
                    queue.append(adjacent)
        self.assertEqual(reached, set(ids))
        membership = json.loads((DRAFT / "membership-plan.json").read_text(encoding="utf-8"))
        assigned = [p for s in membership["states"] for p in s["provinces"]]
        self.assertEqual(Counter(assigned), Counter(ids))
        for s in membership["states"]:
            selected = set(s["provinces"])
            seen, q = {min(selected)}, deque([min(selected)])
            while q:
                for p in graph[q.popleft()] & selected - seen:
                    seen.add(p)
                    q.append(p)
            self.assertEqual(seen, selected)
        (ROOT / "geometry-observation.json").write_text(json.dumps({"width": w, "height": h, "provinces": len(ids), "connected_components_per_province": 1, "connected_graph": True, "edges": sum(map(len, graph.values())) // 2}, indent=2), encoding="utf-8")

    def test_req_cnt_01_six_nations_and_capital_membership(self):
        paths = sorted((PACK / "scenarios/m2/nations").glob("*.toml"))
        self.assertEqual(len(paths), 6)
        nations = [tomllib.loads(p.read_text(encoding="utf-8")) for p in paths]
        self.assertEqual(len({n["id"] for n in nations}), 6)
        membership = json.loads((DRAFT / "membership-plan.json").read_text(encoding="utf-8"))
        for nation, path in zip(nations, paths):
            self.assertEqual(nation["tag"], path.stem)
            owned = {p for s in membership["states"] if s["owner"] == nation["tag"] for p in s["provinces"]}
            self.assertEqual(len(owned), 24)
            self.assertIn(nation["capital"], owned)
            self.assertEqual(sum(Fraction(v) for v in nation["ideology_support"].values()), 1)
            self.assertEqual(set(nation), {"id", "tag", "name_key", "color", "capital", "government_key", "ideology_support"})

    def test_req_gen_03_supported_names_only_and_locale_parity(self):
        catalogs = {}
        for lang in ("ko", "en"):
            text = (PACK / f"localisation/{lang}/m2.ftl").read_text(encoding="utf-8")
            pairs = [line.split(" = ", 1) for line in text.splitlines() if line and not line.startswith("#")]
            self.assertEqual(len(pairs), len({k for k, _ in pairs}))
            catalogs[lang] = dict(pairs)
            self.assertTrue(all(v.strip() for v in catalogs[lang].values()))
        self.assertEqual(set(catalogs["ko"]), set(catalogs["en"]))
        for path in (PACK / "scenarios/m2/nations").glob("*.toml"):
            nation = tomllib.loads(path.read_text(encoding="utf-8"))
            self.assertTrue({nation["name_key"], nation["government_key"], *nation["ideology_support"]} <= set(catalogs["en"]))
        # Incomplete drafts cannot be mistaken for a supported playable scenario.
        self.assertFalse((PACK / "maps/m2/states.toml").exists())
        self.assertFalse((PACK / "scenarios/m2/scenario.toml").exists())
        self.assertFalse((PACK / "common").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
