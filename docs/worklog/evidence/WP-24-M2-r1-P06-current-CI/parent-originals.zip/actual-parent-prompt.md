역할: 구현 세션. OpenHOI4 M2-r1 WP-24 P-06, 필수 Save CI의 frozen/current 입력 연결을 보완한다.
전용 worktree: E:/openhoi/.orchestrator/wt/WP-24-M2-r1
브랜치: codex/wp24-pack-validation-m2r1
정확 인수 base: c28f90425905774c23b1d90a5d900c596ade2745
부모 threadId 01a113d1-c44c-7703-881b-d56e57557f55, hostId local. 사용자 승인된 업무 메시지만 사용하고 새 채팅/세션은 만들지 않는다.

모든 shell workdir는 위 경로로 강제한다. 먼저 own clean4ae와 c28 ancestry를 확인하고 git merge --ff-only c28f90425905774c23b1d90a5d900c596ade2745로 현재 통합 입력 보완을 인수한다. 불가능하면 reset/rebase/강제로 진행하지 않고 보고한다. 원 c2/P03/P06-6268/4ae/P05/정책 source22, 원17 97f/7f/P06-234/c28/P06-188/P05, 원 fixture/기대값/골든은 보존한다. main 수정/병합/푸시/새 세션/설정 변경은 금지다. 다른 세션의 변경을 되돌리지 않는다.

[원 실패와 한정 계약]
먼저 최신 E:/openhoi/.orchestrator/ceo/DIRECTIVES.md의 2026-10-07T12:21 필수 저장 CI 입력 연결 절, 실제 REQUEST0008 A, 원 docs/verify/WP-17.M2-r1.attempt2.md와 evidence를 읽는다. 원 c28 새 P05는 필수 Save CI 연결 FAIL과 raw index 불변성 FAIL로 무효다. 기능 관측이 통과했어도 유효 PASS가 아니며 원 index/baseline을 복구하지 않는다.

실제 .github/workflows/save-determinism.yml:28은 원 check_save_determinism.py capture를 생산한다. 이는 원 frozen mutable-v1 pack/SHA57b13...를 유지한다. line38 save_native.py는 같은 run-1/pack 및 paused.ohsave를 HTTP 서버 복원 정상 입력으로 소비한다. REQUEST8은 이 역사 mutable-v1 source의 CLI 재개만 허용하므로 서버는 ko/en 이름 누락으로 정확히 native1/무HTTPWS를 내며 필수 pipeline은 실패한다. 임의 server_restore policy entry, 가짜 이름/번역, --force/codec/header/expected/fixture 변경, 검사 skip/continue-on-error로 통과시키지 않는다.

[독점 파일 소유]
.github/workflows/save-determinism.yml의 실제 생산/소비·추가 current 비교 단계, crates/oh_save/tools/check_save_determinism.py의 additive current capture/compare 명령 또는 별도 전용 checker, 새로운 crates/oh_save/tests/test_save_current_evidence.py 등 checker 검증, crates/oh_server/tests/save_native.py의 필요한 입력/진단 연결 및 별도 current/historical native 검증 도구, own WP24-schema/worklog/ADR-2401 추가 절이 담당이다. 기존 save_native.py의 HTTP200/WS welcome/query/served JS/exclusive PID/정상 종료0 단언은 전부 유지한다. 기존 check_save_determinism.py capture/compare·test_save_evidence.py의 fixture/SHA/전체 state/native/3OS 단언을 삭제하거나 약화하지 않는다. 기존 메서드는 그대로 두고 additive current 명령/검사를 쓰는 방식이 권장된다.

oh_data host policy/로더, oh_sim/oh_proto/client, oh_save src codec/header/body, protected tests/support/helper와 examples/save_fixture.rs의 original capture, 원 source/frozen fixture/expected/golden, deps/ASSETS/다른 CI/부모 01/02/03/HANDOFF/M2 문서는 수정하지 않는다. 이미 있는 save_fixture capture-current를 소비한다. 추가 파일이 필요하면 실제 이유와 경로를 부모에 보고해 인계받는다.

[구현 전 설계와 red]
schema/ADR에 original frozen capture→원3OS compare 및 CLI, separate current capture→fresh native/CLI→server positive→current3OS compare의 producer/consumer 경로를 먼저 기록한다. 각 mode/version/head/dirty/platform/pack/defines/scenario/seed/tick/queue/config/fullstate/canonical/ledger/hash/native PID/executable SHA/save SHA/report/command 경계를 대응한다. original/current 입력과 결과를 같은 디렉터리·schema의 동일 의미로 섞지 않는다.

원 native script 실패를 같은 base에서 직접 재현해 새로운 target/evidence/WP-24-P06-current-CI/에 원 cmd/cwd/nativeexit/stdout/stderr/pack/header/source/PID/HTTPWS 결과를 남긴다. 관련 REQ와 필수 pipeline을 실제 검사하는 실패 테스트를 먼저 쓴다. original source 기록이나 first2722/6268 evidence를 덮지 않는다.

[필수 동작]
1. 원 frozen 두 번 생성, original fixture/expected bytes·CLI resume·독립 integer ledger/canonical/hash와 3OS 비교는 그대로 유지한다.
2. 별도 current 디렉터리에서 실제 capture-current를 두 번 실행한다. 각 fresh native resume와 CLI, 전체 DTO/config/queue/state/canonical/hash·원장·팩 신원·반복 savebytes/PID 분리·inputsave/source 보존을 검증한다. 새 current 결과는 원 fixture SHA와 혼동하지 않으며 차이 이유를 기록한다.
3. 기존 server native positive의 입력을 이 current 산출물에 연결한다. HTTP/WS/welcome/query/servedJS/PID/정상 Ctrl+C0의 모든 원 단언이 실행되어야 한다. 역사 mutable-v1 source는 별도 server native1/무HTTPWS의 negative로 실제 확인하고 original CLI 재개 정상은 유지한다. force 양쪽도 validation 면제가 아니어야 한다.
4. 같은 exact HEAD의 Linux/Windows/macOS current capture/새 process/원장/canonical/hash/pack·save identity를 실제 CI artifact로 비교한다. 누락 OS/서로 다른 HEAD/dirty/동일PID 재개/missing stdout/nativeexit/변조 state/pack/save/header/hash/원장·잘못된 current mode는 comparer가 거부한다. 실제3OS를 실행하지 않은 로컬 synthetic comparer 테스트를3OS 성공이라고 쓰지 않는다.
5. workflow는 original capture/compare와 모든 기존 검사를 유지하고 current 검사를 추가한다. 비교 단계에서 original/current 모두 성공해야 Save workflow가 성공한다. 새로운 검사를 그냥 로그만 남기거나 실패를 성공으로 삼키지 않는다.

[검증과 제출]
실제 fmt/clippy/workspace, original evidence unit tests와 current 새negative, M0/M1 해시2, current validate0/originalM0 strict1, original/current native 전체상태 재개·실제 server positive/historical negative, docs/assets/architecture/license를 실행한다. 필요 dist는 자기 npm ci/build로 만들고 자기 target을 쓴다. Windows installed cargo 절대 경로나 process PATH만 사용한다.

검증 중 raw index 실패와 달리 구현자는 own source를 수정/커밋하지만 제출 clean HEAD의 원 native evidence는 정확 source를 기록한다. 생성 TS가 바뀌지 않았다면 read-only equality test로 확인하고 같은 bytes의 tracked TS writer를 필요 없이 실행하지 않는다. 실제 index 갱신 주체가 미확인인 원 무효를 환경 잡음·해결로 미리 단정하지 않는다. source 변경 없이 새 P05 raw 전후가 같아야 유효한 독립 검증이다.

새 own branch commit까지 하고 clean exact HEAD에서 모든 native/current/original 증거를 봉인한다. 실제 command/nativeexit/result·fullstate/canonical/hash·source와 regular 파일 전체 SHA manifest를 별도 output에 남긴다. final은 HEAD/clean·변경파일·red→green·원증거·결정/범위외/미완료를 짧게 인계한다. 독립 P05/P07와 같은 main5workflow green/완료 판정은 부모 담당이다.
