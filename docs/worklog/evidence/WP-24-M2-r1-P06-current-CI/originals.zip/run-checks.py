from pathlib import Path
import os,subprocess,json,hashlib
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-CI';env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target')
env['OH_WP24_EVIDENCE_ROOT']=str(out/'generated')
steps=[('npm-ci',['cmd','/c','npm','--prefix','client','ci']),('npm-build',['cmd','/c','npm','--prefix','client','run','build']),
 ('fmt',['cargo','fmt','--check']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('workspace',['cargo','test','--workspace','--locked']),('original-unit',['python','-m','unittest','discover','-s','crates/oh_save/tests','-p','test_save_evidence.py','-v']),
 ('current-unit',['python','-m','unittest','discover','-s','crates/oh_save/tests','-p','test_save_current_evidence.py','-v']),
 ('proto-readonly',['cargo','test','-p','oh_proto','--locked','--test','contract','req_net_04_generated_types_are_current']),
 ('build-server',['cargo','build','-p','oh_server','--locked']),
 ('original',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(out/'provisional-original')]),
 ('current',['python','crates/oh_save/tools/check_save_current.py','capture','--out',str(out/'provisional-current')]),
 ('server',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'provisional-current'),'--out',str(out/'provisional-current/server')]),
 ('server-force',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'provisional-current'),'--out',str(out/'provisional-current/server-force'),'--force']),
 ('historical-negative',['python','crates/oh_server/tests/save_historical_native.py','--capture',str(out/'provisional-original'),'--out',str(out/'provisional-original/server-rejected')]),
 ('validate',['cargo','run','-p','oh_cli','--locked','--','validate','--deny-warnings','data/packs/testland']),
 ('legacy-validate',['cargo','run','-p','oh_cli','--locked','--','validate','--deny-warnings','data/packs/examples/m0/testland']),
 ('localisation',['python','tools/check_localisation.py','--out',str(out/'client-uses.json')]),
 ('architecture',['python','tools/check_architecture.py']),('assets',['python','tools/check_assets.py','--release']),
 ('license',['cargo','deny','check','licenses','bans']),('docs',['python','tools/check_docs.py'])]
for scenario,extra in [('m0',[]),('m1',['--pack','data/packs/testland'])]:
 for i in (1,2):steps.append((scenario+'-hash-'+str(i),['cargo','run','-p','oh_cli','--locked','--','run']+extra+['--scenario','testland' if scenario=='m0' else 'm1','--days','365','--seed','1','--hash-out']))
results=[];proto=root/'client/src/proto/protocol.ts';before=hashlib.sha256(proto.read_bytes()).hexdigest()
for name,args in steps:
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=so,stderr=se);exit=p.wait()
 receipt=dict(command=args,cwd=str(root),pid=p.pid,exit=exit,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),target=env['CARGO_TARGET_DIR'],test_evidence=env['OH_WP24_EVIDENCE_ROOT'])
 (out/(name+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 results.append(dict(name=name,exit=exit,expected=1 if name=='legacy-validate' else 0));print(name+' exit='+str(exit),flush=True)
assert before==hashlib.sha256(proto.read_bytes()).hexdigest()
(out/'proto-readonly-sha.json').write_text(json.dumps(dict(before=before,after=before,unchanged=True),indent=2)+'\n')
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(int(any(r['exit']!=r['expected'] for r in results)))
