from pathlib import Path
import json,hashlib,subprocess,sys
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-CI'
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
original=json.loads((out/'clean-original/result.json').read_text())
current=json.loads((out/'clean-current/result.json').read_text())
native=[json.loads((out/'clean-current'/name/'result.json').read_text()) for name in ('server','server-force')]
negative=json.loads((out/'clean-original/server-rejected/result.json').read_text())
submission=dict(head=head,branch=git('branch','--show-current'),clean=True,base='c28f90425905774c23b1d90a5d900c596ade2745',
 changed_files=git('diff','--name-only','c28f90425905774c23b1d90a5d900c596ade2745','HEAD').splitlines(),
 checks=json.loads((out/'results.json').read_text()),current_unit_tests=17,original_unit_tests=8,
 original_fixture_sha256=original['fixture_sha256'],original_pack_hash=original['pack_hash'],
 current_save_sha256=current['runs'][0]['save_sha256'],current_paused_sha256=current['runs'][0]['paused_sha256'],current_pack=current['runs'][0]['pack'],
 hashes=[current['runs'][0]['split_hash'],current['runs'][0]['resumed_hash']],
 current_local_gate=dict(full_state=True,canonical=True,integer_ledger=True,defines_hash_reference=True,header_binding=True,two_repeats=True,six_fresh_pids=True),
 positive=[dict(force=r['force'],server_pid=r['server_pid'],query_pid=r['query']['pid'],http_status=r['http_status'],server_exit=r['server_exit'],query_exit=r['query_exit']) for r in native],
 historical_negative=[dict(native_exit=r['native_exit'],pid=r['pid'],http_status=r['http_status'],ws_status=r['ws_status'],ctrl_c_sent=r['ctrl_c_sent']) for r in negative['receipts']],
 original_evidence=json.loads((out/'clean-original-evidence-audit.json').read_text()),
 proto=json.loads((out/'proto-readonly-sha.json').read_text()),actual_3os=False,
 limitations=['current defines reference supports the actual integer-only M1 input; future Fx input needs explicit reference extension'],
 pending=['fresh independent WP24 P05-3','parent P07','actual same HEAD three OS workflow and main five workflow green'],
 preserved_failure='WP17 c28 P05-2 actual CI wiring FAIL and raw index FAIL remain; writer/cause unconfirmed, baseline/index not restored')
(out/'submission.json').write_text(json.dumps(submission,indent=2)+'\n')
files=[];reparse=[]
def walk(path):
 for p in sorted(path.iterdir()):
  st=p.lstat();relative=p.relative_to(out).as_posix()
  if p.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:
   reparse.append(relative);continue
  if p.is_dir():walk(p)
  elif relative not in ('evidence-sha256.json','seal-receipt.json'):
   raw=p.read_bytes();files.append(dict(path=relative,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
walk(out);files.sort(key=lambda f:f['path'])
manifest=out/'evidence-sha256.json';manifest.write_text(json.dumps(dict(head=head,files=files,reparse_entries=reparse),indent=2)+'\n')
for f in files:
 raw=(out/f['path']).read_bytes();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
receipt=dict(head=head,files=len(files),mismatches=0,reparse_entries=len(reparse),manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),clean=not bool(git('status','--porcelain')))
(out/'seal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
