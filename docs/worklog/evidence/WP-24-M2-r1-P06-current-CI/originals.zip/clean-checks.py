from pathlib import Path
import os,subprocess,json,sys,hashlib
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-CI';env=dict(os.environ)
env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target');env['OH_WP24_EVIDENCE_ROOT']=str(out/'generated')
sys.path.insert(0,str(root/'crates/oh_save/tools'))
from check_save_current import verify_folder,verify_servers,source_identity,header,files
before=source_identity();assert not before['status']
steps=[('build-server',['cargo','build','-p','oh_server','--locked']),
 ('original',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(out/'clean-original')]),
 ('current',['python','crates/oh_save/tools/check_save_current.py','capture','--out',str(out/'clean-current')]),
 ('server',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'clean-current'),'--out',str(out/'clean-current/server')]),
 ('server-force',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'clean-current'),'--out',str(out/'clean-current/server-force'),'--force']),
 ('historical-negative',['python','crates/oh_server/tests/save_historical_native.py','--capture',str(out/'clean-original'),'--out',str(out/'clean-original/server-rejected')]),
 ('docs',['python','tools/check_docs.py'])]
results=[]
for name,args in steps:
 with (out/('clean-'+name+'.stdout')).open('wb') as so,(out/('clean-'+name+'.stderr')).open('wb') as se:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=so,stderr=se);exit=p.wait()
 receipt=dict(command=args,cwd=str(root),pid=p.pid,exit=exit,head=source_identity()['head'],dirty=bool(source_identity()['status']))
 (out/('clean-'+name+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n');results.append(dict(name=name,exit=exit));print(name+' exit='+str(exit),flush=True)
assert all(r['exit']==0 for r in results),results
current=verify_folder(out/'clean-current');verify_servers(out/'clean-current',current)
original=json.loads((out/'clean-original/result.json').read_text());assert original['dirty'] is False and original['head']==before['head']
negative=json.loads((out/'clean-original/server-rejected/result.json').read_text());assert negative['dirty'] is False and negative['head']==before['head']
source=out/'red-frozen/run-1/pack';save=out/'red-frozen/run-1/paused.ohsave'
(out/'red-input.json').write_text(json.dumps(dict(header=header(save),source_files=files(source),
 actual_original_script_exit=1,actual_server_native_exit=1,actual_server_http_ws_absent=True,
 receipt=json.loads((out/'red-actual-rejection/frozen-server.receipt.json').read_text()),
 preparation_error='the initial probe expected a contiguous substring without ko/en; raw receipt is preserved'),indent=2)+'\n')
after=source_identity();assert before==after,'clean source/raw index changed'
audits=[]
for name,count in [('WP-24',2722),('WP-24-P06',6268)]:
 base=root/'target/evidence'/name;manifest=json.loads((base/'evidence-sha256.json').read_text());assert len(manifest['files'])==count
 for f in manifest['files']:
  raw=(base/f['path']).read_bytes();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'],f['path']
 audits.append(dict(name=name,files=count,mismatches=0,manifest_sha256=hashlib.sha256((base/'evidence-sha256.json').read_bytes()).hexdigest()))
(out/'clean-original-evidence-audit.json').write_text(json.dumps(audits,indent=2)+'\n')
(out/'clean-identity.json').write_text(json.dumps(dict(before=before,after=after,unchanged=True,results=results,current_local_windows_gate=True,actual_3os=False),indent=2)+'\n')
print('clean exact HEAD/raw index unchanged; original/current fullstate/reference and server evidence PASS; actual 3OS not run',flush=True)
