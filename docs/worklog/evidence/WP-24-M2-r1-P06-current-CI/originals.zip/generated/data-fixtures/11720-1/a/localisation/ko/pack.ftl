# 한글
pack-name = { absent }
