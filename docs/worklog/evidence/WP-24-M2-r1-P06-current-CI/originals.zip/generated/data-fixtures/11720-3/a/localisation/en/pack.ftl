pack-name = { absent }
