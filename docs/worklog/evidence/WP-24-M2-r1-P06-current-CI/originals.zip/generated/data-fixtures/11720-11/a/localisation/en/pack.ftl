pack-name = { -absent }
