pack-name =
    .title = Attribute without value
