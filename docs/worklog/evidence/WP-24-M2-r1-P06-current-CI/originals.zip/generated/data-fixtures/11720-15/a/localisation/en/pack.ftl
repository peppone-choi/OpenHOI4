pack-name = { other }
other = { pack-name }
