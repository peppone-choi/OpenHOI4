-brand = OpenHOI4
pack-name = { -brand } { $count ->
    [one] One
   *[other] Many
    }
    .title = Title
