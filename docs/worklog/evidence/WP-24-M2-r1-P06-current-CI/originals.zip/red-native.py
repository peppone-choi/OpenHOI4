from pathlib import Path
import subprocess,os,json,sys,hashlib,importlib.util
root=Path.cwd();out=root/'target/evidence/WP-24-P06-current-CI';out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target')
def invoke(name,args):
 r=subprocess.run(args,cwd=root,env=env,capture_output=True)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 (out/(name+'.command.json')).write_text(json.dumps(dict(command=args,cwd=str(root),exit=r.returncode,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()),indent=2)+'\n')
 print(name+' exit='+str(r.returncode),flush=True);return r.returncode
assert invoke('red-build-server',['cargo','build','-p','oh_server','--locked'])==0
assert invoke('red-frozen-capture',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(out/'red-frozen')])==0
assert invoke('red-original-server-consumer',['python','crates/oh_server/tests/save_native.py','--capture',str(out/'red-frozen'),'--out',str(out/'red-original-native')])==1
sys.path.insert(0,str(root/'crates/oh_server/tests'))
spec=importlib.util.spec_from_file_location('startup_probe',root/'crates/oh_server/tests/pack_startup_native.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
negative=out/'red-actual-rejection';negative.mkdir()
receipt=module.serve(out/'red-original-native/packs',negative,'frozen-server',out/'red-frozen/run-1/paused.ohsave',False,False,'missing message value')
assert receipt['passed']
source=out/'red-frozen/run-1/pack';save=out/'red-frozen/run-1/paused.ohsave'
from save_reference import pack_hash
(out/'red-input.json').write_text(json.dumps(dict(pack_hash=pack_hash(source),save_sha256=hashlib.sha256(save.read_bytes()).hexdigest(),header_prefix_hex=save.read_bytes()[:10].hex(),
 source_files=[dict(path=p.relative_to(source).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(source.rglob('*')) if p.is_file()],receipt=receipt),indent=2)+'\n')
