from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path.cwd();out=root/'target/evidence/WP-17-P06-integration';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,exe,args):
 digest=sha(exe);p=subprocess.Popen([str(exe),*args],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate();(out/(label+'.stdout.json')).write_bytes(stdout);(out/(label+'.stderr.log')).write_bytes(stderr);record={'command':[str(exe),*args],'cwd':str(root),'source':head,'pid':p.pid,'native_exit':p.returncode,'exe_sha256':digest};(out/(label+'.command.json')).write_text(json.dumps(record,indent=2),encoding='utf-8');assert p.returncode==0;assert sha(exe)==digest;return record,json.loads(stdout)
groups=[]
for label,example,filename in [('current-v2','movement_fixture','movement-v2.ohsave'),('current-v3','strait_fixture','strait-v3.ohsave')]:
 exe=root/'target/debug/examples'/f'{example}.exe';runs=[];reports=[]
 for i,args in enumerate([['capture',str(out/f'{label}-1')],['capture',str(out/f'{label}-2')],['resume',str(root/'data/packs/testland'),str(out/f'{label}-1'/filename)]],1):
  r,value=run(f'exact-{label}-{i}',exe,args);runs.append(r);reports.append(value)
 assert reports[0]==reports[1]==reports[2];a=out/f'{label}-1'/filename;b=out/f'{label}-2'/filename;assert a.read_bytes()==b.read_bytes()
 group={'kind':label,'runs':runs,'split_hash':reports[0]['split']['hash'],'end_hash':reports[0]['continuous']['hash'],'save_sha256':sha(a),'full_dto_canonical_equal':True};groups.append(group)
 if label=='current-v2':assert a.read_bytes()!=(root/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave').read_bytes();group['different_current_pack_bytes_from_historical']=True
 else:assert reports[0]['split']['dto']['base']['units'][0]['elapsed']==38654705664;assert reports[0]['arrival']['dto']['base']['units'][0]['province']==40;assert reports[0]['arrival']['dto']['base']['units'][0]['route']==[]
exe=root/'target/debug/examples/movement_fixture.exe';saved=root/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave';record,value=run('exact-historical-v2',exe,['resume',str(root/'crates/oh_save/tests/fixtures/movement-pack-97f'),str(saved)]);expected=json.loads((saved.parent/'movement-v2-97f.expected.json').read_text(encoding='utf-8'));assert value==expected;groups.append({'kind':'historical-v2-source97f','run':record,'original_save_sha256':sha(saved),'original_expected_sha256':sha(saved.parent/'movement-v2-97f.expected.json'),'full_dto_canonical_equal':True})
result={'head':head,'dirty':False,'platform':'Windows','checked_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),'groups':groups};(out/'exact-native-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'head':head,'current_v2':groups[0]['save_sha256'],'current_v3':groups[1]['save_sha256'],'historical_v2':groups[2]['original_save_sha256'],'all_fresh_equal':True}))
