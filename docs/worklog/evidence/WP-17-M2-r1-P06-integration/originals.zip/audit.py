from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=root/'target/evidence/WP-17-P06-integration';results=[]
for name in ['WP-17','WP-17-P06']:
 path=root/'target/evidence'/name/'SHA256-MANIFEST.json';raw=path.read_bytes();m=json.loads(raw);bad=[]
 for e in m['evidence']:
  p=path.parent/e['path']
  if p.stat().st_size!=e['bytes']or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:bad.append(e['path'])
 assert not bad,(name,bad)
 results.append({'directory':name,'head':m['head'],'files':len(m['evidence']),'manifest_sha256':hashlib.sha256(raw).hexdigest(),'all_unchanged':True})
allowed={'crates/oh_save/tests/strait.rs','docs/plans/WP-17-schema.md','docs/worklog/WP-17.md'};changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines());assert changed<=allowed
r={'old_evidence':results,'changed_paths':sorted(changed),'scope_unchanged':True};(out/'old-evidence-audit-result.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r))
