from pathlib import Path
p=Path('crates/oh_save/tests/strait.rs');s=p.read_text(encoding='utf-8');needle='''    let changed = SaveContext::national(&root, "m1").unwrap();''';insert='''    std::fs::write(
        root.join("localisation/ko/wp17-identity-probe.ftl"),
        "wp17-identity-probe = 독립 식별자 시험\\n",
    )
    .unwrap();
''';assert s.count(needle)==1;s=s.replace(needle,insert+needle,1);p.write_text(s,encoding='utf-8')
