import argparse,subprocess,os,json,datetime
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.command;cmd=cmd[1:]if cmd and cmd[0]=='--'else cmd
root=Path.cwd();out=root/'target/evidence/WP-17-P06-integration';env=os.environ.copy();env['PATH']=r'C:\Users\user\.cargo\bin;'+env['PATH'];env['CARGO_TARGET_DIR']=str(root/'target');env['PYTHONUTF8']='1'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();dirty=subprocess.check_output(['git','status','--porcelain'],text=True)
start=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat();proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=proc.communicate();(out/(a.name+'.stdout.log')).write_bytes(stdout);(out/(a.name+'.stderr.log')).write_bytes(stderr)
r={'command':cmd,'cwd':str(root),'head':head,'dirty':dirty,'pid':proc.pid,'native_exit':proc.returncode,'started_at':start,'stdout':a.name+'.stdout.log','stderr':a.name+'.stderr.log'};(out/(a.name+'.json')).write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r));print((stdout+stderr).decode('utf-8',errors='replace')[-5000:]);raise SystemExit(proc.returncode)
