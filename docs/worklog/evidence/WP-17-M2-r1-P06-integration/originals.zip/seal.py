from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();out=root/'target/evidence/WP-17-P06-integration';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],text=True);assert status==''
files=[]
for p in sorted(out.rglob('*')):
 if p.is_file()and p.name!='SHA256-MANIFEST.json':files.append({'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
record={'head':head,'base':'500ba0f91cc53ed10660fca14294d4deb5a146d4','status':status,'worktree':str(root),'evidence':files};(out/'SHA256-MANIFEST.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps({'head':head,'clean':True,'evidence_files':len(files),'manifest_sha256':hashlib.sha256((out/'SHA256-MANIFEST.json').read_bytes()).hexdigest()}))
