"""Synthetic predicate test only. It never establishes actual Linux/macOS runs."""
import pathlib,json,shutil,sys,hashlib
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1');E=W/'target/evidence/WP-13-M2-r2-P05-1';sys.path.insert(0,str(W/'crates/oh_sim/tools'));import check_trigger_determinism as gate
out=E/'stale-predicate';out.mkdir();stale='f44e16e079cad68e21825a1d9c7bcf1745170412'
for runner,platform in gate.RUNNERS.items():
 d=out/f'trigger-{runner}';shutil.copytree(E/'trigger-capture',d)
 for file in ['source-before.json','source-after.json']:
  v=gate.strict_json(d/file);v['head']=stale;(d/file).write_text(json.dumps(v,indent=2),encoding='utf-8')
 v=gate.strict_json(d/'result.json');v.update(head=stale,platform=platform);(d/'result.json').write_text(json.dumps(v,indent=2),encoding='utf-8')
 m=gate.strict_json(d/'manifest.json');m.update(v);m['files']=gate.files(d);m['files'].pop('manifest.json');(d/'manifest.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
try:
 gate.compare_artifacts(out,emit=False)
 rejected=False;error=None
except (AssertionError,ValueError,KeyError,OSError) as e:rejected=True;error=str(e)
result={'kind':'synthetic negative exact-head predicate, never actual3OS','artifact_claimed_head':stale,'actual_verification_head':'ff78a7501bace6fac1741d6cc596be524f887451','rejected':rejected,'error':error}
(E/'stale-predicate-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result));assert rejected,'three matching stale source HEAD claims accepted by actual comparer'
