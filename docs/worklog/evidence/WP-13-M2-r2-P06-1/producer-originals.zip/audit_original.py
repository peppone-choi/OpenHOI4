import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd()
out=root/'target/evidence/WP-13-P06-1'
custody=Path('E:/openhoi/docs/verify/evidence/WP-13-M2-r2-P05-1')
identity=json.loads((custody/'ZIP-IDENTITY.json').read_text(encoding='utf-8'))
manifest=json.loads((custody/'SHA256SUMS.json').read_text(encoding='utf-8'))
digest=lambda data:hashlib.sha256(data).hexdigest()
assert digest((custody/'evidence.zip').read_bytes())==identity['zip_sha256']
assert digest((custody/'SHA256SUMS.json').read_bytes())==identity['manifest_sha256']
with zipfile.ZipFile(custody/'evidence.zip') as archive:
    assert len(archive.namelist())==identity['zip_members']
    for entry in manifest['files']:
        raw=archive.read(entry['path'])
        assert len(raw)==entry['bytes'] and digest(raw)==entry['sha256'],entry['path']
original=out/'original-fail-readonly'
probe=Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1')
inputs={}
for name in ('scratch-runtime.test.ts','runtime-observations.json','checker-stale-probe.py','stale-predicate-result.json'):
    assert (probe/name).read_bytes()==(original/name).read_bytes(),name
    inputs[str(probe/name)]=digest((probe/name).read_bytes())
report=Path('E:/openhoi/docs/verify/WP-13.M2-r2.attempt1.md')
assert report.read_bytes()==(original/report.name).read_bytes()
inputs[str(report)]=digest(report.read_bytes())
old=root/'target/evidence/WP-13/originals.zip'
assert digest(old.read_bytes())=='851bbde074c5636d913a3cd19ba14bbfa098b8947045eb6bfcebb0c0f8b1b89a'
result={'original_p05_head':identity['head'],'zip_sha256':identity['zip_sha256'],
        'manifest_sha256':identity['manifest_sha256'],'manifest_files_verified':len(manifest['files']),
        'zip_members':identity['zip_members'],'mismatches':0,'read_only_inputs':inputs,
        'original_producer_zip_sha256':digest(old.read_bytes())}
(out/'original-custody-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
