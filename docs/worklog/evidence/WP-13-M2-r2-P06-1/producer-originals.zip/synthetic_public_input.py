"""Copies one actual Windows capture for predicate tests only, never 3OS proof."""
import importlib.util,json,shutil
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/WP-13-P06-1'
spec=importlib.util.spec_from_file_location('gate',root/'crates/oh_sim/tools/check_trigger_determinism.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
source=out/'final-trigger'
result,_=gate.verify_folder(source)
identity=gate.identity()
assert identity['status']=='' and result['head']==identity['head']
destination=out/'final-synthetic-public-predicate'
destination.mkdir(exist_ok=False)
for runner,platform in gate.RUNNERS.items():
    folder=destination/f'trigger-{runner}'
    shutil.copytree(source,folder)
    copied=gate.strict_json(folder/'result.json');copied['platform']=platform
    (folder/'result.json').write_text(json.dumps(copied,indent=2),encoding='utf-8')
    copied['files']=gate.files(folder);copied['files'].pop('manifest.json')
    (folder/'manifest.json').write_text(json.dumps(copied,indent=2),encoding='utf-8')
(out/'synthetic-public-disclaimer.json').write_text(json.dumps({
    'source':str(source),'head':result['head'],'actual_platform':'Windows',
    'synthetic_os_labels':True,'evidence_mode':'public predicate only; no actual3OS/mainCI claim'},indent=2),encoding='utf-8')
print('Synthetic public comparer input prepared from one actual Windows capture; predicate only.')
