import importlib.util,json,hashlib,subprocess,shutil,sys
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/WP-13-P06-1'
spec=importlib.util.spec_from_file_location('gate',root/'crates/oh_sim/tools/check_trigger_determinism.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
def load(relative):return json.loads((out/relative).read_text(encoding='utf-8'))
allowed={'client/src/network.ts','client/src/triggerValidation.test.ts',
         'crates/oh_sim/tools/check_trigger_determinism.py','crates/oh_sim/tests/test_trigger_evidence.py',
         'docs/plans/WP-13-schema.md','docs/adr/ADR-1301-trigger-end-state.md','docs/worklog/WP-13.md'}
base='ff78a7501bace6fac1741d6cc596be524f887451'
current=gate.identity();before=load('final-source-before.json')
assert current==before and current['status']==current['diff']==current['cached']==''
changed=set(gate.git('diff','--name-only',base,'HEAD').splitlines())
assert changed==allowed,changed
old=json.loads((root/'target/evidence/WP-13/final-source-before.json').read_text(encoding='utf-8'))
assert old['head']==base and set(old['tracked'])==set(current['tracked'])
protected_changes=[p for p in current['tracked'] if p not in allowed and current['tracked'][p]!=old['tracked'][p]]
assert not protected_changes,protected_changes
old_log=subprocess.check_output(['git','--no-optional-locks','show',base+':docs/worklog/WP-13.md'],cwd=root)
new_log=(root/'docs/worklog/WP-13.md').read_bytes().replace(b'\r\n',b'\n')
assert new_log.startswith(old_log),'worklog must append only'
commands={}
for folder in sorted(out.iterdir()):
    if not folder.is_dir() or not (folder/'command.json').is_file() or not (folder/'result.json').is_file():continue
    command=json.loads((folder/'command.json').read_text(encoding='utf-8'))
    result=json.loads((folder/'result.json').read_text(encoding='utf-8'))
    commands[folder.name]={'command':command,'result':result}
    if folder.name.startswith('final-'):
        expected=1 if folder.name in ('final-public-stale-original','final-audit-command') else 0
        assert result['exit']==expected,(folder.name,result)
        assert command['head']==current['head'] and command['status']=='',folder.name
        assert result['pid']>0 and result['executable_sha256_before']==result['executable_sha256_after']
assert '233 passed' in (out/'final-client-test/stdout.txt').read_text(encoding='utf-8')
assert 'Ran 12 tests' in (out/'final-comparer-tests/stderr.txt').read_text(encoding='utf-8')
for name,expected in [('m0','b039d35666b77fc2'),('m1','b595dc2a1e5b4f8c')]:
    assert (out/f'final-{name}-1/stdout.txt').read_text().strip()==(out/f'final-{name}-2/stdout.txt').read_text().strip()==expected
v4,cases=gate.verify_folder(out/'final-trigger')
assert v4['head']==current['head'] and v4['platform']=='Windows'
for version in ('v2','v3'):
    capture=load(f'final-{version}-capture/stdout.txt');resume=load(f'final-{version}-resume/stdout.txt')
    assert capture==resume,version+' full DTO/hash/canonical differs'
    assert commands[f'final-{version}-capture']['result']['pid']!=commands[f'final-{version}-resume']['result']['pid']
frozen=json.loads((root/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json').read_text())
assert load('final-v2-original/stdout.txt')==frozen
for name in ('final-frozen-v1','final-current-v1'):
    result=load(name+'/result.json')
    assert result['head']==current['head'] and result['dirty'] is False
sys.path.insert(0,str(root/'crates/oh_save/tools'))
import check_save_current
check_save_current.verify_folder(out/'final-current-v1')
servers={}
for path in sorted((out/'final-server').glob('*/result.json')):
    result=json.loads(path.read_text(encoding='utf-8'));servers[path.parent.name]=result
    assert result['head']==current['head'] and result['exit']==result['query_exit']==0
    assert result['http_status']==200 and result['save_preserved'] and result['pack_preserved']
assert len(servers)==4
assert (out/'final-cli-checkpoint/stdout.txt').read_text().strip()==(out/'final-cli-ended-resume/stdout.txt').read_text().strip()=='38e33863e17af7ba'
for path in sorted((out/'final-public-receipts').glob('*/receipt.json')):
    r=json.loads(path.read_text())
    assert r['source_before']==r['source_after'] and r['pid']>0 and len(r['executable_sha256'])==64
    expected=0 if 'same_clean' in path.parent.name else 1
    assert r['native_exit']==expected and r['synthetic_os_labels']
scope=out/'submitted-source'
scope.mkdir(exist_ok=False)
for relative in sorted(allowed):
    target=scope/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/relative,target)
(out/'submitted-diff.patch').write_bytes(subprocess.check_output(['git','--no-optional-locks','diff','--binary',base,'HEAD'],cwd=root))
summary={'head':current['head'],'branch':gate.git('branch','--show-current'),'clean':True,
         'tracked_count':len(current['tracked']),'raw_index_sha256':current['raw_index_sha256'],
         'source_before_equal':True,'changed_files':sorted(changed),'protected_sha_mismatches':protected_changes,
         'protected_files_verified':len(current['tracked'])-len(allowed),'worklog_append_only':True,
         'runtime_tests':{'red':{'total':103,'failed':67,'passed':36,'native_exit':1},'green':{'total':233,'failed':0,'native_exit':0}},
         'comparer_tests':{'red':{'total':12,'failed':2,'native_exit':1},'green':{'total':12,'failed':0,'native_exit':0},
                           'original_stale_public_red_exit':0,'original_stale_public_final_exit':1,'synthetic_os_predicate_only':True},
         'trigger_cases':{name:{'hash':case['hash'],'ended':case['ended']} for name,case in cases.items()},
         'trigger_capture':v4,'actual_server_queries':servers,'legacy_v2_v3_full_dto_equal':True,'original_v2_frozen_equal':True,
         'cli_ended_hash':'38e33863e17af7ba','cli_reencoded_bytes_equal':(out/'final-checkpoint.ohsave').read_bytes()==(out/'final-checkpoint-reencoded.ohsave').read_bytes(),
         'original_custody':load('original-custody-audit.json'),'native_commands':commands,
         'decisions_needed':'none for P06-1; initial deferred scoring/adapters unchanged',
         'pending':['independent P-05','actual Linux/macOS same-main-HEAD3OS','main CI/integration'],
         'audit_preparation_errors':{'final-audit-command':'receipt enumerator tried to read its own unfinished result; FileNotFoundError/native1, product checks not run by this attempt'},
         'actual_3os_claim':False}
(out/'final-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
assert gate.identity()==before
print(json.dumps({k:summary[k] for k in ('head','clean','tracked_count','raw_index_sha256','protected_files_verified','protected_sha_mismatches','legacy_v2_v3_full_dto_equal','original_v2_frozen_equal','actual_3os_claim')}))
