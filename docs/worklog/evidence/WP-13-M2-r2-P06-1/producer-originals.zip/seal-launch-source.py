import json,hashlib,subprocess,sys,importlib.util
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/WP-13-P06-1';receipts=root/'target/evidence/WP-13-P06-1-seal'
receipts.mkdir(exist_ok=False)
cmd=[sys.executable,str(out/'seal.py')]
proc=subprocess.Popen(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
stdout,stderr=proc.communicate()
(receipts/'stdout.txt').write_bytes(stdout);(receipts/'stderr.txt').write_bytes(stderr)
receipt={'command':cmd,'cwd':str(root),'pid':proc.pid,'native_exit':proc.returncode,
         'executable':sys.executable,'executable_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
         'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest()}
(receipts/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert proc.returncode==0,stderr.decode(errors='replace')
spec=importlib.util.spec_from_file_location('gate',root/'crates/oh_sim/tools/check_trigger_determinism.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
source=gate.identity();before=json.loads((out/'final-source-before.json').read_text(encoding='utf-8'))
assert source==before
index=Path(gate.git('rev-parse','--git-path','index'))
if not index.is_absolute():index=root/index
assert index.read_bytes()==(out/'final-source-before.index').read_bytes()
(receipts/'post-seal-source.json').write_text(json.dumps(source,indent=2),encoding='utf-8')
identity=json.loads((out/'ZIP-IDENTITY.json').read_text(encoding='utf-8'))
identity['seal_native_receipt']=receipt
identity['post_seal_source_equal']=True
identity['post_seal_receipts']=str(receipts)
(out/'ZIP-IDENTITY.json').write_text(json.dumps(identity,indent=2),encoding='utf-8')
print(json.dumps(identity))
