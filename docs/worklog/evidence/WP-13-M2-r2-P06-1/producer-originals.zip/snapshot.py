import importlib.util,json,sys,shutil
from pathlib import Path
root=Path.cwd()
spec=importlib.util.spec_from_file_location('gate',root/'crates/oh_sim/tools/check_trigger_determinism.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
current=gate.identity()
out=root/'target/evidence/WP-13-P06-1'
label=sys.argv[1]
path=out/(label+'.json')
assert not path.exists()
path.write_text(json.dumps(current,indent=2),encoding='utf-8')
index=Path(gate.git('rev-parse','--git-path','index'))
if not index.is_absolute():index=root/index
shutil.copyfile(index,out/(label+'.index'))
if len(sys.argv)>2:
    assert json.loads((out/(sys.argv[2]+'.json')).read_text(encoding='utf-8'))==current,'source identity changed'
print(json.dumps({'head':current['head'],'status':current['status'],'tracked_count':len(current['tracked']),
                  'raw_index_sha256':current['raw_index_sha256'],'before_equal':len(sys.argv)>2}))
