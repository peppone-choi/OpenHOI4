역할: 구현 세션. OpenHOI4 M2-r2 WP-13 P-06-1 오류 수정.
전용 worktree E:/openhoi/.orchestrator/wt/WP-13-M2-r2, branch codex/wp13-trigger-engine-m2r2. exact 원 producer ff78a7501bace6fac1741d6cc596be524f887451을 유지하며 자기 branch에만 새 수정 커밋한다. 기본 cwd main이므로 모든 명령 workdir 또는 git -C를 위 전용 경로로 지정한다. 다른 세션의 변경을 되돌리지 않는다. 부모 thread01a114ca-469a-73c0-a9c4-9df475c37769/local 업무 메시지는 사용자 승인이다. 새 앱을 만들거나 main 병합/푸시하지 않는다.

부모가 실제 독립 P05-1 마지막 리포트·최초/최종 추적파일/raw index 불변성·manifest/ZIP member bytes를 보존한 뒤 전송하는 수정 요청이다. 아래 final attachment와 custody를 실제 읽고 원 FAIL을 유지한다. target 상세문서로 actual final을 대체하지 않는다. 원 증거 폴더를 덮지 말고 새 output target/evidence/WP-13-P06-1을 사용한다.

읽기: AGENTS.md, docs/03 P-06/P-03, 자기 WP-13-schema/ADR-1301/worklog, 부모 최신 DIRECTIVES 및 REQUEST0009 A. 해당 actual FAIL/report/probes는 read-only. 최종 verdict·분석·원인·failing regression 먼저 확인한다.

수정 소유: client/src/network.ts, client/src/triggerValidation.test.ts 및 필요한 새 trigger runtime 전용 test; crates/oh_sim/tools/check_trigger_determinism.py, crates/oh_sim/tests/test_trigger_evidence.py; 자기 docs/plans/WP-13-schema.md, ADR-1301 및 docs/worklog/WP-13.md. 근본 해결에 다른 파일이 필요하면 실제 경로/호출/이유를 부모에게 먼저 보내 단일 소유를 인수한다. proto/TS 계약 자체·sim/data/save 원상태/codec·원 workflows/old checker/fixtures/expected/golden·Cargo/ASSETS·부모01/02/03/HANDOFF/계획은 보호한다.

FAIL runtime: 새 TriggerResult/TriggerView/EndView/EndCauseView/NationFlagsView가 실제 typed/sorted/unique/id/u64 상한/unknown-field 규칙을 온전히 강제하지 않는다. 독립 probe의 invalid message가 callback을 갱신하고 connection open 및 추가 command 전송을 유지한다. schema와 Rust 생성 계약에 맞춰 정확 member key/type/null, 십진문자열 u64 상한, 정수 nation ID 범위, 실제 flag/source ID syntax, flags nation/key 정렬·중복, 원인 nonempty·정렬·중복 및 Date/Condition/Explicit의 정확 variant 필드를 검사한다. 필요한 gameplay rule을 client가 재계산하지 않고 wire 구조/순서/범위 신뢰 경계만 강제한다. 정상 unsupported/active/ended/tick0/empty keys/복수원인은 계속 수용한다. malformed는 이전 정상 callback/화면 유지·invalid-server-message close·그 뒤 새 command 차단 계약을 그대로 적용한다. 기존 다른 message 검사 강도를 약화하지 않는다. 실제 malformed callback/close/block 회귀를 수정 전 실패시킨 뒤 고친다.

FAIL checker: 세 artifact가 같은 과거 f44 HEAD를 주장할 때 현재ff78 checkout에 public compare native0로 수용된다. compare_artifacts/public CLI는 먼저 현재 source exact HEAD 및 clean tracked 상태를 read-only로 확인하고 각 artifact source-before/after/result/manifest의 실제 HEAD가 현재와 같음을 강제한다. artifact 사이만 동일 비교하는 것으로 대신하지 않는다. source/index를 갱신하지 않는 git optional lock0을 유지하고 current dirty·다른HEAD를 실패시킨다. 기존 repeat bytes/fullDTO/defs/pack/header/canonical/hash/nativePID/executableSHA/cwd/exit/모든3OS 단언과 synthetic != actual3OS 경계를 유지한다. 새로운 predicate regression은 현재HEAD expected를 명시할 수 있으나 실제 public入口를 synthetic stale/all-same-old HEAD/dirty checkout에 실행하여 native nonzero임을 증명하고 정상 sameclean source를 실제 local capture로 확인한다. 동작을 검증하지 않는 mock/selfbaseline/skip green을 쓰지 않는다. 원 old Save/Core/Simulation checker의 범위는 수정하지 않는다.

P-06 재현→원인→실효 failing test→최소수정→동일원인인접경로 목록→P-03 검증/작업로그 수정기록→자기 clean commit 순서다. 원 runtime/stale FAIL과 CP949 wrapper 출력오류 및 verifier probe 메타데이터 오류는 구분해 유지한다. 검증의 schema/달력/37 CLI/정상서버/paused-active/원None/v1/v2/v3/신규v4 및 원producer 증거 통과를 새 source 검증으로 대신하지 않는다.

fmt/clippy/workspace/client test/typecheck/build 및 readonly TS equality, M0/M1 해시 각2회, runtime invalid end-to-end·stale/dirty public comparer negatives·실제sameclean capture를 직접 실행한다. 커밋 뒤 source-before/after/raw tracked정합과 실제 CLI/server 정상query/end/refusal/native0·기존/신규 freshPID reencode/fullDTO/canonical/hash를 다시 얻고 원 inputbytes 보존을 확인한다. 새 source final/cmd/cwd/PID/nativeexit/stdout/stderr/manifest/원ZIP identity를 새 폴더에 봉인한다. 자기 worklog의 P06 추가 절만 기록하며 전체완료/독립PASS/실제3OS/mainCI는 선언하지 않는다.

마지막은 정확40char HEAD/clean·변경파일·red/green 실제 명령/증거경로·결정필요/범위밖/못한부분을 짧게 보고한다.

[확정 실제 인수]
actual final turn01a11513-bf86-7471-b0f0-bfdb727562fc completed. 부모9951/rawdf3bb 최초/최종동일. MF2186/ZIP2187 bytes/SHA 불일치0, ZIPcf3f62b8794506a0a9ce9efcc56055e889960bac4ecd2f95d21b49fd7929a337. main docs/verify/WP-13.M2-r2.attempt1.md 및 docs/verify/evidence/WP-13-M2-r2-P05-1 읽기만. 독립 repro source: E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1/scratch-runtime.test.ts, runtime-observations.json, checker-stale-probe.py, stale-predicate/ 를 원형보존하고 자기전용회귀에대응.

[actual final 전문]
# 검증 리포트 — WP-13 M2-r2 / P-05 시도 1

| 항목 | 값 |
|---|---|
| 판정 | **FAIL** — 검증 불변성은 유효. 신규 runtime guard와 comparer에 재현 가능한 누락 2건 |
| 검증자 | Codex 검증 세션, 구현 비참여·새 앱 채팅·추적 파일 무변경 |
| 브랜치·커밋 | detached `ff78a7501bace6fac1741d6cc596be524f887451` / 구현 `codex/wp13-trigger-engine-m2r2` |
| 검증 일시 | 2026-10-07 KST, 최종 봉인 15:55 및 봉인 후 불변성 재확인 |
| 전용 worktree | `E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1` |
| 실행 증거 | [command-results.json](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1/command-results.json) — 67개 native command receipt |
| 리포트 원문 | [fullreport.md](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1/fullreport.md) |

## 직접 실행한 명령

모든 명령의 cwd는 위 worktree이며 `GIT_OPTIONAL_LOCKS=0`, Cargo target은 자기 `target`이다. Cargo 실파일 존재를 먼저 확인하고 절대 실행 경로 또는 해당 process PATH를 사용했다. 반복·관련 probe를 묶은 표이며 개별 argv/cwd/env/PID/exit/stdout/stderr는 command-results에 보존했다.

| 명령 | 종료 코드 | 결과 요약 |
|---|---|---|
| `cargo fmt --check` | 0 | 통과 |
| `cargo clippy --workspace -- -D warnings` | 0 | 통과 |
| `cargo test --workspace` | 0 | 전체 통과. data trigger 4·sim trigger 9·save trigger 2 및 기존 회귀 직접 실행 |
| `npm --prefix client ci/test/run typecheck/run build` | 각각 0 | client 131/131, 타입·embedded dist build 통과 |
| `cargo test -p oh_proto req_net_04_generated_types_are_current -- --exact` | 0 | read-only generated TS equality. tracked generator 미실행 |
| `cargo run -p oh_cli -- run --scenario testland --days 365 --seed 1 --hash-out` ×2 | 0/0 | M0 동일 |
| 같은 run에 `--pack data/packs/testland --scenario m1` ×2 | 0/0 | actual M1 동일 |
| `oh_cli validate --deny-warnings` 원팩·trigger팩 | 0/0 | 실제 registered loader 통과 |
| 독립 `data-probe.py` | 0 | 실제 CLI 정상/오류/경계 37건 기대 exit 일치 |
| 독립 Rust probe 및 확장 실행 | 0/0 | 달력·scope·flags·깊이·예산·scheduled 오류 소비·실제 원장 phaseErr 원자성 |
| 독립 native probe `matrix/fresh/mutations` | 최종 모두 0 | legacy strict/force 행렬, v4 pending-only/empty context, fresh pause→unpause, 복원 변조 12건 |
| trigger checker `capture` | 0 | clean Windows capture 2회, 6종 full DTO/canonical/hash·fresh resume·원save bytes |
| trigger evidence unittest | 첫 1, 준비 후 0 | 최초 capture 경로 미준비로 0 tests. 준비 후 9/9 |
| `trigger_native.py` | 0 | ended/tick0/paused 복원 및 tick0 startup, HTTP200·query 지속·명령 거부·Ctrl+C native0 |
| `trigger_negative.py` | 0 | CLI/server normal·force mode mismatch와 unsupported at_war native1, HTTP/WS 미수용·입력 보존 |
| 실제 CLI run/resume·save-out | 모두 0 | 요청 상한 전에 tick48/tick0 정상 종료. 종료 저장 재개도 같은 hash |
| original/current save checker capture | 0/0 | frozen v1와 별도 current input 각각 repeat/fresh 검사 |
| current server normal/force·historical server 검사 | 0/0/0 | current 서버 native0, historical 서버 native1 거부 유지 |
| original/current save evidence unittest | 0/0 | 8/8 및 21/21 |
| 원 movement/strait fixture capture·fresh resume | 모두 0 | v2/v3 전체 JSON·DTO·canonical·hash 일치 |
| Cargo deny·npm licenses | 0/0 | 허용 라이선스 검사 통과, npm 103 dependencies |
| docs/assets/architecture/localisation checker | 각각 0 | docs 오류·경고0, assets 오류0. localisation unused 경고 원문 유지 |
| 독립 scratch Vitest | **1** | 25건 중 22건 FAIL, 3건 PASS |
| runtime 관찰 probe | **1** | invalid 메시지 callback 전달·연결 유지·후속 send 가능 확인 |
| 독립 stale checker probe | **1** | stale source HEAD 거부 단언 실패 |
| 실제 comparer의 stale 입력 실행 | **0, 기대는 거부** | 세 artifact 모두 과거 HEAD여도 수용 |
| 구현 원증거·source·최종 state/bytes audit | 최종 0 | 원 2,154개 파일/ZIP member 불일치0, 보호 원천 변경0 |

준비·검증자 오류도 보존했다.

- npm build/localisation은 native0이었다. 이후 출력 wrapper만 CP949 UnicodeEncodeError로 tool exit1이었다.
- CLI fresh probe 최초101 두 건은 검증자가 저장 timestamp를0으로 가정한 오류였다. 실제 header timestamp/player metadata를 사용한 별도 실행에서 원bytes·전체 DTO/canonical/hash 일치를 확인했다.
- 마지막 audit 최초1은 자기 실행 중 아직 작성되지 않은 result를 찾은 검증자 오류였다. 별도 최종 실행은0이었다.
- 제품 코드·추적 테스트·기대값은 수정하지 않았다.

## REQ별 확인

| REQ | 검사하는 테스트 | 실제 검사 여부 | 결과 |
|---|---|---|---|
| REQ-AGD-05 문법·registry | `single_key_argument_and_depth_validation`, `registry_every_initial_argument_schema_and_malformed`, `actual_registered_loader_rejects_capability_with_source` | 실행 및 source/field표 대조, 독립 CLI 37건 | single-key·null/type/range/ref·미지원 로드 거부 통과 |
| REQ-AGD-05 실제 host | `actual_world_queries_and_read_only_conditions`, `scope_restoration_idempotence_and_v4_restore`, 효과 budget/depth/실패 테스트 | actual World owner/controller/support 및 자체 비연속 NationId87·owner scope 검사 | all/any/not·읽기 불변·idempotence·scope 복귀·깊이16/17·primitive1000/1001 통과 |
| REQ-TIME-04 실행 | inclusive checkpoint, calendar centuries, simultaneous sources/phase error 테스트 | 자체 Gregorian 계산 및 실제 Simulation step/ledger overflow | inclusive 다음날00:00·start=end24h·end<start 오류·초기tick0·다중 원인·한번 종료 통과 |
| REQ-TIME-04 저장·host | v4 codec/legacy mode/query 테스트 및 native probes | 실제 codec/API strict·force 행렬, fresh process, 원save/queue 비교 | 저장·원형 호환·종료 후 query/save·새 명령 거부 통과 |
| 신규 wire/runtime | 기존 `triggerValidation.test.ts`와 독립 scratch-runtime | Rust→tracked TS equality 및 실제 `connect()`의 invalid MessagePack 경로 | **FAIL F1** |
| 신규 evidence gate | 기존 predicate 9개, 독립 stale probe·실제 comparer | 실제 Windows와 합성 negative 분리 | **FAIL F2** |

필드의 definition/initial/mutable/derived, 의미·단위·type/range/null/default/ref/lifetime/authority를 constructor/step/canonical/v4/query와 대조했다.

`with_world`는 초기 권위 설치 뒤 한번 평가하고 `with_movement`는 이를 한번 호출한다. v4 restore는 frozen substrate 복원 후 저장 trigger를 검증·설치하며 초기 flags 생성이나 조건 재평가를 호출하지 않는다. Pause 중 조건이 참이 된 active 저장을 별도 PID에서 그대로 복원했고, 첫 unpause 성공 시간전진에서만 tick1 Condition 종료를 확인했다.

예정 effect budget 오류는 명령을 거부·소비하면서 clock을 전진한다. enqueue preview 오류는 전체 canonical을 보존한다. 효과가 flags/end 후보를 만든 뒤 실제 원장 overflow가 난 phaseErr는 world/state/clock/queue/flags/end/seed를 포함한 전체 canonical을 보존했다.

## 결정론

- M0 해시1/2: `b039d35666b77fc2` / `b039d35666b77fc2`.
- actual M1 해시1/2: `b595dc2a1e5b4f8c` / `b595dc2a1e5b4f8c`.
- 원 v1 split→재개: `4eb703aad086c7aa` → `d19d028857bb7485`.
- frozen v1 fixture SHA: `57b13c62ef1a6f88ade1851d0b3ae398157f95ca5bc246068eac3b2a964322fa` 유지.
- 원 v2 split→continuous/fresh: `18bff036731f4f26` → `a145b72ad0ad25e6`.
- 원 v3 split→continuous/fresh: `84462b78cc1a0f5d` → `299a80d49c17f3ec`.
- v4 active/split/ended/empty/initial/paused_condition의 capture2회·fresh 재개·원save 재인코드 동일. ended의 Date/Condition/Explicit(a)/Explicit(z), 미래 명령5개, movement/strait 상태 보존.
- 독립 pending-only fresh 반복: `41577048c05059f1`.
- Some(empty movement): `66e33169f83d0356`.
- Some(empty strait): `ee9523cc5d37ae97`.
- CLI 실제 tick48 종료: `e374aab2f639f1fe`, 초기tick0: `e2c7c1ba82bc26a4`. native0·fresh 재개 동일.

실제 수행 플랫폼은 Windows만이다. 합성 Linux/macOS labels는 predicate 입력이다. 같은 main 기존5종 CI와 신규 trigger workflow의 실제 OS job/artifact는 부모 통합 후 확인 대상이며 여기서는 미실행·미확인이다.

## 금지 사항 점검

| 항목 | 결과 |
|---|---|
| 시뮬레이션의 f32/f64 | sim source 직접 읽기·검색 및 architecture 검사에서 없음. Fx integer raw arithmetic 확인 |
| HashMap 순회 | 없음. BTreeMap/BTreeSet/ordered Vec 사용 |
| thread_rng / SystemTime / I/O | sim source에 없음. 조건 host는 immutable borrow, chance는 현재 end/if context에서 로드 거부 |
| 코드 내 수치 리터럴 | 신규16/1000은 명세의 기술 상한. Gregorian·wire/codec 타입 경계이며 새 gameplay 계수 없음 |
| 미결정 규칙 구현 | REQUEST-0009 A의 CEO 한정 잠정과 최신01§3.3/02§5.7 대조. 사용자 추가확정으로 바꾸지 않음 |
| 골든 기대값 변경 근거 | 원 packs/golden/repro/frozen fixtures/helpers/checkers·기존 workflows·의존성 파일 변경0. 기존 단언 삭제·약화 없음 |
| 클린룸 | synthetic trigger fixture·ASSETS append·provenance 대조. 원작 자료 사용 근거 없음 |
| 클라이언트 규칙 계산·설정 우회 | 없음. tracked generator·설정 우회 미실행 |

## 작업 로그 증거와 실제 결과 대조

구현 원 manifest의 2,154개 파일을 디스크/ZIP member 전수 bytes·SHA와 대조했고 불일치0이었다. 원 ZIP SHA `851bbde074c5636d913a3cd19ba14bbfa098b8947045eb6bfcebb0c0f8b1b89a`도 custody와 일치했다. red-data/red-sim native101과 이후 clean0 원출력을 보존했다.

구현의 기존 client 131 tests·workspace·해시·native 저장/서버 주장은 재실행과 일치한다. 그 테스트들은 F1과 F2를 검사하지 못했다.

원 tracked source와 최신 planning 사본 HEAD `c8913c8c5255cbf117844534b0291eb8c812c12f`를 구분했다. planning16개 SHA는 parent identity와 모두 같았다.

미지원 정치/법령/경제/장비/전쟁 primitive는 실제 사용 팩의 로드 오류다. 점수는 generic checked Fx 산술만 있으며, 실제 VP accessor/보유 의미·국가 IC·생존/진영은 후속 producer 인수가 필요하다. WP20/22 항복·관전, WP22 결과 UI, M3 chance adapter·전체 MOD07 reference도 미완료로 유지했다. 부분0weight/합성 산술·query를 전체 M2 완료로 세지 않았다.

봉인 후에도 부모 original-before와 HEAD·9,951개 tracked list/SHA·semantic index·raw index bytes·status/diff/cached diff가 모두 동일했다. raw index SHA는 `df3bb6c3ab0ec15d4bc35117f8d096b5bd27543bcea980cee03218691c4319d7`이다. 검증 무효 조건은 발생하지 않았다. 자기 target 실행 프로세스0개를 확인했으며 앱 종료를 CLI exit0으로 기록하지 않았다.

증거는 [SHA256SUMS.json](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1/SHA256SUMS.json)과 [evidence.zip](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1/evidence.zip)에 봉인했다. evidence 2,186개 파일·ZIP 2,187개 member의 전수 bytes·SHA 검사를 통과했다.

ZIP SHA는 `cf3f62b8794506a0a9ce9efcc56055e889960bac4ecd2f95d21b49fd7929a337`이다. manifest/ZIP 자체 identity·native 봉인 receipt·봉인 후 불변성 결과는 별도 [ZIP-IDENTITY.json](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1/ZIP-IDENTITY.json)에 있으며 순환 self hash는 없다.

## FAIL 항목

| # | 재현 명령 | 기대 | 실제 |
|---|---|---|---|
| **F1** | `node client/node_modules/vitest/vitest.mjs run --config target/evidence/WP-13-M2-r2-P05-1/scratch-vitest.config.mjs` | 중복/역순/빈 causes, 중복/역순 nation·flag, invalid ID, u64 초과 tick을 거부하고 callback 전 연결종료·후속 send 차단 | 최초25건 중22 실패. 관찰 probe에서 11종 invalid 모두 callbackCount2/closeCount0/sentAfterInvalid1 |
| **F2** | `python target/evidence/WP-13-M2-r2-P05-1/checker-stale-probe.py`; 실제 comparer `compare --root target/evidence/WP-13-M2-r2-P05-1/stale-predicate` | artifact source HEAD가 현재 exact checkout과 다르면 거부 | 세 합성 artifact의 HEAD를 모두 base `f44e16…`로 바꾸고 manifests를 재봉인해도 comparer native0 |

F1은 [network.ts](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/client/src/network.ts:40)의 decimal/flags/end/trigger guard에서 발생한다. 정상 current/legacy 응답과 잘못된 Explicit 구조 거부는 통과했다.

F2는 [check_trigger_determinism.py](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/crates/oh_sim/tools/check_trigger_determinism.py:345)의 `compare_artifacts`가 artifact끼리의 HEAD 동일성만 검사하고 현재 checkout HEAD와 대조하지 않아 발생한다. 합성 입력의 수용을 actual3OS 성공으로 집계하지 않았다.

재현 source와 fixtures는 ignored target에만 만들었다. 제품 수정·커밋·통합은 수행하지 않았다.
