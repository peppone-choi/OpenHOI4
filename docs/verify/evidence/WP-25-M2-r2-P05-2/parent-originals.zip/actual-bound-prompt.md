역할: 검증 세션. OpenHOI4 M2 W1-c WP-25 새 독립 P05.

구현에 참여하지 않은 새 독립 P05-2 앱이다. 부모는 P06-1 actual completed final·최종 d443 source·원증거 전수를 인수했다. 새 detached worktree·최초 whole/raw snapshot으로 시작한다. 원 e85 P05-1 유효 FAIL은 보존되어 있고 새 source 결과로 대체하지 않는다. 실제 Linux/macOS CI는 진행 중이다. 로컬 검사를 병행하고 새 exact source 원CI 결과까지 직접 확인한 뒤 판정한다.

source: d4433414870845f4e9013bf7114a628b2d3330ab
worktree: E:/openhoi/.orchestrator/wt/WP-25-M2-r2-verify2
prior benchmark SHA: 81deb803944cf6297f13b3f14ca454774cea141b
parent original snapshot: E:/openhoi/.orchestrator/evidence/WP-25-M2-r2-P05-2-before
report format: docs/templates/VERIFY_REPORT_TEMPLATE.md 전문, 한국어, PASS 또는 FAIL

AGENTS 검증규칙/01 REQ-SAV-05·REQ-PERF-03/02§7.3·14.1/P05·WP25 계약·실제코드/ADR를 읽되 구현설명/로그를 판정근거로 믿지 않는다. 모든명령은 지정WT·GIT_OPTIONAL_LOCKS=0/Python-Xutf8로 실행한다. 자기최초 wholetracking/각파일SHA·HEAD·semantic/rawindex·diff/status를 부모원본과먼저대조하고 끝에전체동일을검사한다. 추적파일/commit/source/index/expectation/설정·timeouts/budgets/CI·골든을변경하거나 baseline을교체해PASS로만들지않는다. TS는 trackedwriter를실행하지말고 원빌드lib stdout과generatedraw/Git를읽기전용검사한다.

REQ별실제실패→통과가 무엇을검사하는지독립대조한다. CLI record를자신이nativeprocess로실행해 실제게임세션·표준입력 enqueue/pump/step을다루고 종료ZIP과machine/humanlog를읽는다. fixture-only/seed-only는게임중기록PASS가아니다. 입력받은startSave의기존pending과record후새입력의수명·중복enqueue없음, Pause동일tick다중pump·입력order/거부·예정meaningerror소비·wholephaseErr전체rollback·원RNG/clock·성공step뒤trigger/flags/종료·futurequeue/querysave보존을직접대조한다. accepted/ rejected envelope·각실행경계와start/end identity가serializedlog/실제hoststate에대응해야한다.

fresh CLI repro run 새nativeprocess의fullDTO/canonical/hash·native0와 원record를비교한다. 기대hash변조/중간state/log순서·pack/scenario/seed/참조변조가실제native1인지검사하고 sharedvalidator출력만비교하지않는다. 원None/v1/v2/v3와 Some flags/end v4/emptydefs/current/historicalcaller/force context를각각freshprocess에서대조한다. 재현파일은정말원조건을유지하는지독립입력으로검사한다.

ZIP을직접읽고absolute/drive/UNC/../backslash·NUL·duplicate/normalizedalias·symlink/reparse·unknown/missing/futuremember/schema·CRC/선언size·잘림/ZIPheader중복/extra/compression지원거부·zipbomb/membercount/각/총compressed/uncompressed한도를경계값으로시험한다. 스키마상의명령오류와게임host의정상거부를구분한다. 입력ZIP/save/pack/기존target·sim/queue/clock의실패시보존은nativeI/O로실제bytes대조한다. 검사mutation은자기ignoredtarget만사용하고trackedtests를수정하지않는다.

성능고정prior는위81deb다. current자기baseline/기준CLI없음skipPASS/가짜elapsed를거부한다. sameLinuxrunner의prior/currentactualsource와동일외부driver·실제library별도build/같은profilefeatures/packs/seed/작업량·warmup/measurement분리·성공완료workload/hash·environment·two pairs 원nativeelapsed를확인한다. Linux실행을Windows실행이라고치환하지않고 가능한현지산술검사와actualCI원Linux증거를구분한다. 누락·실패·0·NaN/inf/overflow/입력hash불일치거부,100/115경계PASS/116두회FAIL/116·115비재현을실제productioncomparer에서검사한다. 15%를올리거나timeout을늘려통과시키지않는다. 사전commit/CIsource/필수workflowjob조건과upload원artifact·실제sourcebinary/benchmarkbytes를대조한다.

fmt/clippy/workspace/client/기존M0M1hash각2회/docs/assets/licenses/nativevalidators/save/trigger/repro/bench·원M1 E2E 단일전체를원설정으로실행한다. 관련UI수정이없어도새CLI와server/query기존소비경계를검사하고별도목록을명시한다. 최소ownheadlessbrowser/loopback/profile/PID만가능하며사용자desktop/CUA/focus/globalinput/다른PIDs/profile/BP·환경설정/LFS/공개host/tag는건드리지않는다. 원지도생성180s성능을WP25동일Linuxbench로대신판정하지않는다. 지도/GLB/asset제품blob변화가없으면새반복베이크를검증목적으로요구하지않는다.

각command의실제cwd/argv/nativestdout/stderr·시간·부하/seed/pack/expected·whole/rawbeforeafter를ignoredtarget/evidence에보존한다. 끝의원본manifest/ZIP의 memberbytes/SHA/CRC와path/security를전수대조하며부모가원문을인수할수있는경로/수/전체SHA를리포트에포함한다. 실행되지않은Linuxjob나녹색이없는검사를PASS로표시하지않고미완료/FAIL을기록한다. 판정은담당WP 범위이며W1전체통합/mainCI·M2게이트/후속WP·사용자승인을대신하지않는다. 다른세션생성·추적report저장/commit금지, actualfinal에VERIFY_REPORT 전문을낸다.

생산자 자체검사에서 step/pump unit variant가추가필드를무시하는첫실패를발견한보고가있다. 그원실패를보존하고 새source에서자기독립 입력으로step/pump의extra/unknown/null/duplicatefield·중첩entity/log extra를native입구에서거부하는지 및기존출력파일을보존하는지직접검사한다. 자기검사보고를독립PASS로대체하지않는다.

최초 tracked 11741 / raw index a33c7738052ae0c5a217109ba18808585e8d144903ea2b41ce6990237156f335. 제공 경로 E:/openhoi/.orchestrator/wt/WP-25-M2-r2-verify2/target/evidence/WP-25-M2-r2-P05-2. 자기 명령은 이 WT에서만 실행한다. P05-1 앱/WT/raw57ada 재사용 및 source/index 수정 금지. 원기획 최신 planning 사본을 읽고 parent proof를 직접 대조한다.

보완 source는 e85에서7개파일만 변경했다. prepare_metadata의 각 source cargo fetch --locked 선행·lock bytes 불변·offline metadata/registry 체크섬 대조, 원 timeout·baseline·driver·profile·15% 두회 기준 유지, test-only canonical regular IO fixture·원 partial write 단언 유지와 alias(symlink/Windows junction) 전단거부의 실제 writer 도달 여부/bytes/target/input/authority 보존을 독립 검사한다. 테스트 변경만으로 Mac 실제 PASS를 추정하지 않는다. 추가 cold-cache metadata test가 원 fetch/lock guard를 실질적으로 검사하는지 확인한다. 제품 IO guard/codec/팩/원6workflow 및 benchmark defines 변경 없음도 대조한다.

새 Linux run37664886026, Trigger37664885922, Save37664885946, CI37664885986, Core37664886085, Simulation37664886132, Locale37664886130이다. 모든 source head는 d4433414870845f4e9013bf7114a628b2d3330ab. fresh API의 exact run/head/attempt/job/step/conclusion/logs·performance-linux artifact id/digest/원env/metadata/elapsed/fullDTO/canonical/hash·baseline81deb two pairs240000steps/warm2400/seed1000/native240s/build1200s를 직접 확인한다. 원 e85 7CI6FAIL/1SUCCESS·Linux metadata101/미측정 crunchy offline·Mac partial assertion·Trigger3OS누락·GitHub internal failures는 역사로 분리한다. 현재main2da 6CI25SUCCESS를 새WP25 CI로 치환하지 않는다. 원artifact 대용량은 파일로 stream하고 전체 digest/CRC/member 전수 검사한다.

자료: 부모 P06 docs/worklog/evidence/WP-25-M2-r2-P06-1-d443 및 owner target/evidence/WP-25-M2-r2-P06-1의 full ZIP1,736,541,336B/SHA25e022f0200a0aeb5d438862bba3fdb2f3f7fb24d57aa1671a51e80a646e290b/MF1049/ZIP1050·review1051(원 baseline tar stdout1개만 제외+identity2). 원P03 full7GB/초기temporary3 fixture 일부 미보존 gap도 유지한다. Gitraw22/UTF8EOLonly4는 source 인수 비교이며 본 검증rawindex 면제가 아니다. 필요한 원whole은 부모 ignored copy 또는 owner 원본을 읽고 부모 요약만 믿지 않는다.

valid Active ignored synthetic M0/None save를 실제native record/replay하여 fullDTO/canonical/hash·기존pending1회/future보존을 직접 확인한다. 원example Active locale누락 native거부와 validM0 재현지원 여부를 구분한다. v1/v2/v3/v4·coherent log forgery·기본ZIP 64MiB/총134217000/membercount/inputline 실제 경계·production integer comparator100/115/116/116·115 조건·기존CLI/server/query/243client/41singleE2E 및 실제Save/Trigger3OS·fresh comparers를 검증한다.

독립 증거는 target/evidence/WP-25-M2-r2-P05-2에 고유 namespace로 보존한다. 표준 SHA256SUMS.json/ZIP-IDENTITY.json/evidence.zip 파일명 또는 정확한 자기 파일명을 리포트에 명시한다. ZIP member와 물리경로의 mapping을 JSON으로 제공한다(다른 native harness/binary root를 단순동일relative root라고 가정하지 않는다). 원준비실패도 보존한다. 마지막 actual final은 단일 VERIFY_REPORT_TEMPLATE 전문으로 낸다. 추적 리포트 저장·commit·다른세션생성 금지. 부모의 독립 PASS/main 통합 및W1 판정을 대신하지 않는다.
