역할: 검증 세션. OpenHOI4 M2 W1-c WP-25 새 독립 P05.

구현에 참여하지 않은 새 독립 앱이다. 부모는 actual completed final·최종 source·원증거 전수를 인수한 뒤 새 exact detached worktree와 최초 whole/raw snapshot을 만들었다. 부모 proof와 구현 설명은 독립 판정의 대체물이 아니며 직접 검사한다. 실제 Linux benchmark run37654381217은 진행 중이며 아직 Linux PASS/원artifact 인수는 없다. 독립 로컬 검사와 원CI 수집을 병행하고 실제 Linux 결과까지 직접 확인한 뒤 최종 판정한다.

source: e85ec5b7191604e7fb1903d2cea5fb6e49060a5b
worktree: E:/openhoi/.orchestrator/wt/WP-25-M2-r2-verify1
prior benchmark SHA: 81deb803944cf6297f13b3f14ca454774cea141b
parent original snapshot: E:/openhoi/.orchestrator/evidence/WP-25-M2-r2-P05-1-before
report format: docs/templates/VERIFY_REPORT_TEMPLATE.md 전문, 한국어, PASS 또는 FAIL

AGENTS 검증규칙/01 REQ-SAV-05·REQ-PERF-03/02§7.3·14.1/P05·WP25 계약·실제코드/ADR를 읽되 구현설명/로그를 판정근거로 믿지 않는다. 모든명령은 지정WT·GIT_OPTIONAL_LOCKS=0/Python-Xutf8로 실행한다. 자기최초 wholetracking/각파일SHA·HEAD·semantic/rawindex·diff/status를 부모원본과먼저대조하고 끝에전체동일을검사한다. 추적파일/commit/source/index/expectation/설정·timeouts/budgets/CI·골든을변경하거나 baseline을교체해PASS로만들지않는다. TS는 trackedwriter를실행하지말고 원빌드lib stdout과generatedraw/Git를읽기전용검사한다.

REQ별실제실패→통과가 무엇을검사하는지독립대조한다. CLI record를자신이nativeprocess로실행해 실제게임세션·표준입력 enqueue/pump/step을다루고 종료ZIP과machine/humanlog를읽는다. fixture-only/seed-only는게임중기록PASS가아니다. 입력받은startSave의기존pending과record후새입력의수명·중복enqueue없음, Pause동일tick다중pump·입력order/거부·예정meaningerror소비·wholephaseErr전체rollback·원RNG/clock·성공step뒤trigger/flags/종료·futurequeue/querysave보존을직접대조한다. accepted/ rejected envelope·각실행경계와start/end identity가serializedlog/실제hoststate에대응해야한다.

fresh CLI repro run 새nativeprocess의fullDTO/canonical/hash·native0와 원record를비교한다. 기대hash변조/중간state/log순서·pack/scenario/seed/참조변조가실제native1인지검사하고 sharedvalidator출력만비교하지않는다. 원None/v1/v2/v3와 Some flags/end v4/emptydefs/current/historicalcaller/force context를각각freshprocess에서대조한다. 재현파일은정말원조건을유지하는지독립입력으로검사한다.

ZIP을직접읽고absolute/drive/UNC/../backslash·NUL·duplicate/normalizedalias·symlink/reparse·unknown/missing/futuremember/schema·CRC/선언size·잘림/ZIPheader중복/extra/compression지원거부·zipbomb/membercount/각/총compressed/uncompressed한도를경계값으로시험한다. 스키마상의명령오류와게임host의정상거부를구분한다. 입력ZIP/save/pack/기존target·sim/queue/clock의실패시보존은nativeI/O로실제bytes대조한다. 검사mutation은자기ignoredtarget만사용하고trackedtests를수정하지않는다.

성능고정prior는위81deb다. current자기baseline/기준CLI없음skipPASS/가짜elapsed를거부한다. sameLinuxrunner의prior/currentactualsource와동일외부driver·실제library별도build/같은profilefeatures/packs/seed/작업량·warmup/measurement분리·성공완료workload/hash·environment·two pairs 원nativeelapsed를확인한다. Linux실행을Windows실행이라고치환하지않고 가능한현지산술검사와actualCI원Linux증거를구분한다. 누락·실패·0·NaN/inf/overflow/입력hash불일치거부,100/115경계PASS/116두회FAIL/116·115비재현을실제productioncomparer에서검사한다. 15%를올리거나timeout을늘려통과시키지않는다. 사전commit/CIsource/필수workflowjob조건과upload원artifact·실제sourcebinary/benchmarkbytes를대조한다.

fmt/clippy/workspace/client/기존M0M1hash각2회/docs/assets/licenses/nativevalidators/save/trigger/repro/bench·원M1 E2E 단일전체를원설정으로실행한다. 관련UI수정이없어도새CLI와server/query기존소비경계를검사하고별도목록을명시한다. 최소ownheadlessbrowser/loopback/profile/PID만가능하며사용자desktop/CUA/focus/globalinput/다른PIDs/profile/BP·환경설정/LFS/공개host/tag는건드리지않는다. 원지도생성180s성능을WP25동일Linuxbench로대신판정하지않는다. 지도/GLB/asset제품blob변화가없으면새반복베이크를검증목적으로요구하지않는다.

각command의실제cwd/argv/nativestdout/stderr·시간·부하/seed/pack/expected·whole/rawbeforeafter를ignoredtarget/evidence에보존한다. 끝의원본manifest/ZIP의 memberbytes/SHA/CRC와path/security를전수대조하며부모가원문을인수할수있는경로/수/전체SHA를리포트에포함한다. 실행되지않은Linuxjob나녹색이없는검사를PASS로표시하지않고미완료/FAIL을기록한다. 판정은담당WP 범위이며W1전체통합/mainCI·M2게이트/후속WP·사용자승인을대신하지않는다. 다른세션생성·추적report저장/commit금지, actualfinal에VERIFY_REPORT 전문을낸다.

생산자 자체검사에서 step/pump unit variant가추가필드를무시하는첫실패를발견한보고가있다. 그원실패를보존하고 새source에서자기독립 입력으로step/pump의extra/unknown/null/duplicatefield·중첩entity/log extra를native입구에서거부하는지 및기존출력파일을보존하는지직접검사한다. 자기검사보고를독립PASS로대체하지않는다.

최초 tracked 11739 / raw index 57ada9d5d724514dc99b369ba41f15a1f6bafbb27b622bf397fc4f1cc710d6b6. 제공 경로 E:/openhoi/.orchestrator/wt/WP-25-M2-r2-verify1/target/evidence/WP-25-M2-r2-P05-1. 자기 명령은 전용WT에서만 실행한다. 최신 부모 기획·원custody와 actual/pending Linux 상태를 구분하고 actual Linux 원API/run/head/attempt/job/artifact digest/측정 member를 직접 확인한다. 부모가 code나측정기준을고쳐통과시키지 않았다. 원측정/실패를삭제하거나새source결과로교체하지 않는다. 초기3개의임시harness 일부fixture 미보존을원worklog와대조해gap으로남기며새독립입력으로조건을검사하고삭제원본을복원됐다고하지않는다. 부모 Gitraw20/UTF8EOLonly4는구현원본인수의Git내용대조이고본독립검증원rawindex의면제가아니다.

실제Linux조회는 gh의해당run37654381217/API exact source e85ec5b7191604e7fb1903d2cea5fb6e49060a5b·원job/attempt/원logs와performance-linux artifact다. current/baseline240000steps·warm2400·seed1000/m1·prior81deb·pairs2/15%·native240s/build1200s를유지하고환경/cargo metadata/lock/driver/원elapsed·fullDTO/canonical/hash를직접대조한다. workflow7개 전체sourceCI는본WP독립Linux검사와현재main2da6CI25SUCCESS를구분한다. 빌드/로컬검사를하는동안 원CI대기는후속으로둘수있으며source/검증index를바꾸지않는다. API zipstdout의대용량은메모리에캡처하지말고자기ignored파일로직접stream하고API digest/SHA·memberpaths/CRC/원자료를검사한다. 원baseline-archive.stdout은약2GB며그외native자료와섞어미실행이라지우지않는다. 원ZIP을보존하고요약review를whole원본이라부르지않는다.

최신 실행 상태 정정: 준비 중 sourcee85 CI의 실제FAIL이 발생했다. Linuxperformance run37654381217 step7은 baseline-metadata native101/전체native2이며, 아직측정회귀로판정할결과가아니다. Trigger37654381215 MacOS 신규repro_zip::tests::req_sav_05_partial_native_temp_write_keeps_target_input_and_authority는 error.contains("partial write failure") 단언FAIL이고뒤compare도실제3OS누락FAIL이다. Save/Simulation도sourceCI FAIL, Core37654381210은runFAIL/jobs목록0으로원인을알지못한다. 원상태·전단error·원API/attempt/log/파일상태를직접확인한다. NativebenchmarkLinuxstage가없음을WINDOWSpass로채우지않는다. 원7workflow조회의첫FAIL요약은planning/source-CI-failure-first.json에있다.

이 exacte85 독립검증을준비하고원sourcefail을확인하는동안같은owner의P06는별도구현WT에서진행할수있다. 본검증WT/HEAD/원raw기준선은끝까지e85로고정하며신규source로교체/재시도하여이원판정을PASS로만들지않는다. 의미있는나머지native/ZIP/호환/산술/실제필수회귀를검사하고모든성공·실패·미실행을정확히보고한다. 알려진실패를부모설명만믿지않고직접확인한다. 원bench데이터입수진행경로는E:/openhoi/.orchestrator/evidence/WP-25-e85-Linux-first-failure이며완료전파일을원완료증거로취급하지않는다. rawartifact가완료되면자기cwd에서freshAPI digest를조회하고그원ZIP을읽기전용으로직접SHA/CRC/member검사해중복2GB다운로드를피할수있다. 원파일/metadata를수정하지않는다. sourcefull6.94GB와review4.32MB의원본차이·초기소실fixture는이미제공된부모custody에기록됐다. 처음failedmeasure와추가source실행을구분하며재실행/한도/검사완화·소스수정/push는하지않는다. final은VERIFY_REPORT전문PASS/FAIL이다.
