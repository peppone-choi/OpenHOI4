역할: 검증 세션. OpenHOI4 M2-r1 WP-24 독립 P-05, 시도 1. 너는 구현에 참여하지 않은 새 앱 채팅이다.
exact HEAD: c2c2f638fe5179d11ce5a318f6d991b4b2a0cd4d
전용 detached worktree: E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify1
출력 target: E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify1\target\evidence\WP-24-M2-r1-P05-1
오케스트레이터 threadId 01a113d1-c44c-7703-881b-d56e57557f55, hostId local. 업무상 메시지는 사용자 직접 승인이나 네가 새 채팅/세션을 만들지는 않는다.

모든 shell workdir는 위 전용 worktree로 강제하고 git --no-optional-locks -C 또는 absolute path를 쓴다. Git optional refresh를 피하기 위해 본인 process GIT_OPTIONAL_LOCKS=0을 적용한다. tracked/index 변경·commit 금지, index 복구/최초baseline 교체 금지. 메인/구현 worktree는 read only다. 기본cwd가 main일 수 있으니 그곳에서 build/test/수정하지 않는다. original before는 부모가 앱 생성 전 끝냈으며 E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify1\target\evidence\WP-24-M2-r1-P05-1/parent-before.json 및 .index이다. 본인이 처음부터 current snapshot.py로 자기 최초snapshot을 따로 얻어 parent와 비교하고 최종도 얻는다. mismatch는 무효/FAIL로 보고하고 꾸미지 않는다.

[먼저 읽기]
본인 AGENTS.md, docs/03-production-prompts.md P-05 전문, docs/templates/VERIFY_REPORT_TEMPLATE.md, exact docs/plans/WP-24-schema.md 및 담당 ADR, docs/worklog/WP-24.md. 최신 main 기획은 E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify1\target\evidence\WP-24-M2-r1-P05-1\planning/{01-game-design.md,02-production-spec.md,03-production-prompts.md,04-ceo-automation.md,M2.md,M2-contracts.md,M2-verification.md,schema-planning.md,schema-source-review.md,REQUEST-0006.md,identity.json}의 실제파일이다. 사본은 수정하지 않는다. immutable original source와 latest planning을 구분한다.

[P-05 직접 수행]
구현자의 설명을 믿지 말고 실제 명령/소스/필드/규칙/expected와 REQ를 대조한다. 신규 스키마의 field 의미/단위/type/range/null/default/ref/lifetime/authority, definition/initial/mutable/derived, 관계·정렬/비연속ID/중복/미존재/순환, 실패원자성, hash/save/wire/runtime/UI·legacy/version and 독립 정상/경계/오류예제를 확인한다. 항상통과하는 assert/구현기대값복사/미지원no-op은 FAIL이다.

실제 cargo fmt --check, clippy --workspace -- -D warnings, cargo test --workspace, M0 hash2회와 actualM1 hash2회를 직접 실행한다. installed cargo는 C:/Users/user/.cargo/bin/cargo.exe가 실제 존재하는지 먼저 확인하고 absolute executable 또는 해당 process PATH를 쓴다. client/dist가 필요한 oh_server build는 자기 npm ci/build로 준비하며 자기 target을 사용한다. client바뀜시 unit/typecheck/build/generatedTS no diff와 malformed protocol regression을 실행한다. 라이선스/asset/docs/architecture 및 관련CLI/test command를 직접 실행한다. 처음실패/환경준비FAIL/수정없음/의도negative/최종실패를 각각 기록한다. 실패 원인을 모르거나 실행 못했으면 미검증으로 적으며 retry를 통해 실패를 숨기지 않는다.

[담당 독립 경계]
REQ-MOD-01/02/04・REQ-LOC-03: actual dependency DAG/versions/conflicts/load_after/dedup/permutation/diamond・file/Unicode position warnings exit・registered map/nation/state references and unknown keys・actual FTL multiline/select/term/attributes/duplicate/cycle/null/unused and ko/en parity・pack ordered hash equals old oh_save::pack_hash; source mutation reject. New frozen original b651 testland19 bytes must equal git source byte-for-byte; original m1-v1 save/expected/check_save_determinism.py/assertions unchanged, frozen helper only capture, current generic helper retained, original frozen native capture + current pack encode/decode/fresh process resume/fullstate/hash/changedpack refusal separate. Inspect Cargo.lock only intentional new fluent-syntax0.12.0 and allowed actual licensing, new ASSETS entries. M0 frozen original lacks pack name locale: do not add unconditional legacy exception or record all packs validated when CLI actually rejects; report exact scope. Verify actual CLI validate --deny-warnings and committed localisation CI workflow/checker. Later WP13/14 registry validation is explicit producer handoff, no declared-but-unimplemented PASS.

추가 독립 probe/mutation은 ignored target의 scratch source/fixtures에만 만들고 exact tracked source/tests/expected를 바꾸지 않는다. 주장하는 negative는 실제 원 assertion 또는 정상CLI의 invalid-input을 검사해야 한다. DR float/HashMap iteration/random/I-O/systemclock은 architecture.py 결과만 믿지 말고 해당 sim source를 직접 읽는다. 자체 golden 기대값변경·원작자료·미정규칙·설정변경·클라이언트규칙계산 금지를 확인한다.

[원 실행 증거와 final]
각 명령 cmd/cwd/env의 필요한 부분(비밀은제외)/stdout/stderr/nativeexit/result를 E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify1\target\evidence\WP-24-M2-r1-P05-1에 보존한다. 증거 생성 cwd/default path를 먼저 조사해 자기 ignored target으로 지정한다. missingproducer/준비실패도 원문 유지한다. command-results.json, complete before/after invariance와 fullreport를 생성하고 SHA256SUMS.json의 path/bytes/SHA 및 evidence.zip member에 전수 bytes를 보존한다. manifest/ZIP 자체는 별도 ZIP-IDENTITY.json으로 기록하며 순환self해시를 만들지 않는다. parentbefore raw는 복구하지 않는다.
마지막 메시지는 VERIFY_REPORT_TEMPLATE 양식의 PASS 또는 FAIL **전문**이다. exactHEAD와 모든 REQ/test/실행/해시/새상태/저장/금지/원증거 대조·미실행·FAIL 재현을 적는다. 파일저장은 부모가 한다. 앱 종료에 CLI exit0을 쓰지 않는다. evidence가 모두 준비/실제프로세스 종료한 뒤 final을 낸다.
