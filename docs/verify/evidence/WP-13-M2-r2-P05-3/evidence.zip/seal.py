from run import W,E,ENV
import os,json,hashlib,pathlib,zipfile,subprocess,sys,datetime
D=lambda raw:hashlib.sha256(raw).hexdigest()
# Finalize every completed command receipt before immutable packaging.
record=json.loads((E/'command-results.json').read_text(encoding='utf8'));record['commands']=[]
for p in sorted(E.glob('*/command.json')):
 result=p.parent/'result.json'
 if result.exists():record['commands'].append({'path':str(p.parent.relative_to(E)),'command':json.loads(p.read_text()),'result':json.loads(result.read_text()),'classification':record['nonproduct_failures'].get(p.parent.name,'final verification')})
(E/'command-results.json').write_text(json.dumps(record,indent=2),encoding='utf8')
# Record literal preparation failures without converting them to native test runs.
(E/'preparation-notes.json').write_text(json.dumps({'pre_spawn_console_errors':[{'command':'PowerShell read command using planning/{01-game-design.md,...}','error':'ParserError: Unexpected token -game in expression or statement; no read calls executed'},{'command':'python additional-native.py','error':'FileExistsError existing context-matrix output directory before child spawn'}],'audit_retry_failures':record['nonproduct_failures'],'source_mutation':False},ensure_ascii=False,indent=2),encoding='utf8')
# Full current snapshot via fresh in-memory Git/bytes reads, no index refresh.
def snapshot():
 def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(W),*args],env=ENV).decode('utf8')
 paths=git('ls-files','-z').split('\0');index=pathlib.Path(git('rev-parse','--git-path','index').strip());index=index if index.is_absolute() else W/index;raw=index.read_bytes()
 return {'worktree':str(W),'head':git('rev-parse','HEAD').strip(),'index':git('ls-files','--stage','-z'),'raw_index_sha256':D(raw),'tracked_list':paths,'status':git('status','--porcelain=v1','--untracked-files=no'),'diff':git('diff','--binary'),'cached_diff':git('diff','--cached','--binary'),'files':[[p,D((W/p).read_bytes()) if (W/p).is_file() else None] for p in paths if p]},raw
original=json.loads((E/'parent-before.json').read_text(encoding='utf8'));raw_original=(E/'parent-before.index').read_bytes();before,raw=snapshot();assert before==original and raw==raw_original
excluded={'evidence.zip','SHA256SUMS.json','ZIP-IDENTITY.json'}
paths=[p for p in sorted(E.rglob('*')) if p.is_file() and p.relative_to(E).as_posix() not in excluded]
items=[{'path':p.relative_to(E).as_posix(),'bytes':p.stat().st_size,'sha256':D(p.read_bytes())} for p in paths]
m={'head':original['head'],'scope':'all existing verification evidence before immutable seal; manifest and ZIP identity separate, no self-hash','files':items};(E/'SHA256SUMS.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf8')
with zipfile.ZipFile(E/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(E).as_posix())
 z.write(E/'SHA256SUMS.json','SHA256SUMS.json')
with zipfile.ZipFile(E/'evidence.zip') as z:
 assert set(z.namelist())=={x['path'] for x in items}|{'SHA256SUMS.json'}
 for x in items:
  a=z.read(x['path']);b=(E/x['path']).read_bytes();assert a==b and len(a)==x['bytes'] and D(a)==x['sha256']
 assert z.read('SHA256SUMS.json')==(E/'SHA256SUMS.json').read_bytes()
 members=len(z.namelist())
after,raw=snapshot();assert after==original and raw==raw_original
identity={'head':original['head'],'files':len(items),'zip_members':members,'zip_bytes':(E/'evidence.zip').stat().st_size,'zip_sha256':D((E/'evidence.zip').read_bytes()),'manifest_bytes':(E/'SHA256SUMS.json').stat().st_size,'manifest_sha256':D((E/'SHA256SUMS.json').read_bytes()),'all_member_bytes_sha_verified':True,'complete_source_snapshot_before_after_equal':True,'tracked_count':len(original['files']),'raw_index_sha256':D(raw),'raw_index_bytes_identical':True,'native_pid':os.getpid(),'command':[sys.executable,str(E/'seal.py')],'cwd':str(W),'executable_sha256':D(pathlib.Path(sys.executable).read_bytes()),'env':{k:ENV[k] for k in ('GIT_OPTIONAL_LOCKS','CARGO_TARGET_DIR','PYTHONUTF8','PYTHONIOENCODING')},'seal_native_exit':0,'own_new_actual_3os_claim':False,'original_ci_fail_preserved':True,'native_processes_checked_before_seal':json.loads((E/'native-processes-final.json').read_text(encoding='utf-8-sig')),'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(E/'ZIP-IDENTITY.json').write_text(json.dumps(identity,indent=2),encoding='utf8');print(json.dumps(identity))
