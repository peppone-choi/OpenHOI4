from run import W,E,ENV
import pathlib,sys,shutil,socket,subprocess,json,time,urllib.request,hashlib
sys.path.insert(0,str(W/'crates/oh_server/tests'));from lifecycle import ctrl_c
out=E/'natural-pump-cases2';out.mkdir();pack=out/'packs/testland';shutil.copytree(W/'data/packs/testland',pack)
p=pack/'scenarios/m1/scenario.toml';p.write_text("end_date = '2000-01-01'\n"+p.read_text(encoding='utf8'),encoding='utf8')
p=pack/'scenarios/m1/defines.toml';s=p.read_text(encoding='utf8');s=s.replace('initial_speed = 1','initial_speed = 5');p.write_text(s,encoding='utf8')
with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
url=f'http://127.0.0.1:{port}/';binary=W/'target/debug/oh_server.exe';cmd=[str(binary),'--port',str(port),'--pack-root',str(out/'packs')]
info=subprocess.STARTUPINFO();info.dwFlags=subprocess.STARTF_USESHOWWINDOW;info.wShowWindow=0
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 p=subprocess.Popen(cmd,cwd=W,env=ENV,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NEW_CONSOLE,startupinfo=info)
 receipt={'command':cmd,'cwd':str(W),'pid':p.pid,'exe_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 try:
  deadline=time.monotonic()+15
  while True:
   try:
    with urllib.request.urlopen(url,timeout=1) as r:assert r.status==200;receipt['http_status']=r.status;break
   except OSError:assert p.poll() is None and time.monotonic()<deadline;time.sleep(.05)
  cmd=['node',str(E/'natural-pump-v2.cjs'),url];q=subprocess.Popen(cmd,cwd=W,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE);a,b=q.communicate(timeout=20)
  (out/'query.stdout').write_bytes(a);(out/'query.stderr').write_bytes(b);receipt.update(query_command=cmd,query_pid=q.pid,query_exit=q.returncode)
  assert q.returncode==0,b.decode(errors='replace');assert p.poll() is None
 finally:
  if p.poll() is None:ctrl_c(p)
  code=p.wait(timeout=10);receipt['native_exit']=code;(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
assert code==0;assert b'stopped normally' in (out/'stdout').read_bytes();print(json.dumps(receipt))

