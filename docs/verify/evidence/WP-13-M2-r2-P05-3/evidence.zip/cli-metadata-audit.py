from run import W,E,run
p=str(W/'target/debug/wp13-independent-probe.exe')
for name,pack in [('end',E/'actual-trigger/run-1/pack'),('initial',E/'actual-trigger/run-1/pack-initial')]:
 for version in ('1','2','fresh'):run(f'cli-{name}-{version}-codec',[p,'fresh',str(pack),str(E/f'cli-{name}-{version}.ohsave'),str(E/f'cli-{name}-{version}-codec.ohsave')])
s=(E/'final-audit-v2.py').read_text(encoding='utf8').replace("'final-audit':'audit", "'final-audit-retry':'invalid verifier expectation: CLI --save-out intentionally refreshes host saved_at_utc by one second; native codec preserves whole original bytes; full state and body compared separately','final-audit':'audit")
s=s.replace("assert (E/f'cli-{name}-1.ohsave').read_bytes()==(E/f'cli-{name}-2.ohsave').read_bytes()==(E/f'cli-{name}-fresh.ohsave').read_bytes()", """headers=[];bodies=[];states=[]
 import sys
 sys.path.insert(0,str(W/'crates/oh_sim/tools'));import check_trigger_determinism as cg
 for version in ('1','2','fresh'):
  raw=(E/f'cli-{name}-{version}.ohsave').read_bytes();h=cg.header(E/f'cli-{name}-{version}.ohsave');h.pop('saved_at_utc');headers.append(h);bodies.append(raw[10+int.from_bytes(raw[6:10],'little'):]);state=load(f'cli-{name}-{version}-codec/stdout.txt');assert state['before']==state['after'] and state['before_canonical']==state['after_canonical'];states.append((state['before'],state['before_canonical'],state['hash']));assert raw==(E/f'cli-{name}-{version}-codec.ohsave').read_bytes()
 assert headers[0]==headers[1]==headers[2] and bodies[0]==bodies[1]==bodies[2] and states[0]==states[1]==states[2]""")
(E/'final-audit-v3.py').write_text(s,encoding='utf8');run('final-audit-current',['python',str(E/'final-audit-v3.py')])
