from run import W,E,run
import pathlib,hashlib,json,zipfile,subprocess,ast,shutil
D=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(W),*args])
def audit(folder,manifest,archive,identity=None,disk=True):
 m=json.loads((folder/manifest).read_text(encoding='utf8'));items=m['files'];files={i['path']:i for i in items};mismatch=[]
 with zipfile.ZipFile(folder/archive) as z:
  for rel,item in files.items():
   raw=z.read(rel)
   if len(raw)!=item['bytes'] or D(raw)!=item['sha256']:mismatch.append(rel)
   if disk and raw!=(folder/rel).read_bytes():mismatch.append('disk:'+rel)
  if manifest in z.namelist():assert z.read(manifest)==(folder/manifest).read_bytes()
  members=len(z.namelist())
 actual=D((folder/archive).read_bytes())
 if identity:assert actual==json.loads((folder/identity).read_text())['zip_sha256']
 assert not mismatch,mismatch
 return {'folder':str(folder),'head':m.get('head'),'files':len(files),'members':members,'mismatches':mismatch,'archive_sha256':actual}
base='de0e53058c92d91a6a0b6c30805a6b2ea77dde9d';allowed={'.github/workflows/trigger-determinism.yml','crates/oh_sim/tests/test_trigger_evidence.py','docs/plans/WP-13-schema.md','docs/adr/ADR-1301-trigger-end-state.md','docs/worklog/WP-13.md'}
changed=set(git('diff','--name-only',base,'HEAD').decode().splitlines());assert changed==allowed
before=json.loads((E/'self-before.json').read_text());protected=[]
def tree(ref):
 return {part.split(b'\t',1)[1].decode():part.split(b'\t',1)[0].split()[-1].decode() for part in git('ls-tree','-r','-z',ref).split(b'\0') if part}
old_tree,new_tree=tree(base),tree('HEAD')
for rel,current in before['files']:
 if rel not in allowed:
  assert old_tree[rel]==new_tree[rel],rel
  protected.append({'path':rel,'blob':new_tree[rel],'checkout_sha256':current})
old=git('show',f'{base}:.github/workflows/trigger-determinism.yml');new=git('show','HEAD:.github/workflows/trigger-determinism.yml')
assert new==old.replace(b'path: trigger-evidence',b'path: target/trigger-evidence').replace(b'compare --root trigger-evidence',b'compare --root target/trigger-evidence')
def bodies(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
a=bodies(git('show',f'{base}:crates/oh_sim/tests/test_trigger_evidence.py'));b=bodies(git('show','HEAD:crates/oh_sim/tests/test_trigger_evidence.py'));assert len(a)==12 and len(b)==16 and all(b[k]==v for k,v in a.items())
identity=json.loads((E/'planning/identity.json').read_text());assert all(D(pathlib.Path(v['copy']).read_bytes())==v['sha256'] for v in identity['files'])
source=E/'source-audit';source.mkdir()
(source/'diff.patch').write_bytes(git('diff','--binary',base,'HEAD'));(source/'protected9946.json').write_text(json.dumps(protected,indent=2),encoding='utf8')
implementation=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2/target/evidence')
results=[audit(implementation/'WP-13-P06-2-seal','SHA256SUMS.json','originals.zip','ZIP-IDENTITY.json',disk=False),audit(implementation/'WP-13-P06-1','SHA256SUMS.json','originals.zip','ZIP-IDENTITY.json')]
# P06-2 entries are relative to original evidence directory, not separate seal directory.
m=json.loads((implementation/'WP-13-P06-2-seal/SHA256SUMS.json').read_text());assert all(D((implementation/'WP-13-P06-2'/x['path']).read_bytes())==x['sha256'] for x in m['files'])
ci=pathlib.Path('E:/openhoi/docs/plans/evidence/M2-r2-a652-Trigger-CI-FAIL');custody=json.loads((ci/'custody.json').read_text());ci_result=audit(ci,'custody.json','originals.zip',disk=False);assert ci_result['archive_sha256']==custody['ZIP_sha256'];assert custody['judgement']=='FAIL' and custody['failed_job']==112694021815
with zipfile.ZipFile(ci/'originals.zip') as z:
 # Preserve the original logs/API receipts and all artifact bytes inside our evidence.
 z.extractall(E/'original-ci-readonly-copy')
summary={'head':before['head'],'changed':sorted(changed),'protected':len(protected),'mismatches':0,'workflow_only_two_paths':True,'original_tests_preserved':len(a),'new_tests':len(b),'planning_head':identity['main_documentation_head'],'planning_files':len(identity['files']),'implementation_archives':results,'original_ci':ci_result,'original_ci_verdict':'FAIL','current_verdict_not_inferred':True}
(source/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
