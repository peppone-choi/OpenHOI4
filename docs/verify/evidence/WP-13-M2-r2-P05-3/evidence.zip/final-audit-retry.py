from run import E,run
s=(E/'final-audit.py').read_text(encoding='utf8').replace("'natural-pump':'own", "'final-audit':'audit tried to include its own receipt before native process exit; preparation error; all original commands preserved','natural-pump':'own").replace("if p.parent.parent!=E:continue", "if p.parent.parent!=E or not (p.parent/'result.json').is_file():continue")
(E/'final-audit-v2.py').write_text(s,encoding='utf8')
run('final-audit-retry',['python',str(E/'final-audit-v2.py')])
