from run import run
C='C:/Users/user/.cargo/bin/cargo.exe'
for label,cmd in [('fmt',[C,'fmt','--check']),('clippy',[C,'clippy','--workspace','--','-D','warnings']),('workspace-test',[C,'test','--workspace']),('proto-current',[C,'test','-p','oh_proto','req_net_04_generated_types_are_current','--','--exact'])]:run(label,cmd)
