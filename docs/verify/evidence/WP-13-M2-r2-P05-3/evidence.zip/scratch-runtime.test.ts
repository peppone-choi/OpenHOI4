import {test,expect,vi,afterEach} from 'vitest';
import {encode} from '@msgpack/msgpack';
import {isServerMessage,connect} from '../../../client/src/network';
const base={type:'TriggerResult',request:'independent',supported:true,reason_key:null,trigger:{definitions_hash:'aabbccddeeff0011',flags:[{nation:1,keys:['a','z']},{nation:42,keys:[]}],ended:{tick:'24',date:'2100-03-01',hour:0,causes:[{type:'Date'},{type:'Condition'},{type:'Explicit',source:'finish'}]}}};
const cases:[string,unknown][]=[
 ['duplicate cause',{...base.trigger,ended:{...base.trigger.ended,causes:[{type:'Date'},{type:'Date'}]}}],
 ['cause order',{...base.trigger,ended:{...base.trigger.ended,causes:[{type:'Condition'},{type:'Date'}]}}],
 ['empty causes',{...base.trigger,ended:{...base.trigger.ended,causes:[]}}],
 ['duplicate nation',{...base.trigger,flags:[{nation:1,keys:[]},{nation:1,keys:[]}]}],
 ['nation order',{...base.trigger,flags:[{nation:42,keys:[]},{nation:1,keys:[]}]}],
 ['duplicate flag',{...base.trigger,flags:[{nation:1,keys:['a','a']}]}],
 ['flag order',{...base.trigger,flags:[{nation:1,keys:['z','a']}]}],
 ['invalid flag ID',{...base.trigger,flags:[{nation:1,keys:['INVALID FLAG']}]}],
 ['u64 overflow',{...base.trigger,ended:{...base.trigger.ended,tick:'18446744073709551616'}}],
 ['invalid source ID',{...base.trigger,ended:{...base.trigger.ended,causes:[{type:'Explicit',source:''}]}}],
 ['wrong field',{...base.trigger,flags:[{nation:1,keys:[],intruder:true}]}],
 ['explicit source wrong name',{...base.trigger,ended:{...base.trigger.ended,causes:[{type:'Explicit',source:'finish',intruder:true}]}}]
];
class Socket {static OPEN=1; static latest:Socket;readyState=1;binaryType='';onopen:any=null;onmessage:any=null;onclose:any=null;onerror:any=null;sent:any[]=[];closeCount=0;constructor(){Socket.latest=this;}send(x:any){this.sent.push(x);}close(){this.closeCount++;this.readyState=3;}receive(x:any){this.onmessage?.({data:encode(x).slice().buffer});}}
afterEach(()=>vi.unstubAllGlobals());
test('normal current and legacy response accepted',()=>{expect(isServerMessage(base)).toBe(true);expect(isServerMessage({type:'TriggerResult',request:'legacy',supported:false,reason_key:'unsupported-query',trigger:null})).toBe(true);});
for(const [name,t] of cases){const m={...base,trigger:t};test('strict guard rejects '+name,()=>expect(isServerMessage(m)).toBe(false));test('connection preserves display and blocks input for '+name,()=>{vi.stubGlobal('WebSocket',Socket);vi.stubGlobal('location',{protocol:'http:',host:'localhost'});const received=vi.fn();const closed=vi.fn();const c=connect(received,closed);Socket.latest.receive(m);expect(received).not.toHaveBeenCalled();expect(closed).toHaveBeenCalledExactlyOnceWith('invalid-server-message');expect(Socket.latest.closeCount).toBe(1);c.send({type:'Query',request:'late',kind:'time'});expect(Socket.latest.sent).toEqual([]);});}
import {writeFileSync} from 'node:fs';
test('native runtime observation after valid snapshot and invalid trigger',()=>{const observations=[];for(const [name,t] of cases){vi.stubGlobal('WebSocket',Socket);vi.stubGlobal('location',{protocol:'http:',host:'localhost'});const calls:any[]=[];const reasons:any[]=[];const c=connect(m=>calls.push(m),r=>reasons.push(r));const snap={type:'Snapshot',state:{date:'2000-01-01',hour:0,tick:'0',paused:false,speed:1}};Socket.latest.receive(snap);Socket.latest.receive({...base,trigger:t});c.send({type:'Query',request:'after-invalid',kind:'time'});observations.push({name,callbackCount:calls.length,closeCount:Socket.latest.closeCount,closeReasons:reasons,sentAfterInvalid:Socket.latest.sent.length});c.close();}writeFileSync('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3/target/evidence/WP-13-M2-r2-P05-3/runtime-observations.json',JSON.stringify(observations,null,2));expect(observations.every(x=>x.callbackCount===1&&x.closeCount===1&&x.sentAfterInvalid===0)).toBe(true);});
