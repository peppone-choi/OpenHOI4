from run import W,E,run
s=(E/'data-probe.py').read_text(encoding='utf8').replace("out=E/'independent-data'","out=E/'independent-data-cases'")
(E/'data-probe-v2.py').write_text(s,encoding='utf8')
run('independent-data-retry',['python',str(E/'data-probe-v2.py')])
C='C:/Users/user/.cargo/bin/cargo.exe'
run('build-save-examples',[C,'build','-p','oh_save','--examples','--locked'])
run('save-original-capture',['python','crates/oh_save/tools/check_save_determinism.py','capture','--out',str(E/'save-original')])
run('save-current-capture',['python','crates/oh_save/tools/check_save_current.py','capture','--out',str(E/'save-current')])
for version,helper,save in [('v2','movement_fixture','movement-v2.ohsave'),('v3','strait_fixture','strait-v3.ohsave')]:
 b=str(W/f'target/debug/examples/{helper}.exe');o=E/f'original-{version}'
 run(f'{version}-capture',[b,'capture',str(o)])
 run(f'{version}-resume',[b,'resume',str(W/'data/packs/testland'),str(o/save)])
 if version=='v2':run('v2-frozen-resume',[b,'resume',str(W/'data/packs/testland'),str(W/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave')])
