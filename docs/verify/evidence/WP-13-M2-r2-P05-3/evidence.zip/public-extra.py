from run import W,E,run,ENV
import importlib.util,os,json,pathlib,shutil
os.environ.update(ENV);os.environ.update(TRIGGER_TEST_CAPTURE=str(E/'actual-trigger'),TRIGGER_SCRATCH_ROOT=str(E/'independent-public-scratch'),TRIGGER_PUBLIC_EVIDENCE=str(E/'independent-public-receipts'))
spec=importlib.util.spec_from_file_location('predicates',W/'crates/oh_sim/tests/test_trigger_evidence.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);T=m.TriggerPredicates;T.setUpClass();summary=[]
for name in ('root-unknown-name','platform-invalid','native-exit-invalid','native-pid-invalid','native-stdout-missing','current-stale-head','resigned-save-invalid','normal'):
 t=T('test_public_synthetic_same_clean_source_predicate');t._testMethodName='independent-'+name;t.setUp()
 try:
  repo,evidence,current=t.public_fixture('target/trigger-evidence');folder=evidence/'trigger-windows-latest'
  if name=='root-unknown-name':(evidence/'unknown.json').write_text('{}')
  if name=='platform-invalid':
   value=m.gate.strict_json(folder/'result.json');value['platform']='Darwin';m.write(folder/'result.json',value);m.reseal(folder)
  if name in ('native-exit-invalid','native-pid-invalid'):
   p=folder/'native-resume-1-ended/receipt.json';v=m.gate.strict_json(p);v['exit' if name=='native-exit-invalid' else 'pid']=1 if name=='native-exit-invalid' else 0;m.write(p,v);m.reseal(folder)
  if name=='native-stdout-missing':(folder/'native-resume-1-ended/stdout').unlink();m.reseal(folder)
  if name=='current-stale-head':
   for runner in m.gate.RUNNERS:
    f=evidence/f'trigger-{runner}'
    for part in ('source-before.json','source-after.json','result.json'):
     v=m.gate.strict_json(f/part);v['head']='f44e16e079cad68e21825a1d9c7bcf1745170412';m.write(f/part,v)
    m.reseal(f)
  if name=='resigned-save-invalid':
   p=folder/'run-1/ended.ohsave';v=bytearray(p.read_bytes());v[-1]^=1;p.write_bytes(v);m.reseal(folder)
  r=t.run_public(repo,evidence);expected=0 if name=='normal' else 1;assert r.returncode==expected,(name,r.returncode);summary.append({'name':name,'exit':r.returncode,'expected':expected,'synthetic_os_labels':True})
 finally:t.tearDown()
(E/'independent-public-results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
