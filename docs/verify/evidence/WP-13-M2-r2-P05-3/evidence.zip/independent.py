from run import W,E,run,ENV
import pathlib,shutil,json
OLD=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1')
for name in ('data-probe.py','scratch-runtime.test.ts','scratch-vitest.config.mjs'):
 s=(OLD/name).read_text(encoding='utf8').replace('WP-13-M2-r2-verify1','WP-13-M2-r2-verify3').replace('WP-13-M2-r2-P05-1','WP-13-M2-r2-P05-3')
 (E/name).write_text(s,encoding='utf8')
p=E/'probe';(p/'src').mkdir(parents=True)
for name in ('Cargo.toml','src/main.rs'):
 s=(OLD/'probe'/name).read_text(encoding='utf8').replace('WP-13-M2-r2-verify1','WP-13-M2-r2-verify3')
 (p/name).write_text(s,encoding='utf8')
(E/'probe-provenance.json').write_text(json.dumps({'source':str(OLD),'independent_verifier_probe_reexecution':True,'changes':'path-only to current exact source; prior pass not used as current verdict'},indent=2),encoding='utf8')
C='C:/Users/user/.cargo/bin/cargo.exe'
run('build-native',[C,'build','-p','oh_cli','-p','oh_server'])
for kind,cmd in [('m0',['--scenario','testland']),('m1',['--pack','data/packs/testland','--scenario','m1'])]:
 for i in (1,2):run(f'{kind}-hash-{i}',[str(W/'target/debug/oh_cli.exe'),'run',*cmd,'--days','365','--seed','1','--hash-out'])
run('validate-original',[str(W/'target/debug/oh_cli.exe'),'validate','--deny-warnings','data/packs/testland'])
run('independent-data',['python',str(E/'data-probe.py')])
run('independent-rust',[C,'run','--manifest-path',str(p/'Cargo.toml')])
run('independent-runtime',['node','client/node_modules/vitest/vitest.mjs','run','--config',str(E/'scratch-vitest.config.mjs')])
