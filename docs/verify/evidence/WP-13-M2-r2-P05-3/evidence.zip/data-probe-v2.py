import pathlib,subprocess,shutil,json,hashlib,os
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3'); E=W/'target/evidence/WP-13-M2-r2-P05-3'; out=E/'independent-data-cases';out.mkdir()
pack=out/'pack';shutil.copytree(W/'data/packs/testland',pack);path=pack/'scenarios/m1/scenario.toml';original=path.read_text(encoding='utf-8');binary=W/'target/debug/oh_cli.exe'
cases=[
 ('empty-valid','flag_keys = []\ninitial_flags = {}\neffect_programs = {}\n',0),
 ('all-valid',"end_root = 'NTH'\nend_conditions = {all = [{nation_is = 'NTH'}, {not = {owns_state = 2}}]}\n",0),
 ('end-before',"end_date = '1999-12-31'\n",1),
 ('century1900-invalid',"end_date = '1900-02-29'\n",1),
 ('century2100-invalid',"end_date = '2100-02-29'\n",1),
 ('year-zero',"end_date = '0-01-01'\n",1),
 ('year-overflow',"end_date = '4294967296-01-01'\n",1),
 ('condition-empty',"end_conditions = {}\n",1),
 ('condition-array',"end_conditions = []\n",1),
 ('root-missing',"end_conditions = {nation_is = 'NTH'}\n",1),
 ('root-unknown',"end_root = 'UNK'\nend_conditions = {has_flag = 'x'}\nflag_keys = ['x']\n",1),
 ('keys-duplicate',"flag_keys = ['x','x']\n",1),
 ('initial-duplicate',"flag_keys = ['x']\ninitial_flags = {NTH=['x','x']}\n",1),
 ('initial-unknown-nation',"flag_keys = ['x']\ninitial_flags = {UNK=['x']}\n",1),
 ('initial-unknown-key',"flag_keys = ['x']\ninitial_flags = {NTH=['y']}\n",1),
 ('single-key',"end_conditions = {date_gte='2000-01-01',nation_is='NTH'}\n",1),
 ('two-compare-keys',"end_root='NTH'\nend_conditions={ideology_support={ideology='ideology-test-civic',value={gte='0',lte='1'}}}\n",1),
 ('unknown-condition',"end_conditions={future_condition=true}\n",1),
 ('typed-ID-string',"end_root='NTH'\nend_conditions={owns_state='1'}\n",1),
 ('typed-ID-range',"end_root='NTH'\nend_conditions={owns_state=65536}\n",1),
 ('typed-ID-missing',"end_root='NTH'\nend_conditions={owns_state=10}\n",1),
 ('unselected-missing-ref',"end_root='NTH'\nend_conditions={any=[{nation_is='NTH'},{owns_state=65535}]}\n",1),
 ('chance',"end_conditions={chance='0.5'}\n",1),
 ('unsupported-war',"end_root='NTH'\nend_conditions={at_war=false}\n",1),
 ('unsupported-stability',"end_root='NTH'\nend_conditions={stability={eq='0'}}\n",1),
 ('support-range',"end_root='NTH'\nend_conditions={ideology_support={ideology='ideology-test-civic',value={eq='1.0001'}}}\n",1),
 ('effect-null-type',"effect_programs={p={root='NTH',effects=[{set_flag=3}]}}\n",1),
 ('missing-scope',"flag_keys=['x']\neffect_programs={p={root='NTH',effects=[{scope={target='nation:UNK',effects=[{set_flag='x'}]}}]}}\n",1),
 ('wrong-state-scope',"flag_keys=['x']\neffect_programs={p={root='NTH',effects=[{scope={target='state:1',effects=[{set_flag='x'}]}}]}}\n",1),
 ('unknown-effect',"effect_programs={p={root='NTH',effects=[{future_effect=true}]}}\n",1),
 ('unsupported-equipment',"effect_programs={p={root='NTH',effects=[{add_equipment={equipment='future',amount=1}}]}}\n",1),
 ('unsupported-law',"effect_programs={p={root='NTH',effects=[{set_law='future'}]}}\n",1),
 ('unselected-unsupported-effect',"effect_programs={p={root='NTH',effects=[{if={condition={nation_is='STH'},then=[{add_manpower=1}],else=[]}}]}}\n",1),
 ('score-real-VP-required',"score_weights={victory_points='1',industrial_capacity='0',survival='0',faction_victory='0'}\n",1),
 ('score-Fx-overflow',"score_weights={victory_points='2147483648',industrial_capacity='0',survival='0',faction_victory='0'}\n",1),
]
for depth in (16,17):
 c="{date_gte='2000-01-01'}"
 for _ in range(depth-1):c='{not='+c+'}'
 cases.append((f'depth-{depth}','end_conditions='+c+'\n',0 if depth==16 else 1))
results=[]
for name,prefix,expected in cases:
 case=out/name;case.mkdir();source=(prefix+original).encode();path.write_bytes(source);(case/'scenario.toml').write_bytes(source)
 cmd=[str(binary),'validate','--deny-warnings',str(pack)];p=subprocess.Popen(cmd,cwd=W,env=os.environ,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate();(case/'stdout').write_bytes(stdout);(case/'stderr').write_bytes(stderr)
 result={'name':name,'cmd':cmd,'cwd':str(W),'pid':p.pid,'exit':p.returncode,'expected_exit':expected,'executable_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scenario_sha256':hashlib.sha256(source).hexdigest(),'passed':p.returncode==expected}
 (case/'receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8');results.append(result)
path.write_text(original,encoding='utf-8');(out/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print(json.dumps({'cases':len(results),'failures':[r for r in results if not r['passed']]}));assert all(r['passed'] for r in results)
newpack=out/'new-pending-pack';shutil.copytree(W/'data/packs/testland',newpack);np=newpack/'scenarios/m1/scenario.toml';np.write_text("effect_programs={empty={effects=[]}}\n"+original,encoding='utf-8')
