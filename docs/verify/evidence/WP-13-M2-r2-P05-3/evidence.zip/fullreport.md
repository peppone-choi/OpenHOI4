# 검증 리포트 — WP-13 M2-r2 P-05 시도 3

| 항목 | 값 |
|---|---|
| 판정 | **PASS — exact source의 WP-13 한정 독립 P-05** |
| 검증자 | Codex 검증 세션, 구현 비참여 새 앱 채팅, 추적 파일·index 무변경 |
| 브랜치·커밋 | detached `080e4b54bee775f49915e703fc521ba1742f156b` |
| 검증 일시 | 2026-10-07 17:24–17:40 KST |
| 전용 worktree | `E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3` |
| 증거 | `target/evidence/WP-13-M2-r2-P05-3/` |

이 판정은 현재 소스의 종료·flags/registry·저장/wire/host와 P-06-1 두 수정 및 P-06-2 CI 다운로드 경로 수정에 한정한다. 전체 M2 게이트 또는 main 통합/CI 완료 판정이 아니다. 원 ff78 P-05-1의 F1/F2 FAIL, de0 P-05-2 scoped PASS, a652 실제 Trigger CI FAIL을 구분해 보존했다.

## 직접 실행한 명령

모든 shell workdir는 전용 worktree였다. 각 child에 `GIT_OPTIONAL_LOCKS=0`, 자기 `CARGO_TARGET_DIR`, UTF-8과 실제 cargo PATH를 적용했다. 실제 `C:/Users/user/.cargo/bin/cargo.exe` 존재를 확인했다. 명령별 cmd/cwd/env/stdout/stderr/native PID·exit는 [command-results.json](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3/target/evidence/WP-13-M2-r2-P05-3/command-results.json) 및 해당 명령 폴더에 있다. 중첩 native capture/server/public CLI는 별도 receipts를 보존했다.

| 명령 | 종료 코드 | 결과 요약 |
|---|---|---|
| `cargo fmt --check` | 0 | 실제 exact checkout 통과 |
| `cargo clippy --workspace -- -D warnings` | 0 | workspace 통과 |
| `cargo test --workspace` | 0 | 기존 테스트와 신규 data/sim/save/proto 직접 실행 |
| `cargo test -p oh_proto req_net_04_generated_types_are_current -- --exact` | 0 | 실제 검사 1개 PASS; 생성 TS 재작성 없음 |
| `npm --prefix client ci` / `run build` / `test` / `run typecheck` | 모두 0 | 자기 dist 준비, 233 tests PASS, typecheck/build PASS |
| `npm --prefix client run licenses` | 0 | 실제 설치 의존성 라이선스 검사 |
| `cargo deny check licenses bans sources` | 0 | 기존 pinned 의존성 검사; 신규 의존성 없음 |
| `python tools/check_architecture.py` / `check_assets.py` / `check_assets.py --release` / `check_docs.py` / `check_localisation.py` | 모두 0 | 기존 경고 원문 보존; 문서 오류 0 |
| `cargo build -p oh_cli -p oh_server`, `cargo build -p oh_save --examples --locked` | 0/0 | 자기 target의 실제 native executable |
| `oh_cli run --scenario testland --days 365 --seed 1 --hash-out` ×2 | 0/0 | M0 `b039d35666b77fc2` |
| `oh_cli run --pack data/packs/testland --scenario m1 --days 365 --seed 1 --hash-out` ×2 | 0/0 | actual M1 `b595dc2a1e5b4f8c` |
| `oh_cli validate --deny-warnings data/packs/testland` | 0 | 원 팩 유지 |
| 독립 `data-probe-v2.py`의 public validate 입력 37건 | 0 | 정상/오류 exit을 각각 단언, 실패 0 |
| ignored `probe/Cargo.toml`의 독립 Rust 실행 | 0 | Gregorian·flags·비연속 ID·scope·깊이·budget·전체 rollback 등 16개 검사 묶음 |
| `check_trigger_determinism.py capture --out …/actual-trigger` | 0 | Windows capture2회, 6개 state 종류, fresh native 재개, 원 bytes·DTO/canonical/hash |
| `unittest … test_trigger_evidence.py -v` | 0 | 16 tests; 공개 compare의 실제 scratch Git/native 회귀 포함 |
| `public-extra.py` | 0 | 공개 CLI 8개 독립 입력; unknown root filename/platform/native exit/PID/stdout/stale/save 변조 거부, 정상 합성 수용 |
| 독립 Vitest scratch-runtime / runtime-extra | 0/0 | 26+12 tests; actual connect/MessagePack 콜백·마지막 표시·입력 차단 및 정상 수용 |
| frozen `check_save_determinism.py capture` / current `check_save_current.py capture` | 0/0 | 각각 별도 원/current 입력·capture2회·fresh resume·전체 상태 검사 |
| movement v2 / strait v3 capture·fresh resume | 모두 0 | 전체 JSON/canonical/hash 동일; v2 frozen97f 원 팩+원 save+원 expected 별도 통과 |
| 독립 legacy context matrix / saved-state-invalids | 0/0 | v1/v2/v3 None→local Some strict/force/API 거부 및 v4 손실 없는 왕복, 잘못된 DTO 12개 거부 |
| pending-only / Some(empty movement) / Some(empty strait) fresh ×2 | 모두 0 | fresh PID, 전체 DTO/canonical/hash·원 save 재인코드 동일 |
| paused active fresh→unpause | 0 | 복원은 active 유지, 첫 성공 시간전진 tick1에서만 Condition 종료 |
| own CLI 종료/tick0 run×2·fresh resume·native codec | 모두 0 | 요청 8760틱 전에 tick48/tick0 native0; 실제 checkpoint 저장·재개·원 bytes codec 보존 |
| `trigger_native.py` / `trigger_negative.py` | 0/0 | ended/tick0/paused restore+tick0 startup, HTTP200/query 유지/native0; 실제 CLI/server strict·force mode mismatch 및 unsupported at_war native1 |
| 독립 natural server pump, 올바른 decimal sequences | 0 | 실제 시간 전진 후 tick24 Date 종료, clock/조회 유지, 새 Pause/Speed 거부, 정상 Ctrl+C/native0 |
| `cargo run -p oh_data --example trigger_registry` | 0 | 25개 syntax/argument/example와 actual supported set 대조 |
| 원 구현/P-05/CI custody 및 source 보호 대조 | 최종 모두 0 | 아래 전수 bytes/SHA·HEAD·기존 단언 보존 확인 |
| 최종 `final-audit-v3.py` | 0 | 전체 state/bytes·원 receipts·해시·보호·원 증거 직접 대조, 제품 FAIL 0 |

처음 실패와 준비 오류를 숨기지 않았다. `independent-data`, `additional-native-retry`, `legacy-protection`는 command receipt와 fixture 폴더 충돌로 native 검사 전에 실패했다. 별도 이름으로 실행했으며 원 소스와 stderr를 유지했다. 최초 read command의 PowerShell brace-list ParserError와 `additional-native.py`의 pre-spawn 폴더 충돌도 준비 기록에 남겼다.

`v2-frozen-resume` native1은 원97f save를 current 팩에 연결한 **PackMismatch**다. 정확한 `movement-pack-97f`와 원 expected를 사용한 별도 실행은 native0였다. natural pump 첫 입력 `own1/own2`는 비 decimal sequence이므로 `invalid-sequence`를 반환했다. 원 query native1/server native0를 보존하고 유효 `101/102`에서 종료 거부를 별도 확인했다.

느린 per-file custody audit는 확인한 자기 child PID9860만 중단(native4294967295)했다. 새 batched Git tree 대조로 동일 9,946개 전수를 검사했다. 최초 최종-audit는 자기 receipt 생성 전 읽기 때문에 실패했다. 다음 audit의 CLI 전체 bytes 동일 단언도 실패 원문을 유지했다: CLI `--save-out`는 host `saved_at_utc`를 1초 갱신한다. 기존 CLI 코드의 시각 생성 경로를 직접 확인했으며, 여섯 CLI 저장을 각 fresh codec에서 원 timestamp/players로 재인코드하여 **원 bytes 그대로**임을 검사했다. CLI 사이에는 timestamp 외 모든 header, 저장 본문, 전체 DTO/canonical/hash가 동일했다. 제품 테스트·기대값·추적 파일을 변경하지 않았다.

## REQ별 확인

| REQ | 검사하는 테스트 | 실제 검사 여부 | 결과 |
|---|---|---|---|
| REQ-AGD-05 syntax/registry | `single_key_argument_and_depth_validation`, `registry_every_initial_argument_schema_and_malformed`, `null_schema_refs_initial_keys_and_capabilities`, `actual_registered_loader_rejects_capability_with_source` | 실행, registry/schema/serde/ref/load source 및 독립 public CLI 37건 | PASS |
| REQ-AGD-05 실제 host | `actual_world_queries_and_read_only_conditions`, `scope_restoration_idempotence_and_v4_restore`, effect 1000/1001·root depth·scheduled-budget tests | 실제 World owner/controller/support 대조, 자체 NationId87/owner scope·condition 읽기 불변·실패 검사 | PASS |
| REQ-TIME-04 실제 종료 | inclusive/calendar/simultaneous/phase-error tests | Gregorian 별도 계산, 초기 tick0, 실제 step/clock/ledger failure, constructor/restore source | PASS |
| REQ-TIME-04 저장/host | v4 codec·legacy mode tests, proto typed query test, native probes | strict/force/context/version, Some(empty)/pending-only·future queue·fresh full state·실제 CLI/server/WS | PASS |
| 신규 wire/runtime F1 | 기존 `triggerValidation.test.ts` 및 독립 38 tests | Rust→tracked TS read-only equality, actual connect/MessagePack publication/close/send | PASS, 원 F1 재현 입력 현재 거부 |
| 신규 evidence F2/P06-2 | 16 predicate tests+공개 CLI 8개 자체 입력 | 실제 scratch Git/index, 동일 payload legacy→workflow relocation, 현재 clean HEAD binding | PASS, 원 F2·경로 충돌 현재 거부/수용 계약 충족 |

필드 표의 의미/단위/type/range/null/default/ref/lifetime/authority와 definition/initial/mutable/derived 분류를 실제 constructor→step→canonical→v4→Rust wire→TS→runtime와 대조했다. 최상위 조건은 단일 AST이고 all/any/not 결합과 국가 root를 명시한다. 입력 배열 순번을 국가 ID로 사용하지 않는다. 모든 branch의 unsupported/ref 오류를 load에서 거부한다. AST는 유한 tree이며 재귀 program 호출·자동 국가 반복이 없다.

REQUEST-0009 A는 최신 planning의 01§3.3/02§5.7·원 REQUEST에 있는 **CEO 한정 잠정**이다. 사용자 추가 확정이나 D/OPEN 변경으로 취급하지 않았다. `end_date` inclusive 다음날00:00/start=end24h/end<start 오류, typed Date→Condition→Explicit lexical/중복 제거, once 종료 및 future queue/query/save 보존이 실제로 연결되어 있다.

`with_world`가 초기 권위를 설치하고 정확 한 번 평가한다. `with_movement`는 그 builder를 한 번 호출한다. v4 restore는 frozen substrate의 내부 복원 후 저장 trigger를 검증·설치하며 초기 플래그 reset·조건 재평가를 호출하지 않는다. Pause 중 조건이 참이 된 active state를 fresh native에서 그대로 복원했고 첫 unpause 시간 전진에서만 종료했다.

효과 실패는 clone candidate를 commit하지 않으며 flags/end 후보를 보존한다. enqueue preview 실패는 전체 canonical을 보존한다. 예정 effect budget 실패는 해당 명령을 거부·소비하고 clock을 전진한다. 실제 원장 overflow phaseErr는 World/state/clock/queue/flags/end/seed 전체 canonical을 보존한다. condition host는 immutable이고 이 WP에는 chance RNG adapter가 없다; 사용하는 end/if 팩을 load에서 거부한다.

## 결정론

- M0 해시1/2: `b039d35666b77fc2` / `b039d35666b77fc2`.
- actual M1 해시1/2: `b595dc2a1e5b4f8c` / `b595dc2a1e5b4f8c`.
- frozen v1 split→fresh: `4eb703aad086c7aa` → `d19d028857bb7485`; 원 fixture SHA `57b13c62ef1a6f88ade1851d0b3ae398157f95ca5bc246068eac3b2a964322fa` 동일.
- v2 split→continued/fresh: `18bff036731f4f26` → `a145b72ad0ad25e6`; 원97f fixture/pack/expected 별도 동일.
- v3 split→continued/fresh: `84462b78cc1a0f5d` → `299a80d49c17f3ec`.
- v4 active/split/ended/empty/initial/paused_condition capture2회·fresh PID·전체 DTO/canonical/hash·원 bytes 재인코드 동일. ended의 Date/Condition/Explicit(a)/Explicit(z), future 명령5개, flags/movement/explicit strait 보존.
- pending-only 및 Some(empty movement/strait)도 새native×2의 전체 DTO/canonical/hash·bytes 동일. paused active fresh→unpause tick1 종료 확인.
- 실제 CLI tick48 종료 `38e33863e17af7ba`, 초기tick0 `a14765f6469df690`; 반복/fresh 상태 동일, 요청틱 이전 정상 native0. CLI 저장의 host timestamp 차이는 위에 원 실패와 대조를 기록했다.

현재 source의 실제 수행 플랫폼은 Windows다. Linux/macOS label 복사는 comparer predicate 입력이다. 현재 source의 새 actual3OS/같은 main6 workflow·필수 job/artifact 성공은 **부모 P-07 이후 미실행/미확인**이며 이 보고서의 PASS로 대신하지 않는다.

## 금지 사항 점검

| 항목 | 결과 |
|---|---|
| 시뮬레이션의 f32/f64 | sim source 직접 검색·읽기와 architecture 검사에서 없음; Fx checked raw integer 연산 |
| HashMap 순회 | 없음; ordered Vec/BTreeMap/BTreeSet 사용 |
| thread_rng / SystemTime / I/O | sim source에 없음; CLI save timestamp와 server pump wall clock은 host 경계 |
| 코드 내 수치 리터럴 | 신규16/1000은 명세의 기술 상한; Gregorian/codec/wire 형 경계, 신규 게임 계수 없음 |
| 미결정 규칙 구현 | A의 한정 잠정과 실제 source 대조; 사용자 D/OPEN 확정·새 게임 의미 없음 |
| 골든 기대값 변경 근거 | 원 data/golden/repro/legacy fixtures/expected/checkers/5 workflows/Cargo/ignore 보호 확인; 기존 12 predicate test body 보존 |
| 클린룸 | 자체 synthetic fixture와 ASSETS 출처 대조; 원작 자료 채택 근거 없음 |
| 클라이언트 규칙 계산 | shape/type/order/range 검증만; 날짜/종료 조건/점수 재계산 없음 |
| 사용자 비간섭·설정 | CUA/탭/focus/global input/browser 미사용; 승인/샌드박스/보안/네트워크/model 설정 변경 없음; 자기 native PID만 종료 |

## 작업 로그 증거와 실제 결과 대조

P06-2의 실제 변경은 workflow 두 경로, 전용 test, own schema/ADR/worklog **5파일**이다. de0→080e diff와 Git blob 전수를 검사했으며 나머지 **9,946파일 동일**이다. `.gitignore`/global ignore·원5 workflow/checker/runtime/data/codec/fixtures/expected/Cargo 보호를 변경하지 않았다. P06-1의 ff78→de0도 소유7파일과 대조했다.

동일 scratch Git HEAD/index와 동일 payload에서 과거 untracked `trigger-evidence`는 공개 CLI native1, 실제 workflow `target/trigger-evidence`는 native0였다. `git status/check-ignore`, payload SHA 동일 및 public 호출 전후 index 동일성을 실행 단언했다. 모든 동일 과거 HEAD, tracked dirty, missing OS, invalid platform/native receipt/stdout, unknown root filename, 다시 봉인한 invalid save는 계속 native1이다. 합성 정상 output을 actual3OS로 집계하지 않는다.

원 ff78 구현 manifest **2,154파일**, 원 P-05-1 manifest **2,186파일**, P06-1 **1,668파일**, P06-2 **849파일**, a652 actual CI **819파일**을 원 disk/ZIP member bytes·길이·SHA와 전수 대조했다. 불일치0. 원 a652 run37591208365/compare job112694021815의 FAIL과 3OS producer success, 부모의 같은 a652 ignored-path native0는 서로 다른 증거로 보존했다. 새 source 판정에 원 보고서나 구현자의 green을 대신 쓰지 않았다. P06-2 final-clean 명령의 exact080e/status clean/native0와 red/native1 원출력도 대조했다.

immutable product HEAD080e와 latest planning HEAD `79c9f7d63228748de6121e976c2adcb292ce8bd5`를 구분했고 제공된 planning15개 SHA가 identity와 일치했다. 원 source·사본·부모 baseline은 재작성하지 않았다.

미완료 후속은 실제 VP 보유 의미/accessor, 국가 IC producer, 생존/진영 승리(WP20), 항복·관전(WP20/22), 결과 UI(WP22), 정치/법령/경제/장비/전쟁 adapter(WP14/15/20), M3 event chance와 전체 MOD07 reference다. generic checked Fx 가중합 산술·0weight·query를 네 축 실제 점수나 전체 M2 완료로 세지 않았다. 사용하는 실제 unsupported 팩은 load 오류다. 새 결정 상태 변경 없음.

부모 original-before와 자기 first/after에서 HEAD·9,951개 tracked list/SHA·semantic index·raw index bytes·status/diff/cached diff가 완전히 동일했다. raw index SHA `70ea29f8515f793bd3e4bb447cada155d3bcbc0965b5f6dfc4ae83b3cff29b9b`. 검증 무효 조건 없음. 자기 target의 native process 잔여0 확인; 앱 종료를 CLI exit0으로 기록하지 않았다.

봉인은 [SHA256SUMS.json](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3/target/evidence/WP-13-M2-r2-P05-3/SHA256SUMS.json), [evidence.zip](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3/target/evidence/WP-13-M2-r2-P05-3/evidence.zip), [ZIP-IDENTITY.json](/E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3/target/evidence/WP-13-M2-r2-P05-3/ZIP-IDENTITY.json)에 있다. 전수 member bytes/SHA와 봉인 후 baseline 동일성을 확인하며 manifest/ZIP 자체는 별도 identity에 기록해 순환 self hash를 만들지 않는다.

## FAIL 항목

| # | 재현 명령 | 기대 | 실제 |
|---|---|---|---|
| 없음 | 현재 exact source의 위 직접 실행·독립 입력 | WP-13 한정 계약과 보호 불변성 충족 | PASS; 준비/검증자 가정 오류·의도 negative·미실행 후속을 별도 공개 |

제품 수정·커밋·통합·새 채팅/세션·부모에게 메시지 송신은 수행하지 않았다. tracked 리포트 저장과 P-07/main6CI/actual3OS 확인은 부모 후속이다.
