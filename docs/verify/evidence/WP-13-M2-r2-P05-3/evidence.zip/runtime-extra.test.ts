import {test,expect,vi} from 'vitest';
import {encode} from '@msgpack/msgpack';
import {connect} from '../../../client/src/network';
const v={type:'TriggerResult',request:'own',supported:true,reason_key:null,trigger:{definitions_hash:'0123456789abcdef',flags:[{nation:0,keys:['0','_','b']},{nation:65535,keys:[]}],ended:{tick:'0',date:'2000-01-01',hour:0,causes:[{type:'Condition'},{type:'Explicit',source:'a'},{type:'Explicit',source:'b'}]}}};
class Socket {static OPEN=1;static latest:Socket;readyState=1;onmessage:any=null;onopen:any=null;onclose:any=null;onerror:any=null;binaryType='';sent:any[]=[];closes=0;constructor(){Socket.latest=this;}receive(x:unknown){this.onmessage?.({data:encode(x).slice().buffer});}send(x:unknown){this.sent.push(x);}close(){this.closes++;this.readyState=3;}}
for(const [name,message] of [
 ['unsupported',{...v,supported:false,reason_key:'unsupported-query',trigger:null}],
 ['active',{...v,trigger:{...v.trigger,ended:null}}],
 ['tick0',v], ['empty keys',{...v,trigger:{...v.trigger,flags:[{nation:0,keys:[]}]}}],
 ['empty nations',{...v,trigger:{...v.trigger,flags:[]}}],
 ['max tick',{...v,trigger:{...v.trigger,ended:{...v.trigger.ended,tick:'18446744073709551615'}}}],
 ['explicit sorted',{...v,trigger:{...v.trigger,ended:{...v.trigger.ended,causes:[{type:'Explicit',source:'a'},{type:'Explicit',source:'b'}]}}}],
] as const){test('actual connect accepts '+name,()=>{vi.stubGlobal('WebSocket',Socket);vi.stubGlobal('location',{protocol:'http:',host:'localhost'});const got:any[]=[],closed:any[]=[];const c=connect(m=>got.push(m),r=>closed.push(r));Socket.latest.receive(message);expect(got).toEqual([message]);expect(closed).toEqual([]);c.send({type:'Query',request:'next',kind:'time'});expect(Socket.latest.sent).toHaveLength(1);c.close();vi.unstubAllGlobals();});}
for(const [name,message] of [
 ['unknown variant',{...v,trigger:{...v.trigger,ended:{...v.trigger.ended,causes:[{type:'Unknown'}]}}}],
 ['outer unknown',{...v,unknown:'x'}],
 ['flag null',{...v,trigger:{...v.trigger,flags:[{nation:0,keys:null}]}}],
 ['unsupported nonnull',{...v,supported:false}],
 ['cause member',{...v,trigger:{...v.trigger,ended:{...v.trigger.ended,causes:[{type:'Condition',source:'fake'}]}}}],
] as const){test('actual connect preserves last display and blocks invalid '+name,()=>{vi.stubGlobal('WebSocket',Socket);vi.stubGlobal('location',{protocol:'http:',host:'localhost'});const got:any[]=[],closed:any[]=[];const c=connect(m=>got.push(m),r=>closed.push(r));const snapshot={type:'Snapshot',state:{date:'2000-01-01',hour:0,tick:'0',paused:false,speed:1}};Socket.latest.receive(snapshot);Socket.latest.receive(message);Socket.latest.receive(v);c.send({type:'Query',request:'next',kind:'time'});expect(got).toEqual([snapshot]);expect(closed).toEqual(['invalid-server-message']);expect(Socket.latest.closes).toBe(1);expect(Socket.latest.sent).toEqual([]);vi.unstubAllGlobals();});}
