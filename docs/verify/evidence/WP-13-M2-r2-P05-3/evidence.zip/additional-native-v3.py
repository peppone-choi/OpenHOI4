from run import W,E,run
import pathlib,json,shutil
probe=W/'target/debug/wp13-independent-probe.exe';p=E/'independent-data-cases/new-pending-pack';o=E/'context-matrix-cases3';o.mkdir()
run('context-matrix-execution',[str(probe),'matrix',str(W/'data/packs/testland'),str(p),str(o)])
for name in ('pending-only','empty-movement','empty-strait'):
 for i in (1,2):run(f'fresh-{name}-{i}',[str(probe),'fresh',str(p),str(o/f'{name}.ohsave'),str(E/f'{name}-repeat{i}.ohsave')])
capture=E/'actual-trigger/run-1'
run('saved-state-invalids',[str(probe),'mutations',str(capture/'pack'),str(capture/'ended.ohsave')])
run('paused-fresh-unpause',[str(probe),'fresh',str(capture/'pack-paused_condition'),str(capture/'paused_condition.ohsave'),str(E/'paused-unpaused.ohsave'),'unpause'])
cli=str(W/'target/debug/oh_cli.exe')
for name,pack in [('end',capture/'pack'),('initial',capture/'pack-initial')]:
 for i in (1,2):run(f'cli-{name}-{i}',[cli,'run','--pack',str(pack),'--scenario','m1','--ticks','8760','--seed','7','--hash-out','--save-out',str(E/f'cli-{name}-{i}.ohsave')])
 run(f'cli-{name}-fresh',[cli,'resume','--load',str(E/f'cli-{name}-1.ohsave'),'--pack',str(pack),'--ticks','8760','--hash-out','--save-out',str(E/f'cli-{name}-fresh.ohsave')])
run('registry-reference',['C:/Users/user/.cargo/bin/cargo.exe','run','-p','oh_data','--example','trigger_registry'])
run('release-assets',['python','tools/check_assets.py','--release'])


