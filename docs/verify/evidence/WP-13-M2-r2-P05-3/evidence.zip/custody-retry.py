from run import E,run
s=(E/'custody-audit.py').read_text(encoding='utf8')
start=s.index("for rel,current in before['files']:")
end=s.index("old=git('show',",start)
s=s[:start]+'''def tree(ref):
 return {part.split(b'\\t',1)[1].decode():part.split(b'\\t',1)[0].split()[-1].decode() for part in git('ls-tree','-r','-z',ref).split(b'\\0') if part}
old_tree,new_tree=tree(base),tree('HEAD')
for rel,current in before['files']:
 if rel not in allowed:
  assert old_tree[rel]==new_tree[rel],rel
  protected.append({'path':rel,'blob':new_tree[rel],'checkout_sha256':current})
''' + s[end:]
(E/'custody-audit-v2.py').write_text(s,encoding='utf8')
run('custody-audit-batched',['python',str(E/'custody-audit-v2.py')])
