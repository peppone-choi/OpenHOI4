from run import E,run
run('trigger-server',['python','crates/oh_server/tests/trigger_native.py','--capture',str(E/'actual-trigger'),'--out',str(E/'trigger-server-cases')])
run('trigger-negative',['python','crates/oh_server/tests/trigger_negative.py','--out',str(E/'trigger-negative-cases')])
