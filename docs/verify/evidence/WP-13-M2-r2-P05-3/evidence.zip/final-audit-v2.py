from run import W,E,run
import json,pathlib,hashlib,importlib.util,sys,subprocess,zipfile
load=lambda p:json.loads((E/p).read_text(encoding='utf8'))
cmds=[]
nonproduct={'independent-data':'fixture output directory collided with command receipt directory, before CLI spawn','additional-native-retry':'fixture directory collided with command receipt, before native spawn','legacy-protection':'output-directory collision, before audit assertions','v2-frozen-resume':'expected PackMismatch using current pack with historical frozen97f save; original frozen pack subsequently passed','custody-audit':'own slow audit interrupted at verified child PID9860 and replaced by batched Git tree comparison','final-audit':'audit tried to include its own receipt before native process exit; preparation error; all original commands preserved','natural-pump':'own nondecimal sequence own1/own2 rejected invalid-sequence; correct decimal sequences subsequently passed'}
for p in sorted(E.rglob('command.json')):
 if p.parent.parent!=E or not (p.parent/'result.json').is_file():continue
 result=json.loads((p.parent/'result.json').read_text());command=json.loads(p.read_text());cmds.append({'path':str(p.parent.relative_to(E)),'command':command,'result':result,'classification':nonproduct.get(p.parent.name,'final verification')})
for r in cmds:
 if r['result']['native_exit']!=0:assert r['path'] in nonproduct,r
(E/'command-results.json').write_text(json.dumps({'commands':cmds,'nonproduct_failures':nonproduct,'console_preparation_failures':['PowerShell unsupported brace path-list syntax: ParserError before read command executed','additional-native.py failed before spawn due to existing context-matrix directory; original tool stderr preserved in tool transcript and source v1 retained'],'tracked_modification':False},indent=2),encoding='utf8')
assert load('source-audit/summary.json')['protected']==9946
assert load('legacy-protection-cases/report.json')['frozen_differences']==[]
assert load('original-fail1-custody.json')['mismatches']==0
# Current producer clean native evidence is independent of this verifier run.
I=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2/target/evidence/WP-13-P06-2');v=json.loads((I/'final-summary.json').read_text());assert v['head']==load('self-before.json')['head'];assert v['protected_sha_mismatches']==[]
for name,case in v['native_commands'].items():
 if name.startswith('final-'):assert case['result']['exit']==0 and case['command']['head']==v['head'] and case['command']['status']==''
# Repeat/fresh bytes and whole structured state are independent assertions.
for kind,expected in [('m0','b039d35666b77fc2'),('m1','b595dc2a1e5b4f8c')]:
 assert (E/f'{kind}-hash-1/stdout.txt').read_text().strip()==(E/f'{kind}-hash-2/stdout.txt').read_text().strip()==expected
for version in ('v2','v3'):assert load(f'{version}-capture/stdout.txt')==load(f'{version}-resume/stdout.txt')
assert load('v2-frozen-correct/stdout.txt')==json.loads((W/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json').read_text())
for name in ('pending-only','empty-movement','empty-strait'):
 a,b=load(f'fresh-{name}-1/stdout.txt'),load(f'fresh-{name}-2/stdout.txt');assert a['pid']!=b['pid'];assert {k:a[k] for k in a if k!='pid'}=={k:b[k] for k in b if k!='pid'}
 assert a['before']==a['after'] and a['before_canonical']==a['after_canonical'];assert (E/f'{name}-repeat1.ohsave').read_bytes()==(E/f'{name}-repeat2.ohsave').read_bytes()
for name in ('end','initial'):
 assert (E/f'cli-{name}-1/stdout.txt').read_text()==(E/f'cli-{name}-2/stdout.txt').read_text()==(E/f'cli-{name}-fresh/stdout.txt').read_text()
 assert (E/f'cli-{name}-1.ohsave').read_bytes()==(E/f'cli-{name}-2.ohsave').read_bytes()==(E/f'cli-{name}-fresh.ohsave').read_bytes()
p=load('paused-fresh-unpause/stdout.txt');assert p['before']['trigger']['ended'] is None and p['after']['trigger']['ended']['causes']==['Condition'];assert p['after']['base']['base']['base']['state']['tick']==1
sys.path.insert(0,str(W/'crates/oh_sim/tools'));import check_trigger_determinism as g
state,cases=g.verify_folder(E/'actual-trigger');assert state['head']==v['head'] and not state['dirty']
sys.path.insert(0,str(W/'crates/oh_save/tools'));import check_save_current as current
current.verify_folder(E/'save-current')
public=[]
for p in (E/'public-receipts').rglob('receipt.json'):
 r=json.loads(p.read_text());assert r['source_before']==r['source_after'];public.append({'case':p.relative_to(E/'public-receipts').as_posix(),'exit':r['native_exit'],'synthetic_os_labels':True})
pair={x['case']:x['exit'] for x in public};assert pair['test_public_workflow_download_keeps_source_clean/legacy/receipt.json']==1 and pair['test_public_workflow_download_keeps_source_clean/workflow/receipt.json']==0
for p in (E/'trigger-server-cases').glob('*/result.json'):
 r=json.loads(p.read_text());assert r['head']==v['head'] and r['exit']==r['query_exit']==0 and r['pack_preserved'] and r['save_preserved']
assert load('natural-pump-cases2/receipt.json')['native_exit']==0
assert all(x['callbackCount']==1 and x['closeCount']==1 and x['sentAfterInvalid']==0 for x in load('runtime-observations.json'))
summary={'head':v['head'],'commands':len(cmds),'nonproduct_failures':nonproduct,'protected_files':9946,'original_tests_preserved':12,'client_tests':233,'independent_runtime_tests':38,'independent_data_cases':37,'independent_sim_checks':16,'public_synthetic_cli_receipts':public,'m0':'b039d35666b77fc2','m1':'b595dc2a1e5b4f8c','v1':load('save-original/result.json'),'v2':load('v2-capture/stdout.txt')['split']['hash'],'v2_continued':load('v2-capture/stdout.txt')['continuous']['hash'],'v3':load('v3-capture/stdout.txt')['split']['hash'],'v3_continued':load('v3-capture/stdout.txt')['continuous']['hash'],'cli_end':(E/'cli-end-1/stdout.txt').read_text().strip(),'cli_initial':(E/'cli-initial-1/stdout.txt').read_text().strip(),'trigger_capture':state,'planning_head':load('source-audit/summary.json')['planning_head'],'product_failures':[],'unexecuted':['actual current source Linux/macOS capture','new same-main six workflows and three-OS CI: parent follow-up','full scoring/surrender/spectate/result UI and future adapters: downstream scope']}
(E/'final-audit.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps({k:summary[k] for k in ('head','commands','protected_files','client_tests','independent_runtime_tests','m0','m1','v2','v2_continued','v3','v3_continued','cli_end','cli_initial','product_failures')}))
