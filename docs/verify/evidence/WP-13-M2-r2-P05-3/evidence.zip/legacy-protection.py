import pathlib,subprocess,hashlib,json,shutil
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3');E=W/'target/evidence/WP-13-M2-r2-P05-3';base='f44e16e079cad68e21825a1d9c7bcf1745170412'
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(W),*a])
changed=git('diff','--name-only',base,'HEAD').decode().splitlines();report={'base':base,'head':git('rev-parse','HEAD').decode().strip(),'changed':changed,'planning':[],'frozen_differences':[]};out=E/'legacy-protection';out.mkdir()
for p in changed:
 dst=out/'current'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((W/p).read_bytes())
 try:old=git('show',base+':'+p)
 except subprocess.CalledProcessError:continue
 dst=out/'base'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(old)
for p in git('ls-files').decode().splitlines():
 protected=p.startswith(('data/packs/','tests/golden/','tests/repro/','crates/oh_save/tests/fixtures/')) and 'fixtures/trigger/' not in p
 protected|=p.startswith('.github/workflows/') and 'trigger-determinism' not in p
 protected|=p.startswith('crates/oh_save/tools/') or p in ['crates/oh_sim/tools/check_sim_determinism.py','Cargo.toml','Cargo.lock','client/package.json','client/package-lock.json','deny.toml','docs/01-game-design.md','docs/02-production-spec.md']
 if protected and p in changed:report['frozen_differences'].append(p)
identity=json.loads((E/'planning/identity.json').read_text(encoding='utf-8'))
for v in identity['files']:
 b=pathlib.Path(v['copy']).read_bytes();report['planning'].append({'source':v['source'],'actual_sha256':hashlib.sha256(b).hexdigest(),'matches':hashlib.sha256(b).hexdigest()==v['sha256']})
(out/'diff.patch').write_bytes(git('diff','--binary',base,'HEAD'));(out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False));assert not report['frozen_differences'];assert all(v['matches'] for v in report['planning'])
