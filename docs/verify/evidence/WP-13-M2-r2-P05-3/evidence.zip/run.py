import subprocess, pathlib, os, json, datetime, sys, hashlib
W=pathlib.Path(r'E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify3'); E=W/'target/evidence/WP-13-M2-r2-P05-3'
ENV=dict(os.environ); ENV.update(GIT_OPTIONAL_LOCKS='0',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',CARGO_TARGET_DIR=str(W/'target'))
ENV['PATH']=r'C:/Users/user/.cargo/bin'+os.pathsep+ENV['PATH']
def run(label, cmd):
 d=E/label; d.mkdir(parents=True,exist_ok=False)
 meta={'cmd':cmd,'cwd':str(W),'env':{k:ENV[k] for k in ['GIT_OPTIONAL_LOCKS','PYTHONUTF8','PYTHONIOENCODING','CARGO_TARGET_DIR']},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (d/'command.json').write_text(json.dumps(meta,indent=2),encoding='utf8')
 with (d/'stdout.txt').open('wb') as out,(d/'stderr.txt').open('wb') as err:
  try:
   p=subprocess.Popen(cmd,cwd=W,env=ENV,stdout=out,stderr=err); rc=p.wait(); result={'pid':p.pid,'native_exit':rc}
  except Exception as ex: result={'native_exit':None,'spawn_error':repr(ex)}
 result.update(label=label,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()); (d/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
 print(json.dumps(result),flush=True)
 return result
if __name__=='__main__':
 run(sys.argv[1],sys.argv[2:])
