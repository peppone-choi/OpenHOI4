from run import run
N='C:/Program Files/nodejs/npm.cmd'
for label,cmd in [('npm-test',[N,'--prefix','client','test']),('npm-typecheck',[N,'--prefix','client','run','typecheck']),('npm-licenses',[N,'--prefix','client','run','licenses']),('architecture',['python','tools/check_architecture.py']),('assets',['python','tools/check_assets.py']),('localisation',['python','tools/check_localisation.py']),('docs',['python','tools/check_docs.py'])]:run(label,cmd)
