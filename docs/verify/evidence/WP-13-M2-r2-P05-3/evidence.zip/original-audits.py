from run import E,run,W
import pathlib,json,hashlib,zipfile,shutil
old=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1')
s=(old/'implementation-audit.py').read_text().replace('WP-13-M2-r2-verify1','WP-13-M2-r2-verify3').replace('WP-13-M2-r2-P05-1','WP-13-M2-r2-P05-3').replace("out=E/'implementation-audit'","out=E/'original-implementation-custody'")
(E/'initial-implementation-audit.py').write_text(s,encoding='utf8');run('initial-implementation-audit',['python',str(E/'initial-implementation-audit.py')])
s=(old/'source-audit.py').read_text().replace('WP-13-M2-r2-verify1','WP-13-M2-r2-verify3').replace('WP-13-M2-r2-P05-1','WP-13-M2-r2-P05-3').replace("out=E/'source-audit'","out=E/'legacy-protection'")
(E/'legacy-protection.py').write_text(s,encoding='utf8');run('legacy-protection',['python',str(E/'legacy-protection.py')])
# Original FAIL1 ZIP and manifest are read-only custody inputs, never a current verdict.
m=json.loads((old/'SHA256SUMS.json').read_text());items=m['files']
with zipfile.ZipFile(old/'evidence.zip') as z:
 for x in items:
  raw=z.read(x['path']);assert raw==(old/x['path']).read_bytes();assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256']
ident=json.loads((old/'ZIP-IDENTITY.json').read_text());assert hashlib.sha256((old/'evidence.zip').read_bytes()).hexdigest()==ident['zip_sha256']
(E/'original-fail1-custody.json').write_text(json.dumps({'files':len(items),'mismatches':0,'archive_sha256':ident['zip_sha256'],'original_verdict':'FAIL F1/F2','current_verdict_not_inferred':True},indent=2))
print('original FAIL1 archive read-only custody verified')
