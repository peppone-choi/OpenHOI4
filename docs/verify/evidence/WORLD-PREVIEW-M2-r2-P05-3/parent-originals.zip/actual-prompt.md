역할: 검증 세션. OpenHOI4 세계지도 지역별 coverage·시가지 분리·해상 프로빈스·HUD/실제3D 후보의 새 독립 P-05-3.

구현 비참여 새 독립 앱이다. 부모가 실제completed final과 critical324/source snapshot·artifact671/원ZIP673 전수대조를 끝낸 뒤 새 exact detached worktree와 최초 full/raw 기준선을 만들었다. 기존 검증 앱/기준선을 재사용하지 않는다.

exact HEAD: 446540f9755f6d381f789192f3576a8cc17aadd2
전용 detached worktree: E:/openhoi/.orchestrator/wt/WORLD-PREVIEW-M2-r2-verify3
ignored output: target/evidence/WORLD-PREVIEW-M2-r2-P05-3
부모 01a114ca-469a-73c0-a9c4-9df475c37769/local. 업무 메시지는 사용자 승인 범위다. 새 앱/세션 생성, commit/main·다른 worktree 수정 금지.

모든 명령은 지정 worktree/절대 path, GIT_OPTIONAL_LOCKS=0에서 실행한다. 부모 최초 full tracked SHA/HEAD/semantic index/raw index/diff/cached/status와 자기 최초·마지막·봉인 뒤 스냅샷 전체를 비교한다. 원 baseline/index를 복구·교체하지 않는다. 추적 파일 생성/재작성도 하지 않는다. ignored 출력만 생성한다. 불변성 차이는 검증 무효 FAIL로 보존한다. 원 stdout/stderr/native exit와 실제 실행을 직접 확인한다.

원 a28 P05-1 F01/F02, 원2d920 P05-2 F03/F04 actual final·원본 ZIP/MF/native failures는 역사 증거다. ab64는 지역 품질 미달 후보이지 독립 PASS가 아니다. P06-3 이전 소스로 새 기능을 검증했다거나 원 FAIL을 새 PASS로 바꾸지 않는다. 기존 2d920 전체 E2E 각 browser41PASS와 ab64 자체 Chrome41PASS는 새 source 전체 실행을 대신하지 않는다. 새 검증 PASS는 미리보기 한정이며 전체 WP32/45·M5·M2묶음·사용자 외관 승인·역사1936·게임기능 완료가 아니다.

AGENTS/P05전문/VERIFY_REPORT_TEMPLATE, 실제 schema/ADR3201/worklog/P06-3 계약과 ignored 최신 planning/identity를 읽는다. 구현 설명을 믿지 않고 final source·manifest·공식 원천 metadata·실제 산출물에 대조한다. 정확 HEAD에 없는 부모 최신 문서는 planning 사본이며 제품 source와 혼합하지 않는다.

사용자 범위: 전체 land+sea+lake 20,000~30,000 제작 목표, 최소20,000 지향, 30,000은 새 절대 상한이 아니다. 도시만20k 또는 모든 도시=1/모든 거대도시=복수라는 새 규칙을 만들지 않는다. 총수·육해호수 각수·모든1pixel/원천true1pixel/의도 분할tiny·지리면적 분포·큰셀 편중을 별도 보고한다. 원천 작은 섬/물 조각을 일괄 삭제하거나 단절 지리를 합쳐 숫자를 맞추면 FAIL이다. 숫자만 목표 범위면 품질 PASS하지 않는다.

독립 지리 원천: 고정 Natural Earth land/lakes/rivers/populated-place SHP좌표/urban-area SHP 및 NOAA ETOPO 두 subset의 공식 URL/date/version/license/SHA/CRC/CRS/axis/형식·메타데이터를 대조한다. 도시 DBF 인구·LandScan·원작 지도/ID CSV/색/경계/수치표가 입력에 없음을 확인한다. urban ZIP embedded4.1.0와 웹표시4.0.0 차이 및 MODIS2002–2003/1km 일반화1:10M 관측 한계를 명시한다. 현대 도시 위치와 시가지가1936경제/인구/승점으로 쓰이면 FAIL이다. 고정 원천에서 offline 재생성하며 runtime 외부 API/tile/CDN/font 없음. 기존 취득 EOF 실패와 후보 실패는 보존한다.

구면 면적은 defines 평균지구반지름과 R²Δλ(sinφN−sinφS)로 독립 재계산한다. Plate Carrée pixel수를 km²라고 하거나 원천 raster 근사를 측량/국가면적이라고 부르지 않는다. Ireland(-8,53)의 전체 연결섬, Great Britain/Honshu/Hokkaido/Shikoku 및 실제 Kyushu 수로 한계, 유럽/아시아/아프리카/아메리카의 연결 component와 잘린 기하 window를 구분해 actual IDs·면적·분포·largestshare·도시점 coverage를 계수한다. ab64 아일랜드5789pixels/1ID6809(근사82,361km²) 원본을 보존하고 같은 geography/scale 새 결과와 대조한다. 큰 connected land마다 공통 면적 최소배정이 실제 작동하고 Ireland 특례/노이즈/임의 행정경계/단절 merge가 없는지 확인한다.

시가지: source polygon을 실제 land와 교차한 mask로 도시와 nonurban-in-source의 실제 province 경계가 나뉘는지 모든 대상 pixel/ID에서 검사한다. point seed 증가는 footprint 분리의 증거가 아니다. 원천 footprint 밖을 권위 농촌/교외라 부르지 않고 도시점 outside-source는 누락으로 남긴다. Dublin/London/Seoul/Tokyo 실제 point·distance·footprint cell/근사면적·ID·urban fraction·주변nonurban·연결/인접·hover/pick을 같은 축척 PNG로 제출한다. 큰 시가지 내부 분할은 actual source/하천/면적의 표시 후보이고 게임효과가 없다. 약1km fragment가 전부 독립 clickable province가 되는 정책을 몰래 만들거나 클릭 불가 미세 조각으로 개수를 채우면 FAIL이다.

해상: sea/lake/land 각각 고유 ID·영역·경계·인접·hover/select가 원raster와 일치한다. English Channel/Irish Sea/Japan 근해/Atlantic 동일 지리 축척으로 연안·해협 상대 세분과 대양 넓은 분할의 실제 면적분포/가독성을 확인한다. 상위 전략해역은 미구현이며 province와 섞지 않는다. dateline/seam/섬둘레/수로/호수 hole과 sourcekind를 모두 검사한다. Natural Earth source 일반화로 Kyushu수로/Caspian이 누락된 곳은 한계이며 경계를 발명해 해결하지 않는다. 원천이 표현하는 수로를 새 생성으로 폐쇄하면 FAIL이다.

기술:8192×4096 RG8u16LE/dense1based1..65535와zero-basedordinal/256lookup/8K capability/CPU picking/orthographic camera를 실제 코드·JSON·SHP·raw와 대조한다. 원 F03 edge없는 유효2×2와 emptyCSR/min/Dijkstra/fallback, F04 65536 ID 거부·65535 허용 및 noanchor/kind변환 original RED를 새ignored fixture로 직접 검사한다. 모든pixelkind/urbanclass·모든ID4connected/bbox/repvalidDEM-or-null/sorteduniqueadjacency/seam/finite/error rollback을 검사한다. 원 source 입력 mutation은 ignored copies에만 만들고 기존 bytes 보존을 비교한다. 두 번 ignored offline bake, 동일 final-source·defines/input/hash, 원본+서로4산출SHA 일치를 검증한다. tracked bake/TS writer는 호출하지 않는다.

P06-3 새 noanchor1×4초안의 expected3은 구현자가 인정한 잘못된 기하 가정이며 원green-first.log1FAIL이 보존된다. kind[1,2,1,2]는4connected land2/lake2=4조각, seam끝lake와처음land는kind다름이며 IDmerge가 아닌adjacency만추가한다. producer noanchor-independent-geometry.json/strengthened6tests native0는 인수 증거이며 독립검증을 대신하지 않는다. 새source에서 별도4neighborfloodfill로4조각·원kind·exactdense/onebased/adjacency를 직접 검증한다. 원F03/F04·기존tests/골든 단언을 약화하지 않는다.

원dirtycandidate1/2 및 첫clean d1de54e는26213/17criticalsource·4shippedSHA같음·원Ireland21 중13≥9px·8tiny로별도보존된다. 후속candidate3은24889/160.156s/PeakCommit2639400960B,land13882/sea6954/lake4053·1pixel2769/2349/1492=6610/Ireland17, 아직finalsource가아니다. actualfragment policy는같은rawseed의최대component가아닌≤8px조각,homogeneousactualkind+urbanmask+eligibleurbanclass,4neighbor>8pxstabletarget의sharededge→targetsize→ordinal 재할당이다. 원whole-seedcore/true지리·actualsurfaceislands/mixedclass/단절물체/datelineID를 일괄merge하지 않는다.1278재할당components/3435pixels와최종dense ID감소1324는다른단위이며dense-renumber를raw changedpixels로집계하지 않는다. 최초8test의RED/green0·원prototype/초기기하가정FAIL은보존한다. 부모33554432decodedkind/partitionedclass전수차0·7sources동일은독립sourcepolygon재raster화가아닌원출력대조이며원자료/최종recipe를직접검증해야한다. 최종actualpolicy/defines/남는tiny/실제clickability/2bake/budget를 다시대조한다.

사용자ProvGen v1.0참고요청은원ZIP/README/Settings읽기전용연구다. CEO research/provgen/ALGORITHM_REVIEW.md·review-receipt.json은latestplanning사본으로제공한다. ZIP19항목에source/LICENSE없고 EXE/DLL미실행·미디컴파일·포함BMP미열람/미추출/미사용이다. 확인된LandMap/회색조육지크기/해안거리sea/지형·도시점/minmax·산악폭제어와현재generator를대조한자기문서만검사한다. Voronoi/watershed/Poisson/Lloyd/seedgrowth/merge/determinism실체를확인했다고쓰거나palette/예시값/canonicalmapformat을도구에서인수하면FAIL. 도시점nearestprovince전체urban태깅은원builtupfootprint분리를대신할수없다. optional모더densityimage입력검토는미구현후보이며예고를제품완료로쓰지않는다.

candidate3/4 debug의preserved_surface_islands11840는실제섬계수가아닌>8px안정same-surface target 없는noncore조각계수였으며그원metadata는보존한다. 최종소스에서는preserved_without_large_same_surface_target 및그하위preserved_with_only_small_same_surface_neighbours / preserved_without_external_same_surface_neighbour로정정됐다. reported11840=427small-neighbour-only+11413external-same-surface-neighbour없음, mixed38은별도다. raw[0×9,1,0,1]·모두samekind/urban/eligible이면작은noncore0조각에same-surface이웃1은있으나>8target이없으므로자연섬이라고계수하면틀린다. 해당새기하case와정말고립된classcase를독립검증하고원counterKeyErrorRED→9testgreen0를기존골든변경과혼동하지않는다. 최종candidate5/6의4SHA는원3/4pair와분리한다. reportedcandidate5 native0/176.000s/PeakCommit2639302656B와candidate6약147s 모두기존180s/3GiB이내이지만한번의176s는4초여유뿐이며performance전체보장으로쓰지않는다. 최종정확source의두boundedbake를직접수행하고원실패를보존한다. CRC검사는DBF rawbytes도decompress/read하지만속성파싱/인구채택은없다는정확한구분을유지한다.

bake180초/3GiB와index64MiB 계약은 실제 native감독/PID 전체기간 peak으로 대조한다. parent renderer CPU/GPU/JS heap·Commit/WorkingSet은 같은 수치가 아니다. limit을 넘으면 원 FAIL을 보존하며 임의 timeout/예산/해상도/단언을 완화하지 않는다. 데이터 크기/ID상한/selector/fallback/shader/GLB/cleanup 기본 계약을 보존한다.

브라우저 검수: computer-use/CUA/사용자desktop·tabs·focus·전역input/desktop전환/visible browser/open-in-app/BPhelper·BP프로세스 금지. 자기 localhost/PID/profile, 최소인자 headlessChrome/CDP page screenshot만. --no-sandbox/security/GPU feature override 없이 actual argv·adapter/backend/headless·frame/shader/nativeexit를 읽는다. 필요 cosmetic hide-scrollbars를 별도 명시하고 원 설정/timeout/retry/workers/assertions 보존한다. 검은/미렌더canvas FAIL, foregroundfallback 금지. 자기 PID만 정리한다.

세계/지역/도시/해상 PNG, KO/EN, zoom/pan/hover/select/clear/borders/geography/province/terrain/3D toggle/resize/DPR/850×650·최소1280을 직접 검수한다. 마지막 버튼·legend/rail overflow와 actual selection 원pixel을 대조한다. own HMR WS와 gameplay WS/unknown WS를 나눠 기록한다. page/console/HTTP error·failed requests·StrictMode/cleanup expectedabort는 rawtiming과 대조하며 한데0으로 쓰지 않는다. UI미연결 슬롯·disabled panels/newcommands없음을 확인한다.

3D 원GLB3·publiccopy·metadata/Node recipe whole bytes/22mesh·6samples912triangles·finite/CCW/normals/material/metre/+Yup/+Zforward/groundpivot/3axisbbox를 직접 검사한다. 실제 scene/light/depth/camera/occlusion/on-offpixel/세종실루엣과dispose/abort/sharedcleanup을 확인한다. PNGbillboard/빈mesh를3D로 부르면FAIL. raw GLB URI/hash/path/header/emptygeometry negative는ignoredmutation만. originalTestlandrenderer pipeline/camera/input/resize/assertions 보존.

기존 Fluent checker 그대로·ko/en preview-* 실제 등록/runtime translator 및 originalprefix/ASSETSunion·개별 sourceLICENSE를 확인한다. npmci/unit/typecheck/build/licenses/read-only generatedTS equality, mapPython 실제 DEM/urban source tests, docs/assets--release/architecture/license, Rustfmt/clippy/workspace 및 M0/M1각2hash를 실행한다. 기존 전체 E2E는 각각 새source단일전체 실행Chrome/Firefox/WebKit로 검사하고 partial합산을 하지 않는다. trackedconfig/test/expected를 변경하지 않는다. 사용 못한 browser/명령은 원오류·미실행 사유를 남기며 완료 판정에서 숨기지 않는다.

마지막 actualfinal VERIFY_REPORT_TEMPLATE PASS또는FAIL 전문에는 범위·실제명령/native·full/raw불변·전체kind/coverage/urban/sea/성능·현대한계·실제GPU/3D/HUD미연결·F01~F04·미실행을 명시한다. 자기 original stdout/PNG/입력metadata/SHA256SUMS.json/evidence.zip/ZIP-IDENTITY.json을 봉인하고 봉인 뒤 다시불변성 비교한다. 큰 ZIP은 원본을 유지하고 부모가 정확 bytes orderedparts로 보관할 수 있으며 producerZIP을 덮지 않는다. 실제 앱final과 fullreport/원receipt를 각각 남기고 cli0로 앱종료를 대신하지 않는다.


착수 바인딩: 최초 tracked 10015 / raw index b6dfe05f2c0d0bf3b7d72a2a3a30978088f59567338b6e6b0641613dba9ce07d. original parent-before JSON/index와 ignored snapshot.py/actual-prompt.md/planning을 위target에 제공했다. 원source producer identitySHA ac02556ce0825d4c1c4b4cbea5449a617d458444fb25b46aa5ad7ba2cc67bae4,원ZIP107651219bytes/SHAfe53808374917360550ddf6bff6d2496b9519a99d2f9274ee069103a7fa4dab0/artifacts671/member673. 부모custody는 E:/openhoi/docs/worklog/evidence/WORLD-PREVIEW-M2-r2-P06-3이고 original producer path는 E:/openhoi/.orchestrator/wt/WORLD-PREVIEW-M2-r2/target/evidence/WORLD-PREVIEW-quality-P06-3/final이다. 원ZIP은producer경로에있으며parentorderedparts는같은bytes의보관형식이다. source324raw와snapshot은같고Git321rawexact/3UTF8 CRLF-LF차이는정확원bytes/SHA로보존했다. 새worktree의canonicalGit내용을검증하며이sourcecheckout간EOL차이를검증중원rawindex불변의면제로쓰지않는다.

중요한 실제 source 계약: 도시분리는>=100km²major MODIS footprint이고작은footprint는미분리다. fragment의same-urban조건은이동pixel과계수한sharededge에적용하며ordinary target province의다른위치에<100km²미분리urban이있을수있다. entiretargetprovince가모두같은actualurban값이어야한다는새요구를만들지않는다. debug old_dense_id/target_dense_id는1based표시이므로0basedindex접근시-1이며sharededges는계수된조건일치edge수다. producer첫debug0based오해/모든targetedgeclass동일오해의원native1×2와수정된1278record 검사0를직접대조한다.

sourcefinal actual41 단일M1회귀는 ed0171f09b330da4335c821e3ad88cd4332a6f17이며그뒤446540f는worklog/SOURCES/ASSETS의기록·source설명변경만이다. 이설명을믿고446 검사를생략하지않고새exact446에서직접원전체41을실행한다. 실제1pixel표본15287/15621의zoom60/11.015625screenpixel·원pick을독립대조하며일반축척선택편의로확대하지않는다. Ireland17중4tiny(1/2/2/8)·13>=9px,GB68/Honshu+Kyushu173source연결한계/Hokkaido16/Shikoku10을directcomponent로대조한다. 전체24,889/onepixel6,610/원sourcekind1pixel6,125의실제분류와면적분포·도시4표본majorfraction1.0·sea선택을검사한다.

모든명령은지정worktree에서GIT_OPTIONAL_LOCKS=0이다. source tools/maps/bounded_bake.py는180s/3GiB/64MiBindex를유지하며newignoredout만허용한다. 실행경로문제면이미설치된 C:/Users/user/.cargo/bin/cargo.exe 절대경로 또는이process PATH만사용하고global설정/추적files/기존timeouts/expected를바꾸지않는다. own localhost권장port4333/4334는사용중이면다른자기port만선택한다. 기존Vite33284/사용자·BP·다른PIDs/profile은건드리지않는다. 마지막actualfinal과VERIFY_REPORT는한국어로쓰며새세션/commits/mainwrite금지.
