// 0d7640524b047c8b80a65008104c6209a1c995ed
var _process$env$OH_MAP_E;
import { expect, test } from '@playwright/test';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { png } from './png';
import { encode, decode } from '@msgpack/msgpack';
import { displayFixture, wideDisplayFixture } from './displayFixture';
const evidence = (_process$env$OH_MAP_E = process.env.OH_MAP_EVIDENCE) !== null && _process$env$OH_MAP_E !== void 0 ? _process$env$OH_MAP_E : '../target/wp08/e2e';
mkdirSync(evidence, {
  recursive: true
});
async function mapPoint(map, x, y) {
  const box = await map.boundingBox();
  const c = JSON.parse(await map.getAttribute('data-camera'));
  return {
    x: (x - c.x) / c.width * box.width + box.width / 2,
    y: (y - c.y) / c.height * box.height + box.height / 2
  };
}
function closeRGB(actual, expected, label = 'pixel') {
  for (let i = 0; i < 3; i++) expect(Math.abs(actual[i] - expected[i]), `${label}: ${actual} expected ${expected}`).toBeLessThanOrEqual(1);
}
test('REQ-MAP-04/05 PLAT-03 actual map pixels, modes, pick and viewport', async ({
  page,
  browser
}, info) => {
  const requests = [];
  page.on('request', r => requests.push(r.url()));
  page.on('websocket', ws => requests.push(ws.url()));
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('/?forceWebGL=1');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-backend', 'webgl2');
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  await expect(page.getByRole('button', {
    name: 'Terrain',
    exact: true
  })).toBeInViewport();
  await expect(page.getByTestId('pause')).toBeInViewport();
  await page.getByTestId('pause').click();
  await expect(page.getByTestId('pause')).toHaveText('Resume');
  const box = await map.boundingBox();
  expect(box).not.toBeNull();
  const camera = JSON.parse(await map.getAttribute('data-camera'));
  const at = (x, y) => ({
    x: (x - camera.x) / camera.width * box.width + box.width / 2,
    y: (y - camera.y) / camera.height * box.height + box.height / 2
  });
  for (const [name, color] of [['Ownership', [40, 100, 180]], ['Terrain', [130, 165, 95]], ['States', [140, 95, 170]]]) {
    await page.getByRole('button', {
      name,
      exact: true
    }).click();
    await page.mouse.move(0, 0);
    await page.waitForTimeout(80);
    const shot = await map.screenshot({
      path: `${evidence}/${info.project.name}-${name}.png`
    });
    const p = at(1, 1);
    const actual = png(shot).pixel(p.x, p.y);
    for (let i = 0; i < 3; i++) expect(Math.abs(actual[i] - color[i]), `${name} pixel ${actual}`).toBeLessThanOrEqual(1);
  }
  await map.click({
    position: at(1, 1)
  });
  await expect(page.getByTestId('selected-province')).toHaveText('10');
  await expect(page.getByTestId('map-hover')).toHaveText('Province 10 · Plains');
  await map.click({
    position: at(1, 3)
  });
  await expect(page.getByTestId('selected-province')).toHaveText('30');
  await expect(page.getByTestId('map-hover')).toHaveText('Province 30 · Plains');
  await expect(page.getByTestId('country-panel').locator('h3')).toHaveText('Southern Test Nation');
  await expect(page.getByTestId('state-panel').locator('h3')).toHaveText('Southern Test State');
  await page.getByTestId('state-panel').getByText('Infrastructure', {
    exact: true
  }).click();
  await expect(page.getByTestId('state-panel').locator('.ledger-tooltip')).toContainText('Value ledger');
  await expect(page.getByTestId('state-panel').locator('.ledger-value strong')).toHaveText('0');
  await expect(page.getByTestId('state-panel').locator('.ledger-tooltip')).toBeInViewport();
  await expect(map).toBeInViewport();
  await page.getByRole('combobox').selectOption('ko');
  await expect(page.getByTestId('map-hover')).toHaveText('프로빈스 30 · 평야');
  await expect(page.getByTestId('state-panel').locator('h3')).toHaveText('남부 시험주');
  await map.click({
    position: at(1, 1)
  });
  await expect(page.getByTestId('selected-province')).toHaveText('10');
  await expect(page.getByTestId('map-hover')).toHaveText('프로빈스 10 · 평야');
  await expect(page.getByTestId('country-panel').locator('h3')).toHaveText('북부 시험국');
  await page.screenshot({
    path: `${evidence}/${info.project.name}-first-map.png`
  });
  expect(errors).toEqual([]);
  expect(requests.every(u => new URL(u).host === new URL(page.url()).host)).toBe(true);
  writeFileSync(`${evidence}/${info.project.name}-map.json`, JSON.stringify({
    browser: browser.version(),
    requests,
    errors,
    diagnostics: await map.evaluate(el => ({
      ...el.dataset
    })),
    viewport: {
      width: 1280,
      height: 720
    },
    scenario: 'm1',
    seed: '1'
  }, null, 2));
});
test('REQ-PLAT-03 preferred actual backend produces the same map RGB and source shader', async ({
  page,
  browser
}, info) => {
  await page.goto('/');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-backend', /webgpu|webgl2/);
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  await page.mouse.move(0, 0);
  const shot = await map.screenshot({
    path: `${evidence}/${info.project.name}-preferred.png`
  });
  const p = await mapPoint(map, 1, 1);
  closeRGB(png(shot).pixel(p.x, p.y), [40, 100, 180]);
  const diagnostics = await map.evaluate(el => ({
    ...el.dataset
  }));
  expect(diagnostics.shaderLanguage).toBe(diagnostics.backend === 'webgpu' ? 'wgsl' : 'glsl');
  expect(Number(diagnostics.shaderLength)).toBeGreaterThan(0);
  for (const [name, x, color] of [['Control', 3, [180, 70, 40]], ['Terrain', 1, [130, 165, 95]], ['States', 1, [140, 95, 170]], ['Ownership', 1, [40, 100, 180]]]) {
    await page.getByRole('button', {
      name,
      exact: true
    }).click();
    await page.mouse.move(0, 0);
    await page.waitForTimeout(60);
    const point = await mapPoint(map, x, 1);
    closeRGB(png(await map.screenshot({
      path: `${evidence}/${info.project.name}-preferred-${name}.png`
    })).pixel(point.x, point.y), color, name);
  }
  await expect.poll(async () => Number(await map.getAttribute('data-frames'))).toBeGreaterThan(60);
  writeFileSync(`${evidence}/${info.project.name}-preferred.json`, JSON.stringify({
    browser: browser.version(),
    diagnostics: await map.evaluate(el => ({
      ...el.dataset
    })),
    performanceScope: 'tiny synthetic map; renderer frame interval, not global hardware benchmark'
  }, null, 2));
});
test('REQ-MAP-04 changed server RGB updates only affected lookup texel on actual backend', async ({
  page
}, info) => {
  let inject = false;
  await page.routeWebSocket('**/ws', route => {
    const server = route.connectToServer();
    server.onMessage(data => {
      const m = decode(data);
      if (inject && m.type === 'WorldResult' && m.world && m.request === 'world') {
        m.world.provinces[0].owner_color = [18, 44, 110];
        route.send(Buffer.from(encode(m)));
      } else route.send(data);
    });
  });
  await page.goto('/');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  inject = true;
  await expect(map).toHaveAttribute('data-last-changed-bytes', '4');
  await page.mouse.move(0, 0);
  const point = await mapPoint(map, 1, 1);
  closeRGB(png(await map.screenshot()).pixel(point.x, point.y), [18, 44, 110]);
  const untouched = await mapPoint(map, 3, 1);
  closeRGB(png(await map.screenshot()).pixel(untouched.x, untouched.y), [40, 100, 180]);
  writeFileSync(`${evidence}/${info.project.name}-partial-update.json`, JSON.stringify(await map.evaluate(el => ({
    ...el.dataset
  })), null, 2));
});
test('REQ-MAP-04/05 RG8 high dense byte and LUT second row pick real ID65535', async ({
  page,
  request
}, info) => {
  const meta = await (await request.get('/maps/testland/metadata')).json();
  let fixture;
  await page.routeWebSocket('**/ws', route => {
    const server = route.connectToServer();
    server.onMessage(data => {
      const m = decode(data);
      if (m.type === 'WorldResult' && m.world && m.request === 'world') {
        fixture = wideDisplayFixture(m.world, meta);
        m.world = fixture.world;
        route.send(Buffer.from(encode(m)));
      } else route.send(data);
    });
  });
  await page.route('**/maps/display_fixture/metadata', r => r.fulfill({
    json: fixture.meta
  }));
  await page.route('**/maps/display_fixture/index.bin?*', r => r.fulfill({
    body: fixture.bytes,
    headers: {
      'x-pack-hash': meta.pack_hash
    }
  }));
  await page.goto('/');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  await page.mouse.move(0, 0);
  const p = await mapPoint(map, 256.5, 3);
  closeRGB(png(await map.screenshot({
    path: `${evidence}/${info.project.name}-dense256.png`
  })).pixel(p.x, p.y), [17, 123, 231]);
  await map.click({
    position: p
  });
  await expect(page.getByTestId('selected-province')).toHaveText('65535');
  writeFileSync(`${evidence}/${info.project.name}-dense256.json`, JSON.stringify(await map.evaluate(el => ({
    ...el.dataset
  })), null, 2));
});
for (const force of [false, true]) test(`REQ-MAP-05 independent three border pixel oracle, u16 sentinel and camera ${force ? 'WebGL2' : 'preferred'}`, async ({
  page,
  request
}, info) => {
  const meta = await (await request.get('/maps/testland/metadata')).json();
  let fixture;
  await page.routeWebSocket('**/ws', route => {
    const server = route.connectToServer();
    server.onMessage(data => {
      const m = decode(data);
      if (m.type === 'WorldResult' && m.world && m.request === 'world') {
        fixture = displayFixture(m.world, meta);
        m.world = fixture.world;
        route.send(Buffer.from(encode(m)));
      } else route.send(data);
    });
  });
  await page.route('**/maps/display_fixture/metadata', route => route.fulfill({
    json: fixture.meta
  }));
  await page.route('**/maps/display_fixture/index.bin?*', route => route.fulfill({
    body: fixture.bytes,
    contentType: 'application/octet-stream',
    headers: {
      'x-pack-hash': meta.pack_hash
    }
  }));
  await page.goto(force ? '/?forceWebGL=1' : '/');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  if (force) await expect(map).toHaveAttribute('data-backend', 'webgl2');
  await page.mouse.move(0, 0);
  const shot = await map.screenshot({
      path: `${evidence}/${info.project.name}-borders-${force}.png`
    }),
    image = png(shot);
  const baseline = png(readFileSync(resolve(import.meta.dirname, 'baselines/display-fixture.png')));
  expect([image.width, image.height]).toEqual([baseline.width, baseline.height]);
  let mismatches = 0;
  for (let y = 0; y < image.height; y++) for (let x = 0; x < image.width; x++) if (image.pixel(x, y).some((v, i) => Math.abs(v - baseline.pixel(x, y)[i]) > 1)) mismatches++;
  // Minor raster boundary differences may affect at most 0.5% of the canvas.
  expect(mismatches / (image.width * image.height)).toBeLessThanOrEqual(.005);
  const boundaryPixels = [];
  // Direct fixture source defines province-only x2, state-only x4, nation x6.
  for (const [x, color] of [[2, meta.style.province_border], [4, meta.style.state_border], [6, meta.style.nation_border]]) {
    const p = await mapPoint(map, x, 1);
    const c = image.pixel(p.x, p.y);
    boundaryPixels.push(c);
    closeRGB(c, color, `border x${x}`);
  }
  const widths = [];
  for (const [x, color] of [[2, meta.style.province_border], [4, meta.style.state_border], [6, meta.style.nation_border]]) {
    const p = await mapPoint(map, x, 1);
    let count = 0;
    for (let dx = -6; dx <= 6; dx++) if (image.pixel(p.x + dx, p.y).every((v, i) => Math.abs(v - color[i]) <= 1)) count++;
    widths.push(count);
  }
  expect(widths[0]).toBeGreaterThan(0);
  expect(widths[1]).toBeGreaterThan(widths[0]);
  expect(widths[2]).toBeGreaterThan(widths[1]);
  // Real ID0 selection is distinct from null, shader highlight and hover change pixels.
  const p0 = await mapPoint(map, 1, 1);
  const box = await map.boundingBox();
  await page.mouse.move(box.x + p0.x, box.y + p0.y);
  await expect(map).toHaveAttribute('data-hover', '0');
  const hoverImage = png(await map.screenshot());
  closeRGB(hoverImage.pixel(p0.x, p0.y), [122, 151, 201], 'hover');
  await map.click({
    position: p0
  });
  await expect(page.getByTestId('selected-province')).toHaveText('0');
  await page.mouse.move(0, 0);
  const selectedImage = png(await map.screenshot());
  closeRGB(selectedImage.pixel(p0.x, p0.y), [122, 142, 162], 'selection');
  await page.getByRole('button', {
    name: 'Clear selection'
  }).click();
  await expect(page.getByTestId('selected-province')).toHaveText('—');
  await map.click({
    position: await mapPoint(map, 11, 1)
  });
  await expect(page.getByTestId('selected-province')).toHaveText('65535');
  await expect(page.getByText('This province has no state or country.')).toBeVisible();
  await map.click({
    position: await mapPoint(map, 1, 5)
  });
  await expect(page.getByTestId('selected-province')).toHaveText('65534');
  await expect(page.getByTestId('map-hover')).toHaveText('Province 65534 · Ocean');
  await page.getByRole('button', {
    name: 'Clear selection'
  }).click();
  const center = await mapPoint(map, 1, 1);
  await page.mouse.move(box.x + center.x, box.y + center.y);
  await page.mouse.wheel(0, -300);
  await expect.poll(async () => JSON.parse(await map.getAttribute('data-camera')).zoom).toBeGreaterThan(1);
  await map.click({
    position: await mapPoint(map, 1, 1)
  });
  await expect(page.getByTestId('selected-province')).toHaveText('0');
  const before = JSON.parse(await map.getAttribute('data-camera'));
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width - 5, box.y + box.height / 2, {
    steps: 8
  });
  await page.mouse.up();
  const after = JSON.parse(await map.getAttribute('data-camera'));
  expect(after.x).toBeLessThan(before.x);
  await map.click({
    position: {
      x: 2,
      y: 2
    }
  });
  await expect(page.getByTestId('selected-province')).toHaveText('—');
  await page.getByRole('button', {
    name: 'Reset view'
  }).click();
  const reset = JSON.parse(await map.getAttribute('data-camera'));
  expect(reset).toMatchObject({
    x: 6,
    y: 3,
    zoom: 1
  });
  await page.mouse.move(0, 0);
  const resetImage = png(await map.screenshot());
  for (const [x, color] of [[2, meta.style.province_border], [4, meta.style.state_border], [6, meta.style.nation_border]]) {
    const p = await mapPoint(map, x, 1);
    closeRGB(resetImage.pixel(p.x, p.y), color);
  }
  writeFileSync(`${evidence}/${info.project.name}-fixture-${force}.json`, JSON.stringify({
    boundaryPixels,
    widths,
    mismatches,
    baselinePixels: image.width * image.height,
    before,
    after,
    reset,
    diagnostics: await map.evaluate(el => ({
      ...el.dataset
    })),
    oracle: 'independent 12x6 displayFixture.ts plus reviewed new screenshot baseline; no shipped golden changed'
  }, null, 2));
});
for (const failure of ['missingGPU', 'nullAdapter', 'adapterReject', 'deviceReject', 'insecure']) test(`REQ-PLAT-03 ${failure} falls back to actual WebGL2 pixels`, async ({
  page
}, info) => {
  await page.addInitScript(kind => {
    if (kind === 'insecure') Object.defineProperty(window, 'isSecureContext', {
      value: false
    });
    if (kind === 'missingGPU') Object.defineProperty(navigator, 'gpu', {
      value: undefined
    });
    if (kind === 'nullAdapter') Object.defineProperty(navigator, 'gpu', {
      value: {
        requestAdapter: async () => null
      }
    });
    if (kind === 'adapterReject') Object.defineProperty(navigator, 'gpu', {
      value: {
        requestAdapter: async () => {
          throw new Error('test adapter rejection');
        }
      }
    });
    if (kind === 'deviceReject') Object.defineProperty(navigator, 'gpu', {
      value: {
        requestAdapter: async () => ({
          features: new Set(),
          requestDevice: async () => {
            throw new Error('test device rejection');
          }
        })
      }
    });
  }, failure);
  await page.goto('/');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-backend', 'webgl2');
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  await page.mouse.move(0, 0);
  const p = await mapPoint(map, 1, 1);
  closeRGB(png(await map.screenshot({
    path: `${evidence}/${info.project.name}-${failure}.png`
  })).pixel(p.x, p.y), [40, 100, 180]);
});
for (const preferred of [false, true]) test(`REQ-PLAT-03 no backend shows localized notices${preferred ? ' after preferred rejection' : ''}`, async ({
  page
}, info) => {
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.addInitScript(prefer => {
    Object.defineProperty(navigator, 'gpu', {
      value: prefer ? {
        requestAdapter: async () => null
      } : undefined
    });
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, ...args) {
      if (type === 'webgl2') return null;
      return Reflect.apply(original, this, [type, ...args]);
    };
  }, preferred);
  await page.goto('/');
  await expect(page.getByRole('alert')).toContainText('could not initialize WebGPU or WebGL2');
  await expect(page.getByTestId('province-map').locator('canvas')).toHaveCount(0);
  await page.getByRole('combobox').selectOption('ko');
  await expect(page.getByRole('alert')).toContainText('초기화할 수 없습니다');
  await page.getByTestId('pause').click();
  await expect(page.getByTestId('pause')).toHaveText('재개');
  const tick = await page.getByTestId('tick').textContent();
  await expect(page.getByTestId('country-panel')).toContainText('북부 시험국');
  await expect(page.getByTestId('state-panel').locator('.ledger-value strong')).toHaveText('1');
  await page.getByRole('combobox').selectOption('en');
  await expect(page.getByRole('alert')).toContainText('could not initialize WebGPU or WebGL2');
  await expect(page.getByTestId('tick')).toHaveText(tick);
  await expect(page.getByTestId('country-panel')).toContainText('Northern Test Nation');
  expect(errors).toEqual([]);
  writeFileSync(`${evidence}/${info.project.name}-no-backend-${preferred ? 'preferred' : 'direct'}.json`, JSON.stringify({
    preferred,
    errors,
    tick,
    canvas: 0,
    authorityPreserved: true
  }, null, 2));
});
test('REQ-PLAT-03 actual WebGL2 texture limit is checked before texture creation', async ({
  page
}) => {
  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'gpu', {
      value: undefined
    });
    const original = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function (parameter) {
      return parameter === this.MAX_TEXTURE_SIZE ? 128 : original.call(this, parameter);
    };
  });
  await page.goto('/');
  await expect(page.getByRole('alert')).toContainText('could not initialize WebGPU or WebGL2');
  await expect(page.getByTestId('province-map').locator('canvas')).toHaveCount(0);
});
test('REQ-MAP-04 missing bundled index fails visibly without external download', async ({
  page,
  request
}) => {
  const requests = [];
  page.on('request', r => requests.push(r.url()));
  await page.route('**/maps/testland/index.bin?*', r => r.fulfill({
    status: 404
  }));
  await page.goto('/');
  await expect(page.getByRole('alert')).toContainText('Map data could not be loaded');
  expect(requests.every(u => new URL(u).host === new URL(page.url()).host)).toBe(true);
  expect((await request.get('/maps/missing/metadata')).status()).toBe(404);
  expect((await request.get('/maps/testland/index.bin?pack=wrong')).status()).toBe(409);
  expect((await request.get('/maps/testland/index.bin')).status()).toBe(409);
});
for (const invalid of ['oldVersion', 'futureVersion', 'wrongPack', 'duplicateIds', 'badStyle', 'shortBytes', 'wrongHash']) test(`REQ-MAP-04 schema boundary ${invalid} rejects atomically`, async ({
  page,
  request
}) => {
  const meta = await (await request.get('/maps/testland/metadata')).json();
  const bytes = await (await request.get(`/maps/testland/index.bin?pack=${meta.pack_hash}`)).body();
  if (invalid === 'oldVersion') delete meta.schema_version;
  if (invalid === 'futureVersion') meta.schema_version = 65535;
  if (invalid === 'wrongPack') meta.pack_hash = '0000000000000000';
  if (invalid === 'duplicateIds') meta.province_ids[1] = meta.province_ids[0];
  if (invalid === 'badStyle') meta.style.fit_milli = 0;
  if (invalid === 'wrongHash') meta.index_hash = '0000000000000000';
  await page.route('**/maps/testland/metadata', r => r.fulfill({
    json: meta
  }));
  if (invalid === 'shortBytes') await page.route('**/maps/testland/index.bin?*', r => r.fulfill({
    body: bytes.subarray(0, bytes.length - 1),
    headers: {
      'x-pack-hash': meta.pack_hash
    }
  }));
  await page.goto('/');
  await expect(page.getByRole('alert')).toContainText('Map data could not be loaded');
  await expect(page.getByTestId('province-map').locator('canvas')).toHaveCount(0);
  await expect(page.getByTestId('country-panel')).toContainText('Northern Test Nation');
});
for (const invalid of ['dangling', 'changedDimensions', 'changedDense']) test(`REQ-MAP-05 ${invalid} preserves last valid map and closes wire`, async ({
  page
}) => {
  let count = 0;
  await page.routeWebSocket('**/ws', route => {
    const server = route.connectToServer();
    server.onMessage(data => {
      const m = decode(data);
      if (m.type === 'WorldResult' && m.world && ++count >= 3) {
        if (invalid === 'dangling') m.world.provinces[0].owner = 65535;
        if (invalid === 'changedDimensions') m.world.width++;
        if (invalid === 'changedDense') m.world.province_ids.reverse();
        route.send(Buffer.from(encode(m)));
      } else route.send(data);
    });
  });
  await page.goto('/');
  const map = page.getByTestId('province-map');
  await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
  await expect(page.getByTestId('connection')).toHaveText('Disconnected');
  await expect(page.getByRole('alert')).toHaveText('Invalid server message; connection closed');
  await expect(page.getByTestId('pause')).toBeDisabled();
  await page.mouse.move(0, 0);
  const point = await mapPoint(map, 1, 1);
  closeRGB(png(await map.screenshot()).pixel(point.x, point.y), [40, 100, 180]);
  await expect(page.getByTestId('country-panel')).toContainText('Northern Test Nation');
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwibWtkaXJTeW5jIiwid3JpdGVGaWxlU3luYyIsInJlYWRGaWxlU3luYyIsInJlc29sdmUiLCJwbmciLCJlbmNvZGUiLCJkZWNvZGUiLCJkaXNwbGF5Rml4dHVyZSIsIndpZGVEaXNwbGF5Rml4dHVyZSIsImV2aWRlbmNlIiwiX3Byb2Nlc3MkZW52JE9IX01BUF9FIiwicHJvY2VzcyIsImVudiIsIk9IX01BUF9FVklERU5DRSIsInJlY3Vyc2l2ZSIsIm1hcFBvaW50IiwibWFwIiwieCIsInkiLCJib3giLCJib3VuZGluZ0JveCIsImMiLCJKU09OIiwicGFyc2UiLCJnZXRBdHRyaWJ1dGUiLCJ3aWR0aCIsImhlaWdodCIsImNsb3NlUkdCIiwiYWN0dWFsIiwiZXhwZWN0ZWQiLCJsYWJlbCIsImkiLCJNYXRoIiwiYWJzIiwidG9CZUxlc3NUaGFuT3JFcXVhbCIsInBhZ2UiLCJicm93c2VyIiwiaW5mbyIsInJlcXVlc3RzIiwib24iLCJyIiwicHVzaCIsInVybCIsIndzIiwiZXJyb3JzIiwiZSIsIm1lc3NhZ2UiLCJnb3RvIiwiZ2V0QnlUZXN0SWQiLCJ0b0hhdmVBdHRyaWJ1dGUiLCJnZXRCeVJvbGUiLCJuYW1lIiwiZXhhY3QiLCJ0b0JlSW5WaWV3cG9ydCIsImNsaWNrIiwidG9IYXZlVGV4dCIsIm5vdCIsInRvQmVOdWxsIiwiY2FtZXJhIiwiYXQiLCJjb2xvciIsIm1vdXNlIiwibW92ZSIsIndhaXRGb3JUaW1lb3V0Iiwic2hvdCIsInNjcmVlbnNob3QiLCJwYXRoIiwicHJvamVjdCIsInAiLCJwaXhlbCIsInBvc2l0aW9uIiwibG9jYXRvciIsImdldEJ5VGV4dCIsInRvQ29udGFpblRleHQiLCJzZWxlY3RPcHRpb24iLCJ0b0VxdWFsIiwiZXZlcnkiLCJ1IiwiVVJMIiwiaG9zdCIsInRvQmUiLCJzdHJpbmdpZnkiLCJ2ZXJzaW9uIiwiZGlhZ25vc3RpY3MiLCJldmFsdWF0ZSIsImVsIiwiZGF0YXNldCIsInZpZXdwb3J0Iiwic2NlbmFyaW8iLCJzZWVkIiwic2hhZGVyTGFuZ3VhZ2UiLCJiYWNrZW5kIiwiTnVtYmVyIiwic2hhZGVyTGVuZ3RoIiwidG9CZUdyZWF0ZXJUaGFuIiwicG9pbnQiLCJwb2xsIiwicGVyZm9ybWFuY2VTY29wZSIsImluamVjdCIsInJvdXRlV2ViU29ja2V0Iiwicm91dGUiLCJzZXJ2ZXIiLCJjb25uZWN0VG9TZXJ2ZXIiLCJvbk1lc3NhZ2UiLCJkYXRhIiwibSIsInR5cGUiLCJ3b3JsZCIsInJlcXVlc3QiLCJwcm92aW5jZXMiLCJvd25lcl9jb2xvciIsInNlbmQiLCJCdWZmZXIiLCJmcm9tIiwidW50b3VjaGVkIiwibWV0YSIsImdldCIsImpzb24iLCJmaXh0dXJlIiwiZnVsZmlsbCIsImJvZHkiLCJieXRlcyIsImhlYWRlcnMiLCJwYWNrX2hhc2giLCJmb3JjZSIsImNvbnRlbnRUeXBlIiwiaW1hZ2UiLCJiYXNlbGluZSIsImltcG9ydCIsImRpcm5hbWUiLCJtaXNtYXRjaGVzIiwic29tZSIsInYiLCJib3VuZGFyeVBpeGVscyIsInN0eWxlIiwicHJvdmluY2VfYm9yZGVyIiwic3RhdGVfYm9yZGVyIiwibmF0aW9uX2JvcmRlciIsIndpZHRocyIsImNvdW50IiwiZHgiLCJwMCIsImhvdmVySW1hZ2UiLCJzZWxlY3RlZEltYWdlIiwidG9CZVZpc2libGUiLCJjZW50ZXIiLCJ3aGVlbCIsInpvb20iLCJiZWZvcmUiLCJkb3duIiwic3RlcHMiLCJ1cCIsImFmdGVyIiwidG9CZUxlc3NUaGFuIiwicmVzZXQiLCJ0b01hdGNoT2JqZWN0IiwicmVzZXRJbWFnZSIsImJhc2VsaW5lUGl4ZWxzIiwib3JhY2xlIiwiZmFpbHVyZSIsImFkZEluaXRTY3JpcHQiLCJraW5kIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJ3aW5kb3ciLCJ2YWx1ZSIsIm5hdmlnYXRvciIsInVuZGVmaW5lZCIsInJlcXVlc3RBZGFwdGVyIiwiRXJyb3IiLCJmZWF0dXJlcyIsIlNldCIsInJlcXVlc3REZXZpY2UiLCJwcmVmZXJyZWQiLCJwcmVmZXIiLCJvcmlnaW5hbCIsIkhUTUxDYW52YXNFbGVtZW50IiwicHJvdG90eXBlIiwiZ2V0Q29udGV4dCIsImFyZ3MiLCJSZWZsZWN0IiwiYXBwbHkiLCJ0b0hhdmVDb3VudCIsInRpY2siLCJ0ZXh0Q29udGVudCIsImNhbnZhcyIsImF1dGhvcml0eVByZXNlcnZlZCIsIldlYkdMMlJlbmRlcmluZ0NvbnRleHQiLCJnZXRQYXJhbWV0ZXIiLCJwYXJhbWV0ZXIiLCJNQVhfVEVYVFVSRV9TSVpFIiwiY2FsbCIsInN0YXR1cyIsImludmFsaWQiLCJzY2hlbWFfdmVyc2lvbiIsInByb3ZpbmNlX2lkcyIsImZpdF9taWxsaSIsImluZGV4X2hhc2giLCJzdWJhcnJheSIsImxlbmd0aCIsIm93bmVyIiwicmV2ZXJzZSIsInRvQmVEaXNhYmxlZCJdLCJzb3VyY2VzIjpbIm1hcC5zcGVjLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGV4cGVjdCx0ZXN0LHR5cGUgTG9jYXRvciB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuaW1wb3J0IHsgbWtkaXJTeW5jLHdyaXRlRmlsZVN5bmMscmVhZEZpbGVTeW5jIH0gZnJvbSAnbm9kZTpmcyc7XG5pbXBvcnQgeyByZXNvbHZlIH0gZnJvbSAnbm9kZTpwYXRoJztcbmltcG9ydCB7IHBuZyB9IGZyb20gJy4vcG5nJztcbmltcG9ydCB7IGVuY29kZSxkZWNvZGUgfSBmcm9tICdAbXNncGFjay9tc2dwYWNrJztcbmltcG9ydCB0eXBlIHsgU2VydmVyTWVzc2FnZSxNYXBNZXRhZGF0YSB9IGZyb20gJy4uL3NyYy9wcm90by9wcm90b2NvbCc7XG5pbXBvcnQgeyBkaXNwbGF5Rml4dHVyZSx3aWRlRGlzcGxheUZpeHR1cmUgfSBmcm9tICcuL2Rpc3BsYXlGaXh0dXJlJztcbmNvbnN0IGV2aWRlbmNlPXByb2Nlc3MuZW52Lk9IX01BUF9FVklERU5DRT8/Jy4uL3RhcmdldC93cDA4L2UyZSc7bWtkaXJTeW5jKGV2aWRlbmNlLHtyZWN1cnNpdmU6dHJ1ZX0pO1xuYXN5bmMgZnVuY3Rpb24gbWFwUG9pbnQobWFwOkxvY2F0b3IseDpudW1iZXIseTpudW1iZXIpe2NvbnN0IGJveD0oYXdhaXQgbWFwLmJvdW5kaW5nQm94KCkpITtjb25zdCBjPUpTT04ucGFyc2UoKGF3YWl0IG1hcC5nZXRBdHRyaWJ1dGUoJ2RhdGEtY2FtZXJhJykpISk7cmV0dXJuIHt4Oih4LWMueCkvYy53aWR0aCpib3gud2lkdGgrYm94LndpZHRoLzIseTooeS1jLnkpL2MuaGVpZ2h0KmJveC5oZWlnaHQrYm94LmhlaWdodC8yfTt9XG5mdW5jdGlvbiBjbG9zZVJHQihhY3R1YWw6bnVtYmVyW10sZXhwZWN0ZWQ6cmVhZG9ubHkgbnVtYmVyW10sbGFiZWw9J3BpeGVsJyl7Zm9yKGxldCBpPTA7aTwzO2krKylleHBlY3QoTWF0aC5hYnMoYWN0dWFsW2ldLWV4cGVjdGVkW2ldKSxgJHtsYWJlbH06ICR7YWN0dWFsfSBleHBlY3RlZCAke2V4cGVjdGVkfWApLnRvQmVMZXNzVGhhbk9yRXF1YWwoMSk7fVxudGVzdCgnUkVRLU1BUC0wNC8wNSBQTEFULTAzIGFjdHVhbCBtYXAgcGl4ZWxzLCBtb2RlcywgcGljayBhbmQgdmlld3BvcnQnLGFzeW5jKHtwYWdlLGJyb3dzZXJ9LGluZm8pPT57XG4gY29uc3QgcmVxdWVzdHM6c3RyaW5nW109W107cGFnZS5vbigncmVxdWVzdCcscj0+cmVxdWVzdHMucHVzaChyLnVybCgpKSk7cGFnZS5vbignd2Vic29ja2V0Jyx3cz0+cmVxdWVzdHMucHVzaCh3cy51cmwoKSkpO2NvbnN0IGVycm9yczpzdHJpbmdbXT1bXTtwYWdlLm9uKCdwYWdlZXJyb3InLGU9PmVycm9ycy5wdXNoKGUubWVzc2FnZSkpO1xuIGF3YWl0IHBhZ2UuZ290bygnLz9mb3JjZVdlYkdMPTEnKTtcbiBjb25zdCBtYXA9cGFnZS5nZXRCeVRlc3RJZCgncHJvdmluY2UtbWFwJyk7XG4gYXdhaXQgZXhwZWN0KG1hcCkudG9IYXZlQXR0cmlidXRlKCdkYXRhLWJhY2tlbmQnLCd3ZWJnbDInKTtcbiBhd2FpdCBleHBlY3QobWFwKS50b0hhdmVBdHRyaWJ1dGUoJ2RhdGEtZnJhbWVzJywvXlsxLTldXFxkKiQvKTtcbiBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J1RlcnJhaW4nLGV4YWN0OnRydWV9KSkudG9CZUluVmlld3BvcnQoKTtcbiBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgncGF1c2UnKSkudG9CZUluVmlld3BvcnQoKTtcbiBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdwYXVzZScpLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3BhdXNlJykpLnRvSGF2ZVRleHQoJ1Jlc3VtZScpO1xuIGNvbnN0IGJveD1hd2FpdCBtYXAuYm91bmRpbmdCb3goKTtleHBlY3QoYm94KS5ub3QudG9CZU51bGwoKTtcbiBjb25zdCBjYW1lcmE9SlNPTi5wYXJzZSgoYXdhaXQgbWFwLmdldEF0dHJpYnV0ZSgnZGF0YS1jYW1lcmEnKSkhKTtcbiBjb25zdCBhdD0oeDpudW1iZXIseTpudW1iZXIpPT4oe3g6KHgtY2FtZXJhLngpL2NhbWVyYS53aWR0aCpib3ghLndpZHRoK2JveCEud2lkdGgvMix5Oih5LWNhbWVyYS55KS9jYW1lcmEuaGVpZ2h0KmJveCEuaGVpZ2h0K2JveCEuaGVpZ2h0LzJ9KTtcbiBmb3IoY29uc3QgW25hbWUsY29sb3JdIG9mIFtbJ093bmVyc2hpcCcsWzQwLDEwMCwxODBdXSxbJ1RlcnJhaW4nLFsxMzAsMTY1LDk1XV0sWydTdGF0ZXMnLFsxNDAsOTUsMTcwXV1dIGFzIGNvbnN0KXtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWUsZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgcGFnZS5tb3VzZS5tb3ZlKDAsMCk7YXdhaXQgcGFnZS53YWl0Rm9yVGltZW91dCg4MCk7XG4gIGNvbnN0IHNob3Q9YXdhaXQgbWFwLnNjcmVlbnNob3Qoe3BhdGg6YCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LSR7bmFtZX0ucG5nYH0pO2NvbnN0IHA9YXQoMSwxKTtjb25zdCBhY3R1YWw9cG5nKHNob3QpLnBpeGVsKHAueCxwLnkpO2ZvcihsZXQgaT0wO2k8MztpKyspZXhwZWN0KE1hdGguYWJzKGFjdHVhbFtpXS1jb2xvcltpXSksYCR7bmFtZX0gcGl4ZWwgJHthY3R1YWx9YCkudG9CZUxlc3NUaGFuT3JFcXVhbCgxKTtcbiB9XG4gYXdhaXQgbWFwLmNsaWNrKHtwb3NpdGlvbjphdCgxLDEpfSk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3NlbGVjdGVkLXByb3ZpbmNlJykpLnRvSGF2ZVRleHQoJzEwJyk7XG4gYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ21hcC1ob3ZlcicpKS50b0hhdmVUZXh0KCdQcm92aW5jZSAxMCDCtyBQbGFpbnMnKTtcbiBhd2FpdCBtYXAuY2xpY2soe3Bvc2l0aW9uOmF0KDEsMyl9KTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc2VsZWN0ZWQtcHJvdmluY2UnKSkudG9IYXZlVGV4dCgnMzAnKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnbWFwLWhvdmVyJykpLnRvSGF2ZVRleHQoJ1Byb3ZpbmNlIDMwIMK3IFBsYWlucycpO1xuIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjb3VudHJ5LXBhbmVsJykubG9jYXRvcignaDMnKSkudG9IYXZlVGV4dCgnU291dGhlcm4gVGVzdCBOYXRpb24nKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5sb2NhdG9yKCdoMycpKS50b0hhdmVUZXh0KCdTb3V0aGVybiBUZXN0IFN0YXRlJyk7XG4gYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5nZXRCeVRleHQoJ0luZnJhc3RydWN0dXJlJyx7ZXhhY3Q6dHJ1ZX0pLmNsaWNrKCk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykubG9jYXRvcignLmxlZGdlci10b29sdGlwJykpLnRvQ29udGFpblRleHQoJ1ZhbHVlIGxlZGdlcicpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzdGF0ZS1wYW5lbCcpLmxvY2F0b3IoJy5sZWRnZXItdmFsdWUgc3Ryb25nJykpLnRvSGF2ZVRleHQoJzAnKTtcbiBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5sb2NhdG9yKCcubGVkZ2VyLXRvb2x0aXAnKSkudG9CZUluVmlld3BvcnQoKTthd2FpdCBleHBlY3QobWFwKS50b0JlSW5WaWV3cG9ydCgpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdjb21ib2JveCcpLnNlbGVjdE9wdGlvbigna28nKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnbWFwLWhvdmVyJykpLnRvSGF2ZVRleHQoJ+2UhOuhnOu5iOyKpCAzMCDCtyDtj4nslbwnKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5sb2NhdG9yKCdoMycpKS50b0hhdmVUZXh0KCfrgqjrtoAg7Iuc7ZeY7KO8Jyk7XG4gYXdhaXQgbWFwLmNsaWNrKHtwb3NpdGlvbjphdCgxLDEpfSk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3NlbGVjdGVkLXByb3ZpbmNlJykpLnRvSGF2ZVRleHQoJzEwJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ21hcC1ob3ZlcicpKS50b0hhdmVUZXh0KCftlITroZzruYjsiqQgMTAgwrcg7Y+J7JW8Jyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NvdW50cnktcGFuZWwnKS5sb2NhdG9yKCdoMycpKS50b0hhdmVUZXh0KCfrtoHrtoAg7Iuc7ZeY6rWtJyk7XG4gYXdhaXQgcGFnZS5zY3JlZW5zaG90KHtwYXRoOmAke2V2aWRlbmNlfS8ke2luZm8ucHJvamVjdC5uYW1lfS1maXJzdC1tYXAucG5nYH0pO1xuIGV4cGVjdChlcnJvcnMpLnRvRXF1YWwoW10pO2V4cGVjdChyZXF1ZXN0cy5ldmVyeSh1PT5uZXcgVVJMKHUpLmhvc3Q9PT1uZXcgVVJMKHBhZ2UudXJsKCkpLmhvc3QpKS50b0JlKHRydWUpO1xuIHdyaXRlRmlsZVN5bmMoYCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LW1hcC5qc29uYCxKU09OLnN0cmluZ2lmeSh7YnJvd3Nlcjpicm93c2VyLnZlcnNpb24oKSxyZXF1ZXN0cyxlcnJvcnMsZGlhZ25vc3RpY3M6YXdhaXQgbWFwLmV2YWx1YXRlKGVsPT4oey4uLiAoZWwgYXMgSFRNTEVsZW1lbnQpLmRhdGFzZXR9KSksdmlld3BvcnQ6e3dpZHRoOjEyODAsaGVpZ2h0OjcyMH0sc2NlbmFyaW86J20xJyxzZWVkOicxJ30sbnVsbCwyKSk7XG59KTtcblxudGVzdCgnUkVRLVBMQVQtMDMgcHJlZmVycmVkIGFjdHVhbCBiYWNrZW5kIHByb2R1Y2VzIHRoZSBzYW1lIG1hcCBSR0IgYW5kIHNvdXJjZSBzaGFkZXInLGFzeW5jKHtwYWdlLGJyb3dzZXJ9LGluZm8pPT57XG4gYXdhaXQgcGFnZS5nb3RvKCcvJyk7Y29uc3QgbWFwPXBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpO2F3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1iYWNrZW5kJywvd2ViZ3B1fHdlYmdsMi8pO2F3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1mcmFtZXMnLC9eWzEtOV1cXGQqJC8pO1xuIGF3YWl0IHBhZ2UubW91c2UubW92ZSgwLDApO2NvbnN0IHNob3Q9YXdhaXQgbWFwLnNjcmVlbnNob3Qoe3BhdGg6YCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LXByZWZlcnJlZC5wbmdgfSk7Y29uc3QgcD1hd2FpdCBtYXBQb2ludChtYXAsMSwxKTtjbG9zZVJHQihwbmcoc2hvdCkucGl4ZWwocC54LHAueSksWzQwLDEwMCwxODBdKTtcbiBjb25zdCBkaWFnbm9zdGljcz1hd2FpdCBtYXAuZXZhbHVhdGUoZWw9Pih7Li4uIChlbCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldH0pKTtleHBlY3QoZGlhZ25vc3RpY3Muc2hhZGVyTGFuZ3VhZ2UpLnRvQmUoZGlhZ25vc3RpY3MuYmFja2VuZD09PSd3ZWJncHUnPyd3Z3NsJzonZ2xzbCcpO2V4cGVjdChOdW1iZXIoZGlhZ25vc3RpY3Muc2hhZGVyTGVuZ3RoKSkudG9CZUdyZWF0ZXJUaGFuKDApO1xuIGZvcihjb25zdCBbbmFtZSx4LGNvbG9yXSBvZiBbWydDb250cm9sJywzLFsxODAsNzAsNDBdXSxbJ1RlcnJhaW4nLDEsWzEzMCwxNjUsOTVdXSxbJ1N0YXRlcycsMSxbMTQwLDk1LDE3MF1dLFsnT3duZXJzaGlwJywxLFs0MCwxMDAsMTgwXV1dIGFzIGNvbnN0KXthd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZSxleGFjdDp0cnVlfSkuY2xpY2soKTthd2FpdCBwYWdlLm1vdXNlLm1vdmUoMCwwKTthd2FpdCBwYWdlLndhaXRGb3JUaW1lb3V0KDYwKTtjb25zdCBwb2ludD1hd2FpdCBtYXBQb2ludChtYXAseCwxKTtjbG9zZVJHQihwbmcoYXdhaXQgbWFwLnNjcmVlbnNob3Qoe3BhdGg6YCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LXByZWZlcnJlZC0ke25hbWV9LnBuZ2B9KSkucGl4ZWwocG9pbnQueCxwb2ludC55KSxjb2xvcixuYW1lKTt9XG4gYXdhaXQgZXhwZWN0LnBvbGwoYXN5bmMoKT0+TnVtYmVyKGF3YWl0IG1hcC5nZXRBdHRyaWJ1dGUoJ2RhdGEtZnJhbWVzJykpKS50b0JlR3JlYXRlclRoYW4oNjApO1xuIHdyaXRlRmlsZVN5bmMoYCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LXByZWZlcnJlZC5qc29uYCxKU09OLnN0cmluZ2lmeSh7YnJvd3Nlcjpicm93c2VyLnZlcnNpb24oKSxkaWFnbm9zdGljczphd2FpdCBtYXAuZXZhbHVhdGUoZWw9Pih7Li4uIChlbCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldH0pKSxwZXJmb3JtYW5jZVNjb3BlOid0aW55IHN5bnRoZXRpYyBtYXA7IHJlbmRlcmVyIGZyYW1lIGludGVydmFsLCBub3QgZ2xvYmFsIGhhcmR3YXJlIGJlbmNobWFyayd9LG51bGwsMikpO1xufSk7XG50ZXN0KCdSRVEtTUFQLTA0IGNoYW5nZWQgc2VydmVyIFJHQiB1cGRhdGVzIG9ubHkgYWZmZWN0ZWQgbG9va3VwIHRleGVsIG9uIGFjdHVhbCBiYWNrZW5kJyxhc3luYyh7cGFnZX0saW5mbyk9PntcbiBsZXQgaW5qZWN0PWZhbHNlO2F3YWl0IHBhZ2Uucm91dGVXZWJTb2NrZXQoJyoqL3dzJyxyb3V0ZT0+e2NvbnN0IHNlcnZlcj1yb3V0ZS5jb25uZWN0VG9TZXJ2ZXIoKTtzZXJ2ZXIub25NZXNzYWdlKGRhdGE9Pntjb25zdCBtPWRlY29kZShkYXRhIGFzIEJ1ZmZlcikgYXMgU2VydmVyTWVzc2FnZTtpZihpbmplY3QmJm0udHlwZT09PSdXb3JsZFJlc3VsdCcmJm0ud29ybGQmJm0ucmVxdWVzdD09PSd3b3JsZCcpe20ud29ybGQucHJvdmluY2VzWzBdLm93bmVyX2NvbG9yPVsxOCw0NCwxMTBdO3JvdXRlLnNlbmQoQnVmZmVyLmZyb20oZW5jb2RlKG0pKSk7fWVsc2Ugcm91dGUuc2VuZChkYXRhKTt9KTt9KTtcbiBhd2FpdCBwYWdlLmdvdG8oJy8nKTtjb25zdCBtYXA9cGFnZS5nZXRCeVRlc3RJZCgncHJvdmluY2UtbWFwJyk7YXdhaXQgZXhwZWN0KG1hcCkudG9IYXZlQXR0cmlidXRlKCdkYXRhLWZyYW1lcycsL15bMS05XVxcZCokLyk7aW5qZWN0PXRydWU7YXdhaXQgZXhwZWN0KG1hcCkudG9IYXZlQXR0cmlidXRlKCdkYXRhLWxhc3QtY2hhbmdlZC1ieXRlcycsJzQnKTthd2FpdCBwYWdlLm1vdXNlLm1vdmUoMCwwKTtjb25zdCBwb2ludD1hd2FpdCBtYXBQb2ludChtYXAsMSwxKTtjbG9zZVJHQihwbmcoYXdhaXQgbWFwLnNjcmVlbnNob3QoKSkucGl4ZWwocG9pbnQueCxwb2ludC55KSxbMTgsNDQsMTEwXSk7Y29uc3QgdW50b3VjaGVkPWF3YWl0IG1hcFBvaW50KG1hcCwzLDEpO2Nsb3NlUkdCKHBuZyhhd2FpdCBtYXAuc2NyZWVuc2hvdCgpKS5waXhlbCh1bnRvdWNoZWQueCx1bnRvdWNoZWQueSksWzQwLDEwMCwxODBdKTt3cml0ZUZpbGVTeW5jKGAke2V2aWRlbmNlfS8ke2luZm8ucHJvamVjdC5uYW1lfS1wYXJ0aWFsLXVwZGF0ZS5qc29uYCxKU09OLnN0cmluZ2lmeShhd2FpdCBtYXAuZXZhbHVhdGUoZWw9Pih7Li4uIChlbCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldH0pKSxudWxsLDIpKTtcbn0pO1xudGVzdCgnUkVRLU1BUC0wNC8wNSBSRzggaGlnaCBkZW5zZSBieXRlIGFuZCBMVVQgc2Vjb25kIHJvdyBwaWNrIHJlYWwgSUQ2NTUzNScsYXN5bmMoe3BhZ2UscmVxdWVzdH0saW5mbyk9PntcbiBjb25zdCBtZXRhPWF3YWl0IChhd2FpdCByZXF1ZXN0LmdldCgnL21hcHMvdGVzdGxhbmQvbWV0YWRhdGEnKSkuanNvbigpIGFzIE1hcE1ldGFkYXRhO2xldCBmaXh0dXJlOlJldHVyblR5cGU8dHlwZW9mIHdpZGVEaXNwbGF5Rml4dHVyZT58dW5kZWZpbmVkO1xuIGF3YWl0IHBhZ2Uucm91dGVXZWJTb2NrZXQoJyoqL3dzJyxyb3V0ZT0+e2NvbnN0IHNlcnZlcj1yb3V0ZS5jb25uZWN0VG9TZXJ2ZXIoKTtzZXJ2ZXIub25NZXNzYWdlKGRhdGE9Pntjb25zdCBtPWRlY29kZShkYXRhIGFzIEJ1ZmZlcikgYXMgU2VydmVyTWVzc2FnZTtpZihtLnR5cGU9PT0nV29ybGRSZXN1bHQnJiZtLndvcmxkJiZtLnJlcXVlc3Q9PT0nd29ybGQnKXtmaXh0dXJlPXdpZGVEaXNwbGF5Rml4dHVyZShtLndvcmxkLG1ldGEpO20ud29ybGQ9Zml4dHVyZS53b3JsZDtyb3V0ZS5zZW5kKEJ1ZmZlci5mcm9tKGVuY29kZShtKSkpO31lbHNlIHJvdXRlLnNlbmQoZGF0YSk7fSk7fSk7XG4gYXdhaXQgcGFnZS5yb3V0ZSgnKiovbWFwcy9kaXNwbGF5X2ZpeHR1cmUvbWV0YWRhdGEnLHI9PnIuZnVsZmlsbCh7anNvbjpmaXh0dXJlIS5tZXRhfSkpO2F3YWl0IHBhZ2Uucm91dGUoJyoqL21hcHMvZGlzcGxheV9maXh0dXJlL2luZGV4LmJpbj8qJyxyPT5yLmZ1bGZpbGwoe2JvZHk6Zml4dHVyZSEuYnl0ZXMsaGVhZGVyczp7J3gtcGFjay1oYXNoJzptZXRhLnBhY2tfaGFzaH19KSk7XG4gYXdhaXQgcGFnZS5nb3RvKCcvJyk7Y29uc3QgbWFwPXBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpO2F3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1mcmFtZXMnLC9eWzEtOV1cXGQqJC8pO2F3YWl0IHBhZ2UubW91c2UubW92ZSgwLDApO2NvbnN0IHA9YXdhaXQgbWFwUG9pbnQobWFwLDI1Ni41LDMpO2Nsb3NlUkdCKHBuZyhhd2FpdCBtYXAuc2NyZWVuc2hvdCh7cGF0aDpgJHtldmlkZW5jZX0vJHtpbmZvLnByb2plY3QubmFtZX0tZGVuc2UyNTYucG5nYH0pKS5waXhlbChwLngscC55KSxbMTcsMTIzLDIzMV0pO2F3YWl0IG1hcC5jbGljayh7cG9zaXRpb246cH0pO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpKS50b0hhdmVUZXh0KCc2NTUzNScpO3dyaXRlRmlsZVN5bmMoYCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LWRlbnNlMjU2Lmpzb25gLEpTT04uc3RyaW5naWZ5KGF3YWl0IG1hcC5ldmFsdWF0ZShlbD0+KHsuLi4gKGVsIGFzIEhUTUxFbGVtZW50KS5kYXRhc2V0fSkpLG51bGwsMikpO1xufSk7XG5cbmZvcihjb25zdCBmb3JjZSBvZiBbZmFsc2UsdHJ1ZV0pdGVzdChgUkVRLU1BUC0wNSBpbmRlcGVuZGVudCB0aHJlZSBib3JkZXIgcGl4ZWwgb3JhY2xlLCB1MTYgc2VudGluZWwgYW5kIGNhbWVyYSAke2ZvcmNlPydXZWJHTDInOidwcmVmZXJyZWQnfWAsYXN5bmMoe3BhZ2UscmVxdWVzdH0saW5mbyk9PntcbiBjb25zdCBtZXRhPWF3YWl0IChhd2FpdCByZXF1ZXN0LmdldCgnL21hcHMvdGVzdGxhbmQvbWV0YWRhdGEnKSkuanNvbigpIGFzIE1hcE1ldGFkYXRhO1xuIGxldCBmaXh0dXJlOlJldHVyblR5cGU8dHlwZW9mIGRpc3BsYXlGaXh0dXJlPnx1bmRlZmluZWQ7XG4gYXdhaXQgcGFnZS5yb3V0ZVdlYlNvY2tldCgnKiovd3MnLHJvdXRlPT57Y29uc3Qgc2VydmVyPXJvdXRlLmNvbm5lY3RUb1NlcnZlcigpO3NlcnZlci5vbk1lc3NhZ2UoZGF0YT0+e2NvbnN0IG09ZGVjb2RlKGRhdGEgYXMgQnVmZmVyKSBhcyBTZXJ2ZXJNZXNzYWdlO2lmKG0udHlwZT09PSdXb3JsZFJlc3VsdCcmJm0ud29ybGQmJm0ucmVxdWVzdD09PSd3b3JsZCcpe2ZpeHR1cmU9ZGlzcGxheUZpeHR1cmUobS53b3JsZCxtZXRhKTttLndvcmxkPWZpeHR1cmUud29ybGQ7cm91dGUuc2VuZChCdWZmZXIuZnJvbShlbmNvZGUobSkpKTt9ZWxzZSByb3V0ZS5zZW5kKGRhdGEpO30pO30pO1xuIGF3YWl0IHBhZ2Uucm91dGUoJyoqL21hcHMvZGlzcGxheV9maXh0dXJlL21ldGFkYXRhJyxyb3V0ZT0+cm91dGUuZnVsZmlsbCh7anNvbjpmaXh0dXJlIS5tZXRhfSkpO1xuIGF3YWl0IHBhZ2Uucm91dGUoJyoqL21hcHMvZGlzcGxheV9maXh0dXJlL2luZGV4LmJpbj8qJyxyb3V0ZT0+cm91dGUuZnVsZmlsbCh7Ym9keTpmaXh0dXJlIS5ieXRlcyxjb250ZW50VHlwZTonYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJyxoZWFkZXJzOnsneC1wYWNrLWhhc2gnOm1ldGEucGFja19oYXNofX0pKTtcbiBhd2FpdCBwYWdlLmdvdG8oZm9yY2U/Jy8/Zm9yY2VXZWJHTD0xJzonLycpO2NvbnN0IG1hcD1wYWdlLmdldEJ5VGVzdElkKCdwcm92aW5jZS1tYXAnKTthd2FpdCBleHBlY3QobWFwKS50b0hhdmVBdHRyaWJ1dGUoJ2RhdGEtZnJhbWVzJywvXlsxLTldXFxkKiQvKTtpZihmb3JjZSlhd2FpdCBleHBlY3QobWFwKS50b0hhdmVBdHRyaWJ1dGUoJ2RhdGEtYmFja2VuZCcsJ3dlYmdsMicpO1xuIGF3YWl0IHBhZ2UubW91c2UubW92ZSgwLDApO2NvbnN0IHNob3Q9YXdhaXQgbWFwLnNjcmVlbnNob3Qoe3BhdGg6YCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LWJvcmRlcnMtJHtmb3JjZX0ucG5nYH0pLGltYWdlPXBuZyhzaG90KTtcbiBjb25zdCBiYXNlbGluZT1wbmcocmVhZEZpbGVTeW5jKHJlc29sdmUoaW1wb3J0Lm1ldGEuZGlybmFtZSwnYmFzZWxpbmVzL2Rpc3BsYXktZml4dHVyZS5wbmcnKSkpO1xuIGV4cGVjdChbaW1hZ2Uud2lkdGgsaW1hZ2UuaGVpZ2h0XSkudG9FcXVhbChbYmFzZWxpbmUud2lkdGgsYmFzZWxpbmUuaGVpZ2h0XSk7XG4gbGV0IG1pc21hdGNoZXM9MDtmb3IobGV0IHk9MDt5PGltYWdlLmhlaWdodDt5KyspZm9yKGxldCB4PTA7eDxpbWFnZS53aWR0aDt4KyspaWYoaW1hZ2UucGl4ZWwoeCx5KS5zb21lKCh2LGkpPT5NYXRoLmFicyh2LWJhc2VsaW5lLnBpeGVsKHgseSlbaV0pPjEpKW1pc21hdGNoZXMrKztcbiAvLyBNaW5vciByYXN0ZXIgYm91bmRhcnkgZGlmZmVyZW5jZXMgbWF5IGFmZmVjdCBhdCBtb3N0IDAuNSUgb2YgdGhlIGNhbnZhcy5cbiBleHBlY3QobWlzbWF0Y2hlcy8oaW1hZ2Uud2lkdGgqaW1hZ2UuaGVpZ2h0KSkudG9CZUxlc3NUaGFuT3JFcXVhbCguMDA1KTtcbiBjb25zdCBib3VuZGFyeVBpeGVsczpudW1iZXJbXVtdPVtdO1xuIC8vIERpcmVjdCBmaXh0dXJlIHNvdXJjZSBkZWZpbmVzIHByb3ZpbmNlLW9ubHkgeDIsIHN0YXRlLW9ubHkgeDQsIG5hdGlvbiB4Ni5cbiBmb3IoY29uc3QgW3gsY29sb3JdIG9mIFtbMixtZXRhLnN0eWxlLnByb3ZpbmNlX2JvcmRlcl0sWzQsbWV0YS5zdHlsZS5zdGF0ZV9ib3JkZXJdLFs2LG1ldGEuc3R5bGUubmF0aW9uX2JvcmRlcl1dIGFzIGNvbnN0KXtjb25zdCBwPWF3YWl0IG1hcFBvaW50KG1hcCx4LDEpO2NvbnN0IGM9aW1hZ2UucGl4ZWwocC54LHAueSk7Ym91bmRhcnlQaXhlbHMucHVzaChjKTtjbG9zZVJHQihjLGNvbG9yLGBib3JkZXIgeCR7eH1gKTt9XG4gY29uc3Qgd2lkdGhzOm51bWJlcltdPVtdO2Zvcihjb25zdCBbeCxjb2xvcl0gb2YgW1syLG1ldGEuc3R5bGUucHJvdmluY2VfYm9yZGVyXSxbNCxtZXRhLnN0eWxlLnN0YXRlX2JvcmRlcl0sWzYsbWV0YS5zdHlsZS5uYXRpb25fYm9yZGVyXV0gYXMgY29uc3Qpe2NvbnN0IHA9YXdhaXQgbWFwUG9pbnQobWFwLHgsMSk7bGV0IGNvdW50PTA7Zm9yKGxldCBkeD0tNjtkeDw9NjtkeCsrKWlmKGltYWdlLnBpeGVsKHAueCtkeCxwLnkpLmV2ZXJ5KCh2LGkpPT5NYXRoLmFicyh2LWNvbG9yW2ldKTw9MSkpY291bnQrKzt3aWR0aHMucHVzaChjb3VudCk7fVxuIGV4cGVjdCh3aWR0aHNbMF0pLnRvQmVHcmVhdGVyVGhhbigwKTtleHBlY3Qod2lkdGhzWzFdKS50b0JlR3JlYXRlclRoYW4od2lkdGhzWzBdKTtleHBlY3Qod2lkdGhzWzJdKS50b0JlR3JlYXRlclRoYW4od2lkdGhzWzFdKTtcbiAvLyBSZWFsIElEMCBzZWxlY3Rpb24gaXMgZGlzdGluY3QgZnJvbSBudWxsLCBzaGFkZXIgaGlnaGxpZ2h0IGFuZCBob3ZlciBjaGFuZ2UgcGl4ZWxzLlxuIGNvbnN0IHAwPWF3YWl0IG1hcFBvaW50KG1hcCwxLDEpO2NvbnN0IGJveD0oYXdhaXQgbWFwLmJvdW5kaW5nQm94KCkpITthd2FpdCBwYWdlLm1vdXNlLm1vdmUoYm94LngrcDAueCxib3gueStwMC55KTthd2FpdCBleHBlY3QobWFwKS50b0hhdmVBdHRyaWJ1dGUoJ2RhdGEtaG92ZXInLCcwJyk7Y29uc3QgaG92ZXJJbWFnZT1wbmcoYXdhaXQgbWFwLnNjcmVlbnNob3QoKSk7Y2xvc2VSR0IoaG92ZXJJbWFnZS5waXhlbChwMC54LHAwLnkpLFsxMjIsMTUxLDIwMV0sJ2hvdmVyJyk7XG4gYXdhaXQgbWFwLmNsaWNrKHtwb3NpdGlvbjpwMH0pO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpKS50b0hhdmVUZXh0KCcwJyk7YXdhaXQgcGFnZS5tb3VzZS5tb3ZlKDAsMCk7Y29uc3Qgc2VsZWN0ZWRJbWFnZT1wbmcoYXdhaXQgbWFwLnNjcmVlbnNob3QoKSk7Y2xvc2VSR0Ioc2VsZWN0ZWRJbWFnZS5waXhlbChwMC54LHAwLnkpLFsxMjIsMTQyLDE2Ml0sJ3NlbGVjdGlvbicpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHtuYW1lOidDbGVhciBzZWxlY3Rpb24nfSkuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc2VsZWN0ZWQtcHJvdmluY2UnKSkudG9IYXZlVGV4dCgn4oCUJyk7XG4gYXdhaXQgbWFwLmNsaWNrKHtwb3NpdGlvbjphd2FpdCBtYXBQb2ludChtYXAsMTEsMSl9KTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc2VsZWN0ZWQtcHJvdmluY2UnKSkudG9IYXZlVGV4dCgnNjU1MzUnKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRleHQoJ1RoaXMgcHJvdmluY2UgaGFzIG5vIHN0YXRlIG9yIGNvdW50cnkuJykpLnRvQmVWaXNpYmxlKCk7XG4gYXdhaXQgbWFwLmNsaWNrKHtwb3NpdGlvbjphd2FpdCBtYXBQb2ludChtYXAsMSw1KX0pO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpKS50b0hhdmVUZXh0KCc2NTUzNCcpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdtYXAtaG92ZXInKSkudG9IYXZlVGV4dCgnUHJvdmluY2UgNjU1MzQgwrcgT2NlYW4nKTtcbiBhd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTonQ2xlYXIgc2VsZWN0aW9uJ30pLmNsaWNrKCk7XG4gY29uc3QgY2VudGVyPWF3YWl0IG1hcFBvaW50KG1hcCwxLDEpO2F3YWl0IHBhZ2UubW91c2UubW92ZShib3gueCtjZW50ZXIueCxib3gueStjZW50ZXIueSk7YXdhaXQgcGFnZS5tb3VzZS53aGVlbCgwLC0zMDApO2F3YWl0IGV4cGVjdC5wb2xsKGFzeW5jKCk9PkpTT04ucGFyc2UoKGF3YWl0IG1hcC5nZXRBdHRyaWJ1dGUoJ2RhdGEtY2FtZXJhJykpISkuem9vbSkudG9CZUdyZWF0ZXJUaGFuKDEpO1xuIGF3YWl0IG1hcC5jbGljayh7cG9zaXRpb246YXdhaXQgbWFwUG9pbnQobWFwLDEsMSl9KTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc2VsZWN0ZWQtcHJvdmluY2UnKSkudG9IYXZlVGV4dCgnMCcpO1xuIGNvbnN0IGJlZm9yZT1KU09OLnBhcnNlKChhd2FpdCBtYXAuZ2V0QXR0cmlidXRlKCdkYXRhLWNhbWVyYScpKSEpO2F3YWl0IHBhZ2UubW91c2UubW92ZShib3gueCtib3gud2lkdGgvMixib3gueStib3guaGVpZ2h0LzIpO2F3YWl0IHBhZ2UubW91c2UuZG93bigpO2F3YWl0IHBhZ2UubW91c2UubW92ZShib3gueCtib3gud2lkdGgtNSxib3gueStib3guaGVpZ2h0LzIse3N0ZXBzOjh9KTthd2FpdCBwYWdlLm1vdXNlLnVwKCk7Y29uc3QgYWZ0ZXI9SlNPTi5wYXJzZSgoYXdhaXQgbWFwLmdldEF0dHJpYnV0ZSgnZGF0YS1jYW1lcmEnKSkhKTtleHBlY3QoYWZ0ZXIueCkudG9CZUxlc3NUaGFuKGJlZm9yZS54KTtcbiBhd2FpdCBtYXAuY2xpY2soe3Bvc2l0aW9uOnt4OjIseToyfX0pO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpKS50b0hhdmVUZXh0KCfigJQnKTtcbiBhd2FpdCBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJyx7bmFtZTonUmVzZXQgdmlldyd9KS5jbGljaygpO2NvbnN0IHJlc2V0PUpTT04ucGFyc2UoKGF3YWl0IG1hcC5nZXRBdHRyaWJ1dGUoJ2RhdGEtY2FtZXJhJykpISk7ZXhwZWN0KHJlc2V0KS50b01hdGNoT2JqZWN0KHt4OjYseTozLHpvb206MX0pO1xuIGF3YWl0IHBhZ2UubW91c2UubW92ZSgwLDApO2NvbnN0IHJlc2V0SW1hZ2U9cG5nKGF3YWl0IG1hcC5zY3JlZW5zaG90KCkpO2Zvcihjb25zdCBbeCxjb2xvcl0gb2YgW1syLG1ldGEuc3R5bGUucHJvdmluY2VfYm9yZGVyXSxbNCxtZXRhLnN0eWxlLnN0YXRlX2JvcmRlcl0sWzYsbWV0YS5zdHlsZS5uYXRpb25fYm9yZGVyXV0gYXMgY29uc3Qpe2NvbnN0IHA9YXdhaXQgbWFwUG9pbnQobWFwLHgsMSk7Y2xvc2VSR0IocmVzZXRJbWFnZS5waXhlbChwLngscC55KSxjb2xvcik7fVxuIHdyaXRlRmlsZVN5bmMoYCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LWZpeHR1cmUtJHtmb3JjZX0uanNvbmAsSlNPTi5zdHJpbmdpZnkoe2JvdW5kYXJ5UGl4ZWxzLHdpZHRocyxtaXNtYXRjaGVzLGJhc2VsaW5lUGl4ZWxzOmltYWdlLndpZHRoKmltYWdlLmhlaWdodCxiZWZvcmUsYWZ0ZXIscmVzZXQsZGlhZ25vc3RpY3M6YXdhaXQgbWFwLmV2YWx1YXRlKGVsPT4oey4uLiAoZWwgYXMgSFRNTEVsZW1lbnQpLmRhdGFzZXR9KSksb3JhY2xlOidpbmRlcGVuZGVudCAxMng2IGRpc3BsYXlGaXh0dXJlLnRzIHBsdXMgcmV2aWV3ZWQgbmV3IHNjcmVlbnNob3QgYmFzZWxpbmU7IG5vIHNoaXBwZWQgZ29sZGVuIGNoYW5nZWQnfSxudWxsLDIpKTtcbn0pO1xuXG5mb3IoY29uc3QgZmFpbHVyZSBvZiBbJ21pc3NpbmdHUFUnLCdudWxsQWRhcHRlcicsJ2FkYXB0ZXJSZWplY3QnLCdkZXZpY2VSZWplY3QnLCdpbnNlY3VyZSddKXRlc3QoYFJFUS1QTEFULTAzICR7ZmFpbHVyZX0gZmFsbHMgYmFjayB0byBhY3R1YWwgV2ViR0wyIHBpeGVsc2AsYXN5bmMoe3BhZ2V9LGluZm8pPT57XG4gYXdhaXQgcGFnZS5hZGRJbml0U2NyaXB0KGtpbmQ9PntcbiAgaWYoa2luZD09PSdpbnNlY3VyZScpT2JqZWN0LmRlZmluZVByb3BlcnR5KHdpbmRvdywnaXNTZWN1cmVDb250ZXh0Jyx7dmFsdWU6ZmFsc2V9KTtcbiAgaWYoa2luZD09PSdtaXNzaW5nR1BVJylPYmplY3QuZGVmaW5lUHJvcGVydHkobmF2aWdhdG9yLCdncHUnLHt2YWx1ZTp1bmRlZmluZWR9KTtcbiAgaWYoa2luZD09PSdudWxsQWRhcHRlcicpT2JqZWN0LmRlZmluZVByb3BlcnR5KG5hdmlnYXRvciwnZ3B1Jyx7dmFsdWU6e3JlcXVlc3RBZGFwdGVyOmFzeW5jKCk9Pm51bGx9fSk7XG4gIGlmKGtpbmQ9PT0nYWRhcHRlclJlamVjdCcpT2JqZWN0LmRlZmluZVByb3BlcnR5KG5hdmlnYXRvciwnZ3B1Jyx7dmFsdWU6e3JlcXVlc3RBZGFwdGVyOmFzeW5jKCk9Pnt0aHJvdyBuZXcgRXJyb3IoJ3Rlc3QgYWRhcHRlciByZWplY3Rpb24nKTt9fX0pO1xuICBpZihraW5kPT09J2RldmljZVJlamVjdCcpT2JqZWN0LmRlZmluZVByb3BlcnR5KG5hdmlnYXRvciwnZ3B1Jyx7dmFsdWU6e3JlcXVlc3RBZGFwdGVyOmFzeW5jKCk9Pih7ZmVhdHVyZXM6bmV3IFNldCgpLHJlcXVlc3REZXZpY2U6YXN5bmMoKT0+e3Rocm93IG5ldyBFcnJvcigndGVzdCBkZXZpY2UgcmVqZWN0aW9uJyk7fX0pfX0pO1xuIH0sZmFpbHVyZSk7XG4gYXdhaXQgcGFnZS5nb3RvKCcvJyk7Y29uc3QgbWFwPXBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpO2F3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1iYWNrZW5kJywnd2ViZ2wyJyk7YXdhaXQgZXhwZWN0KG1hcCkudG9IYXZlQXR0cmlidXRlKCdkYXRhLWZyYW1lcycsL15bMS05XVxcZCokLyk7YXdhaXQgcGFnZS5tb3VzZS5tb3ZlKDAsMCk7XG4gY29uc3QgcD1hd2FpdCBtYXBQb2ludChtYXAsMSwxKTtjbG9zZVJHQihwbmcoYXdhaXQgbWFwLnNjcmVlbnNob3Qoe3BhdGg6YCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LSR7ZmFpbHVyZX0ucG5nYH0pKS5waXhlbChwLngscC55KSxbNDAsMTAwLDE4MF0pO1xufSk7XG5mb3IoY29uc3QgcHJlZmVycmVkIG9mIFtmYWxzZSx0cnVlXSl0ZXN0KGBSRVEtUExBVC0wMyBubyBiYWNrZW5kIHNob3dzIGxvY2FsaXplZCBub3RpY2VzJHtwcmVmZXJyZWQ/JyBhZnRlciBwcmVmZXJyZWQgcmVqZWN0aW9uJzonJ31gLGFzeW5jKHtwYWdlfSxpbmZvKT0+e1xuIGNvbnN0IGVycm9yczpzdHJpbmdbXT1bXTtwYWdlLm9uKCdwYWdlZXJyb3InLGU9PmVycm9ycy5wdXNoKGUubWVzc2FnZSkpO1xuIGF3YWl0IHBhZ2UuYWRkSW5pdFNjcmlwdChwcmVmZXI9PntPYmplY3QuZGVmaW5lUHJvcGVydHkobmF2aWdhdG9yLCdncHUnLHt2YWx1ZTpwcmVmZXI/e3JlcXVlc3RBZGFwdGVyOmFzeW5jKCk9Pm51bGx9OnVuZGVmaW5lZH0pO2NvbnN0IG9yaWdpbmFsPUhUTUxDYW52YXNFbGVtZW50LnByb3RvdHlwZS5nZXRDb250ZXh0O0hUTUxDYW52YXNFbGVtZW50LnByb3RvdHlwZS5nZXRDb250ZXh0PWZ1bmN0aW9uKHRoaXM6SFRNTENhbnZhc0VsZW1lbnQsdHlwZTpzdHJpbmcsLi4uYXJnczp1bmtub3duW10pe2lmKHR5cGU9PT0nd2ViZ2wyJylyZXR1cm4gbnVsbDtyZXR1cm4gUmVmbGVjdC5hcHBseShvcmlnaW5hbCx0aGlzLFt0eXBlLC4uLmFyZ3NdKTt9IGFzIHR5cGVvZiBvcmlnaW5hbDt9LHByZWZlcnJlZCk7XG4gYXdhaXQgcGFnZS5nb3RvKCcvJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0NvbnRhaW5UZXh0KCdjb3VsZCBub3QgaW5pdGlhbGl6ZSBXZWJHUFUgb3IgV2ViR0wyJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpLmxvY2F0b3IoJ2NhbnZhcycpKS50b0hhdmVDb3VudCgwKTthd2FpdCBwYWdlLmdldEJ5Um9sZSgnY29tYm9ib3gnKS5zZWxlY3RPcHRpb24oJ2tvJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0NvbnRhaW5UZXh0KCfstIjquLDtmZTtlaAg7IiYIOyXhuyKteuLiOuLpCcpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ3BhdXNlJykuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgncGF1c2UnKSkudG9IYXZlVGV4dCgn7J6s6rCcJyk7XG4gY29uc3QgdGljaz1hd2FpdCBwYWdlLmdldEJ5VGVzdElkKCd0aWNrJykudGV4dENvbnRlbnQoKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY291bnRyeS1wYW5lbCcpKS50b0NvbnRhaW5UZXh0KCfrtoHrtoAg7Iuc7ZeY6rWtJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykubG9jYXRvcignLmxlZGdlci12YWx1ZSBzdHJvbmcnKSkudG9IYXZlVGV4dCgnMScpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdjb21ib2JveCcpLnNlbGVjdE9wdGlvbignZW4nKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ2NvdWxkIG5vdCBpbml0aWFsaXplIFdlYkdQVSBvciBXZWJHTDInKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgndGljaycpKS50b0hhdmVUZXh0KHRpY2shKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY291bnRyeS1wYW5lbCcpKS50b0NvbnRhaW5UZXh0KCdOb3J0aGVybiBUZXN0IE5hdGlvbicpO1xuIGV4cGVjdChlcnJvcnMpLnRvRXF1YWwoW10pO1xuIHdyaXRlRmlsZVN5bmMoYCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LW5vLWJhY2tlbmQtJHtwcmVmZXJyZWQ/J3ByZWZlcnJlZCc6J2RpcmVjdCd9Lmpzb25gLEpTT04uc3RyaW5naWZ5KHtwcmVmZXJyZWQsZXJyb3JzLHRpY2ssY2FudmFzOjAsYXV0aG9yaXR5UHJlc2VydmVkOnRydWV9LG51bGwsMikpO1xufSk7XG50ZXN0KCdSRVEtUExBVC0wMyBhY3R1YWwgV2ViR0wyIHRleHR1cmUgbGltaXQgaXMgY2hlY2tlZCBiZWZvcmUgdGV4dHVyZSBjcmVhdGlvbicsYXN5bmMoe3BhZ2V9KT0+e1xuIGF3YWl0IHBhZ2UuYWRkSW5pdFNjcmlwdCgoKT0+e09iamVjdC5kZWZpbmVQcm9wZXJ0eShuYXZpZ2F0b3IsJ2dwdScse3ZhbHVlOnVuZGVmaW5lZH0pO2NvbnN0IG9yaWdpbmFsPVdlYkdMMlJlbmRlcmluZ0NvbnRleHQucHJvdG90eXBlLmdldFBhcmFtZXRlcjtXZWJHTDJSZW5kZXJpbmdDb250ZXh0LnByb3RvdHlwZS5nZXRQYXJhbWV0ZXI9ZnVuY3Rpb24ocGFyYW1ldGVyOm51bWJlcil7cmV0dXJuIHBhcmFtZXRlcj09PXRoaXMuTUFYX1RFWFRVUkVfU0laRT8xMjg6b3JpZ2luYWwuY2FsbCh0aGlzLHBhcmFtZXRlcik7fTt9KTtcbiBhd2FpdCBwYWdlLmdvdG8oJy8nKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ2NvdWxkIG5vdCBpbml0aWFsaXplIFdlYkdQVSBvciBXZWJHTDInKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgncHJvdmluY2UtbWFwJykubG9jYXRvcignY2FudmFzJykpLnRvSGF2ZUNvdW50KDApO1xufSk7XG50ZXN0KCdSRVEtTUFQLTA0IG1pc3NpbmcgYnVuZGxlZCBpbmRleCBmYWlscyB2aXNpYmx5IHdpdGhvdXQgZXh0ZXJuYWwgZG93bmxvYWQnLGFzeW5jKHtwYWdlLHJlcXVlc3R9KT0+e1xuIGNvbnN0IHJlcXVlc3RzOnN0cmluZ1tdPVtdO3BhZ2Uub24oJ3JlcXVlc3QnLHI9PnJlcXVlc3RzLnB1c2goci51cmwoKSkpO2F3YWl0IHBhZ2Uucm91dGUoJyoqL21hcHMvdGVzdGxhbmQvaW5kZXguYmluPyonLHI9PnIuZnVsZmlsbCh7c3RhdHVzOjQwNH0pKTthd2FpdCBwYWdlLmdvdG8oJy8nKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvQ29udGFpblRleHQoJ01hcCBkYXRhIGNvdWxkIG5vdCBiZSBsb2FkZWQnKTtleHBlY3QocmVxdWVzdHMuZXZlcnkodT0+bmV3IFVSTCh1KS5ob3N0PT09bmV3IFVSTChwYWdlLnVybCgpKS5ob3N0KSkudG9CZSh0cnVlKTtcbiBleHBlY3QoKGF3YWl0IHJlcXVlc3QuZ2V0KCcvbWFwcy9taXNzaW5nL21ldGFkYXRhJykpLnN0YXR1cygpKS50b0JlKDQwNCk7ZXhwZWN0KChhd2FpdCByZXF1ZXN0LmdldCgnL21hcHMvdGVzdGxhbmQvaW5kZXguYmluP3BhY2s9d3JvbmcnKSkuc3RhdHVzKCkpLnRvQmUoNDA5KTtleHBlY3QoKGF3YWl0IHJlcXVlc3QuZ2V0KCcvbWFwcy90ZXN0bGFuZC9pbmRleC5iaW4nKSkuc3RhdHVzKCkpLnRvQmUoNDA5KTtcbn0pO1xuZm9yKGNvbnN0IGludmFsaWQgb2YgWydvbGRWZXJzaW9uJywnZnV0dXJlVmVyc2lvbicsJ3dyb25nUGFjaycsJ2R1cGxpY2F0ZUlkcycsJ2JhZFN0eWxlJywnc2hvcnRCeXRlcycsJ3dyb25nSGFzaCddKXRlc3QoYFJFUS1NQVAtMDQgc2NoZW1hIGJvdW5kYXJ5ICR7aW52YWxpZH0gcmVqZWN0cyBhdG9taWNhbGx5YCxhc3luYyh7cGFnZSxyZXF1ZXN0fSk9PntcbiBjb25zdCBtZXRhPWF3YWl0IChhd2FpdCByZXF1ZXN0LmdldCgnL21hcHMvdGVzdGxhbmQvbWV0YWRhdGEnKSkuanNvbigpO1xuIGNvbnN0IGJ5dGVzPWF3YWl0IChhd2FpdCByZXF1ZXN0LmdldChgL21hcHMvdGVzdGxhbmQvaW5kZXguYmluP3BhY2s9JHttZXRhLnBhY2tfaGFzaH1gKSkuYm9keSgpO1xuIGlmKGludmFsaWQ9PT0nb2xkVmVyc2lvbicpZGVsZXRlIG1ldGEuc2NoZW1hX3ZlcnNpb247aWYoaW52YWxpZD09PSdmdXR1cmVWZXJzaW9uJyltZXRhLnNjaGVtYV92ZXJzaW9uPTY1NTM1O1xuIGlmKGludmFsaWQ9PT0nd3JvbmdQYWNrJyltZXRhLnBhY2tfaGFzaD0nMDAwMDAwMDAwMDAwMDAwMCc7aWYoaW52YWxpZD09PSdkdXBsaWNhdGVJZHMnKW1ldGEucHJvdmluY2VfaWRzWzFdPW1ldGEucHJvdmluY2VfaWRzWzBdO2lmKGludmFsaWQ9PT0nYmFkU3R5bGUnKW1ldGEuc3R5bGUuZml0X21pbGxpPTA7XG4gaWYoaW52YWxpZD09PSd3cm9uZ0hhc2gnKW1ldGEuaW5kZXhfaGFzaD0nMDAwMDAwMDAwMDAwMDAwMCc7XG4gYXdhaXQgcGFnZS5yb3V0ZSgnKiovbWFwcy90ZXN0bGFuZC9tZXRhZGF0YScscj0+ci5mdWxmaWxsKHtqc29uOm1ldGF9KSk7XG4gaWYoaW52YWxpZD09PSdzaG9ydEJ5dGVzJylhd2FpdCBwYWdlLnJvdXRlKCcqKi9tYXBzL3Rlc3RsYW5kL2luZGV4LmJpbj8qJyxyPT5yLmZ1bGZpbGwoe2JvZHk6Ynl0ZXMuc3ViYXJyYXkoMCxieXRlcy5sZW5ndGgtMSksaGVhZGVyczp7J3gtcGFjay1oYXNoJzptZXRhLnBhY2tfaGFzaH19KSk7XG4gYXdhaXQgcGFnZS5nb3RvKCcvJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0NvbnRhaW5UZXh0KCdNYXAgZGF0YSBjb3VsZCBub3QgYmUgbG9hZGVkJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpLmxvY2F0b3IoJ2NhbnZhcycpKS50b0hhdmVDb3VudCgwKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY291bnRyeS1wYW5lbCcpKS50b0NvbnRhaW5UZXh0KCdOb3J0aGVybiBUZXN0IE5hdGlvbicpO1xufSk7XG5mb3IoY29uc3QgaW52YWxpZCBvZiBbJ2RhbmdsaW5nJywnY2hhbmdlZERpbWVuc2lvbnMnLCdjaGFuZ2VkRGVuc2UnXSl0ZXN0KGBSRVEtTUFQLTA1ICR7aW52YWxpZH0gcHJlc2VydmVzIGxhc3QgdmFsaWQgbWFwIGFuZCBjbG9zZXMgd2lyZWAsYXN5bmMoe3BhZ2V9KT0+e1xuIGxldCBjb3VudD0wO2F3YWl0IHBhZ2Uucm91dGVXZWJTb2NrZXQoJyoqL3dzJyxyb3V0ZT0+e2NvbnN0IHNlcnZlcj1yb3V0ZS5jb25uZWN0VG9TZXJ2ZXIoKTtzZXJ2ZXIub25NZXNzYWdlKGRhdGE9Pntjb25zdCBtPWRlY29kZShkYXRhIGFzIEJ1ZmZlcikgYXMgU2VydmVyTWVzc2FnZTtpZihtLnR5cGU9PT0nV29ybGRSZXN1bHQnJiZtLndvcmxkJiYrK2NvdW50Pj0zKXtpZihpbnZhbGlkPT09J2RhbmdsaW5nJyltLndvcmxkLnByb3ZpbmNlc1swXS5vd25lcj02NTUzNTtpZihpbnZhbGlkPT09J2NoYW5nZWREaW1lbnNpb25zJyltLndvcmxkLndpZHRoKys7aWYoaW52YWxpZD09PSdjaGFuZ2VkRGVuc2UnKW0ud29ybGQucHJvdmluY2VfaWRzLnJldmVyc2UoKTtyb3V0ZS5zZW5kKEJ1ZmZlci5mcm9tKGVuY29kZShtKSkpO31lbHNlIHJvdXRlLnNlbmQoZGF0YSk7fSk7fSk7XG4gYXdhaXQgcGFnZS5nb3RvKCcvJyk7Y29uc3QgbWFwPXBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpO2F3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1mcmFtZXMnLC9eWzEtOV1cXGQqJC8pO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjb25uZWN0aW9uJykpLnRvSGF2ZVRleHQoJ0Rpc2Nvbm5lY3RlZCcpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5Um9sZSgnYWxlcnQnKSkudG9IYXZlVGV4dCgnSW52YWxpZCBzZXJ2ZXIgbWVzc2FnZTsgY29ubmVjdGlvbiBjbG9zZWQnKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgncGF1c2UnKSkudG9CZURpc2FibGVkKCk7XG4gYXdhaXQgcGFnZS5tb3VzZS5tb3ZlKDAsMCk7Y29uc3QgcG9pbnQ9YXdhaXQgbWFwUG9pbnQobWFwLDEsMSk7Y2xvc2VSR0IocG5nKGF3YWl0IG1hcC5zY3JlZW5zaG90KCkpLnBpeGVsKHBvaW50LngscG9pbnQueSksWzQwLDEwMCwxODBdKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY291bnRyeS1wYW5lbCcpKS50b0NvbnRhaW5UZXh0KCdOb3J0aGVybiBUZXN0IE5hdGlvbicpO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7QUFBQSxTQUFTQSxNQUFNLEVBQUNDLElBQUksUUFBcUIsa0JBQWtCO0FBQzNELFNBQVNDLFNBQVMsRUFBQ0MsYUFBYSxFQUFDQyxZQUFZLFFBQVEsU0FBUztBQUM5RCxTQUFTQyxPQUFPLFFBQVEsV0FBVztBQUNuQyxTQUFTQyxHQUFHLFFBQVEsT0FBTztBQUMzQixTQUFTQyxNQUFNLEVBQUNDLE1BQU0sUUFBUSxrQkFBa0I7QUFFaEQsU0FBU0MsY0FBYyxFQUFDQyxrQkFBa0IsUUFBUSxrQkFBa0I7QUFDcEUsTUFBTUMsUUFBUSxJQUFBQyxxQkFBQSxHQUFDQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsZUFBZSxjQUFBSCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFFLG9CQUFvQjtBQUFDVixTQUFTLENBQUNTLFFBQVEsRUFBQztFQUFDSyxTQUFTLEVBQUM7QUFBSSxDQUFDLENBQUM7QUFDckcsZUFBZUMsUUFBUUEsQ0FBQ0MsR0FBVyxFQUFDQyxDQUFRLEVBQUNDLENBQVEsRUFBQztFQUFDLE1BQU1DLEdBQUcsR0FBRSxNQUFNSCxHQUFHLENBQUNJLFdBQVcsQ0FBQyxDQUFHO0VBQUMsTUFBTUMsQ0FBQyxHQUFDQyxJQUFJLENBQUNDLEtBQUssQ0FBRSxNQUFNUCxHQUFHLENBQUNRLFlBQVksQ0FBQyxhQUFhLENBQUcsQ0FBQztFQUFDLE9BQU87SUFBQ1AsQ0FBQyxFQUFDLENBQUNBLENBQUMsR0FBQ0ksQ0FBQyxDQUFDSixDQUFDLElBQUVJLENBQUMsQ0FBQ0ksS0FBSyxHQUFDTixHQUFHLENBQUNNLEtBQUssR0FBQ04sR0FBRyxDQUFDTSxLQUFLLEdBQUMsQ0FBQztJQUFDUCxDQUFDLEVBQUMsQ0FBQ0EsQ0FBQyxHQUFDRyxDQUFDLENBQUNILENBQUMsSUFBRUcsQ0FBQyxDQUFDSyxNQUFNLEdBQUNQLEdBQUcsQ0FBQ08sTUFBTSxHQUFDUCxHQUFHLENBQUNPLE1BQU0sR0FBQztFQUFDLENBQUM7QUFBQztBQUNyUCxTQUFTQyxRQUFRQSxDQUFDQyxNQUFlLEVBQUNDLFFBQTBCLEVBQUNDLEtBQUssR0FBQyxPQUFPLEVBQUM7RUFBQyxLQUFJLElBQUlDLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsRUFBRSxFQUFDakMsTUFBTSxDQUFDa0MsSUFBSSxDQUFDQyxHQUFHLENBQUNMLE1BQU0sQ0FBQ0csQ0FBQyxDQUFDLEdBQUNGLFFBQVEsQ0FBQ0UsQ0FBQyxDQUFDLENBQUMsRUFBQyxHQUFHRCxLQUFLLEtBQUtGLE1BQU0sYUFBYUMsUUFBUSxFQUFFLENBQUMsQ0FBQ0ssbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQUM7QUFDMU1uQyxJQUFJLENBQUMsbUVBQW1FLEVBQUMsT0FBTTtFQUFDb0MsSUFBSTtFQUFDQztBQUFPLENBQUMsRUFBQ0MsSUFBSSxLQUFHO0VBQ3BHLE1BQU1DLFFBQWlCLEdBQUMsRUFBRTtFQUFDSCxJQUFJLENBQUNJLEVBQUUsQ0FBQyxTQUFTLEVBQUNDLENBQUMsSUFBRUYsUUFBUSxDQUFDRyxJQUFJLENBQUNELENBQUMsQ0FBQ0UsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUNQLElBQUksQ0FBQ0ksRUFBRSxDQUFDLFdBQVcsRUFBQ0ksRUFBRSxJQUFFTCxRQUFRLENBQUNHLElBQUksQ0FBQ0UsRUFBRSxDQUFDRCxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFBQyxNQUFNRSxNQUFlLEdBQUMsRUFBRTtFQUFDVCxJQUFJLENBQUNJLEVBQUUsQ0FBQyxXQUFXLEVBQUNNLENBQUMsSUFBRUQsTUFBTSxDQUFDSCxJQUFJLENBQUNJLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDaE0sTUFBTVgsSUFBSSxDQUFDWSxJQUFJLENBQUMsZ0JBQWdCLENBQUM7RUFDakMsTUFBTS9CLEdBQUcsR0FBQ21CLElBQUksQ0FBQ2EsV0FBVyxDQUFDLGNBQWMsQ0FBQztFQUMxQyxNQUFNbEQsTUFBTSxDQUFDa0IsR0FBRyxDQUFDLENBQUNpQyxlQUFlLENBQUMsY0FBYyxFQUFDLFFBQVEsQ0FBQztFQUMxRCxNQUFNbkQsTUFBTSxDQUFDa0IsR0FBRyxDQUFDLENBQUNpQyxlQUFlLENBQUMsYUFBYSxFQUFDLFlBQVksQ0FBQztFQUM3RCxNQUFNbkQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDZSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQyxTQUFTO0lBQUNDLEtBQUssRUFBQztFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNDLGNBQWMsQ0FBQyxDQUFDO0VBQ25GLE1BQU12RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDSyxjQUFjLENBQUMsQ0FBQztFQUN4RCxNQUFNbEIsSUFBSSxDQUFDYSxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUNNLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXhELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNPLFVBQVUsQ0FBQyxRQUFRLENBQUM7RUFDcEcsTUFBTXBDLEdBQUcsR0FBQyxNQUFNSCxHQUFHLENBQUNJLFdBQVcsQ0FBQyxDQUFDO0VBQUN0QixNQUFNLENBQUNxQixHQUFHLENBQUMsQ0FBQ3FDLEdBQUcsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7RUFDNUQsTUFBTUMsTUFBTSxHQUFDcEMsSUFBSSxDQUFDQyxLQUFLLENBQUUsTUFBTVAsR0FBRyxDQUFDUSxZQUFZLENBQUMsYUFBYSxDQUFHLENBQUM7RUFDakUsTUFBTW1DLEVBQUUsR0FBQ0EsQ0FBQzFDLENBQVEsRUFBQ0MsQ0FBUSxNQUFJO0lBQUNELENBQUMsRUFBQyxDQUFDQSxDQUFDLEdBQUN5QyxNQUFNLENBQUN6QyxDQUFDLElBQUV5QyxNQUFNLENBQUNqQyxLQUFLLEdBQUNOLEdBQUcsQ0FBRU0sS0FBSyxHQUFDTixHQUFHLENBQUVNLEtBQUssR0FBQyxDQUFDO0lBQUNQLENBQUMsRUFBQyxDQUFDQSxDQUFDLEdBQUN3QyxNQUFNLENBQUN4QyxDQUFDLElBQUV3QyxNQUFNLENBQUNoQyxNQUFNLEdBQUNQLEdBQUcsQ0FBRU8sTUFBTSxHQUFDUCxHQUFHLENBQUVPLE1BQU0sR0FBQztFQUFDLENBQUMsQ0FBQztFQUM1SSxLQUFJLE1BQU0sQ0FBQ3lCLElBQUksRUFBQ1MsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBQyxDQUFDLEVBQUUsRUFBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLFNBQVMsRUFBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLFFBQVEsRUFBQyxDQUFDLEdBQUcsRUFBQyxFQUFFLEVBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFVO0lBQ2hILE1BQU16QixJQUFJLENBQUNlLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBQ0MsSUFBSTtNQUFDQyxLQUFLLEVBQUM7SUFBSSxDQUFDLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7SUFBQyxNQUFNbkIsSUFBSSxDQUFDMEIsS0FBSyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLE1BQU0zQixJQUFJLENBQUM0QixjQUFjLENBQUMsRUFBRSxDQUFDO0lBQ2pILE1BQU1DLElBQUksR0FBQyxNQUFNaEQsR0FBRyxDQUFDaUQsVUFBVSxDQUFDO01BQUNDLElBQUksRUFBQyxHQUFHekQsUUFBUSxJQUFJNEIsSUFBSSxDQUFDOEIsT0FBTyxDQUFDaEIsSUFBSSxJQUFJQSxJQUFJO0lBQU0sQ0FBQyxDQUFDO0lBQUMsTUFBTWlCLENBQUMsR0FBQ1QsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxNQUFNL0IsTUFBTSxHQUFDeEIsR0FBRyxDQUFDNEQsSUFBSSxDQUFDLENBQUNLLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDbkQsQ0FBQyxFQUFDbUQsQ0FBQyxDQUFDbEQsQ0FBQyxDQUFDO0lBQUMsS0FBSSxJQUFJYSxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEVBQUUsRUFBQ2pDLE1BQU0sQ0FBQ2tDLElBQUksQ0FBQ0MsR0FBRyxDQUFDTCxNQUFNLENBQUNHLENBQUMsQ0FBQyxHQUFDNkIsS0FBSyxDQUFDN0IsQ0FBQyxDQUFDLENBQUMsRUFBQyxHQUFHb0IsSUFBSSxVQUFVdkIsTUFBTSxFQUFFLENBQUMsQ0FBQ00sbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0VBQ3ZQO0VBQ0EsTUFBTWxCLEdBQUcsQ0FBQ3NDLEtBQUssQ0FBQztJQUFDZ0IsUUFBUSxFQUFDWCxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNN0QsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsSUFBSSxDQUFDO0VBQ3hHLE1BQU16RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsc0JBQXNCLENBQUM7RUFDOUUsTUFBTXZDLEdBQUcsQ0FBQ3NDLEtBQUssQ0FBQztJQUFDZ0IsUUFBUSxFQUFDWCxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNN0QsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsSUFBSSxDQUFDO0VBQUMsTUFBTXpELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNPLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQztFQUN2TCxNQUFNekQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUN1QixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQ2hCLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQztFQUFDLE1BQU16RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDaEIsVUFBVSxDQUFDLHFCQUFxQixDQUFDO0VBQzlMLE1BQU1wQixJQUFJLENBQUNhLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ3dCLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBQztJQUFDcEIsS0FBSyxFQUFDO0VBQUksQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTXhELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDdUIsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDLGNBQWMsQ0FBQztFQUFDLE1BQU0zRSxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUNoQixVQUFVLENBQUMsR0FBRyxDQUFDO0VBQzNSLE1BQU16RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNsQixjQUFjLENBQUMsQ0FBQztFQUFDLE1BQU12RCxNQUFNLENBQUNrQixHQUFHLENBQUMsQ0FBQ3FDLGNBQWMsQ0FBQyxDQUFDO0VBQzVILE1BQU1sQixJQUFJLENBQUNlLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQ3dCLFlBQVksQ0FBQyxJQUFJLENBQUM7RUFBQyxNQUFNNUUsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ08sVUFBVSxDQUFDLGNBQWMsQ0FBQztFQUFDLE1BQU16RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDaEIsVUFBVSxDQUFDLFFBQVEsQ0FBQztFQUMzTSxNQUFNdkMsR0FBRyxDQUFDc0MsS0FBSyxDQUFDO0lBQUNnQixRQUFRLEVBQUNYLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU03RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUNPLFVBQVUsQ0FBQyxJQUFJLENBQUM7RUFBQyxNQUFNekQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ08sVUFBVSxDQUFDLGNBQWMsQ0FBQztFQUFDLE1BQU16RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDaEIsVUFBVSxDQUFDLFFBQVEsQ0FBQztFQUNsUSxNQUFNcEIsSUFBSSxDQUFDOEIsVUFBVSxDQUFDO0lBQUNDLElBQUksRUFBQyxHQUFHekQsUUFBUSxJQUFJNEIsSUFBSSxDQUFDOEIsT0FBTyxDQUFDaEIsSUFBSTtFQUFnQixDQUFDLENBQUM7RUFDOUVyRCxNQUFNLENBQUM4QyxNQUFNLENBQUMsQ0FBQytCLE9BQU8sQ0FBQyxFQUFFLENBQUM7RUFBQzdFLE1BQU0sQ0FBQ3dDLFFBQVEsQ0FBQ3NDLEtBQUssQ0FBQ0MsQ0FBQyxJQUFFLElBQUlDLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDLENBQUNFLElBQUksS0FBRyxJQUFJRCxHQUFHLENBQUMzQyxJQUFJLENBQUNPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ3FDLElBQUksQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDM0cvRSxhQUFhLENBQUMsR0FBR1EsUUFBUSxJQUFJNEIsSUFBSSxDQUFDOEIsT0FBTyxDQUFDaEIsSUFBSSxXQUFXLEVBQUM3QixJQUFJLENBQUMyRCxTQUFTLENBQUM7SUFBQzdDLE9BQU8sRUFBQ0EsT0FBTyxDQUFDOEMsT0FBTyxDQUFDLENBQUM7SUFBQzVDLFFBQVE7SUFBQ00sTUFBTTtJQUFDdUMsV0FBVyxFQUFDLE1BQU1uRSxHQUFHLENBQUNvRSxRQUFRLENBQUNDLEVBQUUsS0FBRztNQUFDLEdBQUtBLEVBQUUsQ0FBaUJDO0lBQU8sQ0FBQyxDQUFDLENBQUM7SUFBQ0MsUUFBUSxFQUFDO01BQUM5RCxLQUFLLEVBQUMsSUFBSTtNQUFDQyxNQUFNLEVBQUM7SUFBRyxDQUFDO0lBQUM4RCxRQUFRLEVBQUMsSUFBSTtJQUFDQyxJQUFJLEVBQUM7RUFBRyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlQLENBQUMsQ0FBQztBQUVGMUYsSUFBSSxDQUFDLGtGQUFrRixFQUFDLE9BQU07RUFBQ29DLElBQUk7RUFBQ0M7QUFBTyxDQUFDLEVBQUNDLElBQUksS0FBRztFQUNuSCxNQUFNRixJQUFJLENBQUNZLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNL0IsR0FBRyxHQUFDbUIsSUFBSSxDQUFDYSxXQUFXLENBQUMsY0FBYyxDQUFDO0VBQUMsTUFBTWxELE1BQU0sQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDaUMsZUFBZSxDQUFDLGNBQWMsRUFBQyxlQUFlLENBQUM7RUFBQyxNQUFNbkQsTUFBTSxDQUFDa0IsR0FBRyxDQUFDLENBQUNpQyxlQUFlLENBQUMsYUFBYSxFQUFDLFlBQVksQ0FBQztFQUMvTCxNQUFNZCxJQUFJLENBQUMwQixLQUFLLENBQUNDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTUUsSUFBSSxHQUFDLE1BQU1oRCxHQUFHLENBQUNpRCxVQUFVLENBQUM7SUFBQ0MsSUFBSSxFQUFDLEdBQUd6RCxRQUFRLElBQUk0QixJQUFJLENBQUM4QixPQUFPLENBQUNoQixJQUFJO0VBQWdCLENBQUMsQ0FBQztFQUFDLE1BQU1pQixDQUFDLEdBQUMsTUFBTXJELFFBQVEsQ0FBQ0MsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFBQ1csUUFBUSxDQUFDdkIsR0FBRyxDQUFDNEQsSUFBSSxDQUFDLENBQUNLLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDbkQsQ0FBQyxFQUFDbUQsQ0FBQyxDQUFDbEQsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ25NLE1BQU1pRSxXQUFXLEdBQUMsTUFBTW5FLEdBQUcsQ0FBQ29FLFFBQVEsQ0FBQ0MsRUFBRSxLQUFHO0lBQUMsR0FBS0EsRUFBRSxDQUFpQkM7RUFBTyxDQUFDLENBQUMsQ0FBQztFQUFDeEYsTUFBTSxDQUFDcUYsV0FBVyxDQUFDTyxjQUFjLENBQUMsQ0FBQ1YsSUFBSSxDQUFDRyxXQUFXLENBQUNRLE9BQU8sS0FBRyxRQUFRLEdBQUMsTUFBTSxHQUFDLE1BQU0sQ0FBQztFQUFDN0YsTUFBTSxDQUFDOEYsTUFBTSxDQUFDVCxXQUFXLENBQUNVLFlBQVksQ0FBQyxDQUFDLENBQUNDLGVBQWUsQ0FBQyxDQUFDLENBQUM7RUFDL04sS0FBSSxNQUFNLENBQUMzQyxJQUFJLEVBQUNsQyxDQUFDLEVBQUMyQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFDLENBQUMsRUFBQyxDQUFDLEdBQUcsRUFBQyxFQUFFLEVBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLFNBQVMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxRQUFRLEVBQUMsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEVBQUUsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsV0FBVyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFVO0lBQUMsTUFBTXpCLElBQUksQ0FBQ2UsU0FBUyxDQUFDLFFBQVEsRUFBQztNQUFDQyxJQUFJO01BQUNDLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztJQUFDLE1BQU1uQixJQUFJLENBQUMwQixLQUFLLENBQUNDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsTUFBTTNCLElBQUksQ0FBQzRCLGNBQWMsQ0FBQyxFQUFFLENBQUM7SUFBQyxNQUFNZ0MsS0FBSyxHQUFDLE1BQU1oRixRQUFRLENBQUNDLEdBQUcsRUFBQ0MsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDVSxRQUFRLENBQUN2QixHQUFHLENBQUMsTUFBTVksR0FBRyxDQUFDaUQsVUFBVSxDQUFDO01BQUNDLElBQUksRUFBQyxHQUFHekQsUUFBUSxJQUFJNEIsSUFBSSxDQUFDOEIsT0FBTyxDQUFDaEIsSUFBSSxjQUFjQSxJQUFJO0lBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ2tCLEtBQUssQ0FBQzBCLEtBQUssQ0FBQzlFLENBQUMsRUFBQzhFLEtBQUssQ0FBQzdFLENBQUMsQ0FBQyxFQUFDMEMsS0FBSyxFQUFDVCxJQUFJLENBQUM7RUFBQztFQUNqYixNQUFNckQsTUFBTSxDQUFDa0csSUFBSSxDQUFDLFlBQVNKLE1BQU0sQ0FBQyxNQUFNNUUsR0FBRyxDQUFDUSxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDc0UsZUFBZSxDQUFDLEVBQUUsQ0FBQztFQUM3RjdGLGFBQWEsQ0FBQyxHQUFHUSxRQUFRLElBQUk0QixJQUFJLENBQUM4QixPQUFPLENBQUNoQixJQUFJLGlCQUFpQixFQUFDN0IsSUFBSSxDQUFDMkQsU0FBUyxDQUFDO0lBQUM3QyxPQUFPLEVBQUNBLE9BQU8sQ0FBQzhDLE9BQU8sQ0FBQyxDQUFDO0lBQUNDLFdBQVcsRUFBQyxNQUFNbkUsR0FBRyxDQUFDb0UsUUFBUSxDQUFDQyxFQUFFLEtBQUc7TUFBQyxHQUFLQSxFQUFFLENBQWlCQztJQUFPLENBQUMsQ0FBQyxDQUFDO0lBQUNXLGdCQUFnQixFQUFDO0VBQTRFLENBQUMsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMVIsQ0FBQyxDQUFDO0FBQ0ZsRyxJQUFJLENBQUMsb0ZBQW9GLEVBQUMsT0FBTTtFQUFDb0M7QUFBSSxDQUFDLEVBQUNFLElBQUksS0FBRztFQUM3RyxJQUFJNkQsTUFBTSxHQUFDLEtBQUs7RUFBQyxNQUFNL0QsSUFBSSxDQUFDZ0UsY0FBYyxDQUFDLE9BQU8sRUFBQ0MsS0FBSyxJQUFFO0lBQUMsTUFBTUMsTUFBTSxHQUFDRCxLQUFLLENBQUNFLGVBQWUsQ0FBQyxDQUFDO0lBQUNELE1BQU0sQ0FBQ0UsU0FBUyxDQUFDQyxJQUFJLElBQUU7TUFBQyxNQUFNQyxDQUFDLEdBQUNuRyxNQUFNLENBQUNrRyxJQUFjLENBQWtCO01BQUMsSUFBR04sTUFBTSxJQUFFTyxDQUFDLENBQUNDLElBQUksS0FBRyxhQUFhLElBQUVELENBQUMsQ0FBQ0UsS0FBSyxJQUFFRixDQUFDLENBQUNHLE9BQU8sS0FBRyxPQUFPLEVBQUM7UUFBQ0gsQ0FBQyxDQUFDRSxLQUFLLENBQUNFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxHQUFDLENBQUMsRUFBRSxFQUFDLEVBQUUsRUFBQyxHQUFHLENBQUM7UUFBQ1YsS0FBSyxDQUFDVyxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDNUcsTUFBTSxDQUFDb0csQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDLENBQUMsTUFBS0wsS0FBSyxDQUFDVyxJQUFJLENBQUNQLElBQUksQ0FBQztJQUFDLENBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUNyVixNQUFNckUsSUFBSSxDQUFDWSxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQUMsTUFBTS9CLEdBQUcsR0FBQ21CLElBQUksQ0FBQ2EsV0FBVyxDQUFDLGNBQWMsQ0FBQztFQUFDLE1BQU1sRCxNQUFNLENBQUNrQixHQUFHLENBQUMsQ0FBQ2lDLGVBQWUsQ0FBQyxhQUFhLEVBQUMsWUFBWSxDQUFDO0VBQUNpRCxNQUFNLEdBQUMsSUFBSTtFQUFDLE1BQU1wRyxNQUFNLENBQUNrQixHQUFHLENBQUMsQ0FBQ2lDLGVBQWUsQ0FBQyx5QkFBeUIsRUFBQyxHQUFHLENBQUM7RUFBQyxNQUFNZCxJQUFJLENBQUMwQixLQUFLLENBQUNDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTWlDLEtBQUssR0FBQyxNQUFNaEYsUUFBUSxDQUFDQyxHQUFHLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztFQUFDVyxRQUFRLENBQUN2QixHQUFHLENBQUMsTUFBTVksR0FBRyxDQUFDaUQsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDSSxLQUFLLENBQUMwQixLQUFLLENBQUM5RSxDQUFDLEVBQUM4RSxLQUFLLENBQUM3RSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQyxFQUFFLEVBQUMsR0FBRyxDQUFDLENBQUM7RUFBQyxNQUFNZ0csU0FBUyxHQUFDLE1BQU1uRyxRQUFRLENBQUNDLEdBQUcsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUNXLFFBQVEsQ0FBQ3ZCLEdBQUcsQ0FBQyxNQUFNWSxHQUFHLENBQUNpRCxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUNJLEtBQUssQ0FBQzZDLFNBQVMsQ0FBQ2pHLENBQUMsRUFBQ2lHLFNBQVMsQ0FBQ2hHLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDLEdBQUcsRUFBQyxHQUFHLENBQUMsQ0FBQztFQUFDakIsYUFBYSxDQUFDLEdBQUdRLFFBQVEsSUFBSTRCLElBQUksQ0FBQzhCLE9BQU8sQ0FBQ2hCLElBQUksc0JBQXNCLEVBQUM3QixJQUFJLENBQUMyRCxTQUFTLENBQUMsTUFBTWpFLEdBQUcsQ0FBQ29FLFFBQVEsQ0FBQ0MsRUFBRSxLQUFHO0lBQUMsR0FBS0EsRUFBRSxDQUFpQkM7RUFBTyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQztBQUN0bUIsQ0FBQyxDQUFDO0FBQ0Z2RixJQUFJLENBQUMsd0VBQXdFLEVBQUMsT0FBTTtFQUFDb0MsSUFBSTtFQUFDeUU7QUFBTyxDQUFDLEVBQUN2RSxJQUFJLEtBQUc7RUFDekcsTUFBTThFLElBQUksR0FBQyxNQUFNLENBQUMsTUFBTVAsT0FBTyxDQUFDUSxHQUFHLENBQUMseUJBQXlCLENBQUMsRUFBRUMsSUFBSSxDQUFDLENBQWdCO0VBQUMsSUFBSUMsT0FBdUQ7RUFDakosTUFBTW5GLElBQUksQ0FBQ2dFLGNBQWMsQ0FBQyxPQUFPLEVBQUNDLEtBQUssSUFBRTtJQUFDLE1BQU1DLE1BQU0sR0FBQ0QsS0FBSyxDQUFDRSxlQUFlLENBQUMsQ0FBQztJQUFDRCxNQUFNLENBQUNFLFNBQVMsQ0FBQ0MsSUFBSSxJQUFFO01BQUMsTUFBTUMsQ0FBQyxHQUFDbkcsTUFBTSxDQUFDa0csSUFBYyxDQUFrQjtNQUFDLElBQUdDLENBQUMsQ0FBQ0MsSUFBSSxLQUFHLGFBQWEsSUFBRUQsQ0FBQyxDQUFDRSxLQUFLLElBQUVGLENBQUMsQ0FBQ0csT0FBTyxLQUFHLE9BQU8sRUFBQztRQUFDVSxPQUFPLEdBQUM5RyxrQkFBa0IsQ0FBQ2lHLENBQUMsQ0FBQ0UsS0FBSyxFQUFDUSxJQUFJLENBQUM7UUFBQ1YsQ0FBQyxDQUFDRSxLQUFLLEdBQUNXLE9BQU8sQ0FBQ1gsS0FBSztRQUFDUCxLQUFLLENBQUNXLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUM1RyxNQUFNLENBQUNvRyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxNQUFLTCxLQUFLLENBQUNXLElBQUksQ0FBQ1AsSUFBSSxDQUFDO0lBQUMsQ0FBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQzlVLE1BQU1yRSxJQUFJLENBQUNpRSxLQUFLLENBQUMsa0NBQWtDLEVBQUM1RCxDQUFDLElBQUVBLENBQUMsQ0FBQytFLE9BQU8sQ0FBQztJQUFDRixJQUFJLEVBQUNDLE9BQU8sQ0FBRUg7RUFBSSxDQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1oRixJQUFJLENBQUNpRSxLQUFLLENBQUMscUNBQXFDLEVBQUM1RCxDQUFDLElBQUVBLENBQUMsQ0FBQytFLE9BQU8sQ0FBQztJQUFDQyxJQUFJLEVBQUNGLE9BQU8sQ0FBRUcsS0FBSztJQUFDQyxPQUFPLEVBQUM7TUFBQyxhQUFhLEVBQUNQLElBQUksQ0FBQ1E7SUFBUztFQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzFOLE1BQU14RixJQUFJLENBQUNZLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNL0IsR0FBRyxHQUFDbUIsSUFBSSxDQUFDYSxXQUFXLENBQUMsY0FBYyxDQUFDO0VBQUMsTUFBTWxELE1BQU0sQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDaUMsZUFBZSxDQUFDLGFBQWEsRUFBQyxZQUFZLENBQUM7RUFBQyxNQUFNZCxJQUFJLENBQUMwQixLQUFLLENBQUNDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTU0sQ0FBQyxHQUFDLE1BQU1yRCxRQUFRLENBQUNDLEdBQUcsRUFBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDO0VBQUNXLFFBQVEsQ0FBQ3ZCLEdBQUcsQ0FBQyxNQUFNWSxHQUFHLENBQUNpRCxVQUFVLENBQUM7SUFBQ0MsSUFBSSxFQUFDLEdBQUd6RCxRQUFRLElBQUk0QixJQUFJLENBQUM4QixPQUFPLENBQUNoQixJQUFJO0VBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQ2tCLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDbkQsQ0FBQyxFQUFDbUQsQ0FBQyxDQUFDbEQsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQUMsTUFBTUYsR0FBRyxDQUFDc0MsS0FBSyxDQUFDO0lBQUNnQixRQUFRLEVBQUNGO0VBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTXRFLE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQ08sVUFBVSxDQUFDLE9BQU8sQ0FBQztFQUFDdEQsYUFBYSxDQUFDLEdBQUdRLFFBQVEsSUFBSTRCLElBQUksQ0FBQzhCLE9BQU8sQ0FBQ2hCLElBQUksZ0JBQWdCLEVBQUM3QixJQUFJLENBQUMyRCxTQUFTLENBQUMsTUFBTWpFLEdBQUcsQ0FBQ29FLFFBQVEsQ0FBQ0MsRUFBRSxLQUFHO0lBQUMsR0FBS0EsRUFBRSxDQUFpQkM7RUFBTyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQztBQUM5aUIsQ0FBQyxDQUFDO0FBRUYsS0FBSSxNQUFNc0MsS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxFQUFDN0gsSUFBSSxDQUFDLDZFQUE2RTZILEtBQUssR0FBQyxRQUFRLEdBQUMsV0FBVyxFQUFFLEVBQUMsT0FBTTtFQUFDekYsSUFBSTtFQUFDeUU7QUFBTyxDQUFDLEVBQUN2RSxJQUFJLEtBQUc7RUFDMUssTUFBTThFLElBQUksR0FBQyxNQUFNLENBQUMsTUFBTVAsT0FBTyxDQUFDUSxHQUFHLENBQUMseUJBQXlCLENBQUMsRUFBRUMsSUFBSSxDQUFDLENBQWdCO0VBQ3JGLElBQUlDLE9BQW1EO0VBQ3ZELE1BQU1uRixJQUFJLENBQUNnRSxjQUFjLENBQUMsT0FBTyxFQUFDQyxLQUFLLElBQUU7SUFBQyxNQUFNQyxNQUFNLEdBQUNELEtBQUssQ0FBQ0UsZUFBZSxDQUFDLENBQUM7SUFBQ0QsTUFBTSxDQUFDRSxTQUFTLENBQUNDLElBQUksSUFBRTtNQUFDLE1BQU1DLENBQUMsR0FBQ25HLE1BQU0sQ0FBQ2tHLElBQWMsQ0FBa0I7TUFBQyxJQUFHQyxDQUFDLENBQUNDLElBQUksS0FBRyxhQUFhLElBQUVELENBQUMsQ0FBQ0UsS0FBSyxJQUFFRixDQUFDLENBQUNHLE9BQU8sS0FBRyxPQUFPLEVBQUM7UUFBQ1UsT0FBTyxHQUFDL0csY0FBYyxDQUFDa0csQ0FBQyxDQUFDRSxLQUFLLEVBQUNRLElBQUksQ0FBQztRQUFDVixDQUFDLENBQUNFLEtBQUssR0FBQ1csT0FBTyxDQUFDWCxLQUFLO1FBQUNQLEtBQUssQ0FBQ1csSUFBSSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzVHLE1BQU0sQ0FBQ29HLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxDQUFDLE1BQUtMLEtBQUssQ0FBQ1csSUFBSSxDQUFDUCxJQUFJLENBQUM7SUFBQyxDQUFDLENBQUM7RUFBQyxDQUFDLENBQUM7RUFDMVUsTUFBTXJFLElBQUksQ0FBQ2lFLEtBQUssQ0FBQyxrQ0FBa0MsRUFBQ0EsS0FBSyxJQUFFQSxLQUFLLENBQUNtQixPQUFPLENBQUM7SUFBQ0YsSUFBSSxFQUFDQyxPQUFPLENBQUVIO0VBQUksQ0FBQyxDQUFDLENBQUM7RUFDL0YsTUFBTWhGLElBQUksQ0FBQ2lFLEtBQUssQ0FBQyxxQ0FBcUMsRUFBQ0EsS0FBSyxJQUFFQSxLQUFLLENBQUNtQixPQUFPLENBQUM7SUFBQ0MsSUFBSSxFQUFDRixPQUFPLENBQUVHLEtBQUs7SUFBQ0ksV0FBVyxFQUFDLDBCQUEwQjtJQUFDSCxPQUFPLEVBQUM7TUFBQyxhQUFhLEVBQUNQLElBQUksQ0FBQ1E7SUFBUztFQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ2pMLE1BQU14RixJQUFJLENBQUNZLElBQUksQ0FBQzZFLEtBQUssR0FBQyxnQkFBZ0IsR0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNNUcsR0FBRyxHQUFDbUIsSUFBSSxDQUFDYSxXQUFXLENBQUMsY0FBYyxDQUFDO0VBQUMsTUFBTWxELE1BQU0sQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDaUMsZUFBZSxDQUFDLGFBQWEsRUFBQyxZQUFZLENBQUM7RUFBQyxJQUFHMkUsS0FBSyxFQUFDLE1BQU05SCxNQUFNLENBQUNrQixHQUFHLENBQUMsQ0FBQ2lDLGVBQWUsQ0FBQyxjQUFjLEVBQUMsUUFBUSxDQUFDO0VBQ3hOLE1BQU1kLElBQUksQ0FBQzBCLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNRSxJQUFJLEdBQUMsTUFBTWhELEdBQUcsQ0FBQ2lELFVBQVUsQ0FBQztNQUFDQyxJQUFJLEVBQUMsR0FBR3pELFFBQVEsSUFBSTRCLElBQUksQ0FBQzhCLE9BQU8sQ0FBQ2hCLElBQUksWUFBWXlFLEtBQUs7SUFBTSxDQUFDLENBQUM7SUFBQ0UsS0FBSyxHQUFDMUgsR0FBRyxDQUFDNEQsSUFBSSxDQUFDO0VBQzFJLE1BQU0rRCxRQUFRLEdBQUMzSCxHQUFHLENBQUNGLFlBQVksQ0FBQ0MsT0FBTyxDQUFDNkgsTUFBTSxDQUFDYixJQUFJLENBQUNjLE9BQU8sRUFBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUM7RUFDOUZuSSxNQUFNLENBQUMsQ0FBQ2dJLEtBQUssQ0FBQ3JHLEtBQUssRUFBQ3FHLEtBQUssQ0FBQ3BHLE1BQU0sQ0FBQyxDQUFDLENBQUNpRCxPQUFPLENBQUMsQ0FBQ29ELFFBQVEsQ0FBQ3RHLEtBQUssRUFBQ3NHLFFBQVEsQ0FBQ3JHLE1BQU0sQ0FBQyxDQUFDO0VBQzVFLElBQUl3RyxVQUFVLEdBQUMsQ0FBQztFQUFDLEtBQUksSUFBSWhILENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQzRHLEtBQUssQ0FBQ3BHLE1BQU0sRUFBQ1IsQ0FBQyxFQUFFLEVBQUMsS0FBSSxJQUFJRCxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUM2RyxLQUFLLENBQUNyRyxLQUFLLEVBQUNSLENBQUMsRUFBRSxFQUFDLElBQUc2RyxLQUFLLENBQUN6RCxLQUFLLENBQUNwRCxDQUFDLEVBQUNDLENBQUMsQ0FBQyxDQUFDaUgsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBQ3JHLENBQUMsS0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUNtRyxDQUFDLEdBQUNMLFFBQVEsQ0FBQzFELEtBQUssQ0FBQ3BELENBQUMsRUFBQ0MsQ0FBQyxDQUFDLENBQUNhLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUNtRyxVQUFVLEVBQUU7RUFDaEs7RUFDQXBJLE1BQU0sQ0FBQ29JLFVBQVUsSUFBRUosS0FBSyxDQUFDckcsS0FBSyxHQUFDcUcsS0FBSyxDQUFDcEcsTUFBTSxDQUFDLENBQUMsQ0FBQ1EsbUJBQW1CLENBQUMsSUFBSSxDQUFDO0VBQ3ZFLE1BQU1tRyxjQUF5QixHQUFDLEVBQUU7RUFDbEM7RUFDQSxLQUFJLE1BQU0sQ0FBQ3BILENBQUMsRUFBQzJDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUN1RCxJQUFJLENBQUNtQixLQUFLLENBQUNDLGVBQWUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDcEIsSUFBSSxDQUFDbUIsS0FBSyxDQUFDRSxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQ3JCLElBQUksQ0FBQ21CLEtBQUssQ0FBQ0csYUFBYSxDQUFDLENBQUMsRUFBVTtJQUFDLE1BQU1yRSxDQUFDLEdBQUMsTUFBTXJELFFBQVEsQ0FBQ0MsR0FBRyxFQUFDQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsTUFBTUksQ0FBQyxHQUFDeUcsS0FBSyxDQUFDekQsS0FBSyxDQUFDRCxDQUFDLENBQUNuRCxDQUFDLEVBQUNtRCxDQUFDLENBQUNsRCxDQUFDLENBQUM7SUFBQ21ILGNBQWMsQ0FBQzVGLElBQUksQ0FBQ3BCLENBQUMsQ0FBQztJQUFDTSxRQUFRLENBQUNOLENBQUMsRUFBQ3VDLEtBQUssRUFBQyxXQUFXM0MsQ0FBQyxFQUFFLENBQUM7RUFBQztFQUNoUCxNQUFNeUgsTUFBZSxHQUFDLEVBQUU7RUFBQyxLQUFJLE1BQU0sQ0FBQ3pILENBQUMsRUFBQzJDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUN1RCxJQUFJLENBQUNtQixLQUFLLENBQUNDLGVBQWUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDcEIsSUFBSSxDQUFDbUIsS0FBSyxDQUFDRSxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQ3JCLElBQUksQ0FBQ21CLEtBQUssQ0FBQ0csYUFBYSxDQUFDLENBQUMsRUFBVTtJQUFDLE1BQU1yRSxDQUFDLEdBQUMsTUFBTXJELFFBQVEsQ0FBQ0MsR0FBRyxFQUFDQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSTBILEtBQUssR0FBQyxDQUFDO0lBQUMsS0FBSSxJQUFJQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLEVBQUNBLEVBQUUsSUFBRSxDQUFDLEVBQUNBLEVBQUUsRUFBRSxFQUFDLElBQUdkLEtBQUssQ0FBQ3pELEtBQUssQ0FBQ0QsQ0FBQyxDQUFDbkQsQ0FBQyxHQUFDMkgsRUFBRSxFQUFDeEUsQ0FBQyxDQUFDbEQsQ0FBQyxDQUFDLENBQUMwRCxLQUFLLENBQUMsQ0FBQ3dELENBQUMsRUFBQ3JHLENBQUMsS0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUNtRyxDQUFDLEdBQUN4RSxLQUFLLENBQUM3QixDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDNEcsS0FBSyxFQUFFO0lBQUNELE1BQU0sQ0FBQ2pHLElBQUksQ0FBQ2tHLEtBQUssQ0FBQztFQUFDO0VBQ3JUN0ksTUFBTSxDQUFDNEksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM1QyxlQUFlLENBQUMsQ0FBQyxDQUFDO0VBQUNoRyxNQUFNLENBQUM0SSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzVDLGVBQWUsQ0FBQzRDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFDNUksTUFBTSxDQUFDNEksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM1QyxlQUFlLENBQUM0QyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDOUg7RUFDQSxNQUFNRyxFQUFFLEdBQUMsTUFBTTlILFFBQVEsQ0FBQ0MsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNRyxHQUFHLEdBQUUsTUFBTUgsR0FBRyxDQUFDSSxXQUFXLENBQUMsQ0FBRztFQUFDLE1BQU1lLElBQUksQ0FBQzBCLEtBQUssQ0FBQ0MsSUFBSSxDQUFDM0MsR0FBRyxDQUFDRixDQUFDLEdBQUM0SCxFQUFFLENBQUM1SCxDQUFDLEVBQUNFLEdBQUcsQ0FBQ0QsQ0FBQyxHQUFDMkgsRUFBRSxDQUFDM0gsQ0FBQyxDQUFDO0VBQUMsTUFBTXBCLE1BQU0sQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDaUMsZUFBZSxDQUFDLFlBQVksRUFBQyxHQUFHLENBQUM7RUFBQyxNQUFNNkYsVUFBVSxHQUFDMUksR0FBRyxDQUFDLE1BQU1ZLEdBQUcsQ0FBQ2lELFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFBQ3RDLFFBQVEsQ0FBQ21ILFVBQVUsQ0FBQ3pFLEtBQUssQ0FBQ3dFLEVBQUUsQ0FBQzVILENBQUMsRUFBQzRILEVBQUUsQ0FBQzNILENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsRUFBQyxHQUFHLENBQUMsRUFBQyxPQUFPLENBQUM7RUFDL1EsTUFBTUYsR0FBRyxDQUFDc0MsS0FBSyxDQUFDO0lBQUNnQixRQUFRLEVBQUN1RTtFQUFFLENBQUMsQ0FBQztFQUFDLE1BQU0vSSxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUNPLFVBQVUsQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNcEIsSUFBSSxDQUFDMEIsS0FBSyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1pRixhQUFhLEdBQUMzSSxHQUFHLENBQUMsTUFBTVksR0FBRyxDQUFDaUQsVUFBVSxDQUFDLENBQUMsQ0FBQztFQUFDdEMsUUFBUSxDQUFDb0gsYUFBYSxDQUFDMUUsS0FBSyxDQUFDd0UsRUFBRSxDQUFDNUgsQ0FBQyxFQUFDNEgsRUFBRSxDQUFDM0gsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLFdBQVcsQ0FBQztFQUNoUCxNQUFNaUIsSUFBSSxDQUFDZSxTQUFTLENBQUMsUUFBUSxFQUFDO0lBQUNDLElBQUksRUFBQztFQUFpQixDQUFDLENBQUMsQ0FBQ0csS0FBSyxDQUFDLENBQUM7RUFBQyxNQUFNeEQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsR0FBRyxDQUFDO0VBQ25JLE1BQU12QyxHQUFHLENBQUNzQyxLQUFLLENBQUM7SUFBQ2dCLFFBQVEsRUFBQyxNQUFNdkQsUUFBUSxDQUFDQyxHQUFHLEVBQUMsRUFBRSxFQUFDLENBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNbEIsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsT0FBTyxDQUFDO0VBQUMsTUFBTXpELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ3FDLFNBQVMsQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDLENBQUN3RSxXQUFXLENBQUMsQ0FBQztFQUNqTixNQUFNaEksR0FBRyxDQUFDc0MsS0FBSyxDQUFDO0lBQUNnQixRQUFRLEVBQUMsTUFBTXZELFFBQVEsQ0FBQ0MsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTWxCLE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQ08sVUFBVSxDQUFDLE9BQU8sQ0FBQztFQUFDLE1BQU16RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsd0JBQXdCLENBQUM7RUFDNU0sTUFBTXBCLElBQUksQ0FBQ2UsU0FBUyxDQUFDLFFBQVEsRUFBQztJQUFDQyxJQUFJLEVBQUM7RUFBaUIsQ0FBQyxDQUFDLENBQUNHLEtBQUssQ0FBQyxDQUFDO0VBQy9ELE1BQU0yRixNQUFNLEdBQUMsTUFBTWxJLFFBQVEsQ0FBQ0MsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNbUIsSUFBSSxDQUFDMEIsS0FBSyxDQUFDQyxJQUFJLENBQUMzQyxHQUFHLENBQUNGLENBQUMsR0FBQ2dJLE1BQU0sQ0FBQ2hJLENBQUMsRUFBQ0UsR0FBRyxDQUFDRCxDQUFDLEdBQUMrSCxNQUFNLENBQUMvSCxDQUFDLENBQUM7RUFBQyxNQUFNaUIsSUFBSSxDQUFDMEIsS0FBSyxDQUFDcUYsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUcsQ0FBQztFQUFDLE1BQU1wSixNQUFNLENBQUNrRyxJQUFJLENBQUMsWUFBUzFFLElBQUksQ0FBQ0MsS0FBSyxDQUFFLE1BQU1QLEdBQUcsQ0FBQ1EsWUFBWSxDQUFDLGFBQWEsQ0FBRyxDQUFDLENBQUMySCxJQUFJLENBQUMsQ0FBQ3JELGVBQWUsQ0FBQyxDQUFDLENBQUM7RUFDak8sTUFBTTlFLEdBQUcsQ0FBQ3NDLEtBQUssQ0FBQztJQUFDZ0IsUUFBUSxFQUFDLE1BQU12RCxRQUFRLENBQUNDLEdBQUcsRUFBQyxDQUFDLEVBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1sQixNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUNPLFVBQVUsQ0FBQyxHQUFHLENBQUM7RUFDdkgsTUFBTTZGLE1BQU0sR0FBQzlILElBQUksQ0FBQ0MsS0FBSyxDQUFFLE1BQU1QLEdBQUcsQ0FBQ1EsWUFBWSxDQUFDLGFBQWEsQ0FBRyxDQUFDO0VBQUMsTUFBTVcsSUFBSSxDQUFDMEIsS0FBSyxDQUFDQyxJQUFJLENBQUMzQyxHQUFHLENBQUNGLENBQUMsR0FBQ0UsR0FBRyxDQUFDTSxLQUFLLEdBQUMsQ0FBQyxFQUFDTixHQUFHLENBQUNELENBQUMsR0FBQ0MsR0FBRyxDQUFDTyxNQUFNLEdBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTVMsSUFBSSxDQUFDMEIsS0FBSyxDQUFDd0YsSUFBSSxDQUFDLENBQUM7RUFBQyxNQUFNbEgsSUFBSSxDQUFDMEIsS0FBSyxDQUFDQyxJQUFJLENBQUMzQyxHQUFHLENBQUNGLENBQUMsR0FBQ0UsR0FBRyxDQUFDTSxLQUFLLEdBQUMsQ0FBQyxFQUFDTixHQUFHLENBQUNELENBQUMsR0FBQ0MsR0FBRyxDQUFDTyxNQUFNLEdBQUMsQ0FBQyxFQUFDO0lBQUM0SCxLQUFLLEVBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNbkgsSUFBSSxDQUFDMEIsS0FBSyxDQUFDMEYsRUFBRSxDQUFDLENBQUM7RUFBQyxNQUFNQyxLQUFLLEdBQUNsSSxJQUFJLENBQUNDLEtBQUssQ0FBRSxNQUFNUCxHQUFHLENBQUNRLFlBQVksQ0FBQyxhQUFhLENBQUcsQ0FBQztFQUFDMUIsTUFBTSxDQUFDMEosS0FBSyxDQUFDdkksQ0FBQyxDQUFDLENBQUN3SSxZQUFZLENBQUNMLE1BQU0sQ0FBQ25JLENBQUMsQ0FBQztFQUN6VixNQUFNRCxHQUFHLENBQUNzQyxLQUFLLENBQUM7SUFBQ2dCLFFBQVEsRUFBQztNQUFDckQsQ0FBQyxFQUFDLENBQUM7TUFBQ0MsQ0FBQyxFQUFDO0lBQUM7RUFBQyxDQUFDLENBQUM7RUFBQyxNQUFNcEIsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsR0FBRyxDQUFDO0VBQ3pHLE1BQU1wQixJQUFJLENBQUNlLFNBQVMsQ0FBQyxRQUFRLEVBQUM7SUFBQ0MsSUFBSSxFQUFDO0VBQVksQ0FBQyxDQUFDLENBQUNHLEtBQUssQ0FBQyxDQUFDO0VBQUMsTUFBTW9HLEtBQUssR0FBQ3BJLElBQUksQ0FBQ0MsS0FBSyxDQUFFLE1BQU1QLEdBQUcsQ0FBQ1EsWUFBWSxDQUFDLGFBQWEsQ0FBRyxDQUFDO0VBQUMxQixNQUFNLENBQUM0SixLQUFLLENBQUMsQ0FBQ0MsYUFBYSxDQUFDO0lBQUMxSSxDQUFDLEVBQUMsQ0FBQztJQUFDQyxDQUFDLEVBQUMsQ0FBQztJQUFDaUksSUFBSSxFQUFDO0VBQUMsQ0FBQyxDQUFDO0VBQ3pLLE1BQU1oSCxJQUFJLENBQUMwQixLQUFLLENBQUNDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTThGLFVBQVUsR0FBQ3hKLEdBQUcsQ0FBQyxNQUFNWSxHQUFHLENBQUNpRCxVQUFVLENBQUMsQ0FBQyxDQUFDO0VBQUMsS0FBSSxNQUFNLENBQUNoRCxDQUFDLEVBQUMyQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDdUQsSUFBSSxDQUFDbUIsS0FBSyxDQUFDQyxlQUFlLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQ3BCLElBQUksQ0FBQ21CLEtBQUssQ0FBQ0UsWUFBWSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUNyQixJQUFJLENBQUNtQixLQUFLLENBQUNHLGFBQWEsQ0FBQyxDQUFDLEVBQVU7SUFBQyxNQUFNckUsQ0FBQyxHQUFDLE1BQU1yRCxRQUFRLENBQUNDLEdBQUcsRUFBQ0MsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDVSxRQUFRLENBQUNpSSxVQUFVLENBQUN2RixLQUFLLENBQUNELENBQUMsQ0FBQ25ELENBQUMsRUFBQ21ELENBQUMsQ0FBQ2xELENBQUMsQ0FBQyxFQUFDMEMsS0FBSyxDQUFDO0VBQUM7RUFDN1EzRCxhQUFhLENBQUMsR0FBR1EsUUFBUSxJQUFJNEIsSUFBSSxDQUFDOEIsT0FBTyxDQUFDaEIsSUFBSSxZQUFZeUUsS0FBSyxPQUFPLEVBQUN0RyxJQUFJLENBQUMyRCxTQUFTLENBQUM7SUFBQ29ELGNBQWM7SUFBQ0ssTUFBTTtJQUFDUixVQUFVO0lBQUMyQixjQUFjLEVBQUMvQixLQUFLLENBQUNyRyxLQUFLLEdBQUNxRyxLQUFLLENBQUNwRyxNQUFNO0lBQUMwSCxNQUFNO0lBQUNJLEtBQUs7SUFBQ0UsS0FBSztJQUFDdkUsV0FBVyxFQUFDLE1BQU1uRSxHQUFHLENBQUNvRSxRQUFRLENBQUNDLEVBQUUsS0FBRztNQUFDLEdBQUtBLEVBQUUsQ0FBaUJDO0lBQU8sQ0FBQyxDQUFDLENBQUM7SUFBQ3dFLE1BQU0sRUFBQztFQUFxRyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xYLENBQUMsQ0FBQztBQUVGLEtBQUksTUFBTUMsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFDLGFBQWEsRUFBQyxlQUFlLEVBQUMsY0FBYyxFQUFDLFVBQVUsQ0FBQyxFQUFDaEssSUFBSSxDQUFDLGVBQWVnSyxPQUFPLHFDQUFxQyxFQUFDLE9BQU07RUFBQzVIO0FBQUksQ0FBQyxFQUFDRSxJQUFJLEtBQUc7RUFDaEwsTUFBTUYsSUFBSSxDQUFDNkgsYUFBYSxDQUFDQyxJQUFJLElBQUU7SUFDOUIsSUFBR0EsSUFBSSxLQUFHLFVBQVUsRUFBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUNDLE1BQU0sRUFBQyxpQkFBaUIsRUFBQztNQUFDQyxLQUFLLEVBQUM7SUFBSyxDQUFDLENBQUM7SUFDbEYsSUFBR0osSUFBSSxLQUFHLFlBQVksRUFBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUNHLFNBQVMsRUFBQyxLQUFLLEVBQUM7TUFBQ0QsS0FBSyxFQUFDRTtJQUFTLENBQUMsQ0FBQztJQUMvRSxJQUFHTixJQUFJLEtBQUcsYUFBYSxFQUFDQyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0csU0FBUyxFQUFDLEtBQUssRUFBQztNQUFDRCxLQUFLLEVBQUM7UUFBQ0csY0FBYyxFQUFDLE1BQUFBLENBQUEsS0FBUztNQUFJO0lBQUMsQ0FBQyxDQUFDO0lBQ3JHLElBQUdQLElBQUksS0FBRyxlQUFlLEVBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDRyxTQUFTLEVBQUMsS0FBSyxFQUFDO01BQUNELEtBQUssRUFBQztRQUFDRyxjQUFjLEVBQUMsTUFBQUEsQ0FBQSxLQUFTO1VBQUMsTUFBTSxJQUFJQyxLQUFLLENBQUMsd0JBQXdCLENBQUM7UUFBQztNQUFDO0lBQUMsQ0FBQyxDQUFDO0lBQy9JLElBQUdSLElBQUksS0FBRyxjQUFjLEVBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDRyxTQUFTLEVBQUMsS0FBSyxFQUFDO01BQUNELEtBQUssRUFBQztRQUFDRyxjQUFjLEVBQUMsTUFBQUEsQ0FBQSxNQUFVO1VBQUNFLFFBQVEsRUFBQyxJQUFJQyxHQUFHLENBQUMsQ0FBQztVQUFDQyxhQUFhLEVBQUMsTUFBQUEsQ0FBQSxLQUFTO1lBQUMsTUFBTSxJQUFJSCxLQUFLLENBQUMsdUJBQXVCLENBQUM7VUFBQztRQUFDLENBQUM7TUFBQztJQUFDLENBQUMsQ0FBQztFQUM1TCxDQUFDLEVBQUNWLE9BQU8sQ0FBQztFQUNWLE1BQU01SCxJQUFJLENBQUNZLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNL0IsR0FBRyxHQUFDbUIsSUFBSSxDQUFDYSxXQUFXLENBQUMsY0FBYyxDQUFDO0VBQUMsTUFBTWxELE1BQU0sQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDaUMsZUFBZSxDQUFDLGNBQWMsRUFBQyxRQUFRLENBQUM7RUFBQyxNQUFNbkQsTUFBTSxDQUFDa0IsR0FBRyxDQUFDLENBQUNpQyxlQUFlLENBQUMsYUFBYSxFQUFDLFlBQVksQ0FBQztFQUFDLE1BQU1kLElBQUksQ0FBQzBCLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFDbk4sTUFBTU0sQ0FBQyxHQUFDLE1BQU1yRCxRQUFRLENBQUNDLEdBQUcsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUNXLFFBQVEsQ0FBQ3ZCLEdBQUcsQ0FBQyxNQUFNWSxHQUFHLENBQUNpRCxVQUFVLENBQUM7SUFBQ0MsSUFBSSxFQUFDLEdBQUd6RCxRQUFRLElBQUk0QixJQUFJLENBQUM4QixPQUFPLENBQUNoQixJQUFJLElBQUk0RyxPQUFPO0VBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzFGLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDbkQsQ0FBQyxFQUFDbUQsQ0FBQyxDQUFDbEQsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzFKLENBQUMsQ0FBQztBQUNGLEtBQUksTUFBTTJKLFNBQVMsSUFBSSxDQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsRUFBQzlLLElBQUksQ0FBQyxpREFBaUQ4SyxTQUFTLEdBQUMsNEJBQTRCLEdBQUMsRUFBRSxFQUFFLEVBQUMsT0FBTTtFQUFDMUk7QUFBSSxDQUFDLEVBQUNFLElBQUksS0FBRztFQUN6SixNQUFNTyxNQUFlLEdBQUMsRUFBRTtFQUFDVCxJQUFJLENBQUNJLEVBQUUsQ0FBQyxXQUFXLEVBQUNNLENBQUMsSUFBRUQsTUFBTSxDQUFDSCxJQUFJLENBQUNJLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDdkUsTUFBTVgsSUFBSSxDQUFDNkgsYUFBYSxDQUFDYyxNQUFNLElBQUU7SUFBQ1osTUFBTSxDQUFDQyxjQUFjLENBQUNHLFNBQVMsRUFBQyxLQUFLLEVBQUM7TUFBQ0QsS0FBSyxFQUFDUyxNQUFNLEdBQUM7UUFBQ04sY0FBYyxFQUFDLE1BQUFBLENBQUEsS0FBUztNQUFJLENBQUMsR0FBQ0Q7SUFBUyxDQUFDLENBQUM7SUFBQyxNQUFNUSxRQUFRLEdBQUNDLGlCQUFpQixDQUFDQyxTQUFTLENBQUNDLFVBQVU7SUFBQ0YsaUJBQWlCLENBQUNDLFNBQVMsQ0FBQ0MsVUFBVSxHQUFDLFVBQWdDeEUsSUFBVyxFQUFDLEdBQUd5RSxJQUFjLEVBQUM7TUFBQyxJQUFHekUsSUFBSSxLQUFHLFFBQVEsRUFBQyxPQUFPLElBQUk7TUFBQyxPQUFPMEUsT0FBTyxDQUFDQyxLQUFLLENBQUNOLFFBQVEsRUFBQyxJQUFJLEVBQUMsQ0FBQ3JFLElBQUksRUFBQyxHQUFHeUUsSUFBSSxDQUFDLENBQUM7SUFBQyxDQUFvQjtFQUFDLENBQUMsRUFBQ04sU0FBUyxDQUFDO0VBQ2haLE1BQU0xSSxJQUFJLENBQUNZLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNakQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDZSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ3VCLGFBQWEsQ0FBQyx1Q0FBdUMsQ0FBQztFQUFDLE1BQU0zRSxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDK0csV0FBVyxDQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1uSixJQUFJLENBQUNlLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQ3dCLFlBQVksQ0FBQyxJQUFJLENBQUM7RUFBQyxNQUFNNUUsTUFBTSxDQUFDcUMsSUFBSSxDQUFDZSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ3VCLGFBQWEsQ0FBQyxhQUFhLENBQUM7RUFDeFQsTUFBTXRDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDTSxLQUFLLENBQUMsQ0FBQztFQUFDLE1BQU14RCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDTyxVQUFVLENBQUMsSUFBSSxDQUFDO0VBQ2hHLE1BQU1nSSxJQUFJLEdBQUMsTUFBTXBKLElBQUksQ0FBQ2EsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDd0ksV0FBVyxDQUFDLENBQUM7RUFBQyxNQUFNMUwsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ3lCLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFBQyxNQUFNM0UsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUN1QixPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDaEIsVUFBVSxDQUFDLEdBQUcsQ0FBQztFQUM3TixNQUFNcEIsSUFBSSxDQUFDZSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUN3QixZQUFZLENBQUMsSUFBSSxDQUFDO0VBQUMsTUFBTTVFLE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2UsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUN1QixhQUFhLENBQUMsdUNBQXVDLENBQUM7RUFBQyxNQUFNM0UsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQ08sVUFBVSxDQUFDZ0ksSUFBSyxDQUFDO0VBQUMsTUFBTXpMLE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUN5QixhQUFhLENBQUMsc0JBQXNCLENBQUM7RUFDL1IzRSxNQUFNLENBQUM4QyxNQUFNLENBQUMsQ0FBQytCLE9BQU8sQ0FBQyxFQUFFLENBQUM7RUFDMUIxRSxhQUFhLENBQUMsR0FBR1EsUUFBUSxJQUFJNEIsSUFBSSxDQUFDOEIsT0FBTyxDQUFDaEIsSUFBSSxlQUFlMEgsU0FBUyxHQUFDLFdBQVcsR0FBQyxRQUFRLE9BQU8sRUFBQ3ZKLElBQUksQ0FBQzJELFNBQVMsQ0FBQztJQUFDNEYsU0FBUztJQUFDakksTUFBTTtJQUFDMkksSUFBSTtJQUFDRSxNQUFNLEVBQUMsQ0FBQztJQUFDQyxrQkFBa0IsRUFBQztFQUFJLENBQUMsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEwsQ0FBQyxDQUFDO0FBQ0YzTCxJQUFJLENBQUMsNEVBQTRFLEVBQUMsT0FBTTtFQUFDb0M7QUFBSSxDQUFDLEtBQUc7RUFDaEcsTUFBTUEsSUFBSSxDQUFDNkgsYUFBYSxDQUFDLE1BQUk7SUFBQ0UsTUFBTSxDQUFDQyxjQUFjLENBQUNHLFNBQVMsRUFBQyxLQUFLLEVBQUM7TUFBQ0QsS0FBSyxFQUFDRTtJQUFTLENBQUMsQ0FBQztJQUFDLE1BQU1RLFFBQVEsR0FBQ1ksc0JBQXNCLENBQUNWLFNBQVMsQ0FBQ1csWUFBWTtJQUFDRCxzQkFBc0IsQ0FBQ1YsU0FBUyxDQUFDVyxZQUFZLEdBQUMsVUFBU0MsU0FBZ0IsRUFBQztNQUFDLE9BQU9BLFNBQVMsS0FBRyxJQUFJLENBQUNDLGdCQUFnQixHQUFDLEdBQUcsR0FBQ2YsUUFBUSxDQUFDZ0IsSUFBSSxDQUFDLElBQUksRUFBQ0YsU0FBUyxDQUFDO0lBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUM1UyxNQUFNMUosSUFBSSxDQUFDWSxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQUMsTUFBTWpELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2UsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUN1QixhQUFhLENBQUMsdUNBQXVDLENBQUM7RUFBQyxNQUFNM0UsTUFBTSxDQUFDcUMsSUFBSSxDQUFDYSxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUN1QixPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQytHLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDbE0sQ0FBQyxDQUFDO0FBQ0Z2TCxJQUFJLENBQUMsMEVBQTBFLEVBQUMsT0FBTTtFQUFDb0MsSUFBSTtFQUFDeUU7QUFBTyxDQUFDLEtBQUc7RUFDdEcsTUFBTXRFLFFBQWlCLEdBQUMsRUFBRTtFQUFDSCxJQUFJLENBQUNJLEVBQUUsQ0FBQyxTQUFTLEVBQUNDLENBQUMsSUFBRUYsUUFBUSxDQUFDRyxJQUFJLENBQUNELENBQUMsQ0FBQ0UsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTVAsSUFBSSxDQUFDaUUsS0FBSyxDQUFDLDhCQUE4QixFQUFDNUQsQ0FBQyxJQUFFQSxDQUFDLENBQUMrRSxPQUFPLENBQUM7SUFBQ3lFLE1BQU0sRUFBQztFQUFHLENBQUMsQ0FBQyxDQUFDO0VBQUMsTUFBTTdKLElBQUksQ0FBQ1ksSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUFDLE1BQU1qRCxNQUFNLENBQUNxQyxJQUFJLENBQUNlLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDdUIsYUFBYSxDQUFDLDhCQUE4QixDQUFDO0VBQUMzRSxNQUFNLENBQUN3QyxRQUFRLENBQUNzQyxLQUFLLENBQUNDLENBQUMsSUFBRSxJQUFJQyxHQUFHLENBQUNELENBQUMsQ0FBQyxDQUFDRSxJQUFJLEtBQUcsSUFBSUQsR0FBRyxDQUFDM0MsSUFBSSxDQUFDTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNxQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzdVbEYsTUFBTSxDQUFDLENBQUMsTUFBTThHLE9BQU8sQ0FBQ1EsR0FBRyxDQUFDLHdCQUF3QixDQUFDLEVBQUU0RSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNoSCxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQUNsRixNQUFNLENBQUMsQ0FBQyxNQUFNOEcsT0FBTyxDQUFDUSxHQUFHLENBQUMscUNBQXFDLENBQUMsRUFBRTRFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ2hILElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQ2xGLE1BQU0sQ0FBQyxDQUFDLE1BQU04RyxPQUFPLENBQUNRLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxFQUFFNEUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDaEgsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUMxTyxDQUFDLENBQUM7QUFDRixLQUFJLE1BQU1pSCxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUMsZUFBZSxFQUFDLFdBQVcsRUFBQyxjQUFjLEVBQUMsVUFBVSxFQUFDLFlBQVksRUFBQyxXQUFXLENBQUMsRUFBQ2xNLElBQUksQ0FBQyw4QkFBOEJrTSxPQUFPLHFCQUFxQixFQUFDLE9BQU07RUFBQzlKLElBQUk7RUFBQ3lFO0FBQU8sQ0FBQyxLQUFHO0VBQ3pNLE1BQU1PLElBQUksR0FBQyxNQUFNLENBQUMsTUFBTVAsT0FBTyxDQUFDUSxHQUFHLENBQUMseUJBQXlCLENBQUMsRUFBRUMsSUFBSSxDQUFDLENBQUM7RUFDdEUsTUFBTUksS0FBSyxHQUFDLE1BQU0sQ0FBQyxNQUFNYixPQUFPLENBQUNRLEdBQUcsQ0FBQyxpQ0FBaUNELElBQUksQ0FBQ1EsU0FBUyxFQUFFLENBQUMsRUFBRUgsSUFBSSxDQUFDLENBQUM7RUFDL0YsSUFBR3lFLE9BQU8sS0FBRyxZQUFZLEVBQUMsT0FBTzlFLElBQUksQ0FBQytFLGNBQWM7RUFBQyxJQUFHRCxPQUFPLEtBQUcsZUFBZSxFQUFDOUUsSUFBSSxDQUFDK0UsY0FBYyxHQUFDLEtBQUs7RUFDM0csSUFBR0QsT0FBTyxLQUFHLFdBQVcsRUFBQzlFLElBQUksQ0FBQ1EsU0FBUyxHQUFDLGtCQUFrQjtFQUFDLElBQUdzRSxPQUFPLEtBQUcsY0FBYyxFQUFDOUUsSUFBSSxDQUFDZ0YsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFDaEYsSUFBSSxDQUFDZ0YsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUFDLElBQUdGLE9BQU8sS0FBRyxVQUFVLEVBQUM5RSxJQUFJLENBQUNtQixLQUFLLENBQUM4RCxTQUFTLEdBQUMsQ0FBQztFQUMvSyxJQUFHSCxPQUFPLEtBQUcsV0FBVyxFQUFDOUUsSUFBSSxDQUFDa0YsVUFBVSxHQUFDLGtCQUFrQjtFQUMzRCxNQUFNbEssSUFBSSxDQUFDaUUsS0FBSyxDQUFDLDJCQUEyQixFQUFDNUQsQ0FBQyxJQUFFQSxDQUFDLENBQUMrRSxPQUFPLENBQUM7SUFBQ0YsSUFBSSxFQUFDRjtFQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ3ZFLElBQUc4RSxPQUFPLEtBQUcsWUFBWSxFQUFDLE1BQU05SixJQUFJLENBQUNpRSxLQUFLLENBQUMsOEJBQThCLEVBQUM1RCxDQUFDLElBQUVBLENBQUMsQ0FBQytFLE9BQU8sQ0FBQztJQUFDQyxJQUFJLEVBQUNDLEtBQUssQ0FBQzZFLFFBQVEsQ0FBQyxDQUFDLEVBQUM3RSxLQUFLLENBQUM4RSxNQUFNLEdBQUMsQ0FBQyxDQUFDO0lBQUM3RSxPQUFPLEVBQUM7TUFBQyxhQUFhLEVBQUNQLElBQUksQ0FBQ1E7SUFBUztFQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3ZLLE1BQU14RixJQUFJLENBQUNZLElBQUksQ0FBQyxHQUFHLENBQUM7RUFBQyxNQUFNakQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDZSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ3VCLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQztFQUFDLE1BQU0zRSxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDK0csV0FBVyxDQUFDLENBQUMsQ0FBQztFQUFDLE1BQU14TCxNQUFNLENBQUNxQyxJQUFJLENBQUNhLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDeUIsYUFBYSxDQUFDLHNCQUFzQixDQUFDO0FBQy9RLENBQUMsQ0FBQztBQUNGLEtBQUksTUFBTXdILE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBQyxtQkFBbUIsRUFBQyxjQUFjLENBQUMsRUFBQ2xNLElBQUksQ0FBQyxjQUFja00sT0FBTywyQ0FBMkMsRUFBQyxPQUFNO0VBQUM5SjtBQUFJLENBQUMsS0FBRztFQUN6SixJQUFJd0csS0FBSyxHQUFDLENBQUM7RUFBQyxNQUFNeEcsSUFBSSxDQUFDZ0UsY0FBYyxDQUFDLE9BQU8sRUFBQ0MsS0FBSyxJQUFFO0lBQUMsTUFBTUMsTUFBTSxHQUFDRCxLQUFLLENBQUNFLGVBQWUsQ0FBQyxDQUFDO0lBQUNELE1BQU0sQ0FBQ0UsU0FBUyxDQUFDQyxJQUFJLElBQUU7TUFBQyxNQUFNQyxDQUFDLEdBQUNuRyxNQUFNLENBQUNrRyxJQUFjLENBQWtCO01BQUMsSUFBR0MsQ0FBQyxDQUFDQyxJQUFJLEtBQUcsYUFBYSxJQUFFRCxDQUFDLENBQUNFLEtBQUssSUFBRSxFQUFFZ0MsS0FBSyxJQUFFLENBQUMsRUFBQztRQUFDLElBQUdzRCxPQUFPLEtBQUcsVUFBVSxFQUFDeEYsQ0FBQyxDQUFDRSxLQUFLLENBQUNFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzJGLEtBQUssR0FBQyxLQUFLO1FBQUMsSUFBR1AsT0FBTyxLQUFHLG1CQUFtQixFQUFDeEYsQ0FBQyxDQUFDRSxLQUFLLENBQUNsRixLQUFLLEVBQUU7UUFBQyxJQUFHd0ssT0FBTyxLQUFHLGNBQWMsRUFBQ3hGLENBQUMsQ0FBQ0UsS0FBSyxDQUFDd0YsWUFBWSxDQUFDTSxPQUFPLENBQUMsQ0FBQztRQUFDckcsS0FBSyxDQUFDVyxJQUFJLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDNUcsTUFBTSxDQUFDb0csQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDLENBQUMsTUFBS0wsS0FBSyxDQUFDVyxJQUFJLENBQUNQLElBQUksQ0FBQztJQUFDLENBQUMsQ0FBQztFQUFDLENBQUMsQ0FBQztFQUN2YixNQUFNckUsSUFBSSxDQUFDWSxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQUMsTUFBTS9CLEdBQUcsR0FBQ21CLElBQUksQ0FBQ2EsV0FBVyxDQUFDLGNBQWMsQ0FBQztFQUFDLE1BQU1sRCxNQUFNLENBQUNrQixHQUFHLENBQUMsQ0FBQ2lDLGVBQWUsQ0FBQyxhQUFhLEVBQUMsWUFBWSxDQUFDO0VBQUMsTUFBTW5ELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNPLFVBQVUsQ0FBQyxjQUFjLENBQUM7RUFBQyxNQUFNekQsTUFBTSxDQUFDcUMsSUFBSSxDQUFDZSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0ssVUFBVSxDQUFDLDJDQUEyQyxDQUFDO0VBQUMsTUFBTXpELE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMwSixZQUFZLENBQUMsQ0FBQztFQUMxVixNQUFNdkssSUFBSSxDQUFDMEIsS0FBSyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztFQUFDLE1BQU1pQyxLQUFLLEdBQUMsTUFBTWhGLFFBQVEsQ0FBQ0MsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFBQ1csUUFBUSxDQUFDdkIsR0FBRyxDQUFDLE1BQU1ZLEdBQUcsQ0FBQ2lELFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ksS0FBSyxDQUFDMEIsS0FBSyxDQUFDOUUsQ0FBQyxFQUFDOEUsS0FBSyxDQUFDN0UsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQUMsTUFBTXBCLE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ2EsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUN5QixhQUFhLENBQUMsc0JBQXNCLENBQUM7QUFDL04sQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119