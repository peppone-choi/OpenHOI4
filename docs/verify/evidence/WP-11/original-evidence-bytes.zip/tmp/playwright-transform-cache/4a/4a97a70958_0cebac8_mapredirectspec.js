// 0d54154a38d783f0bd46a9c09fe3bf7aa12bcb4e
var _process$env$OH_MAP_R;
import { expect, test } from '@playwright/test';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { encode, decode } from '@msgpack/msgpack';
import { mapRedirectFixture } from './mapRedirectFixture';
const evidence = (_process$env$OH_MAP_R = process.env.OH_MAP_REDIRECT_EVIDENCE) !== null && _process$env$OH_MAP_R !== void 0 ? _process$env$OH_MAP_R : '../target/wp08/p06-redirect/browser';
mkdirSync(evidence, {
  recursive: true
});
for (const resource of ['metadata', 'index']) {
  for (const reload of [false, true]) {
    test(`WP08 P06 ${resource} CORS redirect sends no foreign request ${reload ? 'after valid selection' : 'on first load'}`, async ({
      page,
      context,
      request
    }, info) => {
      const metaResponse = await request.get('/maps/testland/metadata');
      const originalMeta = await metaResponse.json();
      const upstream = new URL(metaResponse.url()).origin;
      const bytes = await (await request.get(`/maps/testland/index.bin?pack=${originalMeta.pack_hash}`)).body();
      const newHash = originalMeta.pack_hash === '0000000000000000' ? '0000000000000001' : '0000000000000000';
      let hash = originalMeta.pack_hash;
      const foreignHits = [];
      const foreign = createServer((req, res) => {
        var _req$method;
        foreignHits.push({
          method: (_req$method = req.method) !== null && _req$method !== void 0 ? _req$method : '',
          url: req.url,
          origin: req.headers.origin
        });
        res.writeHead(200, {
          'content-type': resource === 'metadata' ? 'application/json' : 'application/octet-stream',
          'access-control-allow-origin': '*',
          'access-control-expose-headers': 'x-pack-hash',
          'x-pack-hash': hash
        });
        res.end(resource === 'metadata' ? JSON.stringify({
          ...originalMeta,
          pack_hash: hash
        }) : bytes);
      });
      foreign.listen(0, '127.0.0.1');
      await once(foreign, 'listening');
      const address = foreign.address();
      if (!address || typeof address === 'string') throw new Error('foreign fixture address');
      const foreignURL = `http://127.0.0.1:${address.port}/payload`;
      const requests = [],
        errors = [],
        redirects = [];
      const failures = [];
      page.on('request', r => requests.push(r.url()));
      page.on('pageerror', e => errors.push(e.message));
      page.on('response', r => {
        if (r.status() === 302) redirects.push({
          url: r.url(),
          status: r.status(),
          location: r.headers().location
        });
      });
      page.on('requestfailed', r => {
        var _r$failure;
        return failures.push({
          url: r.url(),
          error: (_r$failure = r.failure()) === null || _r$failure === void 0 ? void 0 : _r$failure.errorText
        });
      });
      let shouldRedirect = !reload,
        sendIdentity = false,
        injectedIdentity = false;
      const source = await mapRedirectFixture(upstream, {
        resource,
        location: () => foreignURL,
        redirect: () => shouldRedirect,
        metadata: () => reload && resource === 'index' && injectedIdentity ? {
          ...originalMeta,
          pack_hash: hash
        } : undefined
      });
      let controlEvidence;
      let before,
        preserved,
        cameraBefore = null,
        rejectedRequestStartIndex = 0;
      const readUI = async () => ({
        date: await page.getByTestId('date').textContent(),
        hour: await page.getByTestId('hour').textContent(),
        tick: await page.getByTestId('tick').textContent(),
        selected: await page.getByTestId('selected-province').textContent(),
        worldTick: await page.getByTestId('national-panels').getAttribute('data-world-tick'),
        state: await page.getByTestId('state-panel').locator('h3').textContent(),
        country: await page.getByTestId('country-panel').locator('h3').textContent(),
        ledger: await page.getByTestId('state-panel').locator('.ledger-value strong').textContent()
      });
      try {
        // Positive control proves a native browser can consume this actual CORS 200
        // response through a real 302. The game page is a separate negative control.
        const control = await context.newPage();
        const controlRedirects = [];
        control.on('response', r => {
          if (r.status() === 302) controlRedirects.push({
            status: r.status(),
            location: r.headers().location
          });
        });
        await control.goto(`${source.origin}/fonts/OFL.txt`);
        const redirectProbe = await request.get(`${source.origin}/map-fetch-control`, {
          maxRedirects: 0
        });
        expect(redirectProbe.status()).toBe(302);
        expect(redirectProbe.headers().location).toBe(foreignURL);
        controlEvidence = await control.evaluate(async () => {
          const response = await fetch('/map-fetch-control', {
            mode: 'cors',
            redirect: 'follow'
          });
          return {
            status: response.status,
            url: response.url,
            redirected: response.redirected,
            cors: response.type,
            packHash: response.headers.get('x-pack-hash'),
            body: Array.from(new Uint8Array(await response.arrayBuffer()))
          };
        });
        const controlResult = controlEvidence;
        expect(controlResult).toMatchObject({
          status: 200,
          url: foreignURL,
          redirected: true,
          cors: 'cors',
          packHash: hash
        });
        expect(Buffer.from(controlResult.body)).toEqual(resource === 'metadata' ? Buffer.from(JSON.stringify(originalMeta)) : bytes);
        expect(foreignHits).toHaveLength(1);
        expect(source.sent.filter(r => r.url === '/map-fetch-control')).toHaveLength(2);
        controlEvidence = {
          ...controlResult,
          body: undefined,
          controlRedirects,
          redirectProbe: {
            status: redirectProbe.status(),
            location: redirectProbe.headers().location
          },
          bodyLength: controlResult.body.length,
          bodySha256: createHash('sha256').update(Buffer.from(controlResult.body)).digest('hex')
        };
        await control.close();
        foreignHits.length = 0;
        source.sent.length = 0;
        let welcome;
        if (reload) await page.routeWebSocket('**/ws', route => {
          const server = route.connectToServer();
          server.onMessage(data => {
            const m = decode(data);
            if (m.type === 'Welcome') welcome = m;
            route.send(data);
          });
          route.onMessage(data => {
            const m = decode(data);
            // This test-only identity reload exercises the existing MapView effect.
            // Authority values and the original world remain unmodified.
            if (injectedIdentity && m.type === 'Join') return;
            if (sendIdentity && m.type === 'Query') {
              sendIdentity = false;
              injectedIdentity = true;
              hash = newHash;
              route.send(Buffer.from(encode({
                ...welcome,
                packs: welcome.packs.map(p => ({
                  ...p,
                  hash
                }))
              })));
            }
            server.send(data);
          });
        });
        await page.goto(`${source.origin}/?forceWebGL=1`);
        const map = page.getByTestId('province-map');
        if (reload) {
          await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
          await page.getByTestId('pause').click();
          await expect(page.getByTestId('pause')).toHaveText('Resume');
          const box = await map.boundingBox(),
            camera = JSON.parse(await map.getAttribute('data-camera'));
          await map.click({
            position: {
              x: (1 - camera.x) / camera.width * box.width + box.width / 2,
              y: (3 - camera.y) / camera.height * box.height + box.height / 2
            }
          });
          await expect(page.getByTestId('selected-province')).toHaveText('30');
          await expect(page.getByTestId('state-panel').locator('h3')).toHaveText('Southern Test State');
          before = await readUI();
          cameraBefore = await map.getAttribute('data-camera');
          rejectedRequestStartIndex = requests.length;
          shouldRedirect = true;
          sendIdentity = true;
          await page.getByTestId('state-panel').getByRole('button', {
            name: 'Southern Test State',
            exact: true
          }).click();
        }
        await expect(page.getByRole('alert')).toHaveText('Map data could not be loaded. Check the bundled scenario files.');
        await expect(map.locator('canvas')).toHaveCount(0);
        expect(foreignHits).toEqual([]);
        expect(requests.every(url => new URL(url).origin === new URL(page.url()).origin)).toBe(true);
        // Engines report redirect:error through different event channels. The
        // actual HTTP 302, one source GET, zero foreign GETs and UI are invariant.
        expect(source.sent).toHaveLength(1);
        expect(source.sent[0]).toMatchObject({
          status: 302,
          location: foreignURL
        });
        expect(requests.slice(rejectedRequestStartIndex).filter(url => url === source.origin + source.sent[0].url)).toHaveLength(1);
        await expect(page.getByTestId('connection')).toHaveText('Connected');
        if (before) {
          await expect(page.getByTestId('tick')).toHaveText(before.tick);
          await expect(page.getByTestId('selected-province')).toHaveText('30');
          await expect(page.getByTestId('state-panel').locator('h3')).toHaveText(before.state);
          await expect(page.getByTestId('country-panel').locator('h3')).toHaveText(before.country);
          await expect(page.getByTestId('state-panel').locator('.ledger-value strong')).toHaveText('0');
          preserved = await readUI();
          expect(preserved).toEqual(before);
        } else {
          await expect(page.getByTestId('selected-province')).toHaveText('—');
          await expect(page.getByTestId('state-panel').locator('h3')).toHaveText('Northern Test State');
          await expect(page.getByTestId('country-panel').locator('h3')).toHaveText('Northern Test Nation');
        }
        await page.getByRole('combobox').selectOption('ko');
        await expect(page.getByRole('alert')).toHaveText('지도 데이터를 불러올 수 없습니다. 동봉된 시나리오 파일을 확인하세요.');
        // WebKit reports this exact native blocked-fetch diagnostic as pageerror
        // even when fetch is caught; no other JavaScript error is accepted.
        const blockedFetch = `${source.origin.replace(/^http:\//, '')}${source.sent[0].url} due to access control checks.`;
        expect(errors.filter(e => !(info.project.use.browserName === 'webkit' && e === blockedFetch))).toEqual([]);
      } finally {
        try {
          writeFileSync(`${evidence}/${info.project.name}-${resource}-${reload}.json`, JSON.stringify({
            resource,
            reload,
            controlEvidence,
            sourceOrigin: source.origin,
            foreignURL,
            foreignHits,
            requests,
            rejectedRequestStartIndex,
            actualSourceRedirects: source.sent,
            failures,
            responseEvents: redirects,
            errors,
            before,
            preserved,
            cameraBefore,
            rendererOutcome: 'initial load creates no renderer; identity reload disposes previous renderer, keeps authority UI/selection only',
            alerts: await page.getByRole('alert').allTextContents(),
            canvasCount: await page.getByTestId('province-map').locator('canvas').count()
          }, null, 2));
          await page.screenshot({
            path: `${evidence}/${info.project.name}-${resource}-${reload}.png`
          });
        } finally {
          await source.close();
          await new Promise((resolve, reject) => {
            foreign.close(error => error ? reject(error) : resolve());
            foreign.closeAllConnections();
          });
        }
      }
    });
  }
}
for (const resource of ['metadata', 'index']) test(`WP08 P06 ${resource} same-origin redirect is also rejected before follow`, async ({
  page,
  request
}, info) => {
  const metaResponse = await request.get('/maps/testland/metadata'),
    meta = await metaResponse.json();
  const path = resource === 'metadata' ? '/maps/testland/metadata' : `/maps/testland/index.bin?pack=${meta.pack_hash}`;
  const alias = `${path}${resource === 'metadata' ? '?' : '&'}alias=1`;
  const source = await mapRedirectFixture(new URL(metaResponse.url()).origin, {
    resource,
    location: () => alias,
    redirect: () => true
  });
  const direct = await request.get(source.origin + alias);
  expect(direct.status()).toBe(200);
  const probe = await request.get(source.origin + path, {
    maxRedirects: 0
  });
  expect(probe.status()).toBe(302);
  expect(probe.headers().location).toBe(alias);
  source.sent.length = 0;
  const requests = [];
  page.on('request', r => requests.push(r.url()));
  try {
    await page.goto(`${source.origin}/?forceWebGL=1`);
    await expect(page.getByRole('alert')).toHaveText('Map data could not be loaded. Check the bundled scenario files.');
    await expect(page.getByTestId('province-map').locator('canvas')).toHaveCount(0);
    expect(requests.filter(url => new URL(url).searchParams.has('alias'))).toEqual([]);
    expect(source.sent).toEqual([{
      url: path,
      status: 302,
      location: alias
    }]);
  } finally {
    try {
      writeFileSync(`${evidence}/${info.project.name}-${resource}-local.json`, JSON.stringify({
        path,
        alias,
        directStatus: direct.status(),
        actualSourceRedirects: source.sent,
        requests,
        alerts: await page.getByRole('alert').allTextContents()
      }, null, 2));
    } finally {
      await source.close();
    }
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwiY3JlYXRlU2VydmVyIiwib25jZSIsIm1rZGlyU3luYyIsIndyaXRlRmlsZVN5bmMiLCJjcmVhdGVIYXNoIiwiZW5jb2RlIiwiZGVjb2RlIiwibWFwUmVkaXJlY3RGaXh0dXJlIiwiZXZpZGVuY2UiLCJfcHJvY2VzcyRlbnYkT0hfTUFQX1IiLCJwcm9jZXNzIiwiZW52IiwiT0hfTUFQX1JFRElSRUNUX0VWSURFTkNFIiwicmVjdXJzaXZlIiwicmVzb3VyY2UiLCJyZWxvYWQiLCJwYWdlIiwiY29udGV4dCIsInJlcXVlc3QiLCJpbmZvIiwibWV0YVJlc3BvbnNlIiwiZ2V0Iiwib3JpZ2luYWxNZXRhIiwianNvbiIsInVwc3RyZWFtIiwiVVJMIiwidXJsIiwib3JpZ2luIiwiYnl0ZXMiLCJwYWNrX2hhc2giLCJib2R5IiwibmV3SGFzaCIsImhhc2giLCJmb3JlaWduSGl0cyIsImZvcmVpZ24iLCJyZXEiLCJyZXMiLCJfcmVxJG1ldGhvZCIsInB1c2giLCJtZXRob2QiLCJoZWFkZXJzIiwid3JpdGVIZWFkIiwiZW5kIiwiSlNPTiIsInN0cmluZ2lmeSIsImxpc3RlbiIsImFkZHJlc3MiLCJFcnJvciIsImZvcmVpZ25VUkwiLCJwb3J0IiwicmVxdWVzdHMiLCJlcnJvcnMiLCJyZWRpcmVjdHMiLCJmYWlsdXJlcyIsIm9uIiwiciIsImUiLCJtZXNzYWdlIiwic3RhdHVzIiwibG9jYXRpb24iLCJfciRmYWlsdXJlIiwiZXJyb3IiLCJmYWlsdXJlIiwiZXJyb3JUZXh0Iiwic2hvdWxkUmVkaXJlY3QiLCJzZW5kSWRlbnRpdHkiLCJpbmplY3RlZElkZW50aXR5Iiwic291cmNlIiwicmVkaXJlY3QiLCJtZXRhZGF0YSIsInVuZGVmaW5lZCIsImNvbnRyb2xFdmlkZW5jZSIsImJlZm9yZSIsInByZXNlcnZlZCIsImNhbWVyYUJlZm9yZSIsInJlamVjdGVkUmVxdWVzdFN0YXJ0SW5kZXgiLCJyZWFkVUkiLCJkYXRlIiwiZ2V0QnlUZXN0SWQiLCJ0ZXh0Q29udGVudCIsImhvdXIiLCJ0aWNrIiwic2VsZWN0ZWQiLCJ3b3JsZFRpY2siLCJnZXRBdHRyaWJ1dGUiLCJzdGF0ZSIsImxvY2F0b3IiLCJjb3VudHJ5IiwibGVkZ2VyIiwiY29udHJvbCIsIm5ld1BhZ2UiLCJjb250cm9sUmVkaXJlY3RzIiwiZ290byIsInJlZGlyZWN0UHJvYmUiLCJtYXhSZWRpcmVjdHMiLCJ0b0JlIiwiZXZhbHVhdGUiLCJyZXNwb25zZSIsImZldGNoIiwibW9kZSIsInJlZGlyZWN0ZWQiLCJjb3JzIiwidHlwZSIsInBhY2tIYXNoIiwiQXJyYXkiLCJmcm9tIiwiVWludDhBcnJheSIsImFycmF5QnVmZmVyIiwiY29udHJvbFJlc3VsdCIsInRvTWF0Y2hPYmplY3QiLCJCdWZmZXIiLCJ0b0VxdWFsIiwidG9IYXZlTGVuZ3RoIiwic2VudCIsImZpbHRlciIsImJvZHlMZW5ndGgiLCJsZW5ndGgiLCJib2R5U2hhMjU2IiwidXBkYXRlIiwiZGlnZXN0IiwiY2xvc2UiLCJ3ZWxjb21lIiwicm91dGVXZWJTb2NrZXQiLCJyb3V0ZSIsInNlcnZlciIsImNvbm5lY3RUb1NlcnZlciIsIm9uTWVzc2FnZSIsImRhdGEiLCJtIiwic2VuZCIsInBhY2tzIiwibWFwIiwicCIsInRvSGF2ZUF0dHJpYnV0ZSIsImNsaWNrIiwidG9IYXZlVGV4dCIsImJveCIsImJvdW5kaW5nQm94IiwiY2FtZXJhIiwicGFyc2UiLCJwb3NpdGlvbiIsIngiLCJ3aWR0aCIsInkiLCJoZWlnaHQiLCJnZXRCeVJvbGUiLCJuYW1lIiwiZXhhY3QiLCJ0b0hhdmVDb3VudCIsImV2ZXJ5Iiwic2xpY2UiLCJzZWxlY3RPcHRpb24iLCJibG9ja2VkRmV0Y2giLCJyZXBsYWNlIiwicHJvamVjdCIsInVzZSIsImJyb3dzZXJOYW1lIiwic291cmNlT3JpZ2luIiwiYWN0dWFsU291cmNlUmVkaXJlY3RzIiwicmVzcG9uc2VFdmVudHMiLCJyZW5kZXJlck91dGNvbWUiLCJhbGVydHMiLCJhbGxUZXh0Q29udGVudHMiLCJjYW52YXNDb3VudCIsImNvdW50Iiwic2NyZWVuc2hvdCIsInBhdGgiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImNsb3NlQWxsQ29ubmVjdGlvbnMiLCJtZXRhIiwiYWxpYXMiLCJkaXJlY3QiLCJwcm9iZSIsInNlYXJjaFBhcmFtcyIsImhhcyIsImRpcmVjdFN0YXR1cyJdLCJzb3VyY2VzIjpbIm1hcC1yZWRpcmVjdC5zcGVjLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGV4cGVjdCwgdGVzdCB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuaW1wb3J0IHsgY3JlYXRlU2VydmVyIH0gZnJvbSAnbm9kZTpodHRwJztcbmltcG9ydCB7IG9uY2UgfSBmcm9tICdub2RlOmV2ZW50cyc7XG5pbXBvcnQgeyBta2RpclN5bmMsIHdyaXRlRmlsZVN5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGNyZWF0ZUhhc2ggfSBmcm9tICdub2RlOmNyeXB0byc7XG5pbXBvcnQgeyBlbmNvZGUsIGRlY29kZSB9IGZyb20gJ0Btc2dwYWNrL21zZ3BhY2snO1xuaW1wb3J0IHR5cGUgeyBDbGllbnRNZXNzYWdlLCBTZXJ2ZXJNZXNzYWdlIH0gZnJvbSAnLi4vc3JjL3Byb3RvL3Byb3RvY29sJztcbmltcG9ydCB7IG1hcFJlZGlyZWN0Rml4dHVyZSB9IGZyb20gJy4vbWFwUmVkaXJlY3RGaXh0dXJlJztcblxuY29uc3QgZXZpZGVuY2UgPSBwcm9jZXNzLmVudi5PSF9NQVBfUkVESVJFQ1RfRVZJREVOQ0UgPz8gJy4uL3RhcmdldC93cDA4L3AwNi1yZWRpcmVjdC9icm93c2VyJztcbm1rZGlyU3luYyhldmlkZW5jZSwgeyByZWN1cnNpdmU6IHRydWUgfSk7XG5cbmZvciAoY29uc3QgcmVzb3VyY2Ugb2YgWydtZXRhZGF0YScsICdpbmRleCddIGFzIGNvbnN0KSB7XG4gZm9yIChjb25zdCByZWxvYWQgb2YgW2ZhbHNlLCB0cnVlXSkge1xuICB0ZXN0KGBXUDA4IFAwNiAke3Jlc291cmNlfSBDT1JTIHJlZGlyZWN0IHNlbmRzIG5vIGZvcmVpZ24gcmVxdWVzdCAke3JlbG9hZCA/ICdhZnRlciB2YWxpZCBzZWxlY3Rpb24nIDogJ29uIGZpcnN0IGxvYWQnfWAsIGFzeW5jICh7IHBhZ2UsIGNvbnRleHQsIHJlcXVlc3QgfSwgaW5mbykgPT4ge1xuICAgY29uc3QgbWV0YVJlc3BvbnNlID0gYXdhaXQgcmVxdWVzdC5nZXQoJy9tYXBzL3Rlc3RsYW5kL21ldGFkYXRhJyk7XG4gICBjb25zdCBvcmlnaW5hbE1ldGEgPSBhd2FpdCBtZXRhUmVzcG9uc2UuanNvbigpO1xuICAgY29uc3QgdXBzdHJlYW0gPSBuZXcgVVJMKG1ldGFSZXNwb25zZS51cmwoKSkub3JpZ2luO1xuICAgY29uc3QgYnl0ZXMgPSBhd2FpdCAoYXdhaXQgcmVxdWVzdC5nZXQoYC9tYXBzL3Rlc3RsYW5kL2luZGV4LmJpbj9wYWNrPSR7b3JpZ2luYWxNZXRhLnBhY2tfaGFzaH1gKSkuYm9keSgpO1xuICAgY29uc3QgbmV3SGFzaCA9IG9yaWdpbmFsTWV0YS5wYWNrX2hhc2ggPT09ICcwMDAwMDAwMDAwMDAwMDAwJyA/ICcwMDAwMDAwMDAwMDAwMDAxJyA6ICcwMDAwMDAwMDAwMDAwMDAwJztcbiAgIGxldCBoYXNoID0gb3JpZ2luYWxNZXRhLnBhY2tfaGFzaDtcbiAgIGNvbnN0IGZvcmVpZ25IaXRzOiB7IG1ldGhvZDogc3RyaW5nOyB1cmw6IHN0cmluZyB8IHVuZGVmaW5lZDsgb3JpZ2luOiBzdHJpbmcgfCB1bmRlZmluZWQgfVtdID0gW107XG4gICBjb25zdCBmb3JlaWduID0gY3JlYXRlU2VydmVyKChyZXEsIHJlcykgPT4ge1xuICAgIGZvcmVpZ25IaXRzLnB1c2goeyBtZXRob2Q6IHJlcS5tZXRob2QgPz8gJycsIHVybDogcmVxLnVybCwgb3JpZ2luOiByZXEuaGVhZGVycy5vcmlnaW4gfSk7XG4gICAgcmVzLndyaXRlSGVhZCgyMDAsIHtcbiAgICAgJ2NvbnRlbnQtdHlwZSc6IHJlc291cmNlID09PSAnbWV0YWRhdGEnID8gJ2FwcGxpY2F0aW9uL2pzb24nIDogJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbScsXG4gICAgICdhY2Nlc3MtY29udHJvbC1hbGxvdy1vcmlnaW4nOiAnKicsXG4gICAgICdhY2Nlc3MtY29udHJvbC1leHBvc2UtaGVhZGVycyc6ICd4LXBhY2staGFzaCcsXG4gICAgICd4LXBhY2staGFzaCc6IGhhc2gsXG4gICAgfSk7XG4gICAgcmVzLmVuZChyZXNvdXJjZSA9PT0gJ21ldGFkYXRhJyA/IEpTT04uc3RyaW5naWZ5KHsgLi4ub3JpZ2luYWxNZXRhLCBwYWNrX2hhc2g6IGhhc2ggfSkgOiBieXRlcyk7XG4gICB9KTtcbiAgIGZvcmVpZ24ubGlzdGVuKDAsICcxMjcuMC4wLjEnKTsgYXdhaXQgb25jZShmb3JlaWduLCAnbGlzdGVuaW5nJyk7XG4gICBjb25zdCBhZGRyZXNzID0gZm9yZWlnbi5hZGRyZXNzKCk7IGlmICghYWRkcmVzcyB8fCB0eXBlb2YgYWRkcmVzcyA9PT0gJ3N0cmluZycpIHRocm93IG5ldyBFcnJvcignZm9yZWlnbiBmaXh0dXJlIGFkZHJlc3MnKTtcbiAgIGNvbnN0IGZvcmVpZ25VUkwgPSBgaHR0cDovLzEyNy4wLjAuMToke2FkZHJlc3MucG9ydH0vcGF5bG9hZGA7XG4gICBjb25zdCByZXF1ZXN0czogc3RyaW5nW10gPSBbXSwgZXJyb3JzOiBzdHJpbmdbXSA9IFtdLCByZWRpcmVjdHM6IHsgdXJsOiBzdHJpbmc7IHN0YXR1czogbnVtYmVyOyBsb2NhdGlvbjogc3RyaW5nIHwgdW5kZWZpbmVkIH1bXSA9IFtdO1xuICAgY29uc3QgZmFpbHVyZXM6IHsgdXJsOiBzdHJpbmc7IGVycm9yOiBzdHJpbmcgfCB1bmRlZmluZWQgfVtdID0gW107XG4gICBwYWdlLm9uKCdyZXF1ZXN0JywgciA9PiByZXF1ZXN0cy5wdXNoKHIudXJsKCkpKTsgcGFnZS5vbigncGFnZWVycm9yJywgZSA9PiBlcnJvcnMucHVzaChlLm1lc3NhZ2UpKTtcbiAgIHBhZ2Uub24oJ3Jlc3BvbnNlJywgciA9PiB7IGlmIChyLnN0YXR1cygpID09PSAzMDIpIHJlZGlyZWN0cy5wdXNoKHsgdXJsOiByLnVybCgpLCBzdGF0dXM6IHIuc3RhdHVzKCksIGxvY2F0aW9uOiByLmhlYWRlcnMoKS5sb2NhdGlvbiB9KTsgfSk7XG4gICBwYWdlLm9uKCdyZXF1ZXN0ZmFpbGVkJywgciA9PiBmYWlsdXJlcy5wdXNoKHsgdXJsOiByLnVybCgpLCBlcnJvcjogci5mYWlsdXJlKCk/LmVycm9yVGV4dCB9KSk7XG4gICBsZXQgc2hvdWxkUmVkaXJlY3QgPSAhcmVsb2FkLCBzZW5kSWRlbnRpdHkgPSBmYWxzZSwgaW5qZWN0ZWRJZGVudGl0eSA9IGZhbHNlO1xuICAgY29uc3Qgc291cmNlID0gYXdhaXQgbWFwUmVkaXJlY3RGaXh0dXJlKHVwc3RyZWFtLCB7IHJlc291cmNlLCBsb2NhdGlvbjogKCkgPT4gZm9yZWlnblVSTCwgcmVkaXJlY3Q6ICgpID0+IHNob3VsZFJlZGlyZWN0LFxuICAgIG1ldGFkYXRhOiAoKSA9PiByZWxvYWQgJiYgcmVzb3VyY2UgPT09ICdpbmRleCcgJiYgaW5qZWN0ZWRJZGVudGl0eSA/IHsgLi4ub3JpZ2luYWxNZXRhLCBwYWNrX2hhc2g6IGhhc2ggfSA6IHVuZGVmaW5lZCxcbiAgIH0pO1xuICAgbGV0IGNvbnRyb2xFdmlkZW5jZTogdW5rbm93bjtcbiAgIHR5cGUgVUlTdGF0ZSA9IHsgZGF0ZTogc3RyaW5nIHwgbnVsbDsgaG91cjogc3RyaW5nIHwgbnVsbDsgdGljazogc3RyaW5nIHwgbnVsbDsgc2VsZWN0ZWQ6IHN0cmluZyB8IG51bGw7IHdvcmxkVGljazogc3RyaW5nIHwgbnVsbDsgc3RhdGU6IHN0cmluZyB8IG51bGw7IGNvdW50cnk6IHN0cmluZyB8IG51bGw7IGxlZGdlcjogc3RyaW5nIHwgbnVsbCB9O1xuICAgbGV0IGJlZm9yZTogVUlTdGF0ZSB8IHVuZGVmaW5lZCwgcHJlc2VydmVkOiBVSVN0YXRlIHwgdW5kZWZpbmVkLCBjYW1lcmFCZWZvcmU6IHN0cmluZyB8IG51bGwgPSBudWxsLCByZWplY3RlZFJlcXVlc3RTdGFydEluZGV4ID0gMDtcbiAgIGNvbnN0IHJlYWRVSSA9IGFzeW5jICgpOiBQcm9taXNlPFVJU3RhdGU+ID0+ICh7IGRhdGU6IGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ2RhdGUnKS50ZXh0Q29udGVudCgpLCBob3VyOiBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdob3VyJykudGV4dENvbnRlbnQoKSwgdGljazogYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgndGljaycpLnRleHRDb250ZW50KCksIHNlbGVjdGVkOiBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpLnRleHRDb250ZW50KCksIHdvcmxkVGljazogYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnbmF0aW9uYWwtcGFuZWxzJykuZ2V0QXR0cmlidXRlKCdkYXRhLXdvcmxkLXRpY2snKSwgc3RhdGU6IGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykubG9jYXRvcignaDMnKS50ZXh0Q29udGVudCgpLCBjb3VudHJ5OiBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdjb3VudHJ5LXBhbmVsJykubG9jYXRvcignaDMnKS50ZXh0Q29udGVudCgpLCBsZWRnZXI6IGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykubG9jYXRvcignLmxlZGdlci12YWx1ZSBzdHJvbmcnKS50ZXh0Q29udGVudCgpIH0pO1xuICAgdHJ5IHtcbiAgICAvLyBQb3NpdGl2ZSBjb250cm9sIHByb3ZlcyBhIG5hdGl2ZSBicm93c2VyIGNhbiBjb25zdW1lIHRoaXMgYWN0dWFsIENPUlMgMjAwXG4gICAgLy8gcmVzcG9uc2UgdGhyb3VnaCBhIHJlYWwgMzAyLiBUaGUgZ2FtZSBwYWdlIGlzIGEgc2VwYXJhdGUgbmVnYXRpdmUgY29udHJvbC5cbiAgICBjb25zdCBjb250cm9sID0gYXdhaXQgY29udGV4dC5uZXdQYWdlKCk7XG4gICAgY29uc3QgY29udHJvbFJlZGlyZWN0czogeyBzdGF0dXM6IG51bWJlcjsgbG9jYXRpb246IHN0cmluZyB8IHVuZGVmaW5lZCB9W10gPSBbXTtcbiAgICBjb250cm9sLm9uKCdyZXNwb25zZScsIHIgPT4geyBpZiAoci5zdGF0dXMoKSA9PT0gMzAyKSBjb250cm9sUmVkaXJlY3RzLnB1c2goeyBzdGF0dXM6IHIuc3RhdHVzKCksIGxvY2F0aW9uOiByLmhlYWRlcnMoKS5sb2NhdGlvbiB9KTsgfSk7XG4gICAgYXdhaXQgY29udHJvbC5nb3RvKGAke3NvdXJjZS5vcmlnaW59L2ZvbnRzL09GTC50eHRgKTtcbiAgICBjb25zdCByZWRpcmVjdFByb2JlID0gYXdhaXQgcmVxdWVzdC5nZXQoYCR7c291cmNlLm9yaWdpbn0vbWFwLWZldGNoLWNvbnRyb2xgLCB7IG1heFJlZGlyZWN0czogMCB9KTtcbiAgICBleHBlY3QocmVkaXJlY3RQcm9iZS5zdGF0dXMoKSkudG9CZSgzMDIpOyBleHBlY3QocmVkaXJlY3RQcm9iZS5oZWFkZXJzKCkubG9jYXRpb24pLnRvQmUoZm9yZWlnblVSTCk7XG4gICAgY29udHJvbEV2aWRlbmNlID0gYXdhaXQgY29udHJvbC5ldmFsdWF0ZShhc3luYyAoKSA9PiB7XG4gICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9tYXAtZmV0Y2gtY29udHJvbCcsIHsgbW9kZTogJ2NvcnMnLCByZWRpcmVjdDogJ2ZvbGxvdycgfSk7XG4gICAgIHJldHVybiB7IHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLCB1cmw6IHJlc3BvbnNlLnVybCwgcmVkaXJlY3RlZDogcmVzcG9uc2UucmVkaXJlY3RlZCwgY29yczogcmVzcG9uc2UudHlwZSwgcGFja0hhc2g6IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCd4LXBhY2staGFzaCcpLCBib2R5OiBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGF3YWl0IHJlc3BvbnNlLmFycmF5QnVmZmVyKCkpKSB9O1xuICAgIH0pO1xuICAgIGNvbnN0IGNvbnRyb2xSZXN1bHQgPSBjb250cm9sRXZpZGVuY2UgYXMgeyBzdGF0dXM6IG51bWJlcjsgdXJsOiBzdHJpbmc7IHJlZGlyZWN0ZWQ6IGJvb2xlYW47IGNvcnM6IHN0cmluZzsgcGFja0hhc2g6IHN0cmluZzsgYm9keTogbnVtYmVyW10gfTtcbiAgICBleHBlY3QoY29udHJvbFJlc3VsdCkudG9NYXRjaE9iamVjdCh7IHN0YXR1czogMjAwLCB1cmw6IGZvcmVpZ25VUkwsIHJlZGlyZWN0ZWQ6IHRydWUsIGNvcnM6ICdjb3JzJywgcGFja0hhc2g6IGhhc2ggfSk7XG4gICAgZXhwZWN0KEJ1ZmZlci5mcm9tKGNvbnRyb2xSZXN1bHQuYm9keSkpLnRvRXF1YWwocmVzb3VyY2UgPT09ICdtZXRhZGF0YScgPyBCdWZmZXIuZnJvbShKU09OLnN0cmluZ2lmeShvcmlnaW5hbE1ldGEpKSA6IGJ5dGVzKTtcbiAgICBleHBlY3QoZm9yZWlnbkhpdHMpLnRvSGF2ZUxlbmd0aCgxKTtcbiAgICBleHBlY3Qoc291cmNlLnNlbnQuZmlsdGVyKHIgPT4gci51cmwgPT09ICcvbWFwLWZldGNoLWNvbnRyb2wnKSkudG9IYXZlTGVuZ3RoKDIpO1xuICAgIGNvbnRyb2xFdmlkZW5jZSA9IHsgLi4uY29udHJvbFJlc3VsdCwgYm9keTogdW5kZWZpbmVkLCBjb250cm9sUmVkaXJlY3RzLCByZWRpcmVjdFByb2JlOiB7IHN0YXR1czogcmVkaXJlY3RQcm9iZS5zdGF0dXMoKSwgbG9jYXRpb246IHJlZGlyZWN0UHJvYmUuaGVhZGVycygpLmxvY2F0aW9uIH0sIGJvZHlMZW5ndGg6IGNvbnRyb2xSZXN1bHQuYm9keS5sZW5ndGgsIGJvZHlTaGEyNTY6IGNyZWF0ZUhhc2goJ3NoYTI1NicpLnVwZGF0ZShCdWZmZXIuZnJvbShjb250cm9sUmVzdWx0LmJvZHkpKS5kaWdlc3QoJ2hleCcpIH07XG4gICAgYXdhaXQgY29udHJvbC5jbG9zZSgpOyBmb3JlaWduSGl0cy5sZW5ndGggPSAwOyBzb3VyY2Uuc2VudC5sZW5ndGggPSAwO1xuXG4gICAgbGV0IHdlbGNvbWU6IEV4dHJhY3Q8U2VydmVyTWVzc2FnZSwgeyB0eXBlOiAnV2VsY29tZScgfT4gfCB1bmRlZmluZWQ7XG4gICAgaWYgKHJlbG9hZCkgYXdhaXQgcGFnZS5yb3V0ZVdlYlNvY2tldCgnKiovd3MnLCByb3V0ZSA9PiB7XG4gICAgIGNvbnN0IHNlcnZlciA9IHJvdXRlLmNvbm5lY3RUb1NlcnZlcigpO1xuICAgICBzZXJ2ZXIub25NZXNzYWdlKGRhdGEgPT4geyBjb25zdCBtID0gZGVjb2RlKGRhdGEgYXMgQnVmZmVyKSBhcyBTZXJ2ZXJNZXNzYWdlOyBpZiAobS50eXBlID09PSAnV2VsY29tZScpIHdlbGNvbWUgPSBtOyByb3V0ZS5zZW5kKGRhdGEpOyB9KTtcbiAgICAgcm91dGUub25NZXNzYWdlKGRhdGEgPT4ge1xuICAgICAgY29uc3QgbSA9IGRlY29kZShkYXRhIGFzIEJ1ZmZlcikgYXMgQ2xpZW50TWVzc2FnZTtcbiAgICAgIC8vIFRoaXMgdGVzdC1vbmx5IGlkZW50aXR5IHJlbG9hZCBleGVyY2lzZXMgdGhlIGV4aXN0aW5nIE1hcFZpZXcgZWZmZWN0LlxuICAgICAgLy8gQXV0aG9yaXR5IHZhbHVlcyBhbmQgdGhlIG9yaWdpbmFsIHdvcmxkIHJlbWFpbiB1bm1vZGlmaWVkLlxuICAgICAgaWYgKGluamVjdGVkSWRlbnRpdHkgJiYgbS50eXBlID09PSAnSm9pbicpIHJldHVybjtcbiAgICAgIGlmIChzZW5kSWRlbnRpdHkgJiYgbS50eXBlID09PSAnUXVlcnknKSB7XG4gICAgICAgc2VuZElkZW50aXR5ID0gZmFsc2U7IGluamVjdGVkSWRlbnRpdHkgPSB0cnVlOyBoYXNoID0gbmV3SGFzaDtcbiAgICAgICByb3V0ZS5zZW5kKEJ1ZmZlci5mcm9tKGVuY29kZSh7IC4uLndlbGNvbWUhLCBwYWNrczogd2VsY29tZSEucGFja3MubWFwKHAgPT4gKHsgLi4ucCwgaGFzaCB9KSkgfSkpKTtcbiAgICAgIH1cbiAgICAgIHNlcnZlci5zZW5kKGRhdGEpO1xuICAgICB9KTtcbiAgICB9KTtcbiAgICBhd2FpdCBwYWdlLmdvdG8oYCR7c291cmNlLm9yaWdpbn0vP2ZvcmNlV2ViR0w9MWApO1xuICAgIGNvbnN0IG1hcCA9IHBhZ2UuZ2V0QnlUZXN0SWQoJ3Byb3ZpbmNlLW1hcCcpO1xuICAgIGlmIChyZWxvYWQpIHtcbiAgICAgYXdhaXQgZXhwZWN0KG1hcCkudG9IYXZlQXR0cmlidXRlKCdkYXRhLWZyYW1lcycsIC9eWzEtOV1cXGQqJC8pO1xuICAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdwYXVzZScpLmNsaWNrKCk7IGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdwYXVzZScpKS50b0hhdmVUZXh0KCdSZXN1bWUnKTtcbiAgICAgY29uc3QgYm94ID0gKGF3YWl0IG1hcC5ib3VuZGluZ0JveCgpKSEsIGNhbWVyYSA9IEpTT04ucGFyc2UoKGF3YWl0IG1hcC5nZXRBdHRyaWJ1dGUoJ2RhdGEtY2FtZXJhJykpISk7XG4gICAgIGF3YWl0IG1hcC5jbGljayh7IHBvc2l0aW9uOiB7IHg6ICgxIC0gY2FtZXJhLngpIC8gY2FtZXJhLndpZHRoICogYm94LndpZHRoICsgYm94LndpZHRoIC8gMiwgeTogKDMgLSBjYW1lcmEueSkgLyBjYW1lcmEuaGVpZ2h0ICogYm94LmhlaWdodCArIGJveC5oZWlnaHQgLyAyIH0gfSk7XG4gICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpKS50b0hhdmVUZXh0KCczMCcpO1xuICAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5sb2NhdG9yKCdoMycpKS50b0hhdmVUZXh0KCdTb3V0aGVybiBUZXN0IFN0YXRlJyk7XG4gICAgIGJlZm9yZSA9IGF3YWl0IHJlYWRVSSgpOyBjYW1lcmFCZWZvcmUgPSBhd2FpdCBtYXAuZ2V0QXR0cmlidXRlKCdkYXRhLWNhbWVyYScpO1xuICAgICByZWplY3RlZFJlcXVlc3RTdGFydEluZGV4ID0gcmVxdWVzdHMubGVuZ3RoO1xuICAgICBzaG91bGRSZWRpcmVjdCA9IHRydWU7IHNlbmRJZGVudGl0eSA9IHRydWU7XG4gICAgIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6ICdTb3V0aGVybiBUZXN0IFN0YXRlJywgZXhhY3Q6IHRydWUgfSkuY2xpY2soKTtcbiAgICB9XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdhbGVydCcpKS50b0hhdmVUZXh0KCdNYXAgZGF0YSBjb3VsZCBub3QgYmUgbG9hZGVkLiBDaGVjayB0aGUgYnVuZGxlZCBzY2VuYXJpbyBmaWxlcy4nKTtcbiAgICBhd2FpdCBleHBlY3QobWFwLmxvY2F0b3IoJ2NhbnZhcycpKS50b0hhdmVDb3VudCgwKTtcbiAgICBleHBlY3QoZm9yZWlnbkhpdHMpLnRvRXF1YWwoW10pO1xuICAgIGV4cGVjdChyZXF1ZXN0cy5ldmVyeSh1cmwgPT4gbmV3IFVSTCh1cmwpLm9yaWdpbiA9PT0gbmV3IFVSTChwYWdlLnVybCgpKS5vcmlnaW4pKS50b0JlKHRydWUpO1xuICAgIC8vIEVuZ2luZXMgcmVwb3J0IHJlZGlyZWN0OmVycm9yIHRocm91Z2ggZGlmZmVyZW50IGV2ZW50IGNoYW5uZWxzLiBUaGVcbiAgICAvLyBhY3R1YWwgSFRUUCAzMDIsIG9uZSBzb3VyY2UgR0VULCB6ZXJvIGZvcmVpZ24gR0VUcyBhbmQgVUkgYXJlIGludmFyaWFudC5cbiAgICBleHBlY3Qoc291cmNlLnNlbnQpLnRvSGF2ZUxlbmd0aCgxKTsgZXhwZWN0KHNvdXJjZS5zZW50WzBdKS50b01hdGNoT2JqZWN0KHsgc3RhdHVzOiAzMDIsIGxvY2F0aW9uOiBmb3JlaWduVVJMIH0pO1xuICAgIGV4cGVjdChyZXF1ZXN0cy5zbGljZShyZWplY3RlZFJlcXVlc3RTdGFydEluZGV4KS5maWx0ZXIodXJsID0+IHVybCA9PT0gc291cmNlLm9yaWdpbiArIHNvdXJjZS5zZW50WzBdLnVybCkpLnRvSGF2ZUxlbmd0aCgxKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY29ubmVjdGlvbicpKS50b0hhdmVUZXh0KCdDb25uZWN0ZWQnKTtcbiAgICBpZiAoYmVmb3JlKSB7XG4gICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCd0aWNrJykpLnRvSGF2ZVRleHQoYmVmb3JlLnRpY2shKTtcbiAgICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3NlbGVjdGVkLXByb3ZpbmNlJykpLnRvSGF2ZVRleHQoJzMwJyk7XG4gICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzdGF0ZS1wYW5lbCcpLmxvY2F0b3IoJ2gzJykpLnRvSGF2ZVRleHQoYmVmb3JlLnN0YXRlISk7XG4gICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjb3VudHJ5LXBhbmVsJykubG9jYXRvcignaDMnKSkudG9IYXZlVGV4dChiZWZvcmUuY291bnRyeSEpO1xuICAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5sb2NhdG9yKCcubGVkZ2VyLXZhbHVlIHN0cm9uZycpKS50b0hhdmVUZXh0KCcwJyk7XG4gICAgIHByZXNlcnZlZCA9IGF3YWl0IHJlYWRVSSgpOyBleHBlY3QocHJlc2VydmVkKS50b0VxdWFsKGJlZm9yZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3NlbGVjdGVkLXByb3ZpbmNlJykpLnRvSGF2ZVRleHQoJ+KAlCcpO1xuICAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnc3RhdGUtcGFuZWwnKS5sb2NhdG9yKCdoMycpKS50b0hhdmVUZXh0KCdOb3J0aGVybiBUZXN0IFN0YXRlJyk7XG4gICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjb3VudHJ5LXBhbmVsJykubG9jYXRvcignaDMnKSkudG9IYXZlVGV4dCgnTm9ydGhlcm4gVGVzdCBOYXRpb24nKTtcbiAgICB9XG4gICAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2NvbWJvYm94Jykuc2VsZWN0T3B0aW9uKCdrbycpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5Um9sZSgnYWxlcnQnKSkudG9IYXZlVGV4dCgn7KeA64+EIOuNsOydtO2EsOulvCDrtojrn6zsmKwg7IiYIOyXhuyKteuLiOuLpC4g64+Z67SJ65CcIOyLnOuCmOumrOyYpCDtjIzsnbzsnYQg7ZmV7J247ZWY7IS47JqULicpO1xuICAgIC8vIFdlYktpdCByZXBvcnRzIHRoaXMgZXhhY3QgbmF0aXZlIGJsb2NrZWQtZmV0Y2ggZGlhZ25vc3RpYyBhcyBwYWdlZXJyb3JcbiAgICAvLyBldmVuIHdoZW4gZmV0Y2ggaXMgY2F1Z2h0OyBubyBvdGhlciBKYXZhU2NyaXB0IGVycm9yIGlzIGFjY2VwdGVkLlxuICAgIGNvbnN0IGJsb2NrZWRGZXRjaCA9IGAke3NvdXJjZS5vcmlnaW4ucmVwbGFjZSgvXmh0dHA6XFwvLywgJycpfSR7c291cmNlLnNlbnRbMF0udXJsfSBkdWUgdG8gYWNjZXNzIGNvbnRyb2wgY2hlY2tzLmA7XG4gICAgZXhwZWN0KGVycm9ycy5maWx0ZXIoZSA9PiAhKGluZm8ucHJvamVjdC51c2UuYnJvd3Nlck5hbWUgPT09ICd3ZWJraXQnICYmIGUgPT09IGJsb2NrZWRGZXRjaCkpKS50b0VxdWFsKFtdKTtcbiAgIH0gZmluYWxseSB7XG4gICAgdHJ5IHtcbiAgICAgd3JpdGVGaWxlU3luYyhgJHtldmlkZW5jZX0vJHtpbmZvLnByb2plY3QubmFtZX0tJHtyZXNvdXJjZX0tJHtyZWxvYWR9Lmpzb25gLCBKU09OLnN0cmluZ2lmeSh7IHJlc291cmNlLCByZWxvYWQsIGNvbnRyb2xFdmlkZW5jZSwgc291cmNlT3JpZ2luOiBzb3VyY2Uub3JpZ2luLCBmb3JlaWduVVJMLCBmb3JlaWduSGl0cywgcmVxdWVzdHMsIHJlamVjdGVkUmVxdWVzdFN0YXJ0SW5kZXgsIGFjdHVhbFNvdXJjZVJlZGlyZWN0czogc291cmNlLnNlbnQsIGZhaWx1cmVzLCByZXNwb25zZUV2ZW50czogcmVkaXJlY3RzLCBlcnJvcnMsIGJlZm9yZSwgcHJlc2VydmVkLCBjYW1lcmFCZWZvcmUsIHJlbmRlcmVyT3V0Y29tZTogJ2luaXRpYWwgbG9hZCBjcmVhdGVzIG5vIHJlbmRlcmVyOyBpZGVudGl0eSByZWxvYWQgZGlzcG9zZXMgcHJldmlvdXMgcmVuZGVyZXIsIGtlZXBzIGF1dGhvcml0eSBVSS9zZWxlY3Rpb24gb25seScsIGFsZXJ0czogYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2FsZXJ0JykuYWxsVGV4dENvbnRlbnRzKCksIGNhbnZhc0NvdW50OiBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdwcm92aW5jZS1tYXAnKS5sb2NhdG9yKCdjYW52YXMnKS5jb3VudCgpIH0sIG51bGwsIDIpKTtcbiAgICAgYXdhaXQgcGFnZS5zY3JlZW5zaG90KHsgcGF0aDogYCR7ZXZpZGVuY2V9LyR7aW5mby5wcm9qZWN0Lm5hbWV9LSR7cmVzb3VyY2V9LSR7cmVsb2FkfS5wbmdgIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgIGF3YWl0IHNvdXJjZS5jbG9zZSgpO1xuICAgICBhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7IGZvcmVpZ24uY2xvc2UoZXJyb3IgPT4gZXJyb3IgPyByZWplY3QoZXJyb3IpIDogcmVzb2x2ZSgpKTsgZm9yZWlnbi5jbG9zZUFsbENvbm5lY3Rpb25zKCk7IH0pO1xuICAgIH1cbiAgIH1cbiAgfSk7XG4gfVxufVxuXG5mb3IgKGNvbnN0IHJlc291cmNlIG9mIFsnbWV0YWRhdGEnLCAnaW5kZXgnXSBhcyBjb25zdCkgdGVzdChgV1AwOCBQMDYgJHtyZXNvdXJjZX0gc2FtZS1vcmlnaW4gcmVkaXJlY3QgaXMgYWxzbyByZWplY3RlZCBiZWZvcmUgZm9sbG93YCwgYXN5bmMgKHsgcGFnZSwgcmVxdWVzdCB9LCBpbmZvKSA9PiB7XG4gY29uc3QgbWV0YVJlc3BvbnNlID0gYXdhaXQgcmVxdWVzdC5nZXQoJy9tYXBzL3Rlc3RsYW5kL21ldGFkYXRhJyksIG1ldGEgPSBhd2FpdCBtZXRhUmVzcG9uc2UuanNvbigpO1xuIGNvbnN0IHBhdGggPSByZXNvdXJjZSA9PT0gJ21ldGFkYXRhJyA/ICcvbWFwcy90ZXN0bGFuZC9tZXRhZGF0YScgOiBgL21hcHMvdGVzdGxhbmQvaW5kZXguYmluP3BhY2s9JHttZXRhLnBhY2tfaGFzaH1gO1xuIGNvbnN0IGFsaWFzID0gYCR7cGF0aH0ke3Jlc291cmNlID09PSAnbWV0YWRhdGEnID8gJz8nIDogJyYnfWFsaWFzPTFgO1xuIGNvbnN0IHNvdXJjZSA9IGF3YWl0IG1hcFJlZGlyZWN0Rml4dHVyZShuZXcgVVJMKG1ldGFSZXNwb25zZS51cmwoKSkub3JpZ2luLCB7IHJlc291cmNlLCBsb2NhdGlvbjogKCkgPT4gYWxpYXMsIHJlZGlyZWN0OiAoKSA9PiB0cnVlIH0pO1xuIGNvbnN0IGRpcmVjdCA9IGF3YWl0IHJlcXVlc3QuZ2V0KHNvdXJjZS5vcmlnaW4gKyBhbGlhcyk7IGV4cGVjdChkaXJlY3Quc3RhdHVzKCkpLnRvQmUoMjAwKTtcbiBjb25zdCBwcm9iZSA9IGF3YWl0IHJlcXVlc3QuZ2V0KHNvdXJjZS5vcmlnaW4gKyBwYXRoLCB7IG1heFJlZGlyZWN0czogMCB9KTsgZXhwZWN0KHByb2JlLnN0YXR1cygpKS50b0JlKDMwMik7IGV4cGVjdChwcm9iZS5oZWFkZXJzKCkubG9jYXRpb24pLnRvQmUoYWxpYXMpOyBzb3VyY2Uuc2VudC5sZW5ndGggPSAwO1xuIGNvbnN0IHJlcXVlc3RzOiBzdHJpbmdbXSA9IFtdOyBwYWdlLm9uKCdyZXF1ZXN0JywgciA9PiByZXF1ZXN0cy5wdXNoKHIudXJsKCkpKTtcbiB0cnkge1xuICBhd2FpdCBwYWdlLmdvdG8oYCR7c291cmNlLm9yaWdpbn0vP2ZvcmNlV2ViR0w9MWApO1xuICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2FsZXJ0JykpLnRvSGF2ZVRleHQoJ01hcCBkYXRhIGNvdWxkIG5vdCBiZSBsb2FkZWQuIENoZWNrIHRoZSBidW5kbGVkIHNjZW5hcmlvIGZpbGVzLicpO1xuICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgncHJvdmluY2UtbWFwJykubG9jYXRvcignY2FudmFzJykpLnRvSGF2ZUNvdW50KDApO1xuICBleHBlY3QocmVxdWVzdHMuZmlsdGVyKHVybCA9PiBuZXcgVVJMKHVybCkuc2VhcmNoUGFyYW1zLmhhcygnYWxpYXMnKSkpLnRvRXF1YWwoW10pO1xuICBleHBlY3Qoc291cmNlLnNlbnQpLnRvRXF1YWwoW3sgdXJsOiBwYXRoLCBzdGF0dXM6IDMwMiwgbG9jYXRpb246IGFsaWFzIH1dKTtcbiB9IGZpbmFsbHkge1xuICB0cnkgeyB3cml0ZUZpbGVTeW5jKGAke2V2aWRlbmNlfS8ke2luZm8ucHJvamVjdC5uYW1lfS0ke3Jlc291cmNlfS1sb2NhbC5qc29uYCwgSlNPTi5zdHJpbmdpZnkoeyBwYXRoLCBhbGlhcywgZGlyZWN0U3RhdHVzOiBkaXJlY3Quc3RhdHVzKCksIGFjdHVhbFNvdXJjZVJlZGlyZWN0czogc291cmNlLnNlbnQsIHJlcXVlc3RzLCBhbGVydHM6IGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdhbGVydCcpLmFsbFRleHRDb250ZW50cygpIH0sIG51bGwsIDIpKTsgfVxuICBmaW5hbGx5IHsgYXdhaXQgc291cmNlLmNsb3NlKCk7IH1cbiB9XG59KTtcbiJdLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE1BQU0sRUFBRUMsSUFBSSxRQUFRLGtCQUFrQjtBQUMvQyxTQUFTQyxZQUFZLFFBQVEsV0FBVztBQUN4QyxTQUFTQyxJQUFJLFFBQVEsYUFBYTtBQUNsQyxTQUFTQyxTQUFTLEVBQUVDLGFBQWEsUUFBUSxTQUFTO0FBQ2xELFNBQVNDLFVBQVUsUUFBUSxhQUFhO0FBQ3hDLFNBQVNDLE1BQU0sRUFBRUMsTUFBTSxRQUFRLGtCQUFrQjtBQUVqRCxTQUFTQyxrQkFBa0IsUUFBUSxzQkFBc0I7QUFFekQsTUFBTUMsUUFBUSxJQUFBQyxxQkFBQSxHQUFHQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0Msd0JBQXdCLGNBQUFILHFCQUFBLGNBQUFBLHFCQUFBLEdBQUkscUNBQXFDO0FBQzlGUCxTQUFTLENBQUNNLFFBQVEsRUFBRTtFQUFFSyxTQUFTLEVBQUU7QUFBSyxDQUFDLENBQUM7QUFFeEMsS0FBSyxNQUFNQyxRQUFRLElBQUksQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLEVBQVc7RUFDdEQsS0FBSyxNQUFNQyxNQUFNLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7SUFDbkNoQixJQUFJLENBQUMsWUFBWWUsUUFBUSwyQ0FBMkNDLE1BQU0sR0FBRyx1QkFBdUIsR0FBRyxlQUFlLEVBQUUsRUFBRSxPQUFPO01BQUVDLElBQUk7TUFBRUMsT0FBTztNQUFFQztJQUFRLENBQUMsRUFBRUMsSUFBSSxLQUFLO01BQ3JLLE1BQU1DLFlBQVksR0FBRyxNQUFNRixPQUFPLENBQUNHLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztNQUNqRSxNQUFNQyxZQUFZLEdBQUcsTUFBTUYsWUFBWSxDQUFDRyxJQUFJLENBQUMsQ0FBQztNQUM5QyxNQUFNQyxRQUFRLEdBQUcsSUFBSUMsR0FBRyxDQUFDTCxZQUFZLENBQUNNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsTUFBTTtNQUNuRCxNQUFNQyxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU1WLE9BQU8sQ0FBQ0csR0FBRyxDQUFDLGlDQUFpQ0MsWUFBWSxDQUFDTyxTQUFTLEVBQUUsQ0FBQyxFQUFFQyxJQUFJLENBQUMsQ0FBQztNQUN6RyxNQUFNQyxPQUFPLEdBQUdULFlBQVksQ0FBQ08sU0FBUyxLQUFLLGtCQUFrQixHQUFHLGtCQUFrQixHQUFHLGtCQUFrQjtNQUN2RyxJQUFJRyxJQUFJLEdBQUdWLFlBQVksQ0FBQ08sU0FBUztNQUNqQyxNQUFNSSxXQUFzRixHQUFHLEVBQUU7TUFDakcsTUFBTUMsT0FBTyxHQUFHbEMsWUFBWSxDQUFDLENBQUNtQyxHQUFHLEVBQUVDLEdBQUcsS0FBSztRQUFBLElBQUFDLFdBQUE7UUFDMUNKLFdBQVcsQ0FBQ0ssSUFBSSxDQUFDO1VBQUVDLE1BQU0sR0FBQUYsV0FBQSxHQUFFRixHQUFHLENBQUNJLE1BQU0sY0FBQUYsV0FBQSxjQUFBQSxXQUFBLEdBQUksRUFBRTtVQUFFWCxHQUFHLEVBQUVTLEdBQUcsQ0FBQ1QsR0FBRztVQUFFQyxNQUFNLEVBQUVRLEdBQUcsQ0FBQ0ssT0FBTyxDQUFDYjtRQUFPLENBQUMsQ0FBQztRQUN4RlMsR0FBRyxDQUFDSyxTQUFTLENBQUMsR0FBRyxFQUFFO1VBQ2xCLGNBQWMsRUFBRTNCLFFBQVEsS0FBSyxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsMEJBQTBCO1VBQ3pGLDZCQUE2QixFQUFFLEdBQUc7VUFDbEMsK0JBQStCLEVBQUUsYUFBYTtVQUM5QyxhQUFhLEVBQUVrQjtRQUNoQixDQUFDLENBQUM7UUFDRkksR0FBRyxDQUFDTSxHQUFHLENBQUM1QixRQUFRLEtBQUssVUFBVSxHQUFHNkIsSUFBSSxDQUFDQyxTQUFTLENBQUM7VUFBRSxHQUFHdEIsWUFBWTtVQUFFTyxTQUFTLEVBQUVHO1FBQUssQ0FBQyxDQUFDLEdBQUdKLEtBQUssQ0FBQztNQUNoRyxDQUFDLENBQUM7TUFDRk0sT0FBTyxDQUFDVyxNQUFNLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQztNQUFFLE1BQU01QyxJQUFJLENBQUNpQyxPQUFPLEVBQUUsV0FBVyxDQUFDO01BQ2hFLE1BQU1ZLE9BQU8sR0FBR1osT0FBTyxDQUFDWSxPQUFPLENBQUMsQ0FBQztNQUFFLElBQUksQ0FBQ0EsT0FBTyxJQUFJLE9BQU9BLE9BQU8sS0FBSyxRQUFRLEVBQUUsTUFBTSxJQUFJQyxLQUFLLENBQUMseUJBQXlCLENBQUM7TUFDMUgsTUFBTUMsVUFBVSxHQUFHLG9CQUFvQkYsT0FBTyxDQUFDRyxJQUFJLFVBQVU7TUFDN0QsTUFBTUMsUUFBa0IsR0FBRyxFQUFFO1FBQUVDLE1BQWdCLEdBQUcsRUFBRTtRQUFFQyxTQUEwRSxHQUFHLEVBQUU7TUFDckksTUFBTUMsUUFBc0QsR0FBRyxFQUFFO01BQ2pFckMsSUFBSSxDQUFDc0MsRUFBRSxDQUFDLFNBQVMsRUFBRUMsQ0FBQyxJQUFJTCxRQUFRLENBQUNaLElBQUksQ0FBQ2lCLENBQUMsQ0FBQzdCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFFVixJQUFJLENBQUNzQyxFQUFFLENBQUMsV0FBVyxFQUFFRSxDQUFDLElBQUlMLE1BQU0sQ0FBQ2IsSUFBSSxDQUFDa0IsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQztNQUNsR3pDLElBQUksQ0FBQ3NDLEVBQUUsQ0FBQyxVQUFVLEVBQUVDLENBQUMsSUFBSTtRQUFFLElBQUlBLENBQUMsQ0FBQ0csTUFBTSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUVOLFNBQVMsQ0FBQ2QsSUFBSSxDQUFDO1VBQUVaLEdBQUcsRUFBRTZCLENBQUMsQ0FBQzdCLEdBQUcsQ0FBQyxDQUFDO1VBQUVnQyxNQUFNLEVBQUVILENBQUMsQ0FBQ0csTUFBTSxDQUFDLENBQUM7VUFBRUMsUUFBUSxFQUFFSixDQUFDLENBQUNmLE9BQU8sQ0FBQyxDQUFDLENBQUNtQjtRQUFTLENBQUMsQ0FBQztNQUFFLENBQUMsQ0FBQztNQUMzSTNDLElBQUksQ0FBQ3NDLEVBQUUsQ0FBQyxlQUFlLEVBQUVDLENBQUM7UUFBQSxJQUFBSyxVQUFBO1FBQUEsT0FBSVAsUUFBUSxDQUFDZixJQUFJLENBQUM7VUFBRVosR0FBRyxFQUFFNkIsQ0FBQyxDQUFDN0IsR0FBRyxDQUFDLENBQUM7VUFBRW1DLEtBQUssR0FBQUQsVUFBQSxHQUFFTCxDQUFDLENBQUNPLE9BQU8sQ0FBQyxDQUFDLGNBQUFGLFVBQUEsdUJBQVhBLFVBQUEsQ0FBYUc7UUFBVSxDQUFDLENBQUM7TUFBQSxFQUFDO01BQzdGLElBQUlDLGNBQWMsR0FBRyxDQUFDakQsTUFBTTtRQUFFa0QsWUFBWSxHQUFHLEtBQUs7UUFBRUMsZ0JBQWdCLEdBQUcsS0FBSztNQUM1RSxNQUFNQyxNQUFNLEdBQUcsTUFBTTVELGtCQUFrQixDQUFDaUIsUUFBUSxFQUFFO1FBQUVWLFFBQVE7UUFBRTZDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNWCxVQUFVO1FBQUVvQixRQUFRLEVBQUVBLENBQUEsS0FBTUosY0FBYztRQUN2SEssUUFBUSxFQUFFQSxDQUFBLEtBQU10RCxNQUFNLElBQUlELFFBQVEsS0FBSyxPQUFPLElBQUlvRCxnQkFBZ0IsR0FBRztVQUFFLEdBQUc1QyxZQUFZO1VBQUVPLFNBQVMsRUFBRUc7UUFBSyxDQUFDLEdBQUdzQztNQUM3RyxDQUFDLENBQUM7TUFDRixJQUFJQyxlQUF3QjtNQUU1QixJQUFJQyxNQUEyQjtRQUFFQyxTQUE4QjtRQUFFQyxZQUEyQixHQUFHLElBQUk7UUFBRUMseUJBQXlCLEdBQUcsQ0FBQztNQUNsSSxNQUFNQyxNQUFNLEdBQUcsTUFBQUEsQ0FBQSxNQUErQjtRQUFFQyxJQUFJLEVBQUUsTUFBTTdELElBQUksQ0FBQzhELFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7UUFBRUMsSUFBSSxFQUFFLE1BQU1oRSxJQUFJLENBQUM4RCxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO1FBQUVFLElBQUksRUFBRSxNQUFNakUsSUFBSSxDQUFDOEQsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztRQUFFRyxRQUFRLEVBQUUsTUFBTWxFLElBQUksQ0FBQzhELFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztRQUFFSSxTQUFTLEVBQUUsTUFBTW5FLElBQUksQ0FBQzhELFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDTSxZQUFZLENBQUMsaUJBQWlCLENBQUM7UUFBRUMsS0FBSyxFQUFFLE1BQU1yRSxJQUFJLENBQUM4RCxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUNRLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQ1AsV0FBVyxDQUFDLENBQUM7UUFBRVEsT0FBTyxFQUFFLE1BQU12RSxJQUFJLENBQUM4RCxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNRLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQ1AsV0FBVyxDQUFDLENBQUM7UUFBRVMsTUFBTSxFQUFFLE1BQU14RSxJQUFJLENBQUM4RCxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUNRLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDUCxXQUFXLENBQUM7TUFBRSxDQUFDLENBQUM7TUFDN2xCLElBQUk7UUFDSDtRQUNBO1FBQ0EsTUFBTVUsT0FBTyxHQUFHLE1BQU14RSxPQUFPLENBQUN5RSxPQUFPLENBQUMsQ0FBQztRQUN2QyxNQUFNQyxnQkFBb0UsR0FBRyxFQUFFO1FBQy9FRixPQUFPLENBQUNuQyxFQUFFLENBQUMsVUFBVSxFQUFFQyxDQUFDLElBQUk7VUFBRSxJQUFJQSxDQUFDLENBQUNHLE1BQU0sQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFaUMsZ0JBQWdCLENBQUNyRCxJQUFJLENBQUM7WUFBRW9CLE1BQU0sRUFBRUgsQ0FBQyxDQUFDRyxNQUFNLENBQUMsQ0FBQztZQUFFQyxRQUFRLEVBQUVKLENBQUMsQ0FBQ2YsT0FBTyxDQUFDLENBQUMsQ0FBQ21CO1VBQVMsQ0FBQyxDQUFDO1FBQUUsQ0FBQyxDQUFDO1FBQ3ZJLE1BQU04QixPQUFPLENBQUNHLElBQUksQ0FBQyxHQUFHekIsTUFBTSxDQUFDeEMsTUFBTSxnQkFBZ0IsQ0FBQztRQUNwRCxNQUFNa0UsYUFBYSxHQUFHLE1BQU0zRSxPQUFPLENBQUNHLEdBQUcsQ0FBQyxHQUFHOEMsTUFBTSxDQUFDeEMsTUFBTSxvQkFBb0IsRUFBRTtVQUFFbUUsWUFBWSxFQUFFO1FBQUUsQ0FBQyxDQUFDO1FBQ2xHaEcsTUFBTSxDQUFDK0YsYUFBYSxDQUFDbkMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDcUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUFFakcsTUFBTSxDQUFDK0YsYUFBYSxDQUFDckQsT0FBTyxDQUFDLENBQUMsQ0FBQ21CLFFBQVEsQ0FBQyxDQUFDb0MsSUFBSSxDQUFDL0MsVUFBVSxDQUFDO1FBQ25HdUIsZUFBZSxHQUFHLE1BQU1rQixPQUFPLENBQUNPLFFBQVEsQ0FBQyxZQUFZO1VBQ3BELE1BQU1DLFFBQVEsR0FBRyxNQUFNQyxLQUFLLENBQUMsb0JBQW9CLEVBQUU7WUFBRUMsSUFBSSxFQUFFLE1BQU07WUFBRS9CLFFBQVEsRUFBRTtVQUFTLENBQUMsQ0FBQztVQUN4RixPQUFPO1lBQUVWLE1BQU0sRUFBRXVDLFFBQVEsQ0FBQ3ZDLE1BQU07WUFBRWhDLEdBQUcsRUFBRXVFLFFBQVEsQ0FBQ3ZFLEdBQUc7WUFBRTBFLFVBQVUsRUFBRUgsUUFBUSxDQUFDRyxVQUFVO1lBQUVDLElBQUksRUFBRUosUUFBUSxDQUFDSyxJQUFJO1lBQUVDLFFBQVEsRUFBRU4sUUFBUSxDQUFDekQsT0FBTyxDQUFDbkIsR0FBRyxDQUFDLGFBQWEsQ0FBQztZQUFFUyxJQUFJLEVBQUUwRSxLQUFLLENBQUNDLElBQUksQ0FBQyxJQUFJQyxVQUFVLENBQUMsTUFBTVQsUUFBUSxDQUFDVSxXQUFXLENBQUMsQ0FBQyxDQUFDO1VBQUUsQ0FBQztRQUMzTixDQUFDLENBQUM7UUFDRixNQUFNQyxhQUFhLEdBQUdyQyxlQUF1SDtRQUM3SXpFLE1BQU0sQ0FBQzhHLGFBQWEsQ0FBQyxDQUFDQyxhQUFhLENBQUM7VUFBRW5ELE1BQU0sRUFBRSxHQUFHO1VBQUVoQyxHQUFHLEVBQUVzQixVQUFVO1VBQUVvRCxVQUFVLEVBQUUsSUFBSTtVQUFFQyxJQUFJLEVBQUUsTUFBTTtVQUFFRSxRQUFRLEVBQUV2RTtRQUFLLENBQUMsQ0FBQztRQUNySGxDLE1BQU0sQ0FBQ2dILE1BQU0sQ0FBQ0wsSUFBSSxDQUFDRyxhQUFhLENBQUM5RSxJQUFJLENBQUMsQ0FBQyxDQUFDaUYsT0FBTyxDQUFDakcsUUFBUSxLQUFLLFVBQVUsR0FBR2dHLE1BQU0sQ0FBQ0wsSUFBSSxDQUFDOUQsSUFBSSxDQUFDQyxTQUFTLENBQUN0QixZQUFZLENBQUMsQ0FBQyxHQUFHTSxLQUFLLENBQUM7UUFDNUg5QixNQUFNLENBQUNtQyxXQUFXLENBQUMsQ0FBQytFLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDbkNsSCxNQUFNLENBQUNxRSxNQUFNLENBQUM4QyxJQUFJLENBQUNDLE1BQU0sQ0FBQzNELENBQUMsSUFBSUEsQ0FBQyxDQUFDN0IsR0FBRyxLQUFLLG9CQUFvQixDQUFDLENBQUMsQ0FBQ3NGLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDL0V6QyxlQUFlLEdBQUc7VUFBRSxHQUFHcUMsYUFBYTtVQUFFOUUsSUFBSSxFQUFFd0MsU0FBUztVQUFFcUIsZ0JBQWdCO1VBQUVFLGFBQWEsRUFBRTtZQUFFbkMsTUFBTSxFQUFFbUMsYUFBYSxDQUFDbkMsTUFBTSxDQUFDLENBQUM7WUFBRUMsUUFBUSxFQUFFa0MsYUFBYSxDQUFDckQsT0FBTyxDQUFDLENBQUMsQ0FBQ21CO1VBQVMsQ0FBQztVQUFFd0QsVUFBVSxFQUFFUCxhQUFhLENBQUM5RSxJQUFJLENBQUNzRixNQUFNO1VBQUVDLFVBQVUsRUFBRWpILFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQ2tILE1BQU0sQ0FBQ1IsTUFBTSxDQUFDTCxJQUFJLENBQUNHLGFBQWEsQ0FBQzlFLElBQUksQ0FBQyxDQUFDLENBQUN5RixNQUFNLENBQUMsS0FBSztRQUFFLENBQUM7UUFDdlMsTUFBTTlCLE9BQU8sQ0FBQytCLEtBQUssQ0FBQyxDQUFDO1FBQUV2RixXQUFXLENBQUNtRixNQUFNLEdBQUcsQ0FBQztRQUFFakQsTUFBTSxDQUFDOEMsSUFBSSxDQUFDRyxNQUFNLEdBQUcsQ0FBQztRQUVyRSxJQUFJSyxPQUFnRTtRQUNwRSxJQUFJMUcsTUFBTSxFQUFFLE1BQU1DLElBQUksQ0FBQzBHLGNBQWMsQ0FBQyxPQUFPLEVBQUVDLEtBQUssSUFBSTtVQUN2RCxNQUFNQyxNQUFNLEdBQUdELEtBQUssQ0FBQ0UsZUFBZSxDQUFDLENBQUM7VUFDdENELE1BQU0sQ0FBQ0UsU0FBUyxDQUFDQyxJQUFJLElBQUk7WUFBRSxNQUFNQyxDQUFDLEdBQUcxSCxNQUFNLENBQUN5SCxJQUFjLENBQWtCO1lBQUUsSUFBSUMsQ0FBQyxDQUFDMUIsSUFBSSxLQUFLLFNBQVMsRUFBRW1CLE9BQU8sR0FBR08sQ0FBQztZQUFFTCxLQUFLLENBQUNNLElBQUksQ0FBQ0YsSUFBSSxDQUFDO1VBQUUsQ0FBQyxDQUFDO1VBQ3pJSixLQUFLLENBQUNHLFNBQVMsQ0FBQ0MsSUFBSSxJQUFJO1lBQ3ZCLE1BQU1DLENBQUMsR0FBRzFILE1BQU0sQ0FBQ3lILElBQWMsQ0FBa0I7WUFDakQ7WUFDQTtZQUNBLElBQUk3RCxnQkFBZ0IsSUFBSThELENBQUMsQ0FBQzFCLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDM0MsSUFBSXJDLFlBQVksSUFBSStELENBQUMsQ0FBQzFCLElBQUksS0FBSyxPQUFPLEVBQUU7Y0FDdkNyQyxZQUFZLEdBQUcsS0FBSztjQUFFQyxnQkFBZ0IsR0FBRyxJQUFJO2NBQUVsQyxJQUFJLEdBQUdELE9BQU87Y0FDN0Q0RixLQUFLLENBQUNNLElBQUksQ0FBQ25CLE1BQU0sQ0FBQ0wsSUFBSSxDQUFDcEcsTUFBTSxDQUFDO2dCQUFFLEdBQUdvSCxPQUFRO2dCQUFFUyxLQUFLLEVBQUVULE9BQU8sQ0FBRVMsS0FBSyxDQUFDQyxHQUFHLENBQUNDLENBQUMsS0FBSztrQkFBRSxHQUFHQSxDQUFDO2tCQUFFcEc7Z0JBQUssQ0FBQyxDQUFDO2NBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRztZQUNBNEYsTUFBTSxDQUFDSyxJQUFJLENBQUNGLElBQUksQ0FBQztVQUNsQixDQUFDLENBQUM7UUFDSCxDQUFDLENBQUM7UUFDRixNQUFNL0csSUFBSSxDQUFDNEUsSUFBSSxDQUFDLEdBQUd6QixNQUFNLENBQUN4QyxNQUFNLGdCQUFnQixDQUFDO1FBQ2pELE1BQU13RyxHQUFHLEdBQUduSCxJQUFJLENBQUM4RCxXQUFXLENBQUMsY0FBYyxDQUFDO1FBQzVDLElBQUkvRCxNQUFNLEVBQUU7VUFDWCxNQUFNakIsTUFBTSxDQUFDcUksR0FBRyxDQUFDLENBQUNFLGVBQWUsQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDO1VBQzlELE1BQU1ySCxJQUFJLENBQUM4RCxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUN3RCxLQUFLLENBQUMsQ0FBQztVQUFFLE1BQU14SSxNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ3lELFVBQVUsQ0FBQyxRQUFRLENBQUM7VUFDckcsTUFBTUMsR0FBRyxHQUFJLE1BQU1MLEdBQUcsQ0FBQ00sV0FBVyxDQUFDLENBQUc7WUFBRUMsTUFBTSxHQUFHL0YsSUFBSSxDQUFDZ0csS0FBSyxDQUFFLE1BQU1SLEdBQUcsQ0FBQy9DLFlBQVksQ0FBQyxhQUFhLENBQUcsQ0FBQztVQUNyRyxNQUFNK0MsR0FBRyxDQUFDRyxLQUFLLENBQUM7WUFBRU0sUUFBUSxFQUFFO2NBQUVDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBR0gsTUFBTSxDQUFDRyxDQUFDLElBQUlILE1BQU0sQ0FBQ0ksS0FBSyxHQUFHTixHQUFHLENBQUNNLEtBQUssR0FBR04sR0FBRyxDQUFDTSxLQUFLLEdBQUcsQ0FBQztjQUFFQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUdMLE1BQU0sQ0FBQ0ssQ0FBQyxJQUFJTCxNQUFNLENBQUNNLE1BQU0sR0FBR1IsR0FBRyxDQUFDUSxNQUFNLEdBQUdSLEdBQUcsQ0FBQ1EsTUFBTSxHQUFHO1lBQUU7VUFBRSxDQUFDLENBQUM7VUFDaEssTUFBTWxKLE1BQU0sQ0FBQ2tCLElBQUksQ0FBQzhELFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUN5RCxVQUFVLENBQUMsSUFBSSxDQUFDO1VBQ3BFLE1BQU16SSxNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUNRLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDaUQsVUFBVSxDQUFDLHFCQUFxQixDQUFDO1VBQzdGL0QsTUFBTSxHQUFHLE1BQU1JLE1BQU0sQ0FBQyxDQUFDO1VBQUVGLFlBQVksR0FBRyxNQUFNeUQsR0FBRyxDQUFDL0MsWUFBWSxDQUFDLGFBQWEsQ0FBQztVQUM3RVQseUJBQXlCLEdBQUd6QixRQUFRLENBQUNrRSxNQUFNO1VBQzNDcEQsY0FBYyxHQUFHLElBQUk7VUFBRUMsWUFBWSxHQUFHLElBQUk7VUFDMUMsTUFBTWpELElBQUksQ0FBQzhELFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ21FLFNBQVMsQ0FBQyxRQUFRLEVBQUU7WUFBRUMsSUFBSSxFQUFFLHFCQUFxQjtZQUFFQyxLQUFLLEVBQUU7VUFBSyxDQUFDLENBQUMsQ0FBQ2IsS0FBSyxDQUFDLENBQUM7UUFDaEg7UUFDQSxNQUFNeEksTUFBTSxDQUFDa0IsSUFBSSxDQUFDaUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNWLFVBQVUsQ0FBQyxpRUFBaUUsQ0FBQztRQUNuSCxNQUFNekksTUFBTSxDQUFDcUksR0FBRyxDQUFDN0MsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM4RCxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQ2xEdEosTUFBTSxDQUFDbUMsV0FBVyxDQUFDLENBQUM4RSxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQy9CakgsTUFBTSxDQUFDb0QsUUFBUSxDQUFDbUcsS0FBSyxDQUFDM0gsR0FBRyxJQUFJLElBQUlELEdBQUcsQ0FBQ0MsR0FBRyxDQUFDLENBQUNDLE1BQU0sS0FBSyxJQUFJRixHQUFHLENBQUNULElBQUksQ0FBQ1UsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDb0UsSUFBSSxDQUFDLElBQUksQ0FBQztRQUM1RjtRQUNBO1FBQ0FqRyxNQUFNLENBQUNxRSxNQUFNLENBQUM4QyxJQUFJLENBQUMsQ0FBQ0QsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUFFbEgsTUFBTSxDQUFDcUUsTUFBTSxDQUFDOEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNKLGFBQWEsQ0FBQztVQUFFbkQsTUFBTSxFQUFFLEdBQUc7VUFBRUMsUUFBUSxFQUFFWDtRQUFXLENBQUMsQ0FBQztRQUNoSGxELE1BQU0sQ0FBQ29ELFFBQVEsQ0FBQ29HLEtBQUssQ0FBQzNFLHlCQUF5QixDQUFDLENBQUN1QyxNQUFNLENBQUN4RixHQUFHLElBQUlBLEdBQUcsS0FBS3lDLE1BQU0sQ0FBQ3hDLE1BQU0sR0FBR3dDLE1BQU0sQ0FBQzhDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZGLEdBQUcsQ0FBQyxDQUFDLENBQUNzRixZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQzNILE1BQU1sSCxNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQ3lELFVBQVUsQ0FBQyxXQUFXLENBQUM7UUFDcEUsSUFBSS9ELE1BQU0sRUFBRTtVQUNYLE1BQU0xRSxNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQ3lELFVBQVUsQ0FBQy9ELE1BQU0sQ0FBQ1MsSUFBSyxDQUFDO1VBQy9ELE1BQU1uRixNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDeUQsVUFBVSxDQUFDLElBQUksQ0FBQztVQUNwRSxNQUFNekksTUFBTSxDQUFDa0IsSUFBSSxDQUFDOEQsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDUSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQ2lELFVBQVUsQ0FBQy9ELE1BQU0sQ0FBQ2EsS0FBTSxDQUFDO1VBQ3JGLE1BQU12RixNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNRLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDaUQsVUFBVSxDQUFDL0QsTUFBTSxDQUFDZSxPQUFRLENBQUM7VUFDekYsTUFBTXpGLE1BQU0sQ0FBQ2tCLElBQUksQ0FBQzhELFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ1EsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQ2lELFVBQVUsQ0FBQyxHQUFHLENBQUM7VUFDN0Y5RCxTQUFTLEdBQUcsTUFBTUcsTUFBTSxDQUFDLENBQUM7VUFBRTlFLE1BQU0sQ0FBQzJFLFNBQVMsQ0FBQyxDQUFDc0MsT0FBTyxDQUFDdkMsTUFBTSxDQUFDO1FBQzlELENBQUMsTUFBTTtVQUNOLE1BQU0xRSxNQUFNLENBQUNrQixJQUFJLENBQUM4RCxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDeUQsVUFBVSxDQUFDLEdBQUcsQ0FBQztVQUNuRSxNQUFNekksTUFBTSxDQUFDa0IsSUFBSSxDQUFDOEQsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDUSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQ2lELFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQztVQUM3RixNQUFNekksTUFBTSxDQUFDa0IsSUFBSSxDQUFDOEQsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDUSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQ2lELFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQztRQUNqRztRQUNBLE1BQU12SCxJQUFJLENBQUNpSSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUNNLFlBQVksQ0FBQyxJQUFJLENBQUM7UUFDbkQsTUFBTXpKLE1BQU0sQ0FBQ2tCLElBQUksQ0FBQ2lJLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDVixVQUFVLENBQUMseUNBQXlDLENBQUM7UUFDM0Y7UUFDQTtRQUNBLE1BQU1pQixZQUFZLEdBQUcsR0FBR3JGLE1BQU0sQ0FBQ3hDLE1BQU0sQ0FBQzhILE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLEdBQUd0RixNQUFNLENBQUM4QyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUN2RixHQUFHLGdDQUFnQztRQUNsSDVCLE1BQU0sQ0FBQ3FELE1BQU0sQ0FBQytELE1BQU0sQ0FBQzFELENBQUMsSUFBSSxFQUFFckMsSUFBSSxDQUFDdUksT0FBTyxDQUFDQyxHQUFHLENBQUNDLFdBQVcsS0FBSyxRQUFRLElBQUlwRyxDQUFDLEtBQUtnRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUN6QyxPQUFPLENBQUMsRUFBRSxDQUFDO01BQzNHLENBQUMsU0FBUztRQUNULElBQUk7VUFDSDVHLGFBQWEsQ0FBQyxHQUFHSyxRQUFRLElBQUlXLElBQUksQ0FBQ3VJLE9BQU8sQ0FBQ1IsSUFBSSxJQUFJcEksUUFBUSxJQUFJQyxNQUFNLE9BQU8sRUFBRTRCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1lBQUU5QixRQUFRO1lBQUVDLE1BQU07WUFBRXdELGVBQWU7WUFBRXNGLFlBQVksRUFBRTFGLE1BQU0sQ0FBQ3hDLE1BQU07WUFBRXFCLFVBQVU7WUFBRWYsV0FBVztZQUFFaUIsUUFBUTtZQUFFeUIseUJBQXlCO1lBQUVtRixxQkFBcUIsRUFBRTNGLE1BQU0sQ0FBQzhDLElBQUk7WUFBRTVELFFBQVE7WUFBRTBHLGNBQWMsRUFBRTNHLFNBQVM7WUFBRUQsTUFBTTtZQUFFcUIsTUFBTTtZQUFFQyxTQUFTO1lBQUVDLFlBQVk7WUFBRXNGLGVBQWUsRUFBRSxpSEFBaUg7WUFBRUMsTUFBTSxFQUFFLE1BQU1qSixJQUFJLENBQUNpSSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUNpQixlQUFlLENBQUMsQ0FBQztZQUFFQyxXQUFXLEVBQUUsTUFBTW5KLElBQUksQ0FBQzhELFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQ1EsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDOEUsS0FBSyxDQUFDO1VBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztVQUNybUIsTUFBTXBKLElBQUksQ0FBQ3FKLFVBQVUsQ0FBQztZQUFFQyxJQUFJLEVBQUUsR0FBRzlKLFFBQVEsSUFBSVcsSUFBSSxDQUFDdUksT0FBTyxDQUFDUixJQUFJLElBQUlwSSxRQUFRLElBQUlDLE1BQU07VUFBTyxDQUFDLENBQUM7UUFDOUYsQ0FBQyxTQUFTO1VBQ1QsTUFBTW9ELE1BQU0sQ0FBQ3FELEtBQUssQ0FBQyxDQUFDO1VBQ3BCLE1BQU0sSUFBSStDLE9BQU8sQ0FBTyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztZQUFFdkksT0FBTyxDQUFDc0YsS0FBSyxDQUFDM0QsS0FBSyxJQUFJQSxLQUFLLEdBQUc0RyxNQUFNLENBQUM1RyxLQUFLLENBQUMsR0FBRzJHLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFBRXRJLE9BQU8sQ0FBQ3dJLG1CQUFtQixDQUFDLENBQUM7VUFBRSxDQUFDLENBQUM7UUFDNUk7TUFDRDtJQUNELENBQUMsQ0FBQztFQUNIO0FBQ0Q7QUFFQSxLQUFLLE1BQU01SixRQUFRLElBQUksQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLEVBQVdmLElBQUksQ0FBQyxZQUFZZSxRQUFRLHNEQUFzRCxFQUFFLE9BQU87RUFBRUUsSUFBSTtFQUFFRTtBQUFRLENBQUMsRUFBRUMsSUFBSSxLQUFLO0VBQzFLLE1BQU1DLFlBQVksR0FBRyxNQUFNRixPQUFPLENBQUNHLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztJQUFFc0osSUFBSSxHQUFHLE1BQU12SixZQUFZLENBQUNHLElBQUksQ0FBQyxDQUFDO0VBQ25HLE1BQU0rSSxJQUFJLEdBQUd4SixRQUFRLEtBQUssVUFBVSxHQUFHLHlCQUF5QixHQUFHLGlDQUFpQzZKLElBQUksQ0FBQzlJLFNBQVMsRUFBRTtFQUNwSCxNQUFNK0ksS0FBSyxHQUFHLEdBQUdOLElBQUksR0FBR3hKLFFBQVEsS0FBSyxVQUFVLEdBQUcsR0FBRyxHQUFHLEdBQUcsU0FBUztFQUNwRSxNQUFNcUQsTUFBTSxHQUFHLE1BQU01RCxrQkFBa0IsQ0FBQyxJQUFJa0IsR0FBRyxDQUFDTCxZQUFZLENBQUNNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxFQUFFO0lBQUViLFFBQVE7SUFBRTZDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNaUgsS0FBSztJQUFFeEcsUUFBUSxFQUFFQSxDQUFBLEtBQU07RUFBSyxDQUFDLENBQUM7RUFDdEksTUFBTXlHLE1BQU0sR0FBRyxNQUFNM0osT0FBTyxDQUFDRyxHQUFHLENBQUM4QyxNQUFNLENBQUN4QyxNQUFNLEdBQUdpSixLQUFLLENBQUM7RUFBRTlLLE1BQU0sQ0FBQytLLE1BQU0sQ0FBQ25ILE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3FDLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDMUYsTUFBTStFLEtBQUssR0FBRyxNQUFNNUosT0FBTyxDQUFDRyxHQUFHLENBQUM4QyxNQUFNLENBQUN4QyxNQUFNLEdBQUcySSxJQUFJLEVBQUU7SUFBRXhFLFlBQVksRUFBRTtFQUFFLENBQUMsQ0FBQztFQUFFaEcsTUFBTSxDQUFDZ0wsS0FBSyxDQUFDcEgsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDcUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUFFakcsTUFBTSxDQUFDZ0wsS0FBSyxDQUFDdEksT0FBTyxDQUFDLENBQUMsQ0FBQ21CLFFBQVEsQ0FBQyxDQUFDb0MsSUFBSSxDQUFDNkUsS0FBSyxDQUFDO0VBQUV6RyxNQUFNLENBQUM4QyxJQUFJLENBQUNHLE1BQU0sR0FBRyxDQUFDO0VBQ2xMLE1BQU1sRSxRQUFrQixHQUFHLEVBQUU7RUFBRWxDLElBQUksQ0FBQ3NDLEVBQUUsQ0FBQyxTQUFTLEVBQUVDLENBQUMsSUFBSUwsUUFBUSxDQUFDWixJQUFJLENBQUNpQixDQUFDLENBQUM3QixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDOUUsSUFBSTtJQUNILE1BQU1WLElBQUksQ0FBQzRFLElBQUksQ0FBQyxHQUFHekIsTUFBTSxDQUFDeEMsTUFBTSxnQkFBZ0IsQ0FBQztJQUNqRCxNQUFNN0IsTUFBTSxDQUFDa0IsSUFBSSxDQUFDaUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNWLFVBQVUsQ0FBQyxpRUFBaUUsQ0FBQztJQUNuSCxNQUFNekksTUFBTSxDQUFDa0IsSUFBSSxDQUFDOEQsV0FBVyxDQUFDLGNBQWMsQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzhELFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDL0V0SixNQUFNLENBQUNvRCxRQUFRLENBQUNnRSxNQUFNLENBQUN4RixHQUFHLElBQUksSUFBSUQsR0FBRyxDQUFDQyxHQUFHLENBQUMsQ0FBQ3FKLFlBQVksQ0FBQ0MsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ2pFLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDbEZqSCxNQUFNLENBQUNxRSxNQUFNLENBQUM4QyxJQUFJLENBQUMsQ0FBQ0YsT0FBTyxDQUFDLENBQUM7TUFBRXJGLEdBQUcsRUFBRTRJLElBQUk7TUFBRTVHLE1BQU0sRUFBRSxHQUFHO01BQUVDLFFBQVEsRUFBRWlIO0lBQU0sQ0FBQyxDQUFDLENBQUM7RUFDM0UsQ0FBQyxTQUFTO0lBQ1QsSUFBSTtNQUFFekssYUFBYSxDQUFDLEdBQUdLLFFBQVEsSUFBSVcsSUFBSSxDQUFDdUksT0FBTyxDQUFDUixJQUFJLElBQUlwSSxRQUFRLGFBQWEsRUFBRTZCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQUUwSCxJQUFJO1FBQUVNLEtBQUs7UUFBRUssWUFBWSxFQUFFSixNQUFNLENBQUNuSCxNQUFNLENBQUMsQ0FBQztRQUFFb0cscUJBQXFCLEVBQUUzRixNQUFNLENBQUM4QyxJQUFJO1FBQUUvRCxRQUFRO1FBQUUrRyxNQUFNLEVBQUUsTUFBTWpKLElBQUksQ0FBQ2lJLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQ2lCLGVBQWUsQ0FBQztNQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDLFNBQ3pQO01BQUUsTUFBTS9GLE1BQU0sQ0FBQ3FELEtBQUssQ0FBQyxDQUFDO0lBQUU7RUFDakM7QUFDRCxDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=