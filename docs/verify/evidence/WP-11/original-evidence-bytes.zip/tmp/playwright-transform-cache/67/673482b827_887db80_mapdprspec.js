// 259fa0ae3954e6bfa845abf7a9b7bf73ee5a76b1
var _process$env$OH_MAP_D;
import { expect, test } from '@playwright/test';
import { decode, encode } from '@msgpack/msgpack';
import { mkdirSync, writeFileSync } from 'node:fs';
import { png } from './png';
const evidence = (_process$env$OH_MAP_D = process.env.OH_MAP_DPR_EVIDENCE) !== null && _process$env$OH_MAP_D !== void 0 ? _process$env$OH_MAP_D : '../target/wp08/dpr';
mkdirSync(evidence, {
  recursive: true
});
for (const force of [false, true]) test(`REQ-PLAT-03 DPR surface preserves display and authority ${force ? 'forced GL' : 'preferred'}`, async ({
  browser,
  browserName
}, info) => {
  // Chromium supports an actual live DPR change through tab-scoped CDP.
  // Firefox/WebKit exercise native DPR2 creation; no dynamic-change claim.
  const context = await browser.newContext({
    viewport: {
      width: 1280,
      height: 720
    },
    deviceScaleFactor: browserName === 'chromium' ? 1 : 2,
    locale: 'en-US',
    baseURL: info.project.use.baseURL
  });
  const page = await context.newPage(),
    errors = [],
    steps = [];
  let world,
    worlds = 0,
    reload = false,
    changed = false,
    metadata = 0,
    index = 0;
  const map = page.getByTestId('province-map'),
    cam = async () => JSON.parse(await map.getAttribute('data-camera')),
    life = () => page.evaluate(() => window.__dprLife());
  try {
    await page.addInitScript(() => {
      const media = new Set(),
        listeners = new Set(),
        observers = new Set(),
        rafs = new Set();
      const add = EventTarget.prototype.addEventListener,
        remove = EventTarget.prototype.removeEventListener;
      EventTarget.prototype.addEventListener = function (type, listener, options) {
        if (listener) {
          if (this instanceof MediaQueryList && type === 'change') media.add(listener);
          if (this instanceof HTMLElement && this.classList.contains('province-map')) listeners.add(listener);
        }
        return add.call(this, type, listener, options);
      };
      EventTarget.prototype.removeEventListener = function (type, listener, options) {
        if (listener) {
          if (this instanceof MediaQueryList && type === 'change') media.delete(listener);
          if (this instanceof HTMLElement && this.classList.contains('province-map')) listeners.delete(listener);
        }
        return remove.call(this, type, listener, options);
      };
      const observe = ResizeObserver.prototype.observe,
        disconnect = ResizeObserver.prototype.disconnect;
      ResizeObserver.prototype.observe = function (target, options) {
        if (target instanceof HTMLElement && target.classList.contains('province-map')) observers.add(this);
        return observe.call(this, target, options);
      };
      ResizeObserver.prototype.disconnect = function () {
        observers.delete(this);
        return disconnect.call(this);
      };
      const raf = window.requestAnimationFrame,
        cancel = window.cancelAnimationFrame;
      window.requestAnimationFrame = fn => {
        let id;
        id = raf(t => {
          rafs.delete(id);
          fn(t);
        });
        rafs.add(id);
        return id;
      };
      window.cancelAnimationFrame = id => {
        rafs.delete(id);
        cancel(id);
      };
      Object.assign(window, {
        __dprLife: () => ({
          media: media.size,
          listeners: listeners.size,
          observers: observers.size,
          rafs: rafs.size
        })
      });
    });
    page.on('pageerror', e => errors.push(e.message));
    await page.routeWebSocket('**/ws', route => {
      const server = route.connectToServer();
      server.onMessage(data => {
        const m = decode(data);
        if (m.type === 'WorldResult' && m.world) {
          if (++worlds >= 2) m.world.provinces.find(p => p.id === 10).terrain_color = [77, 111, 155];
          world = m.world;
        }
        if (reload && !changed) {
          changed = true;
          route.send(Buffer.from(encode({
            type: 'Welcome',
            engine_version: 'fixture',
            protocol_version: 'm0-v1',
            accepted: true,
            reason_key: null,
            packs: [{
              id: 'testland',
              version: '0.1.0',
              hash: '0000000000000001'
            }],
            sessions: ['local']
          })));
        }
        route.send(Buffer.from(encode(m)));
      });
    });
    await page.route('**/maps/testland/metadata', r => {
      metadata++;
      return reload ? r.fulfill({
        status: 404
      }) : r.continue();
    });
    await page.route('**/maps/testland/index.bin?*', r => {
      index++;
      return r.continue();
    });
    await page.goto(force ? '/?forceWebGL=1' : '/');
    await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
    await page.getByTestId('pause').click();
    await expect(page.getByTestId('pause')).toHaveText('Resume');
    const box = await map.boundingBox(),
      camera = await cam();
    await map.click({
      position: {
        x: (1 - camera.x) / camera.width * box.width + box.width / 2,
        y: (3 - camera.y) / camera.height * box.height + box.height / 2
      }
    });
    await expect(page.getByTestId('selected-province')).toHaveText('30');
    await expect(page.getByTestId('state-panel').locator('.ledger-value strong')).toHaveText('0');
    await page.getByTestId('speed-2').click();
    await expect.poll(() => worlds).toBeGreaterThanOrEqual(2);
    await page.getByRole('button', {
      name: 'Terrain',
      exact: true
    }).click();
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await page.mouse.wheel(0, -200);
    await expect.poll(async () => (await cam()).zoom).toBeGreaterThan(1);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width / 2 + 20, box.y + box.height / 2 + 10, {
      steps: 4
    });
    await page.mouse.up();
    await page.mouse.move(0, 0);
    const saved = await cam(),
      authority = {
        tick: await page.getByTestId('tick').textContent(),
        date: await page.getByTestId('date').textContent(),
        hour: await page.getByTestId('hour').textContent()
      },
      backend = await map.getAttribute('data-backend'),
      cdp = browserName === 'chromium' ? await context.newCDPSession(page) : null;
    const buffer = () => map.locator('canvas').evaluate(c => ({
      width: c.width,
      height: c.height,
      expectedWidth: Math.floor(c.clientWidth * devicePixelRatio),
      expectedHeight: Math.floor(c.clientHeight * devicePixelRatio)
    }));
    for (const dpr of cdp ? [2, 1.5, 1, 2, 1.5, 1] : [2]) {
      const old = await map.locator('canvas').elementHandle();
      if (cdp) await cdp.send('Emulation.setDeviceMetricsOverride', {
        width: 1280,
        height: 720,
        deviceScaleFactor: dpr,
        mobile: false
      });
      await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(dpr);
      // No Reset or CSS geometry change may be used to trigger this update.
      await expect.poll(async () => {
        const b = await buffer();
        return {
          width: b.width - b.expectedWidth,
          height: b.height - b.expectedHeight
        };
      }).toEqual({
        width: 0,
        height: 0
      });
      await expect(map).toHaveAttribute('data-frames', /^[1-9]\d*$/);
      expect(await map.boundingBox()).toEqual(box);
      expect(await cam()).toEqual(saved);
      await expect(map).toHaveAttribute('data-mode', 'map-mode-terrain');
      if (cdp) {
        expect(await old.evaluate(c => c.isConnected)).toBe(backend === 'webgpu');
        if (backend === 'webgl2') expect(await old.evaluate(c => c.getContext('webgl2').isContextLost())).toBe(true);
      }
      // Element screenshots on Chromium restore the configured context DPR1.
      // Capture the full native viewport without a clip for this live DPR test.
      // Existing resize/mode tests retain their element screenshot stability gate.
      const path = `${evidence}/${info.project.name}-${force}-dpr${dpr}-${steps.length}.png`,
        b = await map.boundingBox(),
        c = await cam(),
        viewport = await page.evaluate(() => ({
          width: innerWidth,
          height: innerHeight,
          scrollX,
          scrollY
        }));
      const bytes = cdp ? Buffer.from((await cdp.send('Page.captureScreenshot', {
        format: 'png',
        captureBeyondViewport: false
      })).data, 'base64') : await map.screenshot({
        path
      });
      if (cdp) writeFileSync(path, bytes);
      const image = png(bytes),
        x = (1 - c.x) / c.width * b.width + b.width / 2,
        y = (1 - c.y) / c.height * b.height + b.height / 2;
      const actual = cdp ? image.pixel((b.x + x) * image.width / viewport.width, (b.y + y) * image.height / viewport.height) : image.pixel(x * image.width / b.width, y * image.height / b.height),
        expected = world.provinces.find(p => p.id === 10).terrain_color;
      for (let i = 0; i < 3; i++) expect(Math.abs(actual[i] - expected[i])).toBeLessThanOrEqual(1);
      const gpu = await map.evaluate(async (host, {
        x,
        y
      }) => {
        if (host.dataset.backend !== 'webgl2') return null;
        const canvas = host.querySelector('canvas'),
          gl = canvas.getContext('webgl2');
        return new Promise(resolve => requestAnimationFrame(() => {
          const pixel = new Uint8Array(4);
          gl.readPixels(Math.floor(x * canvas.width / host.clientWidth), canvas.height - 1 - Math.floor(y * canvas.height / host.clientHeight), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixel);
          resolve({
            pixel: Array.from(pixel),
            error: gl.getError(),
            lost: gl.isContextLost()
          });
        }));
      }, {
        x,
        y
      });
      if (gpu) {
        expect(gpu.error).toBe(0);
        expect(gpu.lost).toBe(false);
        for (let i = 0; i < 3; i++) expect(Math.abs(gpu.pixel[i] - expected[i])).toBeLessThanOrEqual(1);
      }
      await expect.poll(() => page.evaluate(() => devicePixelRatio)).toBe(dpr);
      await expect.poll(async () => {
        const b = await buffer();
        return {
          width: b.width - b.expectedWidth,
          height: b.height - b.expectedHeight
        };
      }).toEqual({
        width: 0,
        height: 0
      });
      await expect(page.getByTestId('selected-province')).toHaveText('30');
      await expect(page.getByTestId('state-panel').locator('.ledger-value strong')).toHaveText('0');
      for (const [key, value] of Object.entries(authority)) await expect(page.getByTestId(key)).toHaveText(value);
      const resources = await life();
      expect(resources).toMatchObject({
        listeners: 6,
        observers: 1
      });
      steps.push({
        dpr,
        backend,
        buffer: await buffer(),
        actual,
        expected,
        gpu,
        image: {
          width: image.width,
          height: image.height,
          capture: cdp ? 'native full viewport without clip' : 'element screenshot'
        },
        camera: c,
        box: b,
        authority,
        resources
      });
    }
    await (cdp === null || cdp === void 0 ? void 0 : cdp.detach());
    expect(metadata).toBe(1);
    expect(index).toBe(1);
    reload = true;
    await page.getByTestId('speed-3').click();
    await expect(page.getByRole('alert').filter({
      hasText: 'Map data'
    })).toContainText('Map data');
    await expect(map.locator('canvas')).toHaveCount(0);
    await expect.poll(life).toEqual({
      media: 0,
      listeners: 0,
      observers: 0,
      rafs: 0
    });
    await expect(page.getByTestId('selected-province')).toHaveText('30');
    await expect(page.getByTestId('state-panel').locator('.ledger-value strong')).toHaveText('0');
    for (const [key, value] of Object.entries(authority)) await expect(page.getByTestId(key)).toHaveText(value);
    expect(errors).toEqual([]);
  } finally {
    writeFileSync(`${evidence}/${info.project.name}-${force}.json`, JSON.stringify({
      browser: browser.version(),
      scope: browserName === 'chromium' ? 'live CDP DPR1↔2, fixed CSS box' : 'native DPR2 creation only; live CDP unavailable',
      steps,
      errors,
      resources: await page.evaluate(() => {
        var _dprLife, _ref;
        return (_dprLife = (_ref = window).__dprLife) === null || _dprLife === void 0 ? void 0 : _dprLife.call(_ref);
      }).catch(() => null),
      surface: await map.evaluate(host => {
        const canvas = host.querySelector('canvas');
        return {
          dpr: devicePixelRatio,
          resolution1: matchMedia('(resolution: 1dppx)').matches,
          resolution2: matchMedia('(resolution: 2dppx)').matches,
          canvas: canvas ? {
            width: canvas.width,
            height: canvas.height,
            cssWidth: canvas.clientWidth,
            cssHeight: canvas.clientHeight
          } : null,
          dataset: {
            ...host.dataset
          }
        };
      }).catch(() => null)
    }, null, 2));
    await context.close();
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwiZGVjb2RlIiwiZW5jb2RlIiwibWtkaXJTeW5jIiwid3JpdGVGaWxlU3luYyIsInBuZyIsImV2aWRlbmNlIiwiX3Byb2Nlc3MkZW52JE9IX01BUF9EIiwicHJvY2VzcyIsImVudiIsIk9IX01BUF9EUFJfRVZJREVOQ0UiLCJyZWN1cnNpdmUiLCJmb3JjZSIsImJyb3dzZXIiLCJicm93c2VyTmFtZSIsImluZm8iLCJjb250ZXh0IiwibmV3Q29udGV4dCIsInZpZXdwb3J0Iiwid2lkdGgiLCJoZWlnaHQiLCJkZXZpY2VTY2FsZUZhY3RvciIsImxvY2FsZSIsImJhc2VVUkwiLCJwcm9qZWN0IiwidXNlIiwicGFnZSIsIm5ld1BhZ2UiLCJlcnJvcnMiLCJzdGVwcyIsIndvcmxkIiwid29ybGRzIiwicmVsb2FkIiwiY2hhbmdlZCIsIm1ldGFkYXRhIiwiaW5kZXgiLCJtYXAiLCJnZXRCeVRlc3RJZCIsImNhbSIsIkpTT04iLCJwYXJzZSIsImdldEF0dHJpYnV0ZSIsImxpZmUiLCJldmFsdWF0ZSIsIndpbmRvdyIsIl9fZHByTGlmZSIsImFkZEluaXRTY3JpcHQiLCJtZWRpYSIsIlNldCIsImxpc3RlbmVycyIsIm9ic2VydmVycyIsInJhZnMiLCJhZGQiLCJFdmVudFRhcmdldCIsInByb3RvdHlwZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidHlwZSIsImxpc3RlbmVyIiwib3B0aW9ucyIsIk1lZGlhUXVlcnlMaXN0IiwiSFRNTEVsZW1lbnQiLCJjbGFzc0xpc3QiLCJjb250YWlucyIsImNhbGwiLCJkZWxldGUiLCJvYnNlcnZlIiwiUmVzaXplT2JzZXJ2ZXIiLCJkaXNjb25uZWN0IiwidGFyZ2V0IiwicmFmIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwiY2FuY2VsIiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJmbiIsImlkIiwidCIsIk9iamVjdCIsImFzc2lnbiIsInNpemUiLCJvbiIsImUiLCJwdXNoIiwibWVzc2FnZSIsInJvdXRlV2ViU29ja2V0Iiwicm91dGUiLCJzZXJ2ZXIiLCJjb25uZWN0VG9TZXJ2ZXIiLCJvbk1lc3NhZ2UiLCJkYXRhIiwibSIsInByb3ZpbmNlcyIsImZpbmQiLCJwIiwidGVycmFpbl9jb2xvciIsInNlbmQiLCJCdWZmZXIiLCJmcm9tIiwiZW5naW5lX3ZlcnNpb24iLCJwcm90b2NvbF92ZXJzaW9uIiwiYWNjZXB0ZWQiLCJyZWFzb25fa2V5IiwicGFja3MiLCJ2ZXJzaW9uIiwiaGFzaCIsInNlc3Npb25zIiwiciIsImZ1bGZpbGwiLCJzdGF0dXMiLCJjb250aW51ZSIsImdvdG8iLCJ0b0hhdmVBdHRyaWJ1dGUiLCJjbGljayIsInRvSGF2ZVRleHQiLCJib3giLCJib3VuZGluZ0JveCIsImNhbWVyYSIsInBvc2l0aW9uIiwieCIsInkiLCJsb2NhdG9yIiwicG9sbCIsInRvQmVHcmVhdGVyVGhhbk9yRXF1YWwiLCJnZXRCeVJvbGUiLCJuYW1lIiwiZXhhY3QiLCJtb3VzZSIsIm1vdmUiLCJ3aGVlbCIsInpvb20iLCJ0b0JlR3JlYXRlclRoYW4iLCJkb3duIiwidXAiLCJzYXZlZCIsImF1dGhvcml0eSIsInRpY2siLCJ0ZXh0Q29udGVudCIsImRhdGUiLCJob3VyIiwiYmFja2VuZCIsImNkcCIsIm5ld0NEUFNlc3Npb24iLCJidWZmZXIiLCJjIiwiZXhwZWN0ZWRXaWR0aCIsIk1hdGgiLCJmbG9vciIsImNsaWVudFdpZHRoIiwiZGV2aWNlUGl4ZWxSYXRpbyIsImV4cGVjdGVkSGVpZ2h0IiwiY2xpZW50SGVpZ2h0IiwiZHByIiwib2xkIiwiZWxlbWVudEhhbmRsZSIsIm1vYmlsZSIsInRvQmUiLCJiIiwidG9FcXVhbCIsImlzQ29ubmVjdGVkIiwiZ2V0Q29udGV4dCIsImlzQ29udGV4dExvc3QiLCJwYXRoIiwibGVuZ3RoIiwiaW5uZXJXaWR0aCIsImlubmVySGVpZ2h0Iiwic2Nyb2xsWCIsInNjcm9sbFkiLCJieXRlcyIsImZvcm1hdCIsImNhcHR1cmVCZXlvbmRWaWV3cG9ydCIsInNjcmVlbnNob3QiLCJpbWFnZSIsImFjdHVhbCIsInBpeGVsIiwiZXhwZWN0ZWQiLCJpIiwiYWJzIiwidG9CZUxlc3NUaGFuT3JFcXVhbCIsImdwdSIsImhvc3QiLCJkYXRhc2V0IiwiY2FudmFzIiwicXVlcnlTZWxlY3RvciIsImdsIiwiUHJvbWlzZSIsInJlc29sdmUiLCJVaW50OEFycmF5IiwicmVhZFBpeGVscyIsIlJHQkEiLCJVTlNJR05FRF9CWVRFIiwiQXJyYXkiLCJlcnJvciIsImdldEVycm9yIiwibG9zdCIsImtleSIsInZhbHVlIiwiZW50cmllcyIsInJlc291cmNlcyIsInRvTWF0Y2hPYmplY3QiLCJjYXB0dXJlIiwiZGV0YWNoIiwiZmlsdGVyIiwiaGFzVGV4dCIsInRvQ29udGFpblRleHQiLCJ0b0hhdmVDb3VudCIsInN0cmluZ2lmeSIsInNjb3BlIiwiX2RwckxpZmUiLCJfcmVmIiwiY2F0Y2giLCJzdXJmYWNlIiwicmVzb2x1dGlvbjEiLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsInJlc29sdXRpb24yIiwiY3NzV2lkdGgiLCJjc3NIZWlnaHQiLCJjbG9zZSJdLCJzb3VyY2VzIjpbIm1hcC1kcHIuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2V4cGVjdCx0ZXN0fSBmcm9tICdAcGxheXdyaWdodC90ZXN0JztcbmltcG9ydCB7ZGVjb2RlLGVuY29kZX0gZnJvbSAnQG1zZ3BhY2svbXNncGFjayc7XG5pbXBvcnQge21rZGlyU3luYyx3cml0ZUZpbGVTeW5jfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB0eXBlIHtTZXJ2ZXJNZXNzYWdlLFdvcmxkVmlld30gZnJvbSAnLi4vc3JjL3Byb3RvL3Byb3RvY29sJztcbmltcG9ydCB7cG5nfSBmcm9tICcuL3BuZyc7XG5jb25zdCBldmlkZW5jZT1wcm9jZXNzLmVudi5PSF9NQVBfRFBSX0VWSURFTkNFPz8nLi4vdGFyZ2V0L3dwMDgvZHByJztta2RpclN5bmMoZXZpZGVuY2Use3JlY3Vyc2l2ZTp0cnVlfSk7XG5mb3IoY29uc3QgZm9yY2Ugb2YgW2ZhbHNlLHRydWVdKXRlc3QoYFJFUS1QTEFULTAzIERQUiBzdXJmYWNlIHByZXNlcnZlcyBkaXNwbGF5IGFuZCBhdXRob3JpdHkgJHtmb3JjZT8nZm9yY2VkIEdMJzoncHJlZmVycmVkJ31gLGFzeW5jKHticm93c2VyLGJyb3dzZXJOYW1lfSxpbmZvKT0+e1xuIC8vIENocm9taXVtIHN1cHBvcnRzIGFuIGFjdHVhbCBsaXZlIERQUiBjaGFuZ2UgdGhyb3VnaCB0YWItc2NvcGVkIENEUC5cbiAvLyBGaXJlZm94L1dlYktpdCBleGVyY2lzZSBuYXRpdmUgRFBSMiBjcmVhdGlvbjsgbm8gZHluYW1pYy1jaGFuZ2UgY2xhaW0uXG4gY29uc3QgY29udGV4dD1hd2FpdCBicm93c2VyLm5ld0NvbnRleHQoe3ZpZXdwb3J0Ont3aWR0aDoxMjgwLGhlaWdodDo3MjB9LGRldmljZVNjYWxlRmFjdG9yOmJyb3dzZXJOYW1lPT09J2Nocm9taXVtJz8xOjIsbG9jYWxlOidlbi1VUycsYmFzZVVSTDppbmZvLnByb2plY3QudXNlLmJhc2VVUkx9KTtcbiBjb25zdCBwYWdlPWF3YWl0IGNvbnRleHQubmV3UGFnZSgpLGVycm9yczpzdHJpbmdbXT1bXSxzdGVwczp1bmtub3duW109W107bGV0IHdvcmxkOldvcmxkVmlld3x1bmRlZmluZWQsd29ybGRzPTAscmVsb2FkPWZhbHNlLGNoYW5nZWQ9ZmFsc2UsbWV0YWRhdGE9MCxpbmRleD0wO1xuIGNvbnN0IG1hcD1wYWdlLmdldEJ5VGVzdElkKCdwcm92aW5jZS1tYXAnKSxjYW09YXN5bmMoKT0+SlNPTi5wYXJzZSgoYXdhaXQgbWFwLmdldEF0dHJpYnV0ZSgnZGF0YS1jYW1lcmEnKSkhKSxsaWZlPSgpPT5wYWdlLmV2YWx1YXRlKCgpPT4od2luZG93IGFzIHVua25vd24gYXMge19fZHByTGlmZTooKT0+dW5rbm93bn0pLl9fZHByTGlmZSgpKTtcbiB0cnl7XG4gYXdhaXQgcGFnZS5hZGRJbml0U2NyaXB0KCgpPT57XG4gIGNvbnN0IG1lZGlhPW5ldyBTZXQ8RXZlbnRMaXN0ZW5lck9yRXZlbnRMaXN0ZW5lck9iamVjdD4oKSxsaXN0ZW5lcnM9bmV3IFNldDxFdmVudExpc3RlbmVyT3JFdmVudExpc3RlbmVyT2JqZWN0PigpLG9ic2VydmVycz1uZXcgU2V0PFJlc2l6ZU9ic2VydmVyPigpLHJhZnM9bmV3IFNldDxudW1iZXI+KCk7XG4gIGNvbnN0IGFkZD1FdmVudFRhcmdldC5wcm90b3R5cGUuYWRkRXZlbnRMaXN0ZW5lcixyZW1vdmU9RXZlbnRUYXJnZXQucHJvdG90eXBlLnJlbW92ZUV2ZW50TGlzdGVuZXI7XG4gIEV2ZW50VGFyZ2V0LnByb3RvdHlwZS5hZGRFdmVudExpc3RlbmVyPWZ1bmN0aW9uKHR5cGUsbGlzdGVuZXIsb3B0aW9ucyl7aWYobGlzdGVuZXIpe2lmKHRoaXMgaW5zdGFuY2VvZiBNZWRpYVF1ZXJ5TGlzdCYmdHlwZT09PSdjaGFuZ2UnKW1lZGlhLmFkZChsaXN0ZW5lcik7aWYodGhpcyBpbnN0YW5jZW9mIEhUTUxFbGVtZW50JiZ0aGlzLmNsYXNzTGlzdC5jb250YWlucygncHJvdmluY2UtbWFwJykpbGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7fXJldHVybiBhZGQuY2FsbCh0aGlzLHR5cGUsbGlzdGVuZXIsb3B0aW9ucyk7fTtcbiAgRXZlbnRUYXJnZXQucHJvdG90eXBlLnJlbW92ZUV2ZW50TGlzdGVuZXI9ZnVuY3Rpb24odHlwZSxsaXN0ZW5lcixvcHRpb25zKXtpZihsaXN0ZW5lcil7aWYodGhpcyBpbnN0YW5jZW9mIE1lZGlhUXVlcnlMaXN0JiZ0eXBlPT09J2NoYW5nZScpbWVkaWEuZGVsZXRlKGxpc3RlbmVyKTtpZih0aGlzIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQmJnRoaXMuY2xhc3NMaXN0LmNvbnRhaW5zKCdwcm92aW5jZS1tYXAnKSlsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTt9cmV0dXJuIHJlbW92ZS5jYWxsKHRoaXMsdHlwZSxsaXN0ZW5lcixvcHRpb25zKTt9O1xuICBjb25zdCBvYnNlcnZlPVJlc2l6ZU9ic2VydmVyLnByb3RvdHlwZS5vYnNlcnZlLGRpc2Nvbm5lY3Q9UmVzaXplT2JzZXJ2ZXIucHJvdG90eXBlLmRpc2Nvbm5lY3Q7XG4gIFJlc2l6ZU9ic2VydmVyLnByb3RvdHlwZS5vYnNlcnZlPWZ1bmN0aW9uKHRhcmdldCxvcHRpb25zKXtpZih0YXJnZXQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCYmdGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygncHJvdmluY2UtbWFwJykpb2JzZXJ2ZXJzLmFkZCh0aGlzKTtyZXR1cm4gb2JzZXJ2ZS5jYWxsKHRoaXMsdGFyZ2V0LG9wdGlvbnMpO307XG4gIFJlc2l6ZU9ic2VydmVyLnByb3RvdHlwZS5kaXNjb25uZWN0PWZ1bmN0aW9uKCl7b2JzZXJ2ZXJzLmRlbGV0ZSh0aGlzKTtyZXR1cm4gZGlzY29ubmVjdC5jYWxsKHRoaXMpO307XG4gIGNvbnN0IHJhZj13aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lLGNhbmNlbD13aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWU7XG4gIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWU9Zm49PntsZXQgaWQ6bnVtYmVyO2lkPXJhZih0PT57cmFmcy5kZWxldGUoaWQpO2ZuKHQpO30pO3JhZnMuYWRkKGlkKTtyZXR1cm4gaWQ7fTt3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWU9aWQ9PntyYWZzLmRlbGV0ZShpZCk7Y2FuY2VsKGlkKTt9O1xuICBPYmplY3QuYXNzaWduKHdpbmRvdyx7X19kcHJMaWZlOigpPT4oe21lZGlhOm1lZGlhLnNpemUsbGlzdGVuZXJzOmxpc3RlbmVycy5zaXplLG9ic2VydmVyczpvYnNlcnZlcnMuc2l6ZSxyYWZzOnJhZnMuc2l6ZX0pfSk7XG4gfSk7XG4gcGFnZS5vbigncGFnZWVycm9yJyxlPT5lcnJvcnMucHVzaChlLm1lc3NhZ2UpKTtcbiBhd2FpdCBwYWdlLnJvdXRlV2ViU29ja2V0KCcqKi93cycscm91dGU9Pntjb25zdCBzZXJ2ZXI9cm91dGUuY29ubmVjdFRvU2VydmVyKCk7c2VydmVyLm9uTWVzc2FnZShkYXRhPT57Y29uc3QgbT1kZWNvZGUoZGF0YSBhcyBCdWZmZXIpIGFzIFNlcnZlck1lc3NhZ2U7aWYobS50eXBlPT09J1dvcmxkUmVzdWx0JyYmbS53b3JsZCl7aWYoKyt3b3JsZHM+PTIpbS53b3JsZC5wcm92aW5jZXMuZmluZChwPT5wLmlkPT09MTApIS50ZXJyYWluX2NvbG9yPVs3NywxMTEsMTU1XTt3b3JsZD1tLndvcmxkO31pZihyZWxvYWQmJiFjaGFuZ2VkKXtjaGFuZ2VkPXRydWU7cm91dGUuc2VuZChCdWZmZXIuZnJvbShlbmNvZGUoe3R5cGU6J1dlbGNvbWUnLGVuZ2luZV92ZXJzaW9uOidmaXh0dXJlJyxwcm90b2NvbF92ZXJzaW9uOidtMC12MScsYWNjZXB0ZWQ6dHJ1ZSxyZWFzb25fa2V5Om51bGwscGFja3M6W3tpZDondGVzdGxhbmQnLHZlcnNpb246JzAuMS4wJyxoYXNoOicwMDAwMDAwMDAwMDAwMDAxJ31dLHNlc3Npb25zOlsnbG9jYWwnXX0pKSk7fXJvdXRlLnNlbmQoQnVmZmVyLmZyb20oZW5jb2RlKG0pKSk7fSk7fSk7XG4gYXdhaXQgcGFnZS5yb3V0ZSgnKiovbWFwcy90ZXN0bGFuZC9tZXRhZGF0YScscj0+e21ldGFkYXRhKys7cmV0dXJuIHJlbG9hZD9yLmZ1bGZpbGwoe3N0YXR1czo0MDR9KTpyLmNvbnRpbnVlKCk7fSk7XG4gYXdhaXQgcGFnZS5yb3V0ZSgnKiovbWFwcy90ZXN0bGFuZC9pbmRleC5iaW4/Kicscj0+e2luZGV4Kys7cmV0dXJuIHIuY29udGludWUoKTt9KTtcbiBhd2FpdCBwYWdlLmdvdG8oZm9yY2U/Jy8/Zm9yY2VXZWJHTD0xJzonLycpO2F3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1mcmFtZXMnLC9eWzEtOV1cXGQqJC8pO2F3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ3BhdXNlJykuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgncGF1c2UnKSkudG9IYXZlVGV4dCgnUmVzdW1lJyk7XG4gY29uc3QgYm94PShhd2FpdCBtYXAuYm91bmRpbmdCb3goKSkhLGNhbWVyYT1hd2FpdCBjYW0oKTtcbiBhd2FpdCBtYXAuY2xpY2soe3Bvc2l0aW9uOnt4OigxLWNhbWVyYS54KS9jYW1lcmEud2lkdGgqYm94LndpZHRoK2JveC53aWR0aC8yLHk6KDMtY2FtZXJhLnkpL2NhbWVyYS5oZWlnaHQqYm94LmhlaWdodCtib3guaGVpZ2h0LzJ9fSk7XG4gYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3NlbGVjdGVkLXByb3ZpbmNlJykpLnRvSGF2ZVRleHQoJzMwJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykubG9jYXRvcignLmxlZGdlci12YWx1ZSBzdHJvbmcnKSkudG9IYXZlVGV4dCgnMCcpO1xuIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ3NwZWVkLTInKS5jbGljaygpO2F3YWl0IGV4cGVjdC5wb2xsKCgpPT53b3JsZHMpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoMik7YXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicse25hbWU6J1RlcnJhaW4nLGV4YWN0OnRydWV9KS5jbGljaygpO1xuIGF3YWl0IHBhZ2UubW91c2UubW92ZShib3gueCtib3gud2lkdGgvMixib3gueStib3guaGVpZ2h0LzIpO2F3YWl0IHBhZ2UubW91c2Uud2hlZWwoMCwtMjAwKTthd2FpdCBleHBlY3QucG9sbChhc3luYygpPT4oYXdhaXQgY2FtKCkpLnpvb20pLnRvQmVHcmVhdGVyVGhhbigxKTthd2FpdCBwYWdlLm1vdXNlLmRvd24oKTthd2FpdCBwYWdlLm1vdXNlLm1vdmUoYm94LngrYm94LndpZHRoLzIrMjAsYm94LnkrYm94LmhlaWdodC8yKzEwLHtzdGVwczo0fSk7YXdhaXQgcGFnZS5tb3VzZS51cCgpO2F3YWl0IHBhZ2UubW91c2UubW92ZSgwLDApO1xuIGNvbnN0IHNhdmVkPWF3YWl0IGNhbSgpLGF1dGhvcml0eT17dGljazphd2FpdCBwYWdlLmdldEJ5VGVzdElkKCd0aWNrJykudGV4dENvbnRlbnQoKSxkYXRlOmF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ2RhdGUnKS50ZXh0Q29udGVudCgpLGhvdXI6YXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnaG91cicpLnRleHRDb250ZW50KCl9LGJhY2tlbmQ9YXdhaXQgbWFwLmdldEF0dHJpYnV0ZSgnZGF0YS1iYWNrZW5kJyksY2RwPWJyb3dzZXJOYW1lPT09J2Nocm9taXVtJz9hd2FpdCBjb250ZXh0Lm5ld0NEUFNlc3Npb24ocGFnZSk6bnVsbDtcbiBjb25zdCBidWZmZXI9KCk9Pm1hcC5sb2NhdG9yKCdjYW52YXMnKS5ldmFsdWF0ZSgoYzpIVE1MQ2FudmFzRWxlbWVudCk9Pih7d2lkdGg6Yy53aWR0aCxoZWlnaHQ6Yy5oZWlnaHQsZXhwZWN0ZWRXaWR0aDpNYXRoLmZsb29yKGMuY2xpZW50V2lkdGgqZGV2aWNlUGl4ZWxSYXRpbyksZXhwZWN0ZWRIZWlnaHQ6TWF0aC5mbG9vcihjLmNsaWVudEhlaWdodCpkZXZpY2VQaXhlbFJhdGlvKX0pKTtcbiBmb3IoY29uc3QgZHByIG9mIGNkcD9bMiwxLjUsMSwyLDEuNSwxXTpbMl0pe1xuICBjb25zdCBvbGQ9YXdhaXQgbWFwLmxvY2F0b3IoJ2NhbnZhcycpLmVsZW1lbnRIYW5kbGUoKTtpZihjZHApYXdhaXQgY2RwLnNlbmQoJ0VtdWxhdGlvbi5zZXREZXZpY2VNZXRyaWNzT3ZlcnJpZGUnLHt3aWR0aDoxMjgwLGhlaWdodDo3MjAsZGV2aWNlU2NhbGVGYWN0b3I6ZHByLG1vYmlsZTpmYWxzZX0pO1xuICBhd2FpdCBleHBlY3QucG9sbCgoKT0+cGFnZS5ldmFsdWF0ZSgoKT0+ZGV2aWNlUGl4ZWxSYXRpbykpLnRvQmUoZHByKTtcbiAgLy8gTm8gUmVzZXQgb3IgQ1NTIGdlb21ldHJ5IGNoYW5nZSBtYXkgYmUgdXNlZCB0byB0cmlnZ2VyIHRoaXMgdXBkYXRlLlxuICBhd2FpdCBleHBlY3QucG9sbChhc3luYygpPT57Y29uc3QgYj1hd2FpdCBidWZmZXIoKTtyZXR1cm4ge3dpZHRoOmIud2lkdGgtYi5leHBlY3RlZFdpZHRoLGhlaWdodDpiLmhlaWdodC1iLmV4cGVjdGVkSGVpZ2h0fTt9KS50b0VxdWFsKHt3aWR0aDowLGhlaWdodDowfSk7XG4gIGF3YWl0IGV4cGVjdChtYXApLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1mcmFtZXMnLC9eWzEtOV1cXGQqJC8pO2V4cGVjdChhd2FpdCBtYXAuYm91bmRpbmdCb3goKSkudG9FcXVhbChib3gpO2V4cGVjdChhd2FpdCBjYW0oKSkudG9FcXVhbChzYXZlZCk7YXdhaXQgZXhwZWN0KG1hcCkudG9IYXZlQXR0cmlidXRlKCdkYXRhLW1vZGUnLCdtYXAtbW9kZS10ZXJyYWluJyk7XG4gIGlmKGNkcCl7ZXhwZWN0KGF3YWl0IG9sZCEuZXZhbHVhdGUoYz0+Yy5pc0Nvbm5lY3RlZCkpLnRvQmUoYmFja2VuZD09PSd3ZWJncHUnKTtpZihiYWNrZW5kPT09J3dlYmdsMicpZXhwZWN0KGF3YWl0IG9sZCEuZXZhbHVhdGUoKGM6SFRNTENhbnZhc0VsZW1lbnQpPT5jLmdldENvbnRleHQoJ3dlYmdsMicpIS5pc0NvbnRleHRMb3N0KCkpKS50b0JlKHRydWUpO31cbiAgLy8gRWxlbWVudCBzY3JlZW5zaG90cyBvbiBDaHJvbWl1bSByZXN0b3JlIHRoZSBjb25maWd1cmVkIGNvbnRleHQgRFBSMS5cbiAgLy8gQ2FwdHVyZSB0aGUgZnVsbCBuYXRpdmUgdmlld3BvcnQgd2l0aG91dCBhIGNsaXAgZm9yIHRoaXMgbGl2ZSBEUFIgdGVzdC5cbiAgLy8gRXhpc3RpbmcgcmVzaXplL21vZGUgdGVzdHMgcmV0YWluIHRoZWlyIGVsZW1lbnQgc2NyZWVuc2hvdCBzdGFiaWxpdHkgZ2F0ZS5cbiAgY29uc3QgcGF0aD1gJHtldmlkZW5jZX0vJHtpbmZvLnByb2plY3QubmFtZX0tJHtmb3JjZX0tZHByJHtkcHJ9LSR7c3RlcHMubGVuZ3RofS5wbmdgLGI9KGF3YWl0IG1hcC5ib3VuZGluZ0JveCgpKSEsYz1hd2FpdCBjYW0oKSx2aWV3cG9ydD1hd2FpdCBwYWdlLmV2YWx1YXRlKCgpPT4oe3dpZHRoOmlubmVyV2lkdGgsaGVpZ2h0OmlubmVySGVpZ2h0LHNjcm9sbFgsc2Nyb2xsWX0pKTtcbiAgY29uc3QgYnl0ZXM9Y2RwP0J1ZmZlci5mcm9tKChhd2FpdCBjZHAuc2VuZCgnUGFnZS5jYXB0dXJlU2NyZWVuc2hvdCcse2Zvcm1hdDoncG5nJyxjYXB0dXJlQmV5b25kVmlld3BvcnQ6ZmFsc2V9KSkuZGF0YSwnYmFzZTY0Jyk6YXdhaXQgbWFwLnNjcmVlbnNob3Qoe3BhdGh9KTtpZihjZHApd3JpdGVGaWxlU3luYyhwYXRoLGJ5dGVzKTtcbiAgY29uc3QgaW1hZ2U9cG5nKGJ5dGVzKSx4PSgxLWMueCkvYy53aWR0aCpiLndpZHRoK2Iud2lkdGgvMix5PSgxLWMueSkvYy5oZWlnaHQqYi5oZWlnaHQrYi5oZWlnaHQvMjtcbiAgY29uc3QgYWN0dWFsPWNkcD9pbWFnZS5waXhlbCgoYi54K3gpKmltYWdlLndpZHRoL3ZpZXdwb3J0LndpZHRoLChiLnkreSkqaW1hZ2UuaGVpZ2h0L3ZpZXdwb3J0LmhlaWdodCk6aW1hZ2UucGl4ZWwoeCppbWFnZS53aWR0aC9iLndpZHRoLHkqaW1hZ2UuaGVpZ2h0L2IuaGVpZ2h0KSxleHBlY3RlZD13b3JsZCEucHJvdmluY2VzLmZpbmQocD0+cC5pZD09PTEwKSEudGVycmFpbl9jb2xvciE7Zm9yKGxldCBpPTA7aTwzO2krKylleHBlY3QoTWF0aC5hYnMoYWN0dWFsW2ldLWV4cGVjdGVkW2ldKSkudG9CZUxlc3NUaGFuT3JFcXVhbCgxKTtcbiAgY29uc3QgZ3B1PWF3YWl0IG1hcC5ldmFsdWF0ZShhc3luYyhob3N0LHt4LHl9KT0+e2lmKGhvc3QuZGF0YXNldC5iYWNrZW5kIT09J3dlYmdsMicpcmV0dXJuIG51bGw7Y29uc3QgY2FudmFzPWhvc3QucXVlcnlTZWxlY3RvcignY2FudmFzJykhLGdsPWNhbnZhcy5nZXRDb250ZXh0KCd3ZWJnbDInKSE7cmV0dXJuIG5ldyBQcm9taXNlPHtwaXhlbDpudW1iZXJbXTtlcnJvcjpudW1iZXI7bG9zdDpib29sZWFufT4ocmVzb2x2ZT0+cmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpPT57Y29uc3QgcGl4ZWw9bmV3IFVpbnQ4QXJyYXkoNCk7Z2wucmVhZFBpeGVscyhNYXRoLmZsb29yKHgqY2FudmFzLndpZHRoL2hvc3QuY2xpZW50V2lkdGgpLGNhbnZhcy5oZWlnaHQtMS1NYXRoLmZsb29yKHkqY2FudmFzLmhlaWdodC9ob3N0LmNsaWVudEhlaWdodCksMSwxLGdsLlJHQkEsZ2wuVU5TSUdORURfQllURSxwaXhlbCk7cmVzb2x2ZSh7cGl4ZWw6QXJyYXkuZnJvbShwaXhlbCksZXJyb3I6Z2wuZ2V0RXJyb3IoKSxsb3N0OmdsLmlzQ29udGV4dExvc3QoKX0pO30pKTt9LHt4LHl9KTtcbiAgaWYoZ3B1KXtleHBlY3QoZ3B1LmVycm9yKS50b0JlKDApO2V4cGVjdChncHUubG9zdCkudG9CZShmYWxzZSk7Zm9yKGxldCBpPTA7aTwzO2krKylleHBlY3QoTWF0aC5hYnMoZ3B1LnBpeGVsW2ldLWV4cGVjdGVkW2ldKSkudG9CZUxlc3NUaGFuT3JFcXVhbCgxKTt9XG4gIGF3YWl0IGV4cGVjdC5wb2xsKCgpPT5wYWdlLmV2YWx1YXRlKCgpPT5kZXZpY2VQaXhlbFJhdGlvKSkudG9CZShkcHIpO2F3YWl0IGV4cGVjdC5wb2xsKGFzeW5jKCk9Pntjb25zdCBiPWF3YWl0IGJ1ZmZlcigpO3JldHVybiB7d2lkdGg6Yi53aWR0aC1iLmV4cGVjdGVkV2lkdGgsaGVpZ2h0OmIuaGVpZ2h0LWIuZXhwZWN0ZWRIZWlnaHR9O30pLnRvRXF1YWwoe3dpZHRoOjAsaGVpZ2h0OjB9KTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3NlbGVjdGVkLXByb3ZpbmNlJykpLnRvSGF2ZVRleHQoJzMwJyk7YXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3N0YXRlLXBhbmVsJykubG9jYXRvcignLmxlZGdlci12YWx1ZSBzdHJvbmcnKSkudG9IYXZlVGV4dCgnMCcpO2Zvcihjb25zdCBba2V5LHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhhdXRob3JpdHkpKWF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKGtleSkpLnRvSGF2ZVRleHQodmFsdWUhKTtcbiAgY29uc3QgcmVzb3VyY2VzPWF3YWl0IGxpZmUoKTtleHBlY3QocmVzb3VyY2VzKS50b01hdGNoT2JqZWN0KHtsaXN0ZW5lcnM6NixvYnNlcnZlcnM6MX0pO3N0ZXBzLnB1c2goe2RwcixiYWNrZW5kLGJ1ZmZlcjphd2FpdCBidWZmZXIoKSxhY3R1YWwsZXhwZWN0ZWQsZ3B1LGltYWdlOnt3aWR0aDppbWFnZS53aWR0aCxoZWlnaHQ6aW1hZ2UuaGVpZ2h0LGNhcHR1cmU6Y2RwPyduYXRpdmUgZnVsbCB2aWV3cG9ydCB3aXRob3V0IGNsaXAnOidlbGVtZW50IHNjcmVlbnNob3QnfSxjYW1lcmE6Yyxib3g6YixhdXRob3JpdHkscmVzb3VyY2VzfSk7XG4gfVxuIGF3YWl0IGNkcD8uZGV0YWNoKCk7ZXhwZWN0KG1ldGFkYXRhKS50b0JlKDEpO2V4cGVjdChpbmRleCkudG9CZSgxKTtcbiByZWxvYWQ9dHJ1ZTthd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdzcGVlZC0zJykuY2xpY2soKTthd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2FsZXJ0JykuZmlsdGVyKHtoYXNUZXh0OidNYXAgZGF0YSd9KSkudG9Db250YWluVGV4dCgnTWFwIGRhdGEnKTthd2FpdCBleHBlY3QobWFwLmxvY2F0b3IoJ2NhbnZhcycpKS50b0hhdmVDb3VudCgwKTthd2FpdCBleHBlY3QucG9sbChsaWZlKS50b0VxdWFsKHttZWRpYTowLGxpc3RlbmVyczowLG9ic2VydmVyczowLHJhZnM6MH0pO1xuIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzZWxlY3RlZC1wcm92aW5jZScpKS50b0hhdmVUZXh0KCczMCcpO2F3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdzdGF0ZS1wYW5lbCcpLmxvY2F0b3IoJy5sZWRnZXItdmFsdWUgc3Ryb25nJykpLnRvSGF2ZVRleHQoJzAnKTtmb3IoY29uc3QgW2tleSx2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoYXV0aG9yaXR5KSlhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZChrZXkpKS50b0hhdmVUZXh0KHZhbHVlISk7ZXhwZWN0KGVycm9ycykudG9FcXVhbChbXSk7XG4gfWZpbmFsbHl7d3JpdGVGaWxlU3luYyhgJHtldmlkZW5jZX0vJHtpbmZvLnByb2plY3QubmFtZX0tJHtmb3JjZX0uanNvbmAsSlNPTi5zdHJpbmdpZnkoe2Jyb3dzZXI6YnJvd3Nlci52ZXJzaW9uKCksc2NvcGU6YnJvd3Nlck5hbWU9PT0nY2hyb21pdW0nPydsaXZlIENEUCBEUFIx4oaUMiwgZml4ZWQgQ1NTIGJveCc6J25hdGl2ZSBEUFIyIGNyZWF0aW9uIG9ubHk7IGxpdmUgQ0RQIHVuYXZhaWxhYmxlJyxzdGVwcyxlcnJvcnMscmVzb3VyY2VzOmF3YWl0IHBhZ2UuZXZhbHVhdGUoKCk9Pih3aW5kb3cgYXMgdW5rbm93biBhcyB7X19kcHJMaWZlPzooKT0+dW5rbm93bn0pLl9fZHByTGlmZT8uKCkpLmNhdGNoKCgpPT5udWxsKSxzdXJmYWNlOmF3YWl0IG1hcC5ldmFsdWF0ZShob3N0PT57Y29uc3QgY2FudmFzPWhvc3QucXVlcnlTZWxlY3RvcignY2FudmFzJyk7cmV0dXJuIHtkcHI6ZGV2aWNlUGl4ZWxSYXRpbyxyZXNvbHV0aW9uMTptYXRjaE1lZGlhKCcocmVzb2x1dGlvbjogMWRwcHgpJykubWF0Y2hlcyxyZXNvbHV0aW9uMjptYXRjaE1lZGlhKCcocmVzb2x1dGlvbjogMmRwcHgpJykubWF0Y2hlcyxjYW52YXM6Y2FudmFzP3t3aWR0aDpjYW52YXMud2lkdGgsaGVpZ2h0OmNhbnZhcy5oZWlnaHQsY3NzV2lkdGg6Y2FudmFzLmNsaWVudFdpZHRoLGNzc0hlaWdodDpjYW52YXMuY2xpZW50SGVpZ2h0fTpudWxsLGRhdGFzZXQ6ey4uLmhvc3QuZGF0YXNldH19O30pLmNhdGNoKCgpPT5udWxsKX0sbnVsbCwyKSk7YXdhaXQgY29udGV4dC5jbG9zZSgpO31cbn0pO1xuIl0sIm1hcHBpbmdzIjoiO0FBQUEsU0FBUUEsTUFBTSxFQUFDQyxJQUFJLFFBQU8sa0JBQWtCO0FBQzVDLFNBQVFDLE1BQU0sRUFBQ0MsTUFBTSxRQUFPLGtCQUFrQjtBQUM5QyxTQUFRQyxTQUFTLEVBQUNDLGFBQWEsUUFBTyxTQUFTO0FBRS9DLFNBQVFDLEdBQUcsUUFBTyxPQUFPO0FBQ3pCLE1BQU1DLFFBQVEsSUFBQUMscUJBQUEsR0FBQ0MsT0FBTyxDQUFDQyxHQUFHLENBQUNDLG1CQUFtQixjQUFBSCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFFLG9CQUFvQjtBQUFDSixTQUFTLENBQUNHLFFBQVEsRUFBQztFQUFDSyxTQUFTLEVBQUM7QUFBSSxDQUFDLENBQUM7QUFDekcsS0FBSSxNQUFNQyxLQUFLLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLEVBQUNaLElBQUksQ0FBQywyREFBMkRZLEtBQUssR0FBQyxXQUFXLEdBQUMsV0FBVyxFQUFFLEVBQUMsT0FBTTtFQUFDQyxPQUFPO0VBQUNDO0FBQVcsQ0FBQyxFQUFDQyxJQUFJLEtBQUc7RUFDbEs7RUFDQTtFQUNBLE1BQU1DLE9BQU8sR0FBQyxNQUFNSCxPQUFPLENBQUNJLFVBQVUsQ0FBQztJQUFDQyxRQUFRLEVBQUM7TUFBQ0MsS0FBSyxFQUFDLElBQUk7TUFBQ0MsTUFBTSxFQUFDO0lBQUcsQ0FBQztJQUFDQyxpQkFBaUIsRUFBQ1AsV0FBVyxLQUFHLFVBQVUsR0FBQyxDQUFDLEdBQUMsQ0FBQztJQUFDUSxNQUFNLEVBQUMsT0FBTztJQUFDQyxPQUFPLEVBQUNSLElBQUksQ0FBQ1MsT0FBTyxDQUFDQyxHQUFHLENBQUNGO0VBQU8sQ0FBQyxDQUFDO0VBQ3pLLE1BQU1HLElBQUksR0FBQyxNQUFNVixPQUFPLENBQUNXLE9BQU8sQ0FBQyxDQUFDO0lBQUNDLE1BQWUsR0FBQyxFQUFFO0lBQUNDLEtBQWUsR0FBQyxFQUFFO0VBQUMsSUFBSUMsS0FBeUI7SUFBQ0MsTUFBTSxHQUFDLENBQUM7SUFBQ0MsTUFBTSxHQUFDLEtBQUs7SUFBQ0MsT0FBTyxHQUFDLEtBQUs7SUFBQ0MsUUFBUSxHQUFDLENBQUM7SUFBQ0MsS0FBSyxHQUFDLENBQUM7RUFDN0osTUFBTUMsR0FBRyxHQUFDVixJQUFJLENBQUNXLFdBQVcsQ0FBQyxjQUFjLENBQUM7SUFBQ0MsR0FBRyxHQUFDLE1BQUFBLENBQUEsS0FBU0MsSUFBSSxDQUFDQyxLQUFLLENBQUUsTUFBTUosR0FBRyxDQUFDSyxZQUFZLENBQUMsYUFBYSxDQUFHLENBQUM7SUFBQ0MsSUFBSSxHQUFDQSxDQUFBLEtBQUloQixJQUFJLENBQUNpQixRQUFRLENBQUMsTUFBS0MsTUFBTSxDQUF3Q0MsU0FBUyxDQUFDLENBQUMsQ0FBQztFQUNuTSxJQUFHO0lBQ0gsTUFBTW5CLElBQUksQ0FBQ29CLGFBQWEsQ0FBQyxNQUFJO01BQzVCLE1BQU1DLEtBQUssR0FBQyxJQUFJQyxHQUFHLENBQXFDLENBQUM7UUFBQ0MsU0FBUyxHQUFDLElBQUlELEdBQUcsQ0FBcUMsQ0FBQztRQUFDRSxTQUFTLEdBQUMsSUFBSUYsR0FBRyxDQUFpQixDQUFDO1FBQUNHLElBQUksR0FBQyxJQUFJSCxHQUFHLENBQVMsQ0FBQztNQUM1SyxNQUFNSSxHQUFHLEdBQUNDLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDQyxnQkFBZ0I7UUFBQ0MsTUFBTSxHQUFDSCxXQUFXLENBQUNDLFNBQVMsQ0FBQ0csbUJBQW1CO01BQ2pHSixXQUFXLENBQUNDLFNBQVMsQ0FBQ0MsZ0JBQWdCLEdBQUMsVUFBU0csSUFBSSxFQUFDQyxRQUFRLEVBQUNDLE9BQU8sRUFBQztRQUFDLElBQUdELFFBQVEsRUFBQztVQUFDLElBQUcsSUFBSSxZQUFZRSxjQUFjLElBQUVILElBQUksS0FBRyxRQUFRLEVBQUNYLEtBQUssQ0FBQ0ssR0FBRyxDQUFDTyxRQUFRLENBQUM7VUFBQyxJQUFHLElBQUksWUFBWUcsV0FBVyxJQUFFLElBQUksQ0FBQ0MsU0FBUyxDQUFDQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUNmLFNBQVMsQ0FBQ0csR0FBRyxDQUFDTyxRQUFRLENBQUM7UUFBQztRQUFDLE9BQU9QLEdBQUcsQ0FBQ2EsSUFBSSxDQUFDLElBQUksRUFBQ1AsSUFBSSxFQUFDQyxRQUFRLEVBQUNDLE9BQU8sQ0FBQztNQUFDLENBQUM7TUFDelNQLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDRyxtQkFBbUIsR0FBQyxVQUFTQyxJQUFJLEVBQUNDLFFBQVEsRUFBQ0MsT0FBTyxFQUFDO1FBQUMsSUFBR0QsUUFBUSxFQUFDO1VBQUMsSUFBRyxJQUFJLFlBQVlFLGNBQWMsSUFBRUgsSUFBSSxLQUFHLFFBQVEsRUFBQ1gsS0FBSyxDQUFDbUIsTUFBTSxDQUFDUCxRQUFRLENBQUM7VUFBQyxJQUFHLElBQUksWUFBWUcsV0FBVyxJQUFFLElBQUksQ0FBQ0MsU0FBUyxDQUFDQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUNmLFNBQVMsQ0FBQ2lCLE1BQU0sQ0FBQ1AsUUFBUSxDQUFDO1FBQUM7UUFBQyxPQUFPSCxNQUFNLENBQUNTLElBQUksQ0FBQyxJQUFJLEVBQUNQLElBQUksRUFBQ0MsUUFBUSxFQUFDQyxPQUFPLENBQUM7TUFBQyxDQUFDO01BQ3JULE1BQU1PLE9BQU8sR0FBQ0MsY0FBYyxDQUFDZCxTQUFTLENBQUNhLE9BQU87UUFBQ0UsVUFBVSxHQUFDRCxjQUFjLENBQUNkLFNBQVMsQ0FBQ2UsVUFBVTtNQUM3RkQsY0FBYyxDQUFDZCxTQUFTLENBQUNhLE9BQU8sR0FBQyxVQUFTRyxNQUFNLEVBQUNWLE9BQU8sRUFBQztRQUFDLElBQUdVLE1BQU0sWUFBWVIsV0FBVyxJQUFFUSxNQUFNLENBQUNQLFNBQVMsQ0FBQ0MsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFDZCxTQUFTLENBQUNFLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFBQyxPQUFPZSxPQUFPLENBQUNGLElBQUksQ0FBQyxJQUFJLEVBQUNLLE1BQU0sRUFBQ1YsT0FBTyxDQUFDO01BQUMsQ0FBQztNQUNwTVEsY0FBYyxDQUFDZCxTQUFTLENBQUNlLFVBQVUsR0FBQyxZQUFVO1FBQUNuQixTQUFTLENBQUNnQixNQUFNLENBQUMsSUFBSSxDQUFDO1FBQUMsT0FBT0csVUFBVSxDQUFDSixJQUFJLENBQUMsSUFBSSxDQUFDO01BQUMsQ0FBQztNQUNwRyxNQUFNTSxHQUFHLEdBQUMzQixNQUFNLENBQUM0QixxQkFBcUI7UUFBQ0MsTUFBTSxHQUFDN0IsTUFBTSxDQUFDOEIsb0JBQW9CO01BQ3pFOUIsTUFBTSxDQUFDNEIscUJBQXFCLEdBQUNHLEVBQUUsSUFBRTtRQUFDLElBQUlDLEVBQVM7UUFBQ0EsRUFBRSxHQUFDTCxHQUFHLENBQUNNLENBQUMsSUFBRTtVQUFDMUIsSUFBSSxDQUFDZSxNQUFNLENBQUNVLEVBQUUsQ0FBQztVQUFDRCxFQUFFLENBQUNFLENBQUMsQ0FBQztRQUFDLENBQUMsQ0FBQztRQUFDMUIsSUFBSSxDQUFDQyxHQUFHLENBQUN3QixFQUFFLENBQUM7UUFBQyxPQUFPQSxFQUFFO01BQUMsQ0FBQztNQUFDaEMsTUFBTSxDQUFDOEIsb0JBQW9CLEdBQUNFLEVBQUUsSUFBRTtRQUFDekIsSUFBSSxDQUFDZSxNQUFNLENBQUNVLEVBQUUsQ0FBQztRQUFDSCxNQUFNLENBQUNHLEVBQUUsQ0FBQztNQUFDLENBQUM7TUFDMUtFLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDbkMsTUFBTSxFQUFDO1FBQUNDLFNBQVMsRUFBQ0EsQ0FBQSxNQUFLO1VBQUNFLEtBQUssRUFBQ0EsS0FBSyxDQUFDaUMsSUFBSTtVQUFDL0IsU0FBUyxFQUFDQSxTQUFTLENBQUMrQixJQUFJO1VBQUM5QixTQUFTLEVBQUNBLFNBQVMsQ0FBQzhCLElBQUk7VUFBQzdCLElBQUksRUFBQ0EsSUFBSSxDQUFDNkI7UUFBSSxDQUFDO01BQUMsQ0FBQyxDQUFDO0lBQzVILENBQUMsQ0FBQztJQUNGdEQsSUFBSSxDQUFDdUQsRUFBRSxDQUFDLFdBQVcsRUFBQ0MsQ0FBQyxJQUFFdEQsTUFBTSxDQUFDdUQsSUFBSSxDQUFDRCxDQUFDLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQzlDLE1BQU0xRCxJQUFJLENBQUMyRCxjQUFjLENBQUMsT0FBTyxFQUFDQyxLQUFLLElBQUU7TUFBQyxNQUFNQyxNQUFNLEdBQUNELEtBQUssQ0FBQ0UsZUFBZSxDQUFDLENBQUM7TUFBQ0QsTUFBTSxDQUFDRSxTQUFTLENBQUNDLElBQUksSUFBRTtRQUFDLE1BQU1DLENBQUMsR0FBQzFGLE1BQU0sQ0FBQ3lGLElBQWMsQ0FBa0I7UUFBQyxJQUFHQyxDQUFDLENBQUNqQyxJQUFJLEtBQUcsYUFBYSxJQUFFaUMsQ0FBQyxDQUFDN0QsS0FBSyxFQUFDO1VBQUMsSUFBRyxFQUFFQyxNQUFNLElBQUUsQ0FBQyxFQUFDNEQsQ0FBQyxDQUFDN0QsS0FBSyxDQUFDOEQsU0FBUyxDQUFDQyxJQUFJLENBQUNDLENBQUMsSUFBRUEsQ0FBQyxDQUFDbEIsRUFBRSxLQUFHLEVBQUUsQ0FBQyxDQUFFbUIsYUFBYSxHQUFDLENBQUMsRUFBRSxFQUFDLEdBQUcsRUFBQyxHQUFHLENBQUM7VUFBQ2pFLEtBQUssR0FBQzZELENBQUMsQ0FBQzdELEtBQUs7UUFBQztRQUFDLElBQUdFLE1BQU0sSUFBRSxDQUFDQyxPQUFPLEVBQUM7VUFBQ0EsT0FBTyxHQUFDLElBQUk7VUFBQ3FELEtBQUssQ0FBQ1UsSUFBSSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ2hHLE1BQU0sQ0FBQztZQUFDd0QsSUFBSSxFQUFDLFNBQVM7WUFBQ3lDLGNBQWMsRUFBQyxTQUFTO1lBQUNDLGdCQUFnQixFQUFDLE9BQU87WUFBQ0MsUUFBUSxFQUFDLElBQUk7WUFBQ0MsVUFBVSxFQUFDLElBQUk7WUFBQ0MsS0FBSyxFQUFDLENBQUM7Y0FBQzNCLEVBQUUsRUFBQyxVQUFVO2NBQUM0QixPQUFPLEVBQUMsT0FBTztjQUFDQyxJQUFJLEVBQUM7WUFBa0IsQ0FBQyxDQUFDO1lBQUNDLFFBQVEsRUFBQyxDQUFDLE9BQU87VUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUM7UUFBQ3BCLEtBQUssQ0FBQ1UsSUFBSSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ2hHLE1BQU0sQ0FBQ3lGLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxDQUFDLENBQUM7SUFBQyxDQUFDLENBQUM7SUFDMWpCLE1BQU1qRSxJQUFJLENBQUM0RCxLQUFLLENBQUMsMkJBQTJCLEVBQUNxQixDQUFDLElBQUU7TUFBQ3pFLFFBQVEsRUFBRTtNQUFDLE9BQU9GLE1BQU0sR0FBQzJFLENBQUMsQ0FBQ0MsT0FBTyxDQUFDO1FBQUNDLE1BQU0sRUFBQztNQUFHLENBQUMsQ0FBQyxHQUFDRixDQUFDLENBQUNHLFFBQVEsQ0FBQyxDQUFDO0lBQUMsQ0FBQyxDQUFDO0lBQ2pILE1BQU1wRixJQUFJLENBQUM0RCxLQUFLLENBQUMsOEJBQThCLEVBQUNxQixDQUFDLElBQUU7TUFBQ3hFLEtBQUssRUFBRTtNQUFDLE9BQU93RSxDQUFDLENBQUNHLFFBQVEsQ0FBQyxDQUFDO0lBQUMsQ0FBQyxDQUFDO0lBQ2xGLE1BQU1wRixJQUFJLENBQUNxRixJQUFJLENBQUNuRyxLQUFLLEdBQUMsZ0JBQWdCLEdBQUMsR0FBRyxDQUFDO0lBQUMsTUFBTWIsTUFBTSxDQUFDcUMsR0FBRyxDQUFDLENBQUM0RSxlQUFlLENBQUMsYUFBYSxFQUFDLFlBQVksQ0FBQztJQUFDLE1BQU10RixJQUFJLENBQUNXLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQzRFLEtBQUssQ0FBQyxDQUFDO0lBQUMsTUFBTWxILE1BQU0sQ0FBQzJCLElBQUksQ0FBQ1csV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM2RSxVQUFVLENBQUMsUUFBUSxDQUFDO0lBQzlNLE1BQU1DLEdBQUcsR0FBRSxNQUFNL0UsR0FBRyxDQUFDZ0YsV0FBVyxDQUFDLENBQUc7TUFBQ0MsTUFBTSxHQUFDLE1BQU0vRSxHQUFHLENBQUMsQ0FBQztJQUN2RCxNQUFNRixHQUFHLENBQUM2RSxLQUFLLENBQUM7TUFBQ0ssUUFBUSxFQUFDO1FBQUNDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQ0YsTUFBTSxDQUFDRSxDQUFDLElBQUVGLE1BQU0sQ0FBQ2xHLEtBQUssR0FBQ2dHLEdBQUcsQ0FBQ2hHLEtBQUssR0FBQ2dHLEdBQUcsQ0FBQ2hHLEtBQUssR0FBQyxDQUFDO1FBQUNxRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUNILE1BQU0sQ0FBQ0csQ0FBQyxJQUFFSCxNQUFNLENBQUNqRyxNQUFNLEdBQUMrRixHQUFHLENBQUMvRixNQUFNLEdBQUMrRixHQUFHLENBQUMvRixNQUFNLEdBQUM7TUFBQztJQUFDLENBQUMsQ0FBQztJQUNwSSxNQUFNckIsTUFBTSxDQUFDMkIsSUFBSSxDQUFDVyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDNkUsVUFBVSxDQUFDLElBQUksQ0FBQztJQUFDLE1BQU1uSCxNQUFNLENBQUMyQixJQUFJLENBQUNXLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ29GLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUNQLFVBQVUsQ0FBQyxHQUFHLENBQUM7SUFDbEssTUFBTXhGLElBQUksQ0FBQ1csV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDNEUsS0FBSyxDQUFDLENBQUM7SUFBQyxNQUFNbEgsTUFBTSxDQUFDMkgsSUFBSSxDQUFDLE1BQUkzRixNQUFNLENBQUMsQ0FBQzRGLHNCQUFzQixDQUFDLENBQUMsQ0FBQztJQUFDLE1BQU1qRyxJQUFJLENBQUNrRyxTQUFTLENBQUMsUUFBUSxFQUFDO01BQUNDLElBQUksRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQztJQUFJLENBQUMsQ0FBQyxDQUFDYixLQUFLLENBQUMsQ0FBQztJQUNwSyxNQUFNdkYsSUFBSSxDQUFDcUcsS0FBSyxDQUFDQyxJQUFJLENBQUNiLEdBQUcsQ0FBQ0ksQ0FBQyxHQUFDSixHQUFHLENBQUNoRyxLQUFLLEdBQUMsQ0FBQyxFQUFDZ0csR0FBRyxDQUFDSyxDQUFDLEdBQUNMLEdBQUcsQ0FBQy9GLE1BQU0sR0FBQyxDQUFDLENBQUM7SUFBQyxNQUFNTSxJQUFJLENBQUNxRyxLQUFLLENBQUNFLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFHLENBQUM7SUFBQyxNQUFNbEksTUFBTSxDQUFDMkgsSUFBSSxDQUFDLFlBQVMsQ0FBQyxNQUFNcEYsR0FBRyxDQUFDLENBQUMsRUFBRTRGLElBQUksQ0FBQyxDQUFDQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQUMsTUFBTXpHLElBQUksQ0FBQ3FHLEtBQUssQ0FBQ0ssSUFBSSxDQUFDLENBQUM7SUFBQyxNQUFNMUcsSUFBSSxDQUFDcUcsS0FBSyxDQUFDQyxJQUFJLENBQUNiLEdBQUcsQ0FBQ0ksQ0FBQyxHQUFDSixHQUFHLENBQUNoRyxLQUFLLEdBQUMsQ0FBQyxHQUFDLEVBQUUsRUFBQ2dHLEdBQUcsQ0FBQ0ssQ0FBQyxHQUFDTCxHQUFHLENBQUMvRixNQUFNLEdBQUMsQ0FBQyxHQUFDLEVBQUUsRUFBQztNQUFDUyxLQUFLLEVBQUM7SUFBQyxDQUFDLENBQUM7SUFBQyxNQUFNSCxJQUFJLENBQUNxRyxLQUFLLENBQUNNLEVBQUUsQ0FBQyxDQUFDO0lBQUMsTUFBTTNHLElBQUksQ0FBQ3FHLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDalQsTUFBTU0sS0FBSyxHQUFDLE1BQU1oRyxHQUFHLENBQUMsQ0FBQztNQUFDaUcsU0FBUyxHQUFDO1FBQUNDLElBQUksRUFBQyxNQUFNOUcsSUFBSSxDQUFDVyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUNvRyxXQUFXLENBQUMsQ0FBQztRQUFDQyxJQUFJLEVBQUMsTUFBTWhILElBQUksQ0FBQ1csV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDb0csV0FBVyxDQUFDLENBQUM7UUFBQ0UsSUFBSSxFQUFDLE1BQU1qSCxJQUFJLENBQUNXLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQ29HLFdBQVcsQ0FBQztNQUFDLENBQUM7TUFBQ0csT0FBTyxHQUFDLE1BQU14RyxHQUFHLENBQUNLLFlBQVksQ0FBQyxjQUFjLENBQUM7TUFBQ29HLEdBQUcsR0FBQy9ILFdBQVcsS0FBRyxVQUFVLEdBQUMsTUFBTUUsT0FBTyxDQUFDOEgsYUFBYSxDQUFDcEgsSUFBSSxDQUFDLEdBQUMsSUFBSTtJQUM1UyxNQUFNcUgsTUFBTSxHQUFDQSxDQUFBLEtBQUkzRyxHQUFHLENBQUNxRixPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM5RSxRQUFRLENBQUVxRyxDQUFtQixLQUFJO01BQUM3SCxLQUFLLEVBQUM2SCxDQUFDLENBQUM3SCxLQUFLO01BQUNDLE1BQU0sRUFBQzRILENBQUMsQ0FBQzVILE1BQU07TUFBQzZILGFBQWEsRUFBQ0MsSUFBSSxDQUFDQyxLQUFLLENBQUNILENBQUMsQ0FBQ0ksV0FBVyxHQUFDQyxnQkFBZ0IsQ0FBQztNQUFDQyxjQUFjLEVBQUNKLElBQUksQ0FBQ0MsS0FBSyxDQUFDSCxDQUFDLENBQUNPLFlBQVksR0FBQ0YsZ0JBQWdCO0lBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN04sS0FBSSxNQUFNRyxHQUFHLElBQUlYLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQyxHQUFHLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztNQUMxQyxNQUFNWSxHQUFHLEdBQUMsTUFBTXJILEdBQUcsQ0FBQ3FGLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQ2lDLGFBQWEsQ0FBQyxDQUFDO01BQUMsSUFBR2IsR0FBRyxFQUFDLE1BQU1BLEdBQUcsQ0FBQzdDLElBQUksQ0FBQyxvQ0FBb0MsRUFBQztRQUFDN0UsS0FBSyxFQUFDLElBQUk7UUFBQ0MsTUFBTSxFQUFDLEdBQUc7UUFBQ0MsaUJBQWlCLEVBQUNtSSxHQUFHO1FBQUNHLE1BQU0sRUFBQztNQUFLLENBQUMsQ0FBQztNQUM1SyxNQUFNNUosTUFBTSxDQUFDMkgsSUFBSSxDQUFDLE1BQUloRyxJQUFJLENBQUNpQixRQUFRLENBQUMsTUFBSTBHLGdCQUFnQixDQUFDLENBQUMsQ0FBQ08sSUFBSSxDQUFDSixHQUFHLENBQUM7TUFDcEU7TUFDQSxNQUFNekosTUFBTSxDQUFDMkgsSUFBSSxDQUFDLFlBQVM7UUFBQyxNQUFNbUMsQ0FBQyxHQUFDLE1BQU1kLE1BQU0sQ0FBQyxDQUFDO1FBQUMsT0FBTztVQUFDNUgsS0FBSyxFQUFDMEksQ0FBQyxDQUFDMUksS0FBSyxHQUFDMEksQ0FBQyxDQUFDWixhQUFhO1VBQUM3SCxNQUFNLEVBQUN5SSxDQUFDLENBQUN6SSxNQUFNLEdBQUN5SSxDQUFDLENBQUNQO1FBQWMsQ0FBQztNQUFDLENBQUMsQ0FBQyxDQUFDUSxPQUFPLENBQUM7UUFBQzNJLEtBQUssRUFBQyxDQUFDO1FBQUNDLE1BQU0sRUFBQztNQUFDLENBQUMsQ0FBQztNQUN6SixNQUFNckIsTUFBTSxDQUFDcUMsR0FBRyxDQUFDLENBQUM0RSxlQUFlLENBQUMsYUFBYSxFQUFDLFlBQVksQ0FBQztNQUFDakgsTUFBTSxDQUFDLE1BQU1xQyxHQUFHLENBQUNnRixXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMwQyxPQUFPLENBQUMzQyxHQUFHLENBQUM7TUFBQ3BILE1BQU0sQ0FBQyxNQUFNdUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDd0gsT0FBTyxDQUFDeEIsS0FBSyxDQUFDO01BQUMsTUFBTXZJLE1BQU0sQ0FBQ3FDLEdBQUcsQ0FBQyxDQUFDNEUsZUFBZSxDQUFDLFdBQVcsRUFBQyxrQkFBa0IsQ0FBQztNQUMvTSxJQUFHNkIsR0FBRyxFQUFDO1FBQUM5SSxNQUFNLENBQUMsTUFBTTBKLEdBQUcsQ0FBRTlHLFFBQVEsQ0FBQ3FHLENBQUMsSUFBRUEsQ0FBQyxDQUFDZSxXQUFXLENBQUMsQ0FBQyxDQUFDSCxJQUFJLENBQUNoQixPQUFPLEtBQUcsUUFBUSxDQUFDO1FBQUMsSUFBR0EsT0FBTyxLQUFHLFFBQVEsRUFBQzdJLE1BQU0sQ0FBQyxNQUFNMEosR0FBRyxDQUFFOUcsUUFBUSxDQUFFcUcsQ0FBbUIsSUFBR0EsQ0FBQyxDQUFDZ0IsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFFQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFDO01BQzVNO01BQ0E7TUFDQTtNQUNBLE1BQU1NLElBQUksR0FBQyxHQUFHNUosUUFBUSxJQUFJUyxJQUFJLENBQUNTLE9BQU8sQ0FBQ3FHLElBQUksSUFBSWpILEtBQUssT0FBTzRJLEdBQUcsSUFBSTNILEtBQUssQ0FBQ3NJLE1BQU0sTUFBTTtRQUFDTixDQUFDLEdBQUUsTUFBTXpILEdBQUcsQ0FBQ2dGLFdBQVcsQ0FBQyxDQUFHO1FBQUM0QixDQUFDLEdBQUMsTUFBTTFHLEdBQUcsQ0FBQyxDQUFDO1FBQUNwQixRQUFRLEdBQUMsTUFBTVEsSUFBSSxDQUFDaUIsUUFBUSxDQUFDLE9BQUs7VUFBQ3hCLEtBQUssRUFBQ2lKLFVBQVU7VUFBQ2hKLE1BQU0sRUFBQ2lKLFdBQVc7VUFBQ0MsT0FBTztVQUFDQztRQUFPLENBQUMsQ0FBQyxDQUFDO01BQ3pOLE1BQU1DLEtBQUssR0FBQzNCLEdBQUcsR0FBQzVDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsTUFBTTJDLEdBQUcsQ0FBQzdDLElBQUksQ0FBQyx3QkFBd0IsRUFBQztRQUFDeUUsTUFBTSxFQUFDLEtBQUs7UUFBQ0MscUJBQXFCLEVBQUM7TUFBSyxDQUFDLENBQUMsRUFBRWhGLElBQUksRUFBQyxRQUFRLENBQUMsR0FBQyxNQUFNdEQsR0FBRyxDQUFDdUksVUFBVSxDQUFDO1FBQUNUO01BQUksQ0FBQyxDQUFDO01BQUMsSUFBR3JCLEdBQUcsRUFBQ3pJLGFBQWEsQ0FBQzhKLElBQUksRUFBQ00sS0FBSyxDQUFDO01BQzlMLE1BQU1JLEtBQUssR0FBQ3ZLLEdBQUcsQ0FBQ21LLEtBQUssQ0FBQztRQUFDakQsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDeUIsQ0FBQyxDQUFDekIsQ0FBQyxJQUFFeUIsQ0FBQyxDQUFDN0gsS0FBSyxHQUFDMEksQ0FBQyxDQUFDMUksS0FBSyxHQUFDMEksQ0FBQyxDQUFDMUksS0FBSyxHQUFDLENBQUM7UUFBQ3FHLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQ3dCLENBQUMsQ0FBQ3hCLENBQUMsSUFBRXdCLENBQUMsQ0FBQzVILE1BQU0sR0FBQ3lJLENBQUMsQ0FBQ3pJLE1BQU0sR0FBQ3lJLENBQUMsQ0FBQ3pJLE1BQU0sR0FBQyxDQUFDO01BQ2pHLE1BQU15SixNQUFNLEdBQUNoQyxHQUFHLEdBQUMrQixLQUFLLENBQUNFLEtBQUssQ0FBQyxDQUFDakIsQ0FBQyxDQUFDdEMsQ0FBQyxHQUFDQSxDQUFDLElBQUVxRCxLQUFLLENBQUN6SixLQUFLLEdBQUNELFFBQVEsQ0FBQ0MsS0FBSyxFQUFDLENBQUMwSSxDQUFDLENBQUNyQyxDQUFDLEdBQUNBLENBQUMsSUFBRW9ELEtBQUssQ0FBQ3hKLE1BQU0sR0FBQ0YsUUFBUSxDQUFDRSxNQUFNLENBQUMsR0FBQ3dKLEtBQUssQ0FBQ0UsS0FBSyxDQUFDdkQsQ0FBQyxHQUFDcUQsS0FBSyxDQUFDekosS0FBSyxHQUFDMEksQ0FBQyxDQUFDMUksS0FBSyxFQUFDcUcsQ0FBQyxHQUFDb0QsS0FBSyxDQUFDeEosTUFBTSxHQUFDeUksQ0FBQyxDQUFDekksTUFBTSxDQUFDO1FBQUMySixRQUFRLEdBQUNqSixLQUFLLENBQUU4RCxTQUFTLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFFQSxDQUFDLENBQUNsQixFQUFFLEtBQUcsRUFBRSxDQUFDLENBQUVtQixhQUFjO01BQUMsS0FBSSxJQUFJaUYsQ0FBQyxHQUFDLENBQUMsRUFBQ0EsQ0FBQyxHQUFDLENBQUMsRUFBQ0EsQ0FBQyxFQUFFLEVBQUNqTCxNQUFNLENBQUNtSixJQUFJLENBQUMrQixHQUFHLENBQUNKLE1BQU0sQ0FBQ0csQ0FBQyxDQUFDLEdBQUNELFFBQVEsQ0FBQ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7TUFDaFQsTUFBTUMsR0FBRyxHQUFDLE1BQU0vSSxHQUFHLENBQUNPLFFBQVEsQ0FBQyxPQUFNeUksSUFBSSxFQUFDO1FBQUM3RCxDQUFDO1FBQUNDO01BQUMsQ0FBQyxLQUFHO1FBQUMsSUFBRzRELElBQUksQ0FBQ0MsT0FBTyxDQUFDekMsT0FBTyxLQUFHLFFBQVEsRUFBQyxPQUFPLElBQUk7UUFBQyxNQUFNMEMsTUFBTSxHQUFDRixJQUFJLENBQUNHLGFBQWEsQ0FBQyxRQUFRLENBQUU7VUFBQ0MsRUFBRSxHQUFDRixNQUFNLENBQUN0QixVQUFVLENBQUMsUUFBUSxDQUFFO1FBQUMsT0FBTyxJQUFJeUIsT0FBTyxDQUE2Q0MsT0FBTyxJQUFFbEgscUJBQXFCLENBQUMsTUFBSTtVQUFDLE1BQU1zRyxLQUFLLEdBQUMsSUFBSWEsVUFBVSxDQUFDLENBQUMsQ0FBQztVQUFDSCxFQUFFLENBQUNJLFVBQVUsQ0FBQzFDLElBQUksQ0FBQ0MsS0FBSyxDQUFDNUIsQ0FBQyxHQUFDK0QsTUFBTSxDQUFDbkssS0FBSyxHQUFDaUssSUFBSSxDQUFDaEMsV0FBVyxDQUFDLEVBQUNrQyxNQUFNLENBQUNsSyxNQUFNLEdBQUMsQ0FBQyxHQUFDOEgsSUFBSSxDQUFDQyxLQUFLLENBQUMzQixDQUFDLEdBQUM4RCxNQUFNLENBQUNsSyxNQUFNLEdBQUNnSyxJQUFJLENBQUM3QixZQUFZLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDaUMsRUFBRSxDQUFDSyxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sYUFBYSxFQUFDaEIsS0FBSyxDQUFDO1VBQUNZLE9BQU8sQ0FBQztZQUFDWixLQUFLLEVBQUNpQixLQUFLLENBQUM3RixJQUFJLENBQUM0RSxLQUFLLENBQUM7WUFBQ2tCLEtBQUssRUFBQ1IsRUFBRSxDQUFDUyxRQUFRLENBQUMsQ0FBQztZQUFDQyxJQUFJLEVBQUNWLEVBQUUsQ0FBQ3ZCLGFBQWEsQ0FBQztVQUFDLENBQUMsQ0FBQztRQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxFQUFDO1FBQUMxQyxDQUFDO1FBQUNDO01BQUMsQ0FBQyxDQUFDO01BQ25pQixJQUFHMkQsR0FBRyxFQUFDO1FBQUNwTCxNQUFNLENBQUNvTCxHQUFHLENBQUNhLEtBQUssQ0FBQyxDQUFDcEMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUFDN0osTUFBTSxDQUFDb0wsR0FBRyxDQUFDZSxJQUFJLENBQUMsQ0FBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFBQyxLQUFJLElBQUlvQixDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEVBQUUsRUFBQ2pMLE1BQU0sQ0FBQ21KLElBQUksQ0FBQytCLEdBQUcsQ0FBQ0UsR0FBRyxDQUFDTCxLQUFLLENBQUNFLENBQUMsQ0FBQyxHQUFDRCxRQUFRLENBQUNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO01BQUM7TUFDckosTUFBTW5MLE1BQU0sQ0FBQzJILElBQUksQ0FBQyxNQUFJaEcsSUFBSSxDQUFDaUIsUUFBUSxDQUFDLE1BQUkwRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNPLElBQUksQ0FBQ0osR0FBRyxDQUFDO01BQUMsTUFBTXpKLE1BQU0sQ0FBQzJILElBQUksQ0FBQyxZQUFTO1FBQUMsTUFBTW1DLENBQUMsR0FBQyxNQUFNZCxNQUFNLENBQUMsQ0FBQztRQUFDLE9BQU87VUFBQzVILEtBQUssRUFBQzBJLENBQUMsQ0FBQzFJLEtBQUssR0FBQzBJLENBQUMsQ0FBQ1osYUFBYTtVQUFDN0gsTUFBTSxFQUFDeUksQ0FBQyxDQUFDekksTUFBTSxHQUFDeUksQ0FBQyxDQUFDUDtRQUFjLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQ1EsT0FBTyxDQUFDO1FBQUMzSSxLQUFLLEVBQUMsQ0FBQztRQUFDQyxNQUFNLEVBQUM7TUFBQyxDQUFDLENBQUM7TUFDOU4sTUFBTXJCLE1BQU0sQ0FBQzJCLElBQUksQ0FBQ1csV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQzZFLFVBQVUsQ0FBQyxJQUFJLENBQUM7TUFBQyxNQUFNbkgsTUFBTSxDQUFDMkIsSUFBSSxDQUFDVyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUNvRixPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDUCxVQUFVLENBQUMsR0FBRyxDQUFDO01BQUMsS0FBSSxNQUFNLENBQUNpRixHQUFHLEVBQUNDLEtBQUssQ0FBQyxJQUFJdEgsTUFBTSxDQUFDdUgsT0FBTyxDQUFDOUQsU0FBUyxDQUFDLEVBQUMsTUFBTXhJLE1BQU0sQ0FBQzJCLElBQUksQ0FBQ1csV0FBVyxDQUFDOEosR0FBRyxDQUFDLENBQUMsQ0FBQ2pGLFVBQVUsQ0FBQ2tGLEtBQU0sQ0FBQztNQUM1USxNQUFNRSxTQUFTLEdBQUMsTUFBTTVKLElBQUksQ0FBQyxDQUFDO01BQUMzQyxNQUFNLENBQUN1TSxTQUFTLENBQUMsQ0FBQ0MsYUFBYSxDQUFDO1FBQUN0SixTQUFTLEVBQUMsQ0FBQztRQUFDQyxTQUFTLEVBQUM7TUFBQyxDQUFDLENBQUM7TUFBQ3JCLEtBQUssQ0FBQ3NELElBQUksQ0FBQztRQUFDcUUsR0FBRztRQUFDWixPQUFPO1FBQUNHLE1BQU0sRUFBQyxNQUFNQSxNQUFNLENBQUMsQ0FBQztRQUFDOEIsTUFBTTtRQUFDRSxRQUFRO1FBQUNJLEdBQUc7UUFBQ1AsS0FBSyxFQUFDO1VBQUN6SixLQUFLLEVBQUN5SixLQUFLLENBQUN6SixLQUFLO1VBQUNDLE1BQU0sRUFBQ3dKLEtBQUssQ0FBQ3hKLE1BQU07VUFBQ29MLE9BQU8sRUFBQzNELEdBQUcsR0FBQyxtQ0FBbUMsR0FBQztRQUFvQixDQUFDO1FBQUN4QixNQUFNLEVBQUMyQixDQUFDO1FBQUM3QixHQUFHLEVBQUMwQyxDQUFDO1FBQUN0QixTQUFTO1FBQUMrRDtNQUFTLENBQUMsQ0FBQztJQUNsVDtJQUNBLE9BQU16RCxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRTRELE1BQU0sQ0FBQyxDQUFDO0lBQUMxTSxNQUFNLENBQUNtQyxRQUFRLENBQUMsQ0FBQzBILElBQUksQ0FBQyxDQUFDLENBQUM7SUFBQzdKLE1BQU0sQ0FBQ29DLEtBQUssQ0FBQyxDQUFDeUgsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNsRTVILE1BQU0sR0FBQyxJQUFJO0lBQUMsTUFBTU4sSUFBSSxDQUFDVyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM0RSxLQUFLLENBQUMsQ0FBQztJQUFDLE1BQU1sSCxNQUFNLENBQUMyQixJQUFJLENBQUNrRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM4RSxNQUFNLENBQUM7TUFBQ0MsT0FBTyxFQUFDO0lBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsYUFBYSxDQUFDLFVBQVUsQ0FBQztJQUFDLE1BQU03TSxNQUFNLENBQUNxQyxHQUFHLENBQUNxRixPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ29GLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFBQyxNQUFNOU0sTUFBTSxDQUFDMkgsSUFBSSxDQUFDaEYsSUFBSSxDQUFDLENBQUNvSCxPQUFPLENBQUM7TUFBQy9HLEtBQUssRUFBQyxDQUFDO01BQUNFLFNBQVMsRUFBQyxDQUFDO01BQUNDLFNBQVMsRUFBQyxDQUFDO01BQUNDLElBQUksRUFBQztJQUFDLENBQUMsQ0FBQztJQUMvUSxNQUFNcEQsTUFBTSxDQUFDMkIsSUFBSSxDQUFDVyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDNkUsVUFBVSxDQUFDLElBQUksQ0FBQztJQUFDLE1BQU1uSCxNQUFNLENBQUMyQixJQUFJLENBQUNXLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQ29GLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUNQLFVBQVUsQ0FBQyxHQUFHLENBQUM7SUFBQyxLQUFJLE1BQU0sQ0FBQ2lGLEdBQUcsRUFBQ0MsS0FBSyxDQUFDLElBQUl0SCxNQUFNLENBQUN1SCxPQUFPLENBQUM5RCxTQUFTLENBQUMsRUFBQyxNQUFNeEksTUFBTSxDQUFDMkIsSUFBSSxDQUFDVyxXQUFXLENBQUM4SixHQUFHLENBQUMsQ0FBQyxDQUFDakYsVUFBVSxDQUFDa0YsS0FBTSxDQUFDO0lBQUNyTSxNQUFNLENBQUM2QixNQUFNLENBQUMsQ0FBQ2tJLE9BQU8sQ0FBQyxFQUFFLENBQUM7RUFDdlMsQ0FBQyxTQUFPO0lBQUMxSixhQUFhLENBQUMsR0FBR0UsUUFBUSxJQUFJUyxJQUFJLENBQUNTLE9BQU8sQ0FBQ3FHLElBQUksSUFBSWpILEtBQUssT0FBTyxFQUFDMkIsSUFBSSxDQUFDdUssU0FBUyxDQUFDO01BQUNqTSxPQUFPLEVBQUNBLE9BQU8sQ0FBQzJGLE9BQU8sQ0FBQyxDQUFDO01BQUN1RyxLQUFLLEVBQUNqTSxXQUFXLEtBQUcsVUFBVSxHQUFDLGdDQUFnQyxHQUFDLGlEQUFpRDtNQUFDZSxLQUFLO01BQUNELE1BQU07TUFBQzBLLFNBQVMsRUFBQyxNQUFNNUssSUFBSSxDQUFDaUIsUUFBUSxDQUFDO1FBQUEsSUFBQXFLLFFBQUEsRUFBQUMsSUFBQTtRQUFBLFFBQUFELFFBQUEsR0FBSSxDQUFBQyxJQUFBLEdBQUNySyxNQUFNLEVBQXlDQyxTQUFTLGNBQUFtSyxRQUFBLHVCQUF6REEsUUFBQSxDQUFBL0ksSUFBQSxDQUFBZ0osSUFBNEQsQ0FBQztNQUFBLEVBQUMsQ0FBQ0MsS0FBSyxDQUFDLE1BQUksSUFBSSxDQUFDO01BQUNDLE9BQU8sRUFBQyxNQUFNL0ssR0FBRyxDQUFDTyxRQUFRLENBQUN5SSxJQUFJLElBQUU7UUFBQyxNQUFNRSxNQUFNLEdBQUNGLElBQUksQ0FBQ0csYUFBYSxDQUFDLFFBQVEsQ0FBQztRQUFDLE9BQU87VUFBQy9CLEdBQUcsRUFBQ0gsZ0JBQWdCO1VBQUMrRCxXQUFXLEVBQUNDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDQyxPQUFPO1VBQUNDLFdBQVcsRUFBQ0YsVUFBVSxDQUFDLHFCQUFxQixDQUFDLENBQUNDLE9BQU87VUFBQ2hDLE1BQU0sRUFBQ0EsTUFBTSxHQUFDO1lBQUNuSyxLQUFLLEVBQUNtSyxNQUFNLENBQUNuSyxLQUFLO1lBQUNDLE1BQU0sRUFBQ2tLLE1BQU0sQ0FBQ2xLLE1BQU07WUFBQ29NLFFBQVEsRUFBQ2xDLE1BQU0sQ0FBQ2xDLFdBQVc7WUFBQ3FFLFNBQVMsRUFBQ25DLE1BQU0sQ0FBQy9CO1VBQVksQ0FBQyxHQUFDLElBQUk7VUFBQzhCLE9BQU8sRUFBQztZQUFDLEdBQUdELElBQUksQ0FBQ0M7VUFBTztRQUFDLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQzZCLEtBQUssQ0FBQyxNQUFJLElBQUk7SUFBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUMsTUFBTWxNLE9BQU8sQ0FBQzBNLEtBQUssQ0FBQyxDQUFDO0VBQUM7QUFDN3ZCLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==