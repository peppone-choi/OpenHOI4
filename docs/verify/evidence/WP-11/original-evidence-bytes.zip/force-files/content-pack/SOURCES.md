independent source annotation
