import sys,os,json,pathlib,subprocess,datetime,hashlib,time
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1'); E=W/'target/evidence/WP-13-M2-r2-P05-1'
env=dict(os.environ);env.update(GIT_OPTIONAL_LOCKS='0',CARGO_TARGET_DIR=str(W/'target'),PYTHONIOENCODING='utf-8',PYTHONUTF8='1');env['PATH']='C:/Users/user/.cargo/bin;'+env['PATH']
name=sys.argv[1];args=sys.argv[2:];d=E/'commands'/name;d.mkdir(parents=True,exist_ok=False)
rec={'id':name,'argv':args,'cwd':str(W),'env':{k:env[k] for k in ('GIT_OPTIONAL_LOCKS','CARGO_TARGET_DIR','PYTHONIOENCODING','PYTHONUTF8')},'PATH_prefix':'C:/Users/user/.cargo/bin','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
rec['head']=subprocess.check_output(['git','--no-optional-locks','-C',str(W),'rev-parse','HEAD'],env=env).decode().strip();(d/'command.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
t=time.monotonic()
try:
 with (d/'stdout.bin').open('wb') as o,(d/'stderr.bin').open('wb') as er:
  p=subprocess.Popen(args,cwd=W,env=env,stdout=o,stderr=er);rec['pid']=p.pid;rec['native_exit']=p.wait()
except Exception as ex:rec.update(native_exit=None,exception=repr(ex))
rec['elapsed_seconds']=time.monotonic()-t;rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for n in ('stdout','stderr'):
 b=(d/(n+'.bin')).read_bytes();(d/(n+'.txt')).write_text(b.decode('utf-8',errors='replace'),encoding='utf-8');rec[n+'_sha256']=hashlib.sha256(b).hexdigest()
(d/'result.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print(json.dumps(rec));print((d/'stdout.txt').read_text(encoding='utf-8')[-2000:]);print((d/'stderr.txt').read_text(encoding='utf-8')[-2000:]);sys.exit(rec['native_exit'] if rec['native_exit'] is not None else 99)
