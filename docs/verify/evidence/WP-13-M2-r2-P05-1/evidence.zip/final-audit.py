import pathlib,json,hashlib,subprocess,re,shutil
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1');E=W/'target/evidence/WP-13-M2-r2-P05-1'
def output(name):return json.loads((E/'commands'/name/'stdout.txt').read_text(encoding='utf-8'))
checks={}
for v in ('v2','v3'):
 a=output(f'original-{v}-capture');b=output(f'original-{v}-fresh-resume');checks[v]={'full_report_equal':a==b,'split_hash':a['split']['hash'],'continuous_hash':a['continuous']['hash']};assert a==b
for a,b in [('cli-end.ohsave','cli-end-repeat.ohsave'),('cli-initial.ohsave','cli-initial-repeat.ohsave'),('pending-repeat1.ohsave','pending-repeat2.ohsave'),('context-matrix/empty-movement.ohsave','empty-movement-repeat.ohsave'),('context-matrix/empty-strait.ohsave','empty-strait-repeat.ohsave')]:
 aa=(E/a).read_bytes();bb=(E/b).read_bytes();checks[a]={'bytes_identical':aa==bb,'sha256':hashlib.sha256(aa).hexdigest()};assert aa==bb
for n in ('cli-end-fresh-metadata-corrected','cli-initial-fresh-metadata-corrected','pending-fresh-1','pending-fresh-2','empty-movement-fresh','empty-strait-fresh'):
 r=output(n);assert r['before']==r['after'] and r['before_canonical']==r['after_canonical'];checks[n]={'full_dto_canonical_equal':True,'hash':r['hash'],'pid':r['pid']}
p=output('paused-fresh-unpause');assert p['before']['trigger']['ended'] is None and p['after']['trigger']['ended']['tick']==1;assert p['before']['trigger']['flags']==p['after']['trigger']['flags'];checks['paused-fresh-unpause']={'active_saved_flags_retained':True,'end_tick':1,'cause':p['after']['trigger']['ended']['causes'],'pid':p['pid']}
bad=[]
for file in (W/'crates/oh_sim/src').glob('*.rs'):
 text=file.read_text(encoding='utf-8')
 for token in (r'\bf32\b',r'\bf64\b',r'\bHashMap\b',r'\bthread_rng\b',r'\bSystemTime\b',r'std::fs',r'std::time'):
  if re.search(token,text):bad.append({'file':str(file.relative_to(W)),'pattern':token})
checks['DR_source_search']=bad;assert not bad
checks['executable_identities']=[]
for file in [W/'target/debug/oh_cli.exe',W/'target/debug/oh_server.exe',W/'target/debug/examples/trigger_fixture.exe',W/'target/debug/examples/movement_fixture.exe',W/'target/debug/examples/strait_fixture.exe',W/'target/debug/wp13-independent-probe.exe']:
 checks['executable_identities'].append({'path':str(file),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
records=[]
for d in sorted((E/'commands').iterdir()):
 if not (d/'result.json').exists():
  if d.name=='final-state-byte-audit-corrected' and (d/'command.json').exists():continue
  raise AssertionError(f'missing producer result: {d}')
 r=json.loads((d/'result.json').read_text(encoding='utf-8'));classification='pass'
 if r['id']=='trigger-predicates':classification='preparation_failure_missing_capture_before_prepared_run'
 elif r['id'] in ['cli-end-fresh-checkpoint','cli-initial-fresh-checkpoint']:classification='verifier_probe_fault_timestamp0_assumption_corrected_separately'
 elif r['id'] in ['independent-runtime','independent-runtime-observation','independent-stale-checker']:classification='final_fail'
 elif r['id']=='stale-comparer-public-command':classification='negative_expected_reject_but_native0_accepts_stale_synthetic'
 elif r['id']=='final-state-byte-audit':classification='verifier_audit_self_record_not_yet_written_corrected_separately'
 if r['id']=='trigger-predicates-prepared':r['additional_env']={'TRIGGER_TEST_CAPTURE':str(E/'trigger-capture')}
 r['classification']=classification;records.append(r)
(E/'command-results.json').write_text(json.dumps({'records':records,'native_process_results_not_outer_tool_wrapper_status':True},indent=2),encoding='utf-8')
checks['command_count']=len(records);checks['native_nonzero']=[{'id':r['id'],'exit':r['native_exit'],'classification':r['classification']}for r in records if r['native_exit']!=0]
(E/'final-audit.json').write_text(json.dumps(checks,indent=2),encoding='utf-8');print(json.dumps(checks,ensure_ascii=False))
