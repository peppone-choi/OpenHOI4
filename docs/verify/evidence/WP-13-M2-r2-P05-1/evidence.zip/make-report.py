import pathlib,json,datetime
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1');E=W/'target/evidence/WP-13-M2-r2-P05-1'
data=json.loads((E/'command-results.json').read_text(encoding='utf-8'));records=data['records'];known={r['id'] for r in records}
for d in sorted((E/'commands').iterdir()):
 if d.name not in known:records.append(json.loads((d/'result.json').read_text(encoding='utf-8')))
data['records']=records;data['count']=len(records);(E/'command-results.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
def link(label,p):return f'[{label}]({(E/p).as_posix()})'
text=f'''# 검증 리포트 — WP-13 M2-r2 / P-05 시도 1

| 항목 | 값 |
|---|---|
| 판정 | **FAIL** — 검증 불변성은 유효. 신규 runtime guard와 comparer에 재현 가능한 누락 2건 |
| 검증자 | Codex 검증 세션, 구현 비참여·새 앱 채팅·추적 파일 무변경 |
| 브랜치·커밋 | detached `ff78a7501bace6fac1741d6cc596be524f887451` / 구현 `codex/wp13-trigger-engine-m2r2` |
| 검증 일시 | 2026-10-07 KST, 개별 명령의 UTC 시각·최종 봉인 receipt 포함 |
| 전용 worktree | `E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1` |
| 실행 증거 | {link('command-results.json','command-results.json')} — {len(records)}개 native command receipt, argv/cwd/env/PID/exit/stdout/stderr 원문 |

## 직접 실행한 명령

모든 명령의 cwd는 위 worktree이며 `GIT_OPTIONAL_LOCKS=0`, Cargo target은 자기 `target`이다. Cargo 실파일 존재를 먼저 확인하고 `C:/Users/user/.cargo/bin/cargo.exe` 또는 해당 process PATH를 사용했다. 아래는 반복·관련 probe를 묶은 표이고, 개별 명령 전문·각 종료 코드는 command-results에 있다.

| 명령 | 종료 코드 | 결과 요약 |
|---|---|---|
| `cargo fmt --check` | 0 | 통과 |
| `cargo clippy --workspace -- -D warnings` | 0 | 통과 |
| `cargo test --workspace` | 0 | 전체 통과; data trigger 4·sim trigger 9·save trigger 2 및 원 v1/v2/v3 회귀 직접 실행 |
| `npm --prefix client ci/test/run typecheck/run build` | 각각 0 | client 131/131, 타입·embedded dist build 통과 |
| `cargo test -p oh_proto req_net_04_generated_types_are_current -- --exact` | 0 | read-only generated TS equality. tracked generator 미실행 |
| `cargo run -p oh_cli -- run --scenario testland --days 365 --seed 1 --hash-out` ×2 | 0/0 | M0 동일 |
| 같은 run에 `--pack data/packs/testland --scenario m1` ×2 | 0/0 | actual M1 동일 |
| `oh_cli validate --deny-warnings` 원팩·trigger팩 | 0/0 | 실제 registered loader 통과 |
| `python data-probe.py` | 0 | 자체 실제 CLI 정상/오류/경계 37건 기대 exit 일치 |
| `cargo run --manifest-path …/probe/Cargo.toml --offline` 및 확장 실행 | 0/0 | 독립 달력·scope·플래그·깊이·예산·scheduled 오류 소비·실제 원장 phaseErr 원자성 |
| 독립 native probe `matrix/fresh/mutations` | 최종 모두 0 | v1/v2/v3 strict/force·None/Some mode, v4 pending-only/empty context, fresh pause→unpause, 복원 변조 12건 |
| `python check_trigger_determinism.py capture --out …/trigger-capture` | 0 | clean Windows 2회 capture; 6종 full DTO/canonical/hash/정의·팩 신원·fresh resume·원save bytes |
| `python -m unittest … test_trigger_evidence.py` | 첫 1, 준비 후 0 | 최초 capture 경로 미준비로 0 tests; 실제 capture 지정 후 9/9. 최초 실패 유지 |
| `python trigger_native.py --capture … --out …` | 0 | ended/tick0/paused 복원 및 tick0 startup, HTTP200·query 지속·명령 거부·Ctrl+C native0 |
| `python trigger_negative.py --out …` | 0 | CLI/server normal·force mode mismatch와 unsupported at_war native1, HTTP/WS 미수용·입력 보존 |
| `oh_cli run/resume … --ticks 8760/999 --save-out … --hash-out` | 모두 0 | 요청 상한 전에 tick48/tick0 정상 종료. 종료 저장 재개도 같은 hash |
| original/current save checker capture | 0/0 | 원 frozen v1와 별도 current input 각각 repeat/fresh state 검사 |
| `save_native.py` normal/force 및 `save_historical_native.py` | 0/0/0 | current 서버 native0; 원 historical 서버 native1 거부 유지 |
| original/current save evidence unittest | 0/0 | 8/8 및 21/21; 합성 predicate는 actual3OS로 집계 안 함 |
| 원 `movement_fixture/strait_fixture` capture·fresh resume | 모두 0 | v2/v3 전체 JSON·DTO·canonical·hash 일치 |
| `cargo deny check licenses bans sources`, npm licenses | 0/0 | Rust 허용목록 및 npm 103 dependencies 검사 통과 |
| docs/assets/architecture/localisation checker | 각각 0 | docs 오류·경고0, assets 오류0. localisation unused 경고 및 build chunk 경고 원문 유지 |
| `node client/node_modules/vitest/vitest.mjs run --config …/scratch-vitest.config.mjs` | **1** | 독립 25건 중 22건 FAIL, 3건 PASS |
| 같은 Vitest의 `-t 'native runtime observation'` | **1** | 11종 invalid 메시지 callback 전달·연결 유지·후속 send 가능 확인 |
| `python checker-stale-probe.py` | **1** | stale source HEAD 거부 단언 실패 |
| 실제 `check_trigger_determinism.py compare --root …/stale-predicate` | **0, 기대는 거부** | 세 합성 artifact 모두 과거 HEAD여도 수용 |
| 구현 원증거·source·최종 state/bytes audit | 최종 0 | 원 2,154개 파일/ZIP member 불일치0, 보호 원천 변경0 |

준비·검증자 오류도 보존했다. npm build/localisation native0 이후 출력 wrapper만 CP949 UnicodeEncodeError로 tool exit1이었다. CLI fresh probe 두 건의 최초101은 검증자가 saved timestamp를0으로 가정한 오류였으며, header의 실제 timestamp/player metadata 사용 후 원bytes·전체 DTO/canonical/hash 일치를 확인했다. 마지막 audit 최초1은 자기 실행 중 result 파일을 찾은 검증자 오류이며, 완료 receipt를 구분한 후 최종0이다. 제품 코드·테스트·기대값은 이 과정에서 수정하지 않았다.

## REQ별 확인

| REQ | 검사하는 테스트 | 실제 검사 여부 | 결과 |
|---|---|---|---|
| REQ-AGD-05 문법·registry | `req_agd_05_single_key_argument_and_depth_validation`, `registry_every_initial_argument_schema_and_malformed`, `actual_registered_loader_rejects_capability_with_source` | 실제 실행 및 source/field표 대조. 독립 CLI 37건 포함 | 문법·null/type/range/ref/미지원 로드 거부 통과 |
| REQ-AGD-05 실제 host | `actual_world_queries_and_read_only_conditions`, `scope_restoration_idempotence_and_v4_restore`, `effect_1000_1001_and_mid_failure_are_full_transactions`, `effect_root_depth16_17_and_unselected_branch_budget`, `enqueue_preview_then_scheduled_budget_failure_is_consumed` | actual World owner/controller/support 및 자체 NationId87·owner_of_state scope 검사 | 단일AST all/any/not, 읽기 불변, set/clear 수명·idempotence·scope 복귀, 깊이16/17·primitive1000/1001 통과 |
| REQ-TIME-04 실행 | `inclusive_checkpoint_and_future_queue_preserved`, `calendar_centuries_year_initial_and_legacy_none`, `simultaneous_sources_sorted_and_phase_error_preserves_all` | 자체 Gregorian 1/1899/1900/1999/2000/2099/2100/2400 계산, 실제 step 및 ledger overflow | inclusive 다음날00:00·start=end24h·end<start 오류·초기tick0·안정 다중 원인·한번 종료 통과 |
| REQ-TIME-04 저장·host | `v4_codec_limits_trailing_full_state_and_future_queue`, `legacy_none_local_some_and_force_cannot_drop_new_definitions`, `trigger_query_retains_typed_end_and_exact_u64_text` 및 native probes | 실제 codec/API strict·force 행렬, new process, 원 header/save/queue 비교 | v4·원형 호환·종료 후 query/save·Gameplay/Pause/Speed 거부 통과 |
| 신규 wire/runtime | 기존 `triggerValidation.test.ts` 및 독립 scratch-runtime | Rust→tracked TS read-only equality 및 실제 `connect()` invalid MessagePack 경로 | **FAIL F1** — 중복/order/ID/범위 오류 수용·연결과 입력 유지 |
| 신규 결정론 evidence gate | 9개 기존 predicate와 독립 stale probe·실제 comparer command | actual Windows와 합성 negative를 분리 | **FAIL F2** — 모두 같은 stale HEAD이면 현재 source와 불일치를 검출 못 함 |

필드표의 definition/initial/mutable/derived, 단위·type/range/null/default/ref/lifetime/authority를 constructor/step/canonical/v4/producer/query와 대조했다. flags는 nation별 정렬 집합, 종료 원인은 typed Date→Condition→Explicit lexical 집합이다. `with_world`가 초기 권위 설치 뒤 한번 평가하고 `with_movement`는 이를 한번 호출한다. v4 restore는 내부 frozen substrate 복원 후 저장 trigger를 검증·설치하며 초기 flags 생성이나 조건 재평가를 호출하지 않는다. Pause 중 조건이 참이 된 active 저장을 별도 PID에서 유지하고 첫 unpause 성공 시간전진에서만 tick1 Condition 종료함을 직접 확인했다.

실제 scheduled effect budget 오류는 해당 명령을 거부·소비하면서 clock을 전진한다. enqueue preview 오류는 전 canonical을 보존한다. 효과가 flags/end 후보를 만든 뒤 실제 원장 overflow가 난 phaseErr는 world/state/clock/queue/flags/end/seed 포함 전체 canonical을 보존한다. 두 오류 계약을 별도로 검사했다.

## 결정론

- M0 해시1/2: `b039d35666b77fc2` / `b039d35666b77fc2`.
- actual M1 해시1/2: `b595dc2a1e5b4f8c` / `b595dc2a1e5b4f8c`.
- 원 v1 split→재개: `4eb703aad086c7aa` → `d19d028857bb7485`; frozen fixture SHA `57b13c62ef1a6f88ade1851d0b3ae398157f95ca5bc246068eac3b2a964322fa` 유지.
- 원 v2 split→continuous/fresh: `18bff036731f4f26` → `a145b72ad0ad25e6`; 원 v3: `84462b78cc1a0f5d` → `299a80d49c17f3ec`. full DTO/canonical 포함 JSON 동일.
- v4 6종 active/split/ended/empty/initial/paused_condition의 capture2회·fresh native 재개·save 재인코드 모두 동일. ended의 Date/Condition/Explicit(a)/Explicit(z), 미래 명령5개, 원 movement/strait 상태 보존.
- 독립 pending-only의 fresh 반복 hash `41577048c05059f1`, Some(empty movement) `66e33169f83d0356`, Some(empty strait) `ee9523cc5d37ae97`; 각 원bytes와 full DTO/canonical 보존.
- CLI 실제 종료 tick48 hash `e374aab2f639f1fe`, 초기tick0 `e2c7c1ba82bc26a4`; native0·fresh 재개 동일.
- 실제 수행 플랫폼은 Windows만이다. 합성 Linux/macOS labels는 predicate 입력이다. same main5종 CI 및 신규 trigger workflow 모든 실제 OS job/artifact는 부모 통합 후 확인 대상이며 이 검증에서 미실행·미확인이다.

## 금지 사항 점검

| 항목 | 결과 |
|---|---|
| 시뮬레이션의 f32/f64 | `crates/oh_sim/src` 직접 읽기·검색 및 architecture 검사에서 없음; Fx integer raw arithmetic 확인 |
| HashMap 순회 | 없음. flags/scopes/queue는 BTreeMap/BTreeSet/ordered Vec |
| thread_rng / SystemTime / I/O | sim source에 없음. 조건 host는 immutable borrow; chance는 현재 end/if context 로드 거부 |
| 코드 내 수치 리터럴 | 신규16/1000은 02§5.6 기술 상한; Gregorian·wire/codec 타입 경계·enum tags이며 새 gameplay 계수 없음 |
| 미결정 규칙 구현 | REQUEST-0009 A의 CEO 한정 잠정과 최신01§3.3/02§5.7 대조; 사용자 D/OPEN 추가확정으로 바꾸지 않음 |
| 골든 기대값 변경 근거 | 원 packs/golden/repro/frozen fixtures/helpers/checkers/기존 workflows·Cargo/npm dependency 파일의 base 대비 변경0; 기존 단언 삭제·약화 없음 |
| 클린룸 | 새 synthetic trigger fixture와 ASSETS append·provenance 대조; 원작 자료 사용 근거 없음 |
| 클라이언트 게임 규칙 계산·설정 우회 | 없음. tracked generator 미실행, sandbox/승인/network/CI 강도 변경 없음 |

## 작업 로그 증거와 실제 결과 대조

구현 원 manifest의 2,154개 파일을 디스크/ZIP member 전수 bytes·SHA와 대조했고 불일치0이다. 원 ZIP SHA `851bbde074c5636d913a3cd19ba14bbfa098b8947045eb6bfcebb0c0f8b1b89a`도 custody와 일치한다. red-data/red-sim의 native101 및 이후 clean0 원출력을 보존했다. 구현의 기존 131 client tests·workspace·해시·native 저장/서버 주장은 재실행과 일치한다. 그 테스트들은 F1과 F2를 검사하지 못했다.

원 tracked source HEAD와 최신 planning 사본 HEAD `c8913c8c5255cbf117844534b0291eb8c812c12f`를 구분했다. planning16개 SHA는 parent identity와 모두 같다. schema/ADR의 현재 지원 범위는 실제 host와 일치하며 미지원 정치/법령/경제/장비/전쟁 primitive 사용은 로드 오류다. 점수는 generic checked Fx 산술만 있고 실제 VP accessor/보유의 owner-control 의미·국가 IC producer·생존/진영은 미완료다. WP14/15/20 producer, WP20/22 항복·관전 및 WP22 결과 UI, M3 event chance adapter와 전체 MOD07 reference는 후속 인수 대상으로 유지한다. 부분0weight/합성 산술·query를 전체 M2 완료로 세지 않았다.

부모 original-before와 verifier-before/after의 HEAD·9,951개 tracked list/SHA·semantic index·raw index bytes·status/diff/cached diff 모두 동일이다. raw index SHA는 `df3bb6c3ab0ec15d4bc35117f8d096b5bd27543bcea980cee03218691c4319d7`. 검증 무효 조건은 발생하지 않았다. 종료 전 자기 target 실행 프로세스0개를 확인했다. 앱 turn 종료를 CLI exit0으로 기록하지 않았다.

원출력·재현 source/fixtures·snapshot·fullreport는 {link('SHA256SUMS.json','SHA256SUMS.json')}과 {link('evidence.zip','evidence.zip')}에 봉인한다. manifest/ZIP의 자체 identity와 native 봉인 receipt는 별도 {link('ZIP-IDENTITY.json','ZIP-IDENTITY.json')}이며 순환 self hash는 없다. 문서 경로 저장·P-06·새 독립 검증·통합은 부모 담당이다.

## FAIL 항목

| # | 재현 명령 | 기대 | 실제 |
|---|---|---|---|
| F1 | `node client/node_modules/vitest/vitest.mjs run --config target/evidence/WP-13-M2-r2-P05-1/scratch-vitest.config.mjs` | 중복/역순/빈 causes, 중복/역순 nation·flag, invalid ID, u64 초과 tick을 수용하지 않고 callback 전 차단·연결종료·후속 send 금지 | 최초25건 중22 실패. 관찰 probe에서 11종 invalid 모두 callbackCount2/closeCount0/sentAfterInvalid1. 정상 current/legacy와 잘못된 Explicit 구조 거부는 통과 |
| F2 | `python target/evidence/WP-13-M2-r2-P05-1/checker-stale-probe.py`; 실제 `python crates/oh_sim/tools/check_trigger_determinism.py compare --root target/evidence/WP-13-M2-r2-P05-1/stale-predicate` | artifact source HEAD가 현재 exact checkout과 다르면 거부 | synthetic3종의 HEAD를 모두 base `f44e16…`로 바꾸고 manifests 재봉인해도 comparer native0. `compare_artifacts`가 서로의 head 동일성만 검사하며 checkout HEAD와 대조하지 않음 |

F1의 실제 소스는 [network.ts]({(W/'client/src/network.ts').as_posix()}:40) 및 decimal/flags/end/trigger guards다. F2는 [check_trigger_determinism.py]({(W/'crates/oh_sim/tools/check_trigger_determinism.py').as_posix()}:345)다. 재현 입력은 ignored target에만 만들었으며 제품 수정은 하지 않았다.
'''
(E/'fullreport.md').write_text(text,encoding='utf-8');print(json.dumps({'report':str(E/'fullreport.md'),'commands':len(records),'bytes':len(text.encode())}))
