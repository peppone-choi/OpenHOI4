import pathlib,hashlib,json,zipfile,shutil
W=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1');E=W/'target/evidence/WP-13-M2-r2-P05-1';I=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2/target/evidence/WP-13');out=E/'implementation-audit';out.mkdir()
m=json.loads((I/'SHA256-MANIFEST.json').read_text(encoding='utf-8'));custody=json.loads((I/'custody.json').read_text(encoding='utf-8'));summary=json.loads((I/'final-summary.json').read_text(encoding='utf-8'));mismatch=[]
with zipfile.ZipFile(I/'originals.zip') as z:
 for item in m['files']:
  p=item['path'];data=(I/p).read_bytes();archived=z.read(p)
  if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256'] or data!=archived:mismatch.append(p)
 if z.read('SHA256-MANIFEST.json')!=(I/'SHA256-MANIFEST.json').read_bytes():mismatch.append('embedded manifest')
result={'files_checked':len(m['files']),'mismatches':mismatch,'head':m['head'],'summary_head':summary['head'],'zip_sha256':hashlib.sha256((I/'originals.zip').read_bytes()).hexdigest(),'custody_zip_matches':hashlib.sha256((I/'originals.zip').read_bytes()).hexdigest()==custody['zip_sha256'],'red_data_native':json.loads((I/'red-data-native/result.json').read_text()),'red_sim_native':json.loads((I/'red-sim-native/result.json').read_text())}
for name in ['final-summary.json','SHA256-MANIFEST.json','custody.json','protected-source-check.json','fixture-provenance.json']:
 shutil.copyfile(I/name,out/name)
for name in ['red-data-native','red-sim-native','final-clean-npm-test','final-clean-readonly-ts','final-clean-workspace','final-clean-m0-1','final-clean-m1-1']:
 shutil.copytree(I/name,out/name)
(out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result));assert not mismatch and result['custody_zip_matches'];assert result['head']==result['summary_head']=='ff78a7501bace6fac1741d6cc596be524f887451'
