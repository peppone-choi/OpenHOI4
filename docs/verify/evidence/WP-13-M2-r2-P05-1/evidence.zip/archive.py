import pathlib,json,hashlib,zipfile,datetime
E=pathlib.Path('E:/openhoi/.orchestrator/wt/WP-13-M2-r2-verify1/target/evidence/WP-13-M2-r2-P05-1');exclude={'SHA256SUMS.json','evidence.zip','ZIP-IDENTITY.json'}
assert not (E/'SHA256SUMS.json').exists() and not (E/'evidence.zip').exists(),'do not overwrite original seal'
paths=sorted(p for p in E.rglob('*') if p.is_file() and p.relative_to(E).as_posix() not in exclude)
manifest={'head':'ff78a7501bace6fac1741d6cc596be524f887451','scope':'all existing evidence files, originals/negative/initial failures preserved; no self hashes','files':[]}
for p in paths:
 b=p.read_bytes();manifest['files'].append({'path':p.relative_to(E).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(E/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(E/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(E).as_posix())
 z.write(E/'SHA256SUMS.json','SHA256SUMS.json')
with zipfile.ZipFile(E/'evidence.zip') as z:
 assert len(z.namelist())==len(paths)+1 and len(set(z.namelist()))==len(z.namelist())
 for r in manifest['files']:
  b=z.read(r['path']);assert b==(E/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
 assert z.read('SHA256SUMS.json')==(E/'SHA256SUMS.json').read_bytes()
identity={'head':manifest['head'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(paths),'zip_members':len(paths)+1,'zip_bytes':(E/'evidence.zip').stat().st_size,'zip_sha256':hashlib.sha256((E/'evidence.zip').read_bytes()).hexdigest(),'manifest_bytes':(E/'SHA256SUMS.json').stat().st_size,'manifest_sha256':hashlib.sha256((E/'SHA256SUMS.json').read_bytes()).hexdigest(),'all_member_bytes_sha_verified':True}
print(json.dumps(identity))
