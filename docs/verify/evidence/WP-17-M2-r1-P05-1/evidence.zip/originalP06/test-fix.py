from pathlib import Path
p=Path('crates/oh_save/tests/strait.rs');s=p.read_text(encoding='utf-8-sig').replace('|d|d.base.units[0].allowed.pop(),','|d|{d.base.units[0].allowed.pop();},');p.write_text(s)
