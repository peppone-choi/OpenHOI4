from pathlib import Path
p=Path('docs/worklog/WP-17.md');s=p.read_text(encoding='utf-8');s=s.replace('## 계획','## 최초 97f 실행 계획 (원 기록 보존)',1);s=s.replace('## 테스트 우선 기록','## 최초 97f 테스트 우선 기록',1);s=s.replace('## 실행한 검증','## 최초 97f 실행한 검증',1);s=s.replace('## 결정 필요','## 최초 97f 결정 필요 (P-06 최신 대응은 아래)',1);s=s.replace('## 범위 밖 발견','## 최초 97f 범위 밖 발견',1);s=s.replace('## 못 한 부분과 이유','## 최초 97f 못 한 부분과 이유',1);s=s.replace('## 수정 기록 (P-06)','## 수정 기록 (P-06) — REQUEST-0007 A 추가 구현',1);s+='''

### P-06 인수·변경·권위 경계

- 원 source `97f688718dabed46bc477fa249798ac09e999581`와 그 `target/evidence/WP-17/` 원 로그/정확 native/manifest를 변경하지 않았다. reset/삭제/기존기대값 교체 없음. 본문 위의 최초 실행 미지원/결정대기는 그 당시 기록이다.
- 부모 main93e3dc1의 최신 01§4.7/02§5.11/03P03/REQUEST0007 및 `E:/openhoi/docs/decisions/evidence/strait-policy/` 원후보 SHA2731e99b719f836d42d2100da349392d199cbebba301796cbbeed098104b2e54/자체독립8산술을 읽었다. CEO A의 한정 게임행동 잠정이며 D/OPEN 추가확정 없음.
- 코드 전에 schema P06 절과 ADR1702의 field/type/unit/optional/context/권위/참조/실패/raw/version·독립예제를 작성하고 부모에 additive v3 기술경계를 보고해 진행 승인을 받았다. 원 v2save 요구는 v2 body 보존이며 기존field에 신규field를 덧붙이라는 뜻이 아니다.
- `CrossingKind`, `StraitFactors`의 독립 strait 슬롯, `StraitContext`, `StraitInput`, trusted `Movement::with_straits`를 추가했다. map의 실제 land-land Strait·allowed 양끝점·방향별 명시 context/kind/양수만 사용한다. 1fallback/river 중복곱/계산실패 NoPath 은폐 없음. 기존 None mode의 canonical·v2 reader/writer/정책은 그대로 유지한다.
- Some explicit context(정지unit·빈 directions·빈 unit집합 포함)는 모두 canonical/v3 save에 포함한다. `SimulationSaveV3{base:SimulationSaveV2,straits:Vec<UnitStraitsV3>}`와 `StraitCorrectionV3{from,to,kind:u8,factors:[i64;4]}`의 순서·raw kind3·four raw slots/복원/예산 preflight를 구현했다. v1/v2/v3 read/write를 유지하며 v3→v2 export는 손실 방지 명시오류다. migration/구버전 거부 없음.
- source97f 정확 native 결과를 새 frozen `movement-v2-97f.ohsave`/`.expected.json`에 그대로 복사했고 fixture README에 출처만 추가했다. 원 v2 reader→writer bytes/dto/canonical/hash 및 실제 재개를 검사한다. binary SHA d3706ae77d226ad480ce24e018137de6898bd45b0bd6dbb203b1a4a4c6c9df0f / JSON SHA7692909bda6561a262df05a93e0ef5797bf65b8a414930790a0b710c817bed81는 원source와 일치한다.
- 부모가 ASSETS.toml의 이 두 fixture append행만 명시 소유인계해 source original/author contributors/CC-BY-SA4.0/modifiedfalse/AIfalse/원source·SHA·hash를 기록했다. 기존 모든 asset행은 불변이다. protected v1 helper/copy/mod/save_fixture 및 WP24 frozenpack 경로는 변경하지 않았다.

### P-06 테스트 우선·실패 보존

| REQ | 테스트 | 구현 전 결과 | 구현 후 결과 |
|---|---|---|---|
| REQ-MIL-04 / REQUEST0007 A | req_mil_04_strait_explicit_slot_9_10_tick_boundary | red-strait.log 실제exit101, CrossingKind/Strait API 부재 | PASS, 10h raw42949672960; tick9 elapsed38654705664 / tick10 도착0 |
| 위 + 신규 저장경계 | strait_v3_tick9_full_context_pending_and_resume | red-strait-save.log 실제exit101, export_save_v3 부재 | PASS, pending/context/progress 전체 exact restore |
| 보강 회귀 | explicit slot/대체8h/동점10h/0·음수·missing·overflow·underflow·wrongkind/ref/nonland/타국/phase오류/예정오류/정렬·zero ID | 위 red 후 추가, 별도 red로 가장하지 않음 | strait sim9개 PASS |
| 저장/호환 회귀 | original97f v2 bytes/dto/hash, v3 kind/raw/idle-empty/malformed/preflight/unknown4/REQUEST6 | 위 red 후 추가 | strait save6개 PASS |

보강 테스트 작성 중 반환형(pop Option) 및 중첩 borrow의 실제 컴파일 실패도 `strait-save-boundaries.log`/`-2.log`에 보존했다(exit101); 작업 내 수정 뒤 `-3.log` PASS다. 이를 제품 기능 red/독립 FAIL로 재해석하지 않는다. 원 최초 red/PATH미실행/UnsupportedFormat 회귀 이력도 위에 유지했다.

### P-06 실행한 검사와 원 증거

모든 명령은 전용 worktree에서, cargo는 설치된 executable과 자기 target으로 수행했다. 아래 로그는 `target/evidence/WP-17-P06/`다.

| 명령 | 실제 exit | 로그/결과 |
|---|---|---|
| cargo test -p oh_sim --test strait (최초) | 101 | red-strait.log |
| cargo test -p oh_save --test strait (최초) | 101 | red-strait-save.log |
| cargo test -p oh_sim --test movement -p oh_save --test movement | 0 | legacy-movement.log, 원11+6 모두 PASS |
| cargo test -p oh_sim --test strait -p oh_save --test strait | 0 | strait-tests-final.log 당시7+6; 최종workspace에서9+6 PASS |
| cargo test --workspace | 0 | workspace-final.log, 기존/신규/REQ6/compile_fail 모두 PASS |
| cargo fmt --check | 0 | fmt.log |
| cargo clippy --workspace -- -D warnings | 0 | clippy.log |
| cargo clippy --workspace --all-targets -- -D warnings | 0 | clippy-all-final.log, 모든tests/examples 포함 |
| python tools/check_assets.py | 0 | assets.log, 0error |
| python tools/check_docs.py | 0 | docs.log, 오류0/경고0 |
| python crates/oh_sim/tools/check_sim_determinism.py capture --out target/evidence/WP-17-P06/m0-hash | 0 | 실제1000틱2회 ff921fd8148e699d |
| 위 capture --m1 --out target/evidence/WP-17-P06/m1-hash | 0 | 실제1000틱2회 60448355cecffa9d |
| python crates/oh_save/tools/check_save_determinism.py capture --out target/evidence/WP-17-P06/v1-save | 0 | 원v1 SHA57b13c62ef1a6f88ade1851d0b3ae398157f95ca5bc246068eac3b2a964322fa와 split4eb703aad086c7aa/재개d19d028857bb7485, 구현중 dirtytrue 원문 보존 |
| cargo run --quiet -p oh_save --example strait_fixture -- capture target/evidence/WP-17-P06/native-strait-1 및 -2 | 각0 | 동일v3 savebytes/dto/canonical/hash |
| 위 strait_fixture -- resume data/packs/testland target/evidence/WP-17-P06/native-strait-1/strait-v3.ohsave | 0 | 새process의 split/arrival/최종 전체구조 동일 |
| python target/evidence/WP-17-P06/compare-native-strait.py | 0 | split84462b78cc1a0f5d/arrivald2c3248b5eca4b8d/final299a80d49c17f3ec; v3 SHAde7ac4afd0c2638716e353dedcfa18c6c56cf7dda8373614a91dd221b51c4814 |

최종 commit 뒤 clean exactHEAD/native PID/exit/executable SHA 및 v1/v2/v3 원파일/DTO/canonical 재개를 별도 `exact-*` 증거로 기록한다. 이 Windows 자체검사를 세OS CI/독립P05 PASS로 기록하지 않는다. UI/MessagePack/client source는 변경하지 않았고 이미 자기 client/dist가 실제 빌드되어 workspace server 검사가 가능했다.

### P-06 최종 후속·결정·인수

- REQUEST0007 A의 strait 미지원/결정대기는 이 추가 구현으로 해소했다. USER D/OPEN 추가확정은 없다. 실제계수 콘텐츠, 함대/봉쇄/해역통제/항구수송/통행권/진행중 allowed 변경은 구현하지 않았다.
- 실제 unit 생성/편제·동적보급/접근 adapter·publicwire/UI는 기존 승인한 WP16/19/20/22 후속 경계다. original/inherited context와 save 형식을 runtime/UI DTO에서 덮는 새 경로가 없다.
- WP13 producer 인수: schema P06 절/ADR1702, with_straits typed initialization, read-only strait_context/has_strait_context, frozenV1/V2와 SimulationSaveV3·encode versionselection·bounded restore. 모든optional/context·state/queue를 잃지 않는 별도 후속추가 경계를 유지해야 한다.
- 차별화 추가 초안: 지형/인프라/보급과 구별된 명시 해협 시간 슬롯·양끝점 권위 접근·방향별context·kind/raw hash/save를 사용해 자체 경로와 명령 원자성을 공개 재현한다. 원작 수치/문장/파일/복제 자료 없음.
- 자기 branch의 새커밋까지 수행하며 main수정/병합/푸시/새채팅/정리 삭제는 하지 않는다. 독립P05와 같은main CI는 부모가 수행한다.
''';p.write_text(s,encoding='utf-8')
p=Path('docs/plans/WP-17-schema.md');s=p.read_text(encoding='utf-8');s=s.replace('2026-10-07. 구현 전 계획.','2026-10-07. 아래 첫 표와 strait 미지원은 최초97f의 구현 전 계획/당시 범위다. 현재 REQUEST0007 대응은 아래 P-06 절에서 확장하며 원 기록을 보존한다.',1);p.write_text(s,encoding='utf-8')
p=Path('docs/adr/ADR-1701-movement.md');s=p.read_text(encoding='utf-8');s+='\nP-06 후속 ADR-1702가 REQUEST-0007 A의 typed Strait 슬롯/explicit context/additive v3를 추가한다. 본 ADR의 원97f strait 미지원/미정 기록은 당시 상태이며, 일반/하천·REQ6·legacy bytes 기술 선택은 그대로 보존한다.\n';p.write_text(s,encoding='utf-8')
