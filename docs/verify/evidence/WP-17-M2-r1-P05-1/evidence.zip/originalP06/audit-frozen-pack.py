from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();path=root/'crates/oh_save/tests/fixtures/movement-pack-97f.source.json';data=json.loads(path.read_text(encoding='utf-8'));folder=path.parent/'movement-pack-97f';actual=sorted(p.relative_to(folder).as_posix() for p in folder.rglob('*')if p.is_file());assert actual==[e['path']for e in data['files']];assert len(actual)==19
for e in data['files']:
 raw=(folder/e['path']).read_bytes();source=subprocess.check_output(['git','show',data['source']+':data/packs/testland/'+e['path']]);assert raw==source;assert len(raw)==e['bytes'];assert hashlib.sha256(raw).hexdigest()==e['sha256']
record={'source':data['source'],'count':19,'all_git_blob_byte_sha_equal':True,'pack_hash':data['pack_hash'],'manifest_sha256':hashlib.sha256(path.read_bytes()).hexdigest()};(root/'target/evidence/WP-17-P06/frozen-pack-audit.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
