from pathlib import Path
import hashlib,json
out=Path('target/evidence/WP-17-P06')
a=json.loads((out/'native-strait-1/capture.json').read_text(encoding='utf-8'));b=json.loads((out/'native-strait-2/capture.json').read_text(encoding='utf-8'));c=json.loads((out/'native-strait-resume.json').read_text(encoding='utf-8-sig'));assert a==b==c
x=(out/'native-strait-1/strait-v3.ohsave').read_bytes();assert x==(out/'native-strait-2/strait-v3.ohsave').read_bytes()
assert a['split']['dto']['base']['units'][0]['elapsed']==38654705664
assert a['split']['dto']['base']['units'][0]['province']==10
assert a['arrival']['dto']['base']['units'][0]['province']==40
assert a['arrival']['dto']['base']['units'][0]['route']==[]
assert a['arrival']['dto']['base']['units'][0]['elapsed']==0
assert a['continuous']['dto']['base']['units'][0]['province']==10
assert a['continuous']['dto']['base']['units'][0]['route']==[]
result={'full_dto_canonical_hash_equal':True,'split_hash':a['split']['hash'],'arrival_hash':a['arrival']['hash'],'continuous_hash':a['continuous']['hash'],'save_sha256':hashlib.sha256(x).hexdigest(),'split_elapsed_raw':38654705664,'kind':a['split']['dto']['straits'][0]['corrections'][0]['kind'],'applied_strait_raw':a['split']['dto']['straits'][0]['corrections'][0]['factors'][3]}
(out/'native-strait-compare.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
