from pathlib import Path
p=Path('crates/oh_sim/src/save_state.rs');s=p.read_text();s=s.replace('''        let movement = self.movement.as_ref().ok_or("V2RequiresMovement")?;''','''        let movement = self.movement.as_ref().ok_or("V2RequiresMovement")?;
        if movement.has_strait_context(){return Err("StraitRequiresV3".into());}''',1)
s=s.replace('''    pub fn from_save_v2(dto: SimulationSaveV2, context: &RestoreContext) -> Result<Self, String> {
        use crate::movement''','''    pub fn from_save_v2(dto: SimulationSaveV2, context: &RestoreContext) -> Result<Self, String> {
        Self::from_movement_save(dto,context,None)
    }
    fn from_movement_save(dto:SimulationSaveV2,context:&RestoreContext,
        straits:Option<BTreeMap<oh_core::DivisionId,crate::movement::DirectedStraits>>)->Result<Self,String>{
        use crate::movement''',1)
s=s.replace('let movement = Movement { units, straits:None };','let movement = Movement { units, straits };',1)
s+='''
/// Frozen v2 body plus independently typed direction/kind/raw time context.
#[derive(Clone,Debug,Eq,PartialEq,Serialize,Deserialize)]
pub struct StraitCorrectionV3 {pub from:u16,pub to:u16,pub kind:u8,pub factors:[i64;4]}
#[derive(Clone,Debug,Eq,PartialEq,Serialize,Deserialize)]
pub struct UnitStraitsV3 {pub unit:u32,pub corrections:Vec<StraitCorrectionV3>}
#[derive(Clone,Debug,Eq,PartialEq,Serialize,Deserialize)]
pub struct SimulationSaveV3 {pub base:SimulationSaveV2,pub straits:Vec<UnitStraitsV3>}
impl Simulation {
    pub fn export_save_v3(&self)->Result<SimulationSaveV3,String>{
        let contexts=self.movement.as_ref().and_then(|m|m.straits.as_ref()).ok_or("V3RequiresStraitContext")?;
        let straits=contexts.iter().map(|(unit,corrections)|UnitStraitsV3{unit:unit.0,corrections:corrections.iter().map(|(&(from,to),c)|StraitCorrectionV3{from:from.0,to:to.0,kind:c.kind as u8,factors:[c.factors.terrain.to_bits(),c.factors.infrastructure.to_bits(),c.factors.supply.to_bits(),c.factors.strait.to_bits()]}).collect()}).collect();
        let mut legacy=self.clone();legacy.movement.as_mut().ok_or("V3RequiresMovement")?.straits=None;
        Ok(SimulationSaveV3{base:legacy.export_save_v2()?,straits})
    }
    pub fn from_save_v3(dto:SimulationSaveV3,context:&RestoreContext)->Result<Self,String>{
        use crate::movement::{CrossingKind,StraitContext,StraitFactors};
        use oh_core::{DivisionId,ProvinceId,Fx};
        if !strictly_sorted(dto.straits.iter().map(|c|c.unit)){return Err("InvalidStrait: duplicate/unsorted units".into());}
        let mut straits=BTreeMap::new();
        for c in dto.straits {
            if !strictly_sorted(c.corrections.iter().map(|e|(e.from,e.to))){return Err("InvalidStrait: duplicate/unsorted directions".into());}
            let mut corrections=BTreeMap::new();
            for e in c.corrections {
                if e.kind!=CrossingKind::Strait as u8{return Err("InvalidStrait: crossing kind".into());}
                corrections.insert((ProvinceId(e.from),ProvinceId(e.to)),StraitContext{kind:CrossingKind::Strait,factors:StraitFactors{terrain:Fx::from_bits(e.factors[0]),infrastructure:Fx::from_bits(e.factors[1]),supply:Fx::from_bits(e.factors[2]),strait:Fx::from_bits(e.factors[3])}});
            }
            straits.insert(DivisionId(c.unit),corrections);
        }
        Self::from_movement_save(dto.base,context,Some(straits))
    }
}
''';p.write_text(s)
p=Path('crates/oh_save/src/bounds.rs');s=p.read_text().replace('    if version == 2 {','    if version >= 2 {',1);idx=s.rfind('    r.end()');s=s[:idx]+'''    if version == 3 {
        for _ in 0..r.entries(limits.map_entries_max)? {
            r.number(32)?;
            for _ in 0..r.entries(limits.map_entries_max)? {
                r.number(16)?;r.number(16)?;
                if r.byte()?!=3 {return Err("Postcard: strait crossing kind".into());}
                for _ in 0..4 {r.number(64)?;}
            }
        }
    }
'''+s[idx:];p.write_text(s)
p=Path('crates/oh_save/src/lib.rs');s=p.read_text().replace('SimulationSaveV1, SimulationSaveV2','SimulationSaveV1, SimulationSaveV2, SimulationSaveV3',1);s=s.replace('pub const MOVEMENT_FORMAT_VERSION: u16 = 2;','pub const MOVEMENT_FORMAT_VERSION: u16 = 2;\npub const STRAIT_FORMAT_VERSION: u16 = 3;')
s=s.replace('''    let version = if sim.movement().is_some() {''','''    let version = if sim.movement().is_some_and(|m|m.has_strait_context()) {
        STRAIT_FORMAT_VERSION
    } else if sim.movement().is_some() {''',1)
s=s.replace('''    let (body, candidate) = if version == MOVEMENT_FORMAT_VERSION {''','''    let (body, candidate) = if version==STRAIT_FORMAT_VERSION {
        let dto=sim.export_save_v3()?;
        (serialize(&dto)?,Simulation::from_save_v3(dto,&context.restore)?)
    } else if version == MOVEMENT_FORMAT_VERSION {''',1)
s=s.replace('[FORMAT_VERSION, MOVEMENT_FORMAT_VERSION]','[FORMAT_VERSION, MOVEMENT_FORMAT_VERSION, STRAIT_FORMAT_VERSION]')
s=s.replace('supported v{FORMAT_VERSION}/v{MOVEMENT_FORMAT_VERSION}','supported v{FORMAT_VERSION}/v{MOVEMENT_FORMAT_VERSION}/v{STRAIT_FORMAT_VERSION}')
a=s.index('    let (base, dto2) = if version');b=s.index('    if header.scenario_id != base.state.scenario',a)
s=s[:a]+'''    let (base,dto2,dto3)=if version==STRAIT_FORMAT_VERSION {
        let dto:SimulationSaveV3=deserialize(&body)?;
        (dto.base.base.clone(),None,Some(dto))
    } else if version == MOVEMENT_FORMAT_VERSION {
        let dto:SimulationSaveV2=deserialize(&body)?;
        (dto.base.clone(),Some(dto),None)
    } else { (deserialize::<SimulationSaveV1>(&body)?,None,None) };
'''+s[b:]
s=s.replace('''    let simulation = match dto2 {
        Some(dto) => Simulation::from_save_v2(dto, &context.restore)?,
        None => Simulation::from_save(base, &context.restore)?,
    };''','''    let simulation=if let Some(dto)=dto3 {Simulation::from_save_v3(dto,&context.restore)?}
        else if let Some(dto)=dto2 {Simulation::from_save_v2(dto,&context.restore)?}
        else {Simulation::from_save(base,&context.restore)?};''',1)
p.write_text(s)
