from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();prefix='data/packs/testland/';head='97f688718dabed46bc477fa249798ac09e999581';dst=root/'crates/oh_save/tests/fixtures/movement-pack-97f';records=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','data/packs/testland'],text=True).splitlines():
 raw=subprocess.check_output(['git','show',head+':'+name]);relative=name.removeprefix(prefix);p=dst/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);assert p.read_bytes()==raw
 records.append({'path':relative,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'source':head,'source_path':'data/packs/testland','files':records,'count':len(records),'pack_hash':13318001328374612931,'pack_hash_oracle':'Original relative-path ordered Postcard/FNV Python save_reference.pack_hash','purpose':'Historical source97f v2 input only; current pack tests remain separate'}
(root/'crates/oh_save/tests/fixtures/movement-pack-97f.source.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
asset=root/'assets/ASSETS.toml'
with asset.open('a',encoding='utf-8') as f:
 for e in records:
  f.write('\n[[asset]]\npath = '+json.dumps('crates/oh_save/tests/fixtures/movement-pack-97f/'+e['path'])+'\nauthor = "OpenHOI contributors"\nsource = "original"\nlicense = "CC-BY-SA-4.0"\nmodified = false\nai_generated = false\nnotes = '+json.dumps('Unmodified source97f688718dabed46bc477fa249798ac09e999581 Testland file for historical v2 compatibility only; SHA256 '+e['sha256']+'. Original synthetic pack; current pack tests are separate; no migration or replacement.')+'\n')
print(json.dumps({'files':len(records),'pack_hash':manifest['pack_hash'],'all_source_bytes_match':True}))
