from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=root/'target/evidence/WP-17-P06';original=root/'target/evidence/WP-17/SHA256-MANIFEST.json';data=json.loads(original.read_text(encoding='utf-8'))
for e in data['evidence']:
 p=original.parent/e['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256'];assert p.stat().st_size==e['bytes']
(out/'original97f-final-audit.json').write_text(json.dumps({'manifest_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'original_head':data['head'],'files':len(data['evidence']),'all_unchanged':True},indent=2),encoding='utf-8')
source={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'worktree':str(root),'status':subprocess.check_output(['git','status','--porcelain'],text=True),'original217_preserved':True,'evidence':[]}
for p in sorted(out.rglob('*')):
 if p.is_file()and p.name!='SHA256-MANIFEST.json':source['evidence'].append({'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'SHA256-MANIFEST.json').write_text(json.dumps(source,indent=2),encoding='utf-8');print(json.dumps({'head':source['head'],'clean':source['status']=='','evidence_files':len(source['evidence']),'manifest':str(out/'SHA256-MANIFEST.json')}))
