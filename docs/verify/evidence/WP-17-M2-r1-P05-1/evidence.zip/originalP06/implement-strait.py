from pathlib import Path
p=Path('crates/oh_sim/src/movement.rs');s=p.read_text();s=s.replace('    InvalidValue,','    InvalidValue,\n    InvalidKind,',1)
idx=s.index('#[derive(Clone, Debug)]\npub struct UnitInput')
s=s[:idx]+'''/// Crossing discriminator is authoritative, never supplied in client commands.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
#[repr(u8)]
pub enum CrossingKind { Normal, RiverSmall, RiverLarge, Strait }
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
pub struct StraitFactors {
    pub terrain: Fx, pub infrastructure: Fx, pub supply: Fx, pub strait: Fx,
}
impl StraitFactors {
    pub fn from_defines(defs:&Defines,map:&MapData,from:ProvinceId,to:ProvinceId,infrastructure:Fx,supply:Fx)->Result<Self,MovementError>{
        if !land(map,from)||!land(map,to) { return Err(MovementError::InvalidReference); }
        let edge=map.edge(from.0,to.0).ok_or(MovementError::InvalidReference)?;
        if edge.kind!=EdgeKind::Strait {return Err(MovementError::InvalidKind);}
        let p=&map.provinces[usize::from(map.province_index(to.0).ok_or(MovementError::InvalidReference)?)];
        let get=|key:&str| match defs.get(key){
            Some(DefineValue::Number(Number::Fixed(v)))=>Ok(*v),
            Some(DefineValue::Number(Number::Integer(v)))=>Fx::checked_from_num(*v).ok_or(MovementError::Overflow),
            _=>Err(MovementError::MissingContext),
        };
        let factors=Self{terrain:get(&format!("movement.terrain_{}",p.terrain))?,infrastructure,supply,strait:get("movement.strait")?};
        factors.validate()?;Ok(factors)
    }
    pub(crate) fn validate(self)->Result<(),MovementError>{
        if [self.terrain,self.infrastructure,self.supply,self.strait].iter().any(|v|*v<=Fx::ZERO){return Err(MovementError::InvalidValue);}Ok(())
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
pub struct StraitContext {pub kind:CrossingKind,pub factors:StraitFactors}
pub type DirectedStraits = BTreeMap<(ProvinceId,ProvinceId),StraitContext>;
#[derive(Clone, Debug)]
pub struct StraitInput {pub unit:DivisionId,pub corrections:DirectedStraits}
''' +s[idx:]
s=s.replace('fn validate(&self, world: &World) -> Result<(), MovementError> {','fn validate(&self, world: &World, straits:Option<&DirectedStraits>) -> Result<(), MovementError> {',1)
s=s.replace('!usable(map, l.from, l.to)','!route_usable(map, l.from, l.to, straits.is_some())',1)
s=s.replace('self.duration(map, l.from, l.to)?','self.duration(map, l.from, l.to, straits)?',1)
s=s.replace('fn duration(&self, map: &MapData, a: ProvinceId, b: ProvinceId) -> Result<Fx, MovementError> {','fn duration(&self, map: &MapData, a: ProvinceId, b: ProvinceId, straits:Option<&DirectedStraits>) -> Result<Fx, MovementError> {',1)
s=s.replace('''        let f = self
            .corrections''','''        if edge.kind==EdgeKind::Strait {
            let context=straits.and_then(|c|c.get(&(a,b))).ok_or(MovementError::MissingContext)?;
            if context.kind!=CrossingKind::Strait {return Err(MovementError::InvalidKind);}
            return crate::formula::strait_hours(edge.distance_km,self.speed,context.factors);
        }
        let f = self
            .corrections''',1)
s=s.replace('''        end: ProvinceId,
    ) -> Result<Vec<Leg>, MovementError>''','''        end: ProvinceId,
        straits: Option<&DirectedStraits>,
    ) -> Result<Vec<Leg>, MovementError>''',1)
s=s.replace('&& usable(map, a, b) {','&& route_usable(map, a, b, straits.is_some()) {',1)
s=s.replace('self.duration(map, p[0], p[1])?','self.duration(map, p[0], p[1], straits)?')
s=s.replace('self.duration(map, a, b)?.to_bits()','self.duration(map, a, b, straits)?.to_bits()')
idx=s.index('#[derive(Clone, Debug, Eq, PartialEq, Serialize)]\npub struct Movement')
s=s[:idx]+'''fn route_usable(map:&MapData,a:ProvinceId,b:ProvinceId,explicit_straits:bool)->bool {
    usable(map,a,b) || explicit_straits && land(map,a)&&land(map,b)&&map.edge(a.0,b.0).is_some_and(|e|e.kind==EdgeKind::Strait)
}
''' +s[idx:]
s=s.replace('''pub struct Movement {
    pub(crate) units: Vec<Unit>,
}''','''pub struct Movement {
    pub(crate) units: Vec<Unit>,
    #[serde(skip_serializing_if="Option::is_none")]
    pub(crate) straits: Option<BTreeMap<DivisionId,DirectedStraits>>,
}''')
s=s.replace('let m = Self { units };','let m = Self { units, straits:None };',1)
idx=s.index('    pub(crate) fn validate(&self, world: &World)')
s=s[:idx]+'''    /// Trusted, explicit crossing authority. Legacy constructors keep v2 policy.
    pub fn with_straits(world:&World,inputs:Vec<UnitInput>,contexts:Vec<StraitInput>)->Result<Self,MovementError>{
        let mut movement=Self::new(world,inputs)?;
        let mut straits=BTreeMap::new();
        for context in contexts {
            if straits.insert(context.unit,context.corrections).is_some(){return Err(MovementError::DuplicateUnit);}
        }
        movement.straits=Some(straits);movement.validate(world)?;Ok(movement)
    }
    pub fn has_strait_context(&self)->bool {self.straits.is_some()}
    pub fn strait_context(&self,id:DivisionId)->Option<&DirectedStraits> {self.straits.as_ref()?.get(&id)}
''' +s[idx:]
s=s.replace('''        for u in &self.units {
            u.validate(world)?;
        }''','''        if let Some(straits)=&self.straits {
            if straits.keys().copied().ne(self.units.iter().map(|u|u.id)){return Err(MovementError::MissingContext);}
            for u in &self.units {
                for (&(from,to),context) in &straits[&u.id] {
                    if !land(world.defs().map(),from)||!land(world.defs().map(),to)||!u.allowed.contains(&from)||!u.allowed.contains(&to){return Err(MovementError::InvalidReference);}
                    let edge=world.defs().map().edge(from.0,to.0).ok_or(MovementError::InvalidReference)?;
                    if context.kind!=CrossingKind::Strait||edge.kind!=EdgeKind::Strait||u.corrections.contains_key(&(from,to)){return Err(MovementError::InvalidKind);}
                    context.factors.validate()?;
                }
            }
        }
        for u in &self.units {u.validate(world,self.strait_context(u.id))?;}''',1)
s=s.replace('u.path(world.defs().map(), u.province, destination)?','u.path(world.defs().map(), u.province, destination, self.strait_context(id))?')
s=s.replace('u.path(world.defs().map(), start, end)?','u.path(world.defs().map(), start, end, self.strait_context(id))?')
p.write_text(s)
p=Path('crates/oh_sim/src/formula.rs');s=p.read_text();s+='''
/// Strait uses its own final time slot. No river factor participates.
pub fn strait_hours(distance:Fx,speed:Fx,factors:crate::movement::StraitFactors)->Result<Fx,crate::movement::MovementError>{
    use crate::movement::MovementError;
    if distance<=Fx::ZERO||speed<=Fx::ZERO{return Err(MovementError::InvalidValue);}
    factors.validate()?;
    let mut value=distance.checked_div(speed).ok_or(MovementError::Overflow)?;
    for factor in [factors.terrain,factors.infrastructure,factors.supply,factors.strait]{value=value.checked_mul(factor).ok_or(MovementError::Overflow)?;}
    if value<=Fx::ZERO{return Err(MovementError::InvalidValue);}Ok(value)
}
''';p.write_text(s)
p=Path('crates/oh_sim/src/save_state.rs');s=p.read_text().replace('let movement = Movement { units };','let movement = Movement { units, straits:None };');p.write_text(s)
