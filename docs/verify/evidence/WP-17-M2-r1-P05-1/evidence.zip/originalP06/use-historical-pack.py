from pathlib import Path
p=Path('crates/oh_save/tests/strait.rs');s=p.read_text();s='#[path="support/strait_pack.rs"]\nmod historical;\n'+s;s=s.replace('''fn frozen_97f_v2_reader_writer_hash_dto_native_contract_unchanged() {
    let c = context();''','''fn frozen_97f_v2_reader_writer_hash_dto_native_contract_unchanged() {
    let c = historical::context();''',1);p.write_text(s)
