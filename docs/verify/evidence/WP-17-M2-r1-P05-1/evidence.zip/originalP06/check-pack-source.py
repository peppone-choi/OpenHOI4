from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();prefix='data/packs/testland/'
head='97f688718dabed46bc477fa249798ac09e999581'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','data/packs/testland'],text=True).splitlines();records=[]
for name in paths:
 raw=subprocess.check_output(['git','show',head+':'+name]);disk=(root/name).read_bytes();assert raw==disk,name
 records.append({'path':name.removeprefix(prefix),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
record={'source':head,'files':records,'count':len(records),'all_match_source_and_current_branch':True}
(root/'target/evidence/WP-17-P06/original-pack-source97f.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps({'source':head,'count':len(records),'all_match':True}))
