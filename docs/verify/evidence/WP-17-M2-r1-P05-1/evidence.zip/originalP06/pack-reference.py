from pathlib import Path
import importlib.util,json
root=Path.cwd();spec=importlib.util.spec_from_file_location('save_reference',root/'crates/oh_save/tools/save_reference.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
value=m.pack_hash(root/'data/packs/testland');p=root/'target/evidence/WP-17-P06/original-pack-source97f.json';r=json.loads(p.read_text(encoding='utf-8'));r['pack_hash_independent_integer_oracle']=value;p.write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps({'original_pack_hash':value}))
