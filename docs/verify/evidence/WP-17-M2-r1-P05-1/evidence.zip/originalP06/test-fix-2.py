from pathlib import Path
p=Path('crates/oh_save/tests/strait.rs');s=p.read_text().replace('|d|d.straits[0].corrections.push(d.straits[0].corrections[0].clone()),','|d|{let c=d.straits[0].corrections[0].clone();d.straits[0].corrections.push(c);},');p.write_text(s)
