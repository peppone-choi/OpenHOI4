from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();m=root/'target/evidence/WP-17/SHA256-MANIFEST.json';original=m.read_bytes();data=json.loads(original);bad=[]
for e in data['evidence']:
 p=m.parent/e['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest()
 if actual!=e['sha256'] or p.stat().st_size!=e['bytes']:bad.append(e['path'])
assert not bad,bad
record={'original_head':data['head'],'original_manifest_sha256':hashlib.sha256(original).hexdigest(),'files':len(data['evidence']),'all_unchanged':True,'fixture_save_sha256':hashlib.sha256((root/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave').read_bytes()).hexdigest(),'fixture_expected_sha256':hashlib.sha256((root/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json').read_bytes()).hexdigest()}
(root/'target/evidence/WP-17-P06/original97f-audit.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
assert subprocess.check_output(['git','show','97f6887:assets/ASSETS.toml'])==(root/'assets/ASSETS.toml').read_bytes().split(b'# Frozen source97f raw v2 movement producer output')[0].rstrip()+b'\n'
print('ASSETS original entries byte-preserved; only two authorized append records')
