from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path.cwd();out=root/'target/evidence/WP-17-P06';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for label,example,filename,pack in [('current-v2','movement_fixture','movement-v2.ohsave',root/'data/packs/testland'),('current-v3','strait_fixture','strait-v3.ohsave',root/'data/packs/testland')]:
 exe=root/'target/debug/examples'/f'{example}.exe';records=[];reports=[]
 args=[['capture',str(out/f'exact-{label}-1')],['capture',str(out/f'exact-{label}-2')],['resume',str(pack),str(out/f'exact-{label}-1'/filename)]]
 for i,tail in enumerate(args,1):
  digest=sha(exe);p=subprocess.Popen([str(exe),*tail],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8');stdout,stderr=p.communicate();assert p.returncode==0;assert sha(exe)==digest
  (out/f'exact-{label}-{i}.stdout.json').write_text(stdout,encoding='utf-8');(out/f'exact-{label}-{i}.stderr.log').write_text(stderr,encoding='utf-8');records.append({'command':[str(exe),*tail],'pid':p.pid,'exit':p.returncode,'exe_sha256':digest});reports.append(json.loads(stdout))
 assert reports[0]==reports[1]==reports[2]
 saved=out/f'exact-{label}-1'/filename;assert saved.read_bytes()==(out/f'exact-{label}-2'/filename).read_bytes()
 result={'kind':label,'runs':records,'split_hash':reports[0]['split']['hash'],'continuous_hash':reports[0]['continuous']['hash'],'save_sha256':sha(saved),'dto_canonical_hash_equal':True};results.append(result)
 if label=='current-v2':assert saved.read_bytes()==(root/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave').read_bytes()
 else:
  assert reports[0]['split']['dto']['base']['units'][0]['elapsed']==38654705664;assert reports[0]['split']['dto']['straits'][0]['corrections'][0]['kind']==3;assert reports[0]['arrival']['dto']['base']['units'][0]['province']==40;assert reports[0]['arrival']['dto']['base']['units'][0]['route']==[];assert reports[0]['arrival']['dto']['base']['units'][0]['elapsed']==0;result['arrival_hash']=reports[0]['arrival']['hash']
exe=root/'target/debug/examples/movement_fixture.exe';pack=root/'crates/oh_save/tests/fixtures/movement-pack-97f';saved=root/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave';args=[str(exe),'resume',str(pack),str(saved)];p=subprocess.Popen(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8');stdout,stderr=p.communicate();assert p.returncode==0;expected=json.loads((root/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json').read_text(encoding='utf-8'));assert json.loads(stdout)==expected
(out/'exact-historical-v2.stdout.json').write_text(stdout,encoding='utf-8');(out/'exact-historical-v2.stderr.log').write_text(stderr,encoding='utf-8');results.append({'kind':'historical-v2-source97f','command':args,'pid':p.pid,'exit':p.returncode,'exe_sha256':sha(exe),'original_save_sha256':sha(saved),'original_expected_sha256':sha(root/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json'),'pack_hash':13318001328374612931,'dto_canonical_hash_equal':True})
result={'head':head,'dirty':False,'platform':'Windows','cwd':str(root),'checked_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),'groups':results};(out/'exact-native-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
