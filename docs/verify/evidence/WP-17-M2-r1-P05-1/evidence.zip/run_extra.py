from run_commands import *
run('independent-pending-route-probe',[C,'test','--offline','--manifest-path',str(E/'probe/Cargo.toml'),'--lib','independent_pending_key_unit_destination_and_active_route_resume','--','--exact','--nocapture'])
run('clippy-all-targets',[C,'clippy','--workspace','--all-targets','--','-D','warnings'])
