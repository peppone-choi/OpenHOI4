from run_commands import *
import shutil,hashlib,re
source='b6516ed';HEAD='7f8cb7635ad10beb815503ca5a8137da0500faa3'
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(W),*args],cwd=W,env=env)
def sha(b):return hashlib.sha256(b).hexdigest()
protected=['Cargo.toml','Cargo.lock','client','crates/oh_proto','crates/oh_server','crates/oh_cli','crates/oh_data','data/packs','tests/golden','crates/oh_save/tests/contracts.rs','crates/oh_save/tests/fixtures/m1-v1.ohsave','crates/oh_save/tests/fixtures/m1-v1.expected.json','crates/oh_save/tests/support/copy.rs','crates/oh_save/tests/support/mod.rs','crates/oh_save/examples/save_fixture.rs','.github','deny.toml','AGENTS.md']
assert git('diff','--name-only',source,HEAD,'--',*protected)==b''
old=git('show',source+':assets/ASSETS.toml');current=(W/'assets/ASSETS.toml').read_bytes();assert current.startswith(old)
sourcefiles=[]
for folder in ['crates/oh_sim/src','crates/oh_sim/tests','crates/oh_save/src','crates/oh_save/tests','crates/oh_save/examples']:
 for p in (W/folder).rglob('*.rs'):
  raw=p.read_bytes();dest=E/'source-review'/p.relative_to(W);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);sourcefiles.append({'path':p.relative_to(W).as_posix(),'bytes':len(raw),'sha256':sha(raw)})
for file in ['AGENTS.md','docs/03-production-prompts.md','docs/templates/VERIFY_REPORT_TEMPLATE.md','docs/plans/WP-17-schema.md','docs/worklog/WP-17.md','docs/adr/ADR-1701-movement.md','docs/adr/ADR-1702-strait-save.md','assets/ASSETS.toml','Cargo.toml','Cargo.lock','deny.toml','tools/check_architecture.py','tools/check_docs.py','tools/check_assets.py','crates/oh_save/tools/save_reference.py']:
 dest=E/'source-review'/file;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/file,dest)
planning=json.loads((E/'planning/identity.json').read_text(encoding='utf-8'));plan=[]
for item in planning['files']:
 file=pathlib.Path(item['copy']);assert sha(file.read_bytes())==item['sha256'];plan.append({'source':item['source'],'sha256':sha(file.read_bytes()),'bytes':file.stat().st_size})
(E/'implementation-scope.diff').write_bytes(git('diff','--binary',source,HEAD));(E/'original-to-final.diff').write_bytes(git('diff','--binary','97f688718dabed46bc477fa249798ac09e999581',HEAD))
tests=[]
for file in ['crates/oh_sim/tests/movement.rs','crates/oh_sim/tests/strait.rs','crates/oh_save/tests/movement.rs','crates/oh_save/tests/strait.rs']:
 for i,line in enumerate((W/file).read_text().splitlines(),1):
  m=re.match(r'fn (\w+)\(',line)
  if m and i>1 and (W/file).read_text().splitlines()[i-2]=='#[test]':tests.append({'file':file,'line':i,'test':m[1]})
# Additional original P06 evidence is read-only; preserve every manifest member.
orig=W.parent/'WP-17-M2-r1/target/evidence/WP-17-P06';manifest=json.loads((orig/'SHA256-MANIFEST.json').read_text());p06=[]
for item in manifest['evidence']:
 raw=(orig/item['path']).read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256'];dest=E/'originalP06'/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);p06.append(item)
shutil.copyfile(orig/'SHA256-MANIFEST.json',E/'originalP06/SHA256-MANIFEST.json')
out={'exact_head':HEAD,'source_base':source,'protected_paths_unchanged':protected,'asset_original_prefix_unchanged':True,'latest_planning_head':planning['main_documentation_head'],'planning_copy_manifest_matches':plan,'reviewed_source':sourcefiles,'requirement_tests':tests,'originalP06_manifest_members':len(p06),'originalP06_member_bytes_sha_all_equal':True,'client_changed':False,'public_wire_changed':False,'new_dependencies':False}
(E/'source-scope-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'test_count':len(tests),'originalP06_member_count':len(p06),'protected_paths_unchanged':True,'planning_copy_SHA_all_equal':True}))
