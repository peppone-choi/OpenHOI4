from run_commands import *
for label,args in [
 ('v1-native',[P,'crates/oh_save/tools/check_save_determinism.py','capture','--out',str(E/'v1-native')]),
 ('m0-1000',[P,'crates/oh_sim/tools/check_sim_determinism.py','capture','--out',str(E/'m0-1000')]),
 ('m1-1000',[P,'crates/oh_sim/tools/check_sim_determinism.py','capture','--m1','--out',str(E/'m1-1000')]),
 ('movement-build',[C,'build','-p','oh_save','--example','movement_fixture','--example','strait_fixture'])]:run(label,args)
for kind,name in [('v2','movement'),('v3','strait')]:
 executable=str(W/'target/debug/examples'/ (name+'_fixture.exe'))
 for i in [1,2]:run(kind+'-capture-'+str(i),[executable,'capture',str(E/(kind+'-capture-'+str(i)))])
 run(kind+'-resume',[executable,'resume',str(W/'data/packs/testland'),str(E/(kind+'-capture-1')/(name+'-'+kind+'.ohsave'))])
run('v2-historical-resume',[str(W/'target/debug/examples/movement_fixture.exe'),'resume',str(W/'crates/oh_save/tests/fixtures/movement-pack-97f'),str(W/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave')])
