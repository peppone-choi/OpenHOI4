from run_commands import *
run('independent-native-audit',[P,str(E/'native_audit.py')])
