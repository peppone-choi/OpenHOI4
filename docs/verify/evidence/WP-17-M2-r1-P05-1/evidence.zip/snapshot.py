import argparse, pathlib, subprocess, hashlib, json, os, sys
p=argparse.ArgumentParser();p.add_argument('worktree');p.add_argument('out');p.add_argument('--compare');a=p.parse_args()
w=pathlib.Path(a.worktree).resolve();out=pathlib.Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);jp=pathlib.Path(str(out)+'.json');bp=pathlib.Path(str(out)+'.index')
if jp.exists() or bp.exists():raise SystemExit('refusing to overwrite original snapshot')
env=dict(os.environ);env['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(w),*args],env=env)
def value(*args):return git(*args).decode('utf-8')
paths=value('ls-files','-z').split('\0');ip=pathlib.Path(value('rev-parse','--git-path','index').strip());ip=ip if ip.is_absolute() else w/ip
raw=ip.read_bytes();snap={'worktree':str(w),'head':value('rev-parse','HEAD').strip(),'index':value('ls-files','--stage','-z'),'raw_index_sha256':hashlib.sha256(raw).hexdigest(),'tracked_list':paths,'status':value('status','--porcelain=v1','--untracked-files=no'),'diff':value('diff','--binary'),'cached_diff':value('diff','--cached','--binary'),'files':[[s,hashlib.sha256((w/s).read_bytes()).hexdigest() if (w/s).is_file() else None] for s in paths if s]}
jp.write_text(json.dumps(snap,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');bp.write_bytes(raw)
result={'head':snap['head'],'tracked_count':len(snap['files']),'clean':not any(snap[k] for k in ['status','diff','cached_diff']),'raw_index_sha256':snap['raw_index_sha256'],'snapshot':str(jp)}
if a.compare:
 b=pathlib.Path(a.compare);before=json.loads(pathlib.Path(str(b)+'.json').read_text(encoding='utf-8'));result['identical']=snap==before;result['raw_bytes_identical']=raw==pathlib.Path(str(b)+'.index').read_bytes();result['differences']=[k for k in snap if snap[k]!=before.get(k)]
print(json.dumps(result,ensure_ascii=False));sys.exit(0 if result['clean'] and result.get('identical',True) and result.get('raw_bytes_identical',True) else 4)
