from run_commands import *
run('source-scope-audit',[P,str(E/'source_audit.py')])
run('final-diff-check',['git','--no-optional-locks','-C',str(W),'diff','--check'])
