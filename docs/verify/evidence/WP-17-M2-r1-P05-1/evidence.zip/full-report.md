# 검증 리포트 — WP-17 (M2-r1 P-05, 시도 1)

| 항목 | 값 |
|---|---|
| 판정 | **PASS — exact WP-17 / REQ-MIL-04 범위** |
| 검증자 | Codex 독립 검증 앱 세션, 구현 비참여, 새 세션, 추적 파일·index 무변경 |
| 브랜치·커밋 | detached `7f8cb7635ad10beb815503ca5a8137da0500faa3`; 구현 브랜치 `codex/wp17-movement-m2r1` |
| 검증 일시 | 2026-10-07, Asia/Seoul |
| 전용 worktree | `E:/openhoi/.orchestrator/wt/WP-17-M2-r1-verify1` |
| 제품 기준 / 최신 기획 | 제품은 위 exact HEAD. 최신 기획 사본은 main `94aba66867adf01e86848b0d15fced5e32d266f2`; `planning/identity.json` 전수 SHA 일치 |
| 증거 루트 | `E:/openhoi/.orchestrator/wt/WP-17-M2-r1-verify1/target/evidence/WP-17-M2-r1-P05-1` |

## 직접 실행한 명령

모든 shell cwd는 전용 worktree다. Cargo는 실제 존재하는 `C:/Users/user/.cargo/bin/cargo.exe`를 사용했고, subprocess의 `GIT_OPTIONAL_LOCKS=0`, `CARGO_TARGET_DIR=<전용 worktree>/target`, PATH의 Cargo prefix를 적용했다. 설정·권한·네트워크 정책 변경은 없다. 원 argv/cwd/env/PID/start/end/native exit/stdout/stderr는 `command-results.json`과 각 동명 `.stdout`/`.stderr`에 있다. 아래 cargo/python은 그 절대 실행파일의 축약이다.

| 명령 | 종료 코드 | 결과 요약 |
|---|---|---|
| cargo --version / node --version | 각 0 | 설치 실행파일 직접 확인, Cargo 1.99.0 |
| npm.cmd --prefix client ci / run build | 각 0 | 자기 client/dist 준비 성공. 최초 준비 실패 없음 |
| cargo fmt --check | 0 | 통과 |
| cargo clippy --workspace -- -D warnings | 0 | 통과 |
| cargo clippy --workspace --all-targets -- -D warnings | 0 | tests/examples 포함 통과 |
| cargo test --workspace | 0 | 142 PASS, 0 FAIL/ignored; WP-17 movement/strait 33개 포함, private authority compile_fail 통과 |
| cargo run --quiet -p oh_cli -- run --scenario testland --days 365 --seed 1 --hash-out | 두 회 각 0 | M0 `b039d35666b77fc2` 동일 |
| cargo run --quiet -p oh_cli -- run --pack data/packs/testland --scenario m1 --days 365 --seed 1 --hash-out | 두 회 각 0 | actual M1 `b595dc2a1e5b4f8c` 동일 |
| python crates/oh_sim/tools/check_sim_determinism.py capture --out <증거>/m0-1000; 위 명령 --m1 --out <증거>/m1-1000 | 각 0 | 실제 1,000틱 두 회씩: M0 `ff921fd8148e699d`, M1 `60448355cecffa9d` |
| python crates/oh_save/tools/check_save_determinism.py capture --out <증거>/v1-native | 0 | v1 fresh native 두 capture·두 restart·CLI resume, 원 fixture/SHA/full structure 유지, clean exact HEAD |
| cargo build -p oh_save --example movement_fixture --example strait_fixture | 0 | 자기 target의 실제 executable 생성 |
| target/debug/examples/movement_fixture.exe capture <증거>/v2-capture-1 및 -2; resume data/packs/testland <capture1>/movement-v2.ohsave | 세 실행 각 0 | 서로 다른 native PID, v2 savebytes/full DTO/canonical/hash 및 continuous 결과 동일 |
| target/debug/examples/strait_fixture.exe capture <증거>/v3-capture-1 및 -2; resume data/packs/testland <capture1>/strait-v3.ohsave | 세 실행 각 0 | 서로 다른 native PID, split/arrival/final 전체 일치 |
| movement_fixture.exe resume crates/oh_save/tests/fixtures/movement-pack-97f crates/oh_save/tests/fixtures/movement-v2-97f.ohsave | 0 | 원97f v2를 역사 context로 fresh native 재개, 원 expected 전문과 일치 |
| cargo test --offline --manifest-path <증거>/probe/Cargo.toml -- --nocapture | 0 | 최초 독립 probe 7개 통과 |
| 위 test --lib independent_pending_key_unit_destination_and_active_route_resume -- --exact --nocapture | 0 | 추가 예약 key/unit/destination·route/progress 왕복 검사 통과, 독립 검사 총 8개 |
| 위 test --test original_movement_mutant req_mil_04_direct_command_actual_phase_and_fractional_carry -- --exact | **101, 의도한 negative** | scratch 입력 speed2→3만 변경; 원 expected 단언이 실제 ProvinceId20≠10으로 실패. tracked source/expected 무변경 |
| python <증거>/native_audit.py | 0 | 독립 정수 Postcard/FNV 기준으로 native 전체 canonical/hash 검사, 원217 evidence·Git97f pack19·동결 DTO/fixture 전수 대조 |
| python <증거>/source_audit.py | 0 | 원 P06 evidence234·기획 사본·소스·보호 경로·asset 원 prefix 보존 |
| python tools/check_docs.py / tools/check_assets.py / tools/check_architecture.py | 각 0 | docs 오류0/경고0, assets 오류0, architecture 통과; sim source도 직접 확인 |
| cargo deny check licenses bans advisories sources / npm.cmd --prefix client run licenses | 각 0 | 허용 라이선스 검사 통과. cargo-deny의 미사용 allowance/중복 의존성 warning은 원문 보존 |
| cargo run --quiet -p oh_cli -- --help | 0 | exact CLI 제공 범위 확인 |
| cargo run --quiet -p oh_cli -- validate --deny-warnings data/packs/testland | **1, 미제공 경계** | usage: `validate, ai-bench and repro belong to later work packages`; WP-24/25 통합 전 명령 부재. 실행 성공으로 기록하지 않음 |
| git --no-optional-locks -C <전용 worktree> diff --check | 0 | 통과 |
| snapshot.py verifier-before --compare parent-before / verifier-after --compare parent-before | 각 0 | HEAD·전수 tracked SHA·목록·semantic/raw index·status/diff/cached 완전 동일 |

client/oh_proto/public wire는 원 `b6516ed` 대비 변경이 없으므로 client unit/typecheck 별도 명령·generated TS 재생성·신규 malformed protocol/UI 촬영은 조건부 대상이 아니다. 기존 Rust protocol 회귀는 workspace에서 실행했다. 실제 client build는 수행했다. UI WP, ai-bench/repro, 세 OS 비교, 기본 브랜치 CI는 이번 검증 완료 증거로 주장하지 않는다.

초기 읽기 도구의 PowerShell brace path 문법은 실행 전 ParserError였고 재발행했다. 1,000틱 capture에 `result.json`이 있다고 추정한 Get-Content는 파일 부재였다. 실제 producer 파일은 `run-1.txt`, `run-2.txt`, `sim-hash.txt`이며 모두 보존했다. 이 읽기 오류를 테스트 실패·성공 또는 producer 산출물로 가장하지 않았다. 직접 검증 명령의 원문은 별도 로그로 보존했고 초기 읽기 기록은 앱 도구 기록 및 `verification-summary.json`에 구분했다.

## REQ별 확인

| REQ / 계약 | 검사하는 테스트 | 실제 검사 여부 | 결과 |
|---|---|---|---|
| REQ-MIL-04 직접 경로·시간 | `req_mil_04_direct_command_actual_phase_and_fractional_carry`, `req_mil_04_path_golden_tie_full_id_order_and_tick_carry`, `req_mil_04_formula_order_exact_floor_missing_define_no_defaults` | actual ordered queue→Commands→Movement; 별도 i128/Python 기준. 거리10/속도2×1.5=7.5h, 7/8/15틱, 8틱의 다음 leg0.5h, lexical 최단 경로·비연속 ID·동일 위치 빈 route | PASS |
| REQ-MIL-04 참조/범위/접근 | `req_mil_04_water_impassable_strait_missing_and_overflow_reject_atomically`, `req_mil_04_context_references_speed_duplicate_and_missing_context`, `movement_zero_typed_ids_are_not_dense_indices` | 물/호수/고립/impassable/None-mode strait, foreign owner, 미존재·중복·허용 누락·missing coefficient·0/음수·overflow/positive-underflow. zero typed ID를 배열 index로 쓰지 않음 | PASS |
| REQUEST-0006 A | `req_mil_04_mid_edge_stop_reroute_preserves_leg_and_elapsed`, `req_mil_04_zero_elapsed_stop_and_back_to_origin_no_teleport`, 독립 clock probe | elapsed0 즉시 Stop/reroute; >0 진행 leg 보존, 끝점부터 경로 재검사; invalid enqueue 보존; Stop8틱 도착 후 elapsed0/budget discard, reroute0.5h carry; pause/speed5도 한 시간 진행 | PASS |
| 예정 의미 오류 / phase 원자성 | `req_mil_04_scheduled_rejection_consumes_only_due_commands`, `req_mil_04_phase_error_preserves_movement_queue_and_clock` 및 strait 대응 두 테스트 | 예정 오류는 due 명령 거부/소비+clock 성공. ledger overflow phase 오류는 movement/context/state/clock/queue 전부 보존. clone commit 소스 직접 대조 | PASS |
| REQUEST-0007 A 해협 | `req_mil_04_strait_explicit_slot_9_10_tick_boundary`, `req_mil_04_strait_alternate8_and_equal10_path_lexical`, `req_mil_04_strait_formula_raw_oracle_and_no_river_slot`, `req_mil_04_strait_defines_separate_slot_no_fallback_and_identity_hash` | actual land-land Strait, allowed 양끝점, 방향 context 및 kind. 독립10h=42949672960raw, tick9=38654705664raw/tick10 도착; 정상 대체8h/동점 lexical; river7과 strait2 중복곱 없음 | PASS |
| 해협 오류/정렬/권위 | `req_mil_04_strait_invalid_kind_refs_allowed_values_and_duplicate_slots`, `req_mil_04_strait_missing_direction_overflow_underflow_and_authority_atomic`, `req_mil_04_strait_noncontiguous_zero_unit_order_is_canonical` | missing reverse/0/음수/underflow/overflow/kind/ref/nonland/타국 거부, 중복 context 및 별도 slot, ID0/비연속·입력 순서에 canonical 불변 | PASS |
| 신규 권위 hash/save | `req_mil_04_new_authority_and_pending_command_hash_sensitivity`, 독립 every_authority 및 pending-route probe | id/nation/position/speed/allowed/directed corrections/각4 factor·route/progress·Move/Stop·pending tick/sequence/unit/destination를 바꾸면 canonical/hash 변화. valid 각 상태 v2 save/restore와 exact resume 검사 | PASS |
| v2 reader/writer·불량 입력 | movement save6개, `v2_untrusted_reference_progress_context_and_queue_preserve_live`, `v2_new_queue_limit_and_oversized_unit_vector_preflight`, 독립 wire probe | 참조/elapsed MIN·cost bit·순서/중복·queue/past·헤더/버전·bounded allocation·oversized vector·hash tamper·trailing 거부 | PASS |
| v3 선택/불량 입력 | `v3_kind_direction_context_raw_bits_and_idle_empty_version_selection`, `v3_context_vector_and_kind_preflight_and_unknown_version`, `v3_malformed_context_route_queue_failure_preserves_live`, 독립 v3/wire probe | Some empty units/directions·idle/newpending도 v3. raw kind3·[terrain,infra,supply,strait] bits 및 ordered refs 보존. wrongkind0/1/2/255, missing/duplicate/unsorted/ref/양수 범위·예산/collection limit·unknown4/65535·trailing/hash mutation 거부 | PASS |
| 원 v1/v2 호환 | `frozen_97f_v2_reader_writer_hash_dto_native_contract_unchanged`, `original_v2_refuses_changed_pack_without_force_and_current_v3_roundtrips`, native audit | 원 v1 fresh bytes/SHA, 원97f v2 DTO/reader/writer/canonical/native 전체 유지. 원19 pack Git bytes/SHA/hash 일치. known changed pack은 PackMismatch, current 신규 v3는 자기 context로 성공; force/expected/header 변경 없음 | PASS |
| 새 저장 재개 | `movement_v2_mid_edge_pending_pause_and_exact_resume`, `strait_v3_tick9_full_context_pending_and_resume`, `v3_request6_stop_pause_reroute_pending_restore_boundary`, native 두capture+fresh resume | 중간 edge/context/모든 pending/paused 전체 구조 복원; 종류별 canonical independent 기준, 정상 재개와 continuous 완전 동일 | PASS |

정확 파일·테스트명·line 매핑 33개는 `source-scope-audit.json`에 있다. 실행되지 않는 선언이나 항상 통과하는 marker만으로 판정하지 않았다. original assertion negative가 입력 변조를 실제 검출했다.

### 필드·관계·후속 범위

schema/ADR-1701/1702와 소스의 의미·단위·형·범위·null/default·참조·수명·권위를 대조했다. 불변 Defs.MapData/정의 계수와 trusted 초기 UnitInput/context, 가변 province/route/elapsed, 파생 경로 탐색을 구분한다. Unit ID u32, nation/province u16은 zero와 비연속을 허용한다. speed는 양수 Fx km/h, distance km, route/progress hour, 시간계수는 양수 무차원 Fx I32F32다. required 입력에 neutral fallback을 추가하지 않았다.

Unit/context는 서버 초기 생성에서만 설정하고 unit/Simulation 수명을 따른다. state mutator는 Commands/Movement뿐이며 read-only Unit/private field 컴파일 거부가 있다. 관계는 unit→nation, position/allowed/correction/route→실제 land/adjacency이고 순서·중복·미존재·kind는 생성/복원 경계에서 검사한다. 지도 순환은 허용하되 shortest path는 양수 cost와 경로 내 중복 정점 제외/ID lexical이다. v3 straits unit 집합은 unit 집합과 정확히 같고 direction/kind/raw가 저장된다.

None movement는 legacy v1, Some movement/None straits는 v2, Some explicit straits는 빈 상태도 v3다. 신규 상태의 v1 export와 explicit straits의 v2 export는 손실 방지 오류다. 지원되는 원 v1/v2를 거부하거나 migration하지 않는다. 모든 벡터는 deserialize 전 기존 Limits/entry allocation charge로 검사한다. restore는 local original pack/definitions/effective defines identity와 실제 route formula bits를 대조한다.

실제 WP16 unit/template 생성, WP14/19/20 infra/supply/access 갱신, public wire/server 조작 및 WP22 UI는 후속이다. 클라이언트가 speed/factors/allowed를 지정하는 경로는 없다. 함대/봉쇄/해역통제/항구수송/통행권/진행중 allowed 변경의 게임 효과를 만들지 않았다. 이 PASS는 완전 군사·UI/전체 M2 완료가 아니다.

## 결정론

- M0 365일 해시 1/2: `b039d35666b77fc2` / `b039d35666b77fc2`.
- actual M1 365일 해시 1/2: `b595dc2a1e5b4f8c` / `b595dc2a1e5b4f8c`.
- 실제 1,000틱 두회씩: M0 `ff921fd8148e699d`, M1 `60448355cecffa9d`.
- 원 v1 split→resume: `4eb703aad086c7aa` → `d19d028857bb7485`; fixture SHA256 `57b13c62ef1a6f88ade1851d0b3ae398157f95ca5bc246068eac3b2a964322fa`. mutable 역사 pack hash `12861016185528173627`.
- 원/current v2 split→final: `18bff036731f4f26` → `a145b72ad0ad25e6`; 374바이트 SHA256 `d3706ae77d226ad480ce24e018137de6898bd45b0bd6dbb203b1a4a4c6c9df0f`; expected JSON SHA256 `7692909bda6561a262df05a93e0ef5797bf65b8a414930790a0b710c817bed81`.
- v3 split→arrival→final: `84462b78cc1a0f5d` → `d2c3248b5eca4b8d` → `299a80d49c17f3ec`; 363바이트 SHA256 `de7ac4afd0c2638716e353dedcfa18c6c56cf7dda8373614a91dd221b51c4814`.
- 저장 후 재개: 세 형식 모두 실제 fresh native process로 확인. v2/v3 두capture/restart는 전체 DTO/canonical/hash 및 위치/route/elapsed/pending 일치, 별도 Python Postcard/FNV/ledger 계산도 일치. historical19 원pack hash는 `13318001328374612931`이며 mutable v1 identity와 구분했다.
- Windows exact HEAD 증거다. Linux/macOS 또는 main CI의 성공으로 확대하지 않는다.

## 금지 사항 점검

| 항목 | 결과 |
|---|---|
| 시뮬레이션의 f32/f64 | PASS. movement/formula/lib/save_state/world/time/ledger 실제 소스 및 검색; Fx만 사용 |
| HashMap 순회 | PASS. ID sorted Vec/BTreeMap/BTreeSet, ordered heap와 전체 path tie |
| thread_rng / SystemTime / I/O | PASS. sim source에 없음, 새 RNG 없음. host fixture/save I/O와 분리 |
| 코드 내 수치 리터럴 | PASS. 1h budget은 명세, enum/version/컬렉션·byte 경계는 기술값. 새 게임 계수는 명시 context/Defines; 합성값은 tests/native evidence 입력 |
| 미결정 규칙 구현 | PASS. REQUEST0006/0007 한정 잠정만 구현. 새로운 보급/접근/해군 정책 없음, D/OPEN 확정 변경 없음 |
| 골든 기대값 변경 근거 | PASS. 기존 tests/golden/v1 save/expected/원 tests 및 helper 보호 경로 불변. 원 v2 fixture는 원97f native byte 그대로 추가 |
| 클린룸 | PASS. 원작 자료를 가져온 변경 없음. 신규 합성 및 own Git 역사 source만 사용 |
| 클라이언트 규칙 계산 | PASS. client/public protocol source 불변; trusted context의 client 변경 입력 없음 |
| 의존성·에셋 | PASS. Cargo.toml/lock/dependency unchanged; cargo-deny/npm licenses/assets 통과, 기존 ASSETS prefix와 승인된 추가행 분리 |
| 설정 우회·추적 변경 | PASS. 보호 설정/CI 불변; tracked/index 수정·commit·복구·새 세션·main/구현 worktree write 없음 |

관련 설치 crate의 버전 존재/기술 문서는 공식 [fixed 1.31.0](https://docs.rs/fixed/1.31.0/fixed/), [postcard 1.1.3](https://docs.rs/postcard/1.1.3/postcard/), [zstd 0.13.3](https://docs.rs/zstd/0.13.3/zstd/)에서 직접 확인했고 `official-docs-response.json`에 응답을 보존했다. 허용 라이선스 판정은 실제 lock 기반 cargo-deny 및 npm 검사 결과를 따른다.

## 작업 로그 증거와 실제 결과 대조

- `WP-17.md`의 원 red는 movement API 부재 9개 compiler error, mid-edge PendingMidEdgePolicy 실패, 초기 UnsupportedFormat 회귀다. P06 red는 typed Strait/with_straits 및 export_save_v3 부재다. 실제 로그의 실패 원문을 확인했고 원217/P06 234 member bytes/SHA를 모두 보존했다. 구현중 반환형/borrow 실패 및 PATH 미실행 이력을 최종 기능 성공이나 독립 결과로 바꾸지 않았다.
- 최초97f immutable evidence manifest SHA256 `3431718ee2cf92106606f46a2bc7b2ae5d5a6be948cb9b81db87fdb63d39cef0`; 217개 전수 일치. frozen native v2와 JSON은 그 원217의 exact capture와 동일했다. historical19는 실제 `git show 97f...:data/packs/testland/<path>` 원바이트와 전수 SHA/길이/목록/hash가 일치했다.
- 원 v2 DTO 선언 구간은 git97f와 byte 동일. v1 fixture와 기존 legacy helper/expected/golden, data/client/wire/server/CLI/lock/settings는 원 base 대비 불변. P06은 additive v3이며 원 v2 field를 덧붙이거나 river의 의미를 재해석하지 않았다.
- 실제 workspace 33개와 독립 8개 검사, fresh native 결과는 로그 주장과 일치한다. `source-scope-audit.json`, `independent-native-audit.json`, `verification-summary.json`에 필드·원 source·current/historical·관계·실행을 분리했다.
- WP24 기존 server validation FAIL 및 REQUEST0008 역사 로드 정책은 최신 기획의 별도 책임이다. 이 source에는 WP24 새 validator/정책이 통합되지 않았다. 원 M0/v1 지원은 이 HEAD에서 직접 확인했지만 WP24 수정 또는 같은 main CI의 성공으로 대신 기록하지 않는다. future frozen pack으로 역사 input을 자동 교체하지 않았다.
- 미실행: client 변경에 종속된 새 TS/unit/malformed/UI 절차, UI 플레이, ai-bench/repro, Linux/macOS 및 same-main CI. 이유는 source 변경/담당 범위/실행 환경의 경계이며 실행했다고 주장하지 않는다. WP17 대상 REQ에 남은 미검증 기능/결정 필요는 없다. 후속 producer/UI는 관계 원장에 남겼다.

### 불변성 및 원 증거 봉인

parent-before→verifier-before→verifier-after가 같은 HEAD·9,770 tracked 파일 SHA/목록·semantic index·raw index bytes·status/diff/cached다. raw index SHA256 `182b8651813e1cf22211586db52b0cb98eae48e599d3e690109d30f2859549b9`; mismatch 없음, clean true. 최초 parent raw를 덮거나 복구하지 않았다.

`full-report.md`는 ignored evidence copy이며 저장소 `docs/verify/`에는 쓰지 않았다. `SHA256SUMS.json`은 원 로그/새 producer/save/전체 source·snapshot·original evidence의 relative path/bytes/SHA를 전수 기록한다. `evidence.zip`에는 manifest와 모든 manifest member의 실제 bytes를 넣고 ZIP 내부 bytes/SHA를 다시 검사했다. manifest/ZIP 자체 identity는 별도 `ZIP-IDENTITY.json`으로 기록하며 자기 해시 순환을 만들지 않는다. 실제 프로세스 종료 뒤 리포트를 낸다. 앱 종료를 CLI exit0으로 기록하지 않는다.

## FAIL 항목

| # | 재현 명령 | 기대 | 실제 |
|---|---|---|---|
| 없음 — WP17 대상 | 위 직접 실행 명령/33개 원 테스트/8개 독립 검사/native 대조 | REQ-MIL-04 및 승인한 저장·해협 경계 | PASS |
| 범위 밖 미제공 | `oh_cli validate --deny-warnings data/packs/testland` | WP24 통합 뒤 제공할 명령 | 이 exact source에서는 exit1 usage. WP24/25 소유이며 해당 명령 PASS로 기록하지 않음 |
| 의도한 negative | scratch original_movement_mutant의 원 테스트 | speed2→3 변경을 원 단언이 검출 | exit101, ProvinceId20≠10. 제품 FAIL 아님 |
