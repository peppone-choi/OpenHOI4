import pathlib,json,sys
E=pathlib.Path(__file__).resolve().parent; W=E.parents[2]
p=E/'run_commands.py';s=p.read_text(encoding='utf-8-sig');s=s.replace('N=r\'C:/Program Files/nodejs/npm.cmd\'; R=[]','N=r\'C:/Program Files/nodejs/npm.cmd\'; R=json.loads((E/\'command-results.json\').read_text(encoding=\'utf-8\')) if (E/\'command-results.json\').exists() else []');p.write_text(s,encoding='utf-8')
probe=E/'probe';(probe/'src').mkdir(parents=True,exist_ok=True)
manifest='[package]\nname="wp17_independent_probe"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\n'
for name in ['oh_core','oh_data','oh_sim','oh_save']:
 manifest+=name+'={path="'+(W/'crates'/name).as_posix()+'"}\n'
manifest+='serde_json="=1.0.151"\nzstd={version="=0.13.3",default-features=false,features=["no_asm"]}\n'
(probe/'Cargo.toml').write_text(manifest,encoding='utf-8');(probe/'src/lib.rs').write_text('',encoding='utf-8')
