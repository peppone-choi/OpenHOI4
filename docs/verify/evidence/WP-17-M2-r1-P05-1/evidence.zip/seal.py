import pathlib,hashlib,json,zipfile,datetime,os,sys
E=pathlib.Path(__file__).resolve().parent
# Fix only the ignored report's text; product files are untouched.
p=E/'full-report.md';s=p.read_text(encoding='utf-8-sig').replace('保存後再開','저장 후 재개');p.write_text(s,encoding='utf-8')
before=json.loads((E/'parent-before.json').read_text());first=json.loads((E/'verifier-before.json').read_text());after=json.loads((E/'verifier-after.json').read_text());assert before==first==after;assert (E/'parent-before.index').read_bytes()==(E/'verifier-before.index').read_bytes()==(E/'verifier-after.index').read_bytes()
summary=json.loads((E/'command-results.json').read_text());assert all(r['native_exit'] is not None and 'end' in r for r in summary);assert {r['id']:r['native_exit'] for r in summary if r['native_exit']}=={'cli-validate':1,'original-assertion-negative':101}
excluded={'SHA256SUMS.json','evidence.zip','ZIP-IDENTITY.json'}
records=[]
for p in sorted(E.rglob('*')):
 if p.is_file() and p.relative_to(E).as_posix() not in excluded:
  raw=p.read_bytes();records.append({'path':p.relative_to(E).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'head':before['head'],'worktree':before['worktree'],'scope':'exact WP17 P05 attempt1 raw evidence; archives/manifest identity excluded to avoid self hash cycles','files':records};mp=E/'SHA256SUMS.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');z=E/'evidence.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
 for item in records:archive.write(E/item['path'],item['path'])
 archive.write(mp,'SHA256SUMS.json')
with zipfile.ZipFile(z)as archive:
 assert set(archive.namelist())=={r['path'] for r in records}|{'SHA256SUMS.json'};assert archive.testzip() is None
 for item in records:
  raw=archive.read(item['path']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
 assert archive.read('SHA256SUMS.json')==mp.read_bytes()
def identity(p):return {'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
result={'manifest':identity(mp),'zip':identity(z),'archive_member_count':len(records)+1,'all_member_bytes_SHA_verified':True,'all_validation_processes_completed':True,'command_count':len(summary),'raw_index_sha256':before['raw_index_sha256'],'invariance':{'parent_before_equals_verifier_before_equals_after':True,'index_raw_bytes_equal':True,'tracked_count':len(before['files'])},'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_self_hash_cycle':True}
(E/'ZIP-IDENTITY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
