from run_commands import *
import shutil,hashlib,re,copy
sys.path.insert(0,str(W/'crates/oh_save/tools'));import save_reference as ref
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(W),*args],cwd=W,env=env)
O=E/'original97f';O.mkdir(exist_ok=True);original=W.parent/'WP-17-M2-r1/target/evidence/WP-17';m=json.loads((original/'SHA256-MANIFEST.json').read_text(encoding='utf-8'))
assert m['head']=='97f688718dabed46bc477fa249798ac09e999581';original_records=[]
for item in m['evidence']:
 raw=(original/item['path']).read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256'],item['path'];dest=O/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);original_records.append(item)
shutil.copyfile(original/'SHA256-MANIFEST.json',O/'SHA256-MANIFEST.json')
source=m['head'];pack=W/'crates/oh_save/tests/fixtures/movement-pack-97f';pm=json.loads((pack.parent/'movement-pack-97f.source.json').read_text(encoding='utf-8'));expected_paths=git('ls-tree','-r','--name-only',source,'--','data/packs/testland').decode().splitlines();actual_paths=sorted(p.relative_to(pack).as_posix() for p in pack.rglob('*') if p.is_file());assert actual_paths==sorted(p.removeprefix('data/packs/testland/') for p in expected_paths)
records=[]
for item in pm['files']:
 raw=git('show',source+':data/packs/testland/'+item['path']);actual=(pack/item['path']).read_bytes();assert raw==actual and sha(actual)==item['sha256'] and len(actual)==item['bytes'];dest=E/'git97f-pack'/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);records.append(item)
assert len(records)==19;assert ref.pack_hash(pack)==13318001328374612931
frozen=W/'crates/oh_save/tests/fixtures/movement-v2-97f.ohsave';expected=W/'crates/oh_save/tests/fixtures/movement-v2-97f.expected.json';assert frozen.read_bytes()==(O/'exact-movement-1/movement-v2.ohsave').read_bytes();assert expected.read_bytes()==(O/'exact-movement-1/capture.json').read_bytes()
old=git('show',source+':crates/oh_sim/src/save_state.rs');now=(W/'crates/oh_sim/src/save_state.rs').read_bytes();(E/'original97f-save_state.rs').write_bytes(old)
getdto=lambda s:s[s.index(b'pub enum CommandV2'):s.index(b'impl Simulation',s.index(b'pub enum CommandV2'))]
assert getdto(old)==getdto(now)
assert git('show',source+':crates/oh_save/tests/fixtures/m1-v1.ohsave')==(W/'crates/oh_save/tests/fixtures/m1-v1.ohsave').read_bytes()
# Integer-only Postcard/FNV oracle constructed independently from field order.
def command(v):
 if isinstance(v,str):raise AssertionError(v)
 name,arg=next(iter(v.items()))
 if name=='Pause':return b'\0'+bytes([int(arg)])
 if name=='SetSpeed':return b'\1'+bytes([arg])
 if name=='Move':return b'\2'+ref.varint(arg['unit'])+ref.varint(arg['destination'])
 if name=='Stop':return b'\3'+ref.varint(arg['unit'])
 raise AssertionError(name)
def queue(q):return ref.varint(q['tick'])+ref.varint(q['nation'])+ref.varint(q['sequence'])+command(q['command'])
def correction(v):return ref.varint(v['from'])+ref.varint(v['to'])+b''.join(ref.signed(x) for x in v['factors'])
def leg(v):return ref.varint(v['from'])+ref.varint(v['to'])+ref.signed(v['hours'])
def unit(v):return (ref.varint(v['id'])+ref.varint(v['nation'])+ref.varint(v['province'])+ref.signed(v['speed'])+ref.sequence(v['allowed'],ref.varint)+ref.sequence(v['corrections'],correction)+ref.sequence(v['route'],leg)+ref.signed(v['elapsed']))
def canonical(dto,version):
 mv=dto['base'] if version==3 else dto;legacy=mv['base'];s=legacy['state'];c=legacy['config'];raw=(ref.string(s['scenario'])+ref.varint(s['seed'])+ref.varint(s['tick'])+ref.date(s['date'])+bytes([s['hour'],int(s['paused']),s['speed']])+b''.join(ref.varint(x) for x in c['speed_ms_per_tick'])+bytes([c['initial_speed']])+ref.sequence(mv['queue'],queue));w=legacy['world'];i=w['inputs'];raw+=b'\1'+ref.varint(w['definitions_hash'])+ref.sequence(i['nations'],ref.nation)+ref.sequence(i['states'],ref.state_world)+ref.sequence(i['provinces'],ref.province);raw+=b'\1'+ref.sequence(mv['units'],unit)
 if version==3:
  raw+=b'\1'+ref.sequence(dto['straits'],lambda u:ref.varint(u['unit'])+ref.sequence(u['corrections'],lambda e:ref.varint(e['from'])+ref.varint(e['to'])+ref.varint(e['kind'])+b''.join(ref.signed(x) for x in e['factors'])))
 return raw
native={}
for version,kind,name in [(2,'v2','movement'),(3,'v3','strait')]:
 a=json.loads((E/(kind+'-capture-1/capture.json')).read_text());b=json.loads((E/(kind+'-capture-2/capture.json')).read_text());r=json.loads((E/(kind+'-resume.stdout')).read_text());assert a==b==r
 binary=(E/(kind+'-capture-1')/(name+'-'+kind+'.ohsave')).read_bytes();assert binary==(E/(kind+'-capture-2')/(name+'-'+kind+'.ohsave')).read_bytes()
 for point,value in a.items():
  raw=canonical(value['dto'],version);assert raw.hex()==value['canonical_hex'],(kind,point,'canonical');assert ref.fnv(raw)==value['hash'];ref.verify_ledger(value['dto']['base']['base'] if version==3 else value['dto']['base'])
 native[kind]={'save_sha256':sha(binary),'bytes':len(binary),'hashes':{k:v['hash'] for k,v in a.items()},'full_dto_canonical_hash_repeats_resume':True,'integer_postcard_fnv_oracle':True}
hist=json.loads((E/'v2-historical-resume.stdout').read_text());assert hist==json.loads(expected.read_text());assert json.loads((O/'exact-movement-1/capture.json').read_text())==hist
out={'original_manifest_sha256':sha((O/'SHA256-MANIFEST.json').read_bytes()),'original_evidence_count':len(original_records),'original217_all_bytes_sha_unchanged':len(original_records)==217,'pack19_git_source_bytes_SHA_equal':records,'pack_hash':ref.pack_hash(pack),'v2DTO_declarations_frozen':True,'v1_fixture_git97f_unchanged':True,'frozen_v2_binary_sha':sha(frozen.read_bytes()),'frozen_v2_json_sha':sha(expected.read_bytes()),'native':native,'historical_full_resume_equals_original':True}
(E/'independent-native-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='pack19_git_source_bytes_SHA_equal'},indent=2))
