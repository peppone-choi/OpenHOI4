from run_commands import *
run('independent-probe',[C,'test','--offline','--manifest-path',str(E/'probe/Cargo.toml'),'--','--nocapture'])
