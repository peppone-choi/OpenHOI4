역할: 검증 세션. WP-08 M1-r3 새 독립 P-05. exact 0ab691d958a96e79f5f421004801a72173870d58, detached E:/openhoi/.orchestrator/wt/WP-08-M1-r3-verify. 구현에 관여하지 않은 새 앱이다. 모든 명령 workdir/Git-C/절대경로를 지정한다. 기본 cwd main은 수정하지 않는다.

AGENTS.md §2/5, 01 M1 REQ/AC, 02 §3/§12.2/§15, 03 P05, docs/plans/WP-08-M1-r3-schema.md 및 담당 ADR·작업로그를 직접읽고 소스/실제명령으로 대조한다. 부모 제공최초baseline E:/openhoi/.orchestrator/evidence/WP-08.M1-r3.verify.before.json/raw .index를 마지막까지 그대로 유지한다. GIT_OPTIONAL_LOCKS=0를 모든 Git읽기/명령 env에 상속한다. 추적파일·index를 수정/복구하거나 commit/새세션생성하지 않는다. 같아 보이는 bytes재생성도 rawindex가 변하면 무효다. 각주요명령 경계와 최종에서 HEAD·raw bytes/semantic index·전체 추적목록·각SHA256·diff/cached/status를 최초와 비교한다. 참고 helper E:/openhoi/.orchestrator/m1r2_snapshot.py. 부모도 전체 직접비교한다.

증거는 전용worktree target/m1-r3-p05 절대경로에만. 실행 전 모든 producer source의 cwd/env/default를 확인해 Effective-output-paths표와 실제Node환경/경로·git check-ignore·추적output negativeguard를 남긴다. 원M0/M1 테스트 디렉터리/순서·브라우저범위·시간30/expect5/retry0/skip0/GPU·PNG/rawGL·카메라·canvas/epoch·buffer·권위·cleanup단언은 유지한다. Windows 원5제품 OH_BROWSER_PRODUCTS=1 fullM0/fullM1 suite별단1회 실행. 기존 port/PID/preview에는 접속·종료하지 말고 빈독점port19471/19472를 확인한다. 실제exe/PID/servedJS bytes/packidentity와 정상종료를 기록한다.

각Node subprocess에 아래8환경변수를 target/m1-r3-p05/e2e/<suite>/<name> 별도절대경로로 지정하고 실제반영 확인: OH_E2E_EVIDENCE, OH_MALFORMED_EVIDENCE, OH_MAP_EVIDENCE, OH_MAP_REDIRECT_EVIDENCE, OH_MAP_CAPABILITY_EVIDENCE, OH_MAP_RESIZE_EVIDENCE, OH_MAP_PIPELINE_EVIDENCE, OH_MAP_DPR_EVIDENCE. 추가 output이 있으면 source에서 확인해 함께 지정한다. 고정 target/wp05/wp12·client/test-results도 ignored인지 조사한다. 기본 ../docs/worklog/evidence/WP-12·p06 출력은 금지다. config-copy 사용 필요시 webServer.cwd는 exact source/client로 명시하며 원명령·옵션은 유지한다.

직접 npmci/test/typecheck/build, fmt/clippy/workspace, M0hash2·actualM1hash2, 아키텍처소스DR검토·license/assets/docs, 관련native 저장회귀를 실행하고 cmd/cwd/env/exit/원로그를 보존한다. npm pretest wire_fixtures가 ignored target에만 쓰는지 확인한다. 프로토콜freshness는 oh_proto::typescript()를 ignored standalone harness에 출력하여 Gitblob/추적전체bytes 대조와 변조1byte copy의 거부를 검사한다. tracked generate example 실행금지. 골든기대값을 바꾸지 않는다. M0hash를 M1mutable상태·저장검사로 대신쓰지 않는다.

DPR 수정 exactdiff와 이전strictc900 동등성표를 직접검토한다. 그룹 DOM관측이 단언·readiness·epoch·원PNG/rawGL·oldcontext·selected30/ledger0/time·cleanup을 약화하지 않았는지 확인한다. 독립 negative로 wrong/missing/duplicatehost/canvas·detached/staleepoch·buffer/camera/authority가 거부되는지 실제확인한다. 원단언이 실제실패하는지 보며 테스트mirror만으로PASS를주지않는다. SDK비용감소를CPU/driver원인·전체성능으로확대하지않는다. Linux진단 한회f19는 역사참고이며 최신정상CI를대신하지않는다. 과거FAIL원문은 docs/verify/evidence/WP-08-Linux-diagnostic-attempt3·WP-08-main6b6-CI-FAIL 및 WP11verify3에 보존된다.

Edge초기Snapshot 문제는 별도판정한다. 입력→수신→runtime검증→적용→UI상태의 원문/수정/회귀를 직접대조하고 이번Windows성공으로 미확정원인해결을 주장하지않는다. 제품계약 변경시 필드/type/unit/null/default/참조/권위/원자성/hash/save/wire/runtime/UI와독립경계예제를확인한다. 계약불변·후속미구현을 분리한다. 클린룸·미승인규칙·수치하드코딩·테스트완화 위반은FAIL.

부모기본브랜치통합/같은HEAD네CI는 P07에서 한다. 본인은현재exact소스P05 범위를판정하고 Linux후속정상CI 미실행/간헐원인한계를명시한다. 구현로그를믿지말고 직접실행결과/소스로증거를대조한다. 마지막메시지에 VERIFY_REPORT_TEMPLATE 양식의 PASS또는FAIL 전문과 exacthead/cwd·REQ별실효검사·cmd/exit·원문/manifest·최초전체/raw불변성·Edge/DPR미확정·미실행을 반환한다. 파일저장·완료판정은 부모담당. 실제turn을끝낸다.


최신 main 기획 8문서의 exacteb87 사본은 자신의 target/m1-r3-p05/latest-main-planning/identity.json에 있다. 실제 읽은경로와제품exact0ab를구분한다. 최신main eb87 일반37547131178의 원DPRpreferred/forcedGL30초2FAIL(M180PASS/후속Firefox미실행)와다른3CI성공은수정전관측이며소급대체하지않는다. 구현증거는 E:/openhoi/.orchestrator/wt/WP-08-M1-r3/target/m1-r3-p06/evidence.zip SHA965cd8dec926a9627d3d95c76b836202038b5daed189ef0d8e0d3c9cfec2b67d 및FINAL-HANDOFF/RESULTS-AUDIT다. pixel-red.py는tracked파일수정하므로실행금지, 원문실패/복구를읽고새독립negative는ignored복사/actualDOM에만한다.
시작준비 오류를정정한다. 최초create에 부모GetContent실패출력이전달됐으며이메시지가실제역할과범위다. 부모프롬프트/기준파일을본인이생성하지않는다. 아직producer를실행하지않았다면그사실을먼저보고하고부모최초before.json/rawindex 완성/확인 후 지시에따라진행한다. 이미producer를실행했다면숨기지말고구체명령을보고하며판정은보류한다. 추적/index복구·baseline교체금지.
