from pathlib import Path
import json,hashlib,re,datetime,subprocess,os
W=Path(r'E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify3');E=W/'target/evidence/WP-24-M2-r1-P05-3'
receipts=[]
for p in sorted(E.rglob('*.command.json')):
 if 'source-inspected' in p.parts or 'other-generated' in p.parts:continue
 data=json.loads(p.read_text(encoding='utf-8-sig'));receipts.append(dict(path=p.relative_to(E).as_posix(),receipt=data))
for p in sorted(E.rglob('*.receipt.json')):
 if 'source-inspected' in p.parts or 'other-generated' in p.parts:continue
 receipts.append(dict(path=p.relative_to(E).as_posix(),receipt=json.loads(p.read_text(encoding='utf-8-sig'))))
(E/'command-results.json').write_text(json.dumps(dict(exact_head='3d5636192c75a48020fff31a6acc721e31db81a8',workdir=str(W),environment=dict(GIT_OPTIONAL_LOCKS='0',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1'),commands=receipts,classification=dict(verifier_preparation_failures=['m1-hash-1.command.json','m1-hash-2.command.json','probe-preparation-failure.json'],intentional_negative='expected_exit=1 with actual1, native expect_online=false passed=true',product_failures=['legacy-nation-invalid.command.json','legacy-nation-save-consumer.command.json','new-boundaries/legacy-nation-startup.receipt.json','save-boundaries/legacy-nation-restore.receipt.json','save-boundaries/legacy-nation-restore-force.receipt.json','comparer-ledger-tamper.command.json']),initial_snapshot=dict(command=['python',str(E/'snapshot.py'),str(W),str(E/'self-before'),'--compare',str(E/'parent-before')],native_exit=0,result=json.loads((E/'self-after.stdout').read_text()))),ensure_ascii=False,indent=2)+'\n')
source=json.loads((E/'source-audit.json').read_text());bounds=json.loads((E/'new-boundaries/summary.json').read_text());frozen=json.loads((E/'original/result.json').read_text());current=json.loads((E/'current/result.json').read_text());v=[]
for ver,file in [('v2','movement-v2.ohsave'),('v3','strait-v3.ohsave')]:
 p=E/'save-boundaries'/(ver+'-run-1')/file;r=json.loads((E/(ver+'-capture-1.stdout')).read_text());v.append(dict(version=ver,save_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),states={k:q['hash'] for k,q in r.items()}))
(E/'verification-summary.json').write_text(json.dumps(dict(verdict='FAIL',valid_invariance=True,failures=['registered legacy nation file is silently unvalidated by validate/run/server startup+restore+force','current evidence comparer accepts raw+receipt ledger tick contradiction to original native assertion'],original=frozen,current=current,v2_v3=v),indent=2)+'\n')
print('commands',len(receipts));print('v2_v3',json.dumps(v));print('snapshot',(E/'self-after.stdout').read_text());print('m0',(E/'m0-hash-1.stdout').read_text().strip());print('m1',(E/'actual-m1-hash-1.stdout').read_text().strip());print('custody',(E/'original-manifest-audit.json').read_text())
