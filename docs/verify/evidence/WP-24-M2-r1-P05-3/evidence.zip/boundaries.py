import os,sys,json,shutil,subprocess,pathlib,contextlib,io
from run import W,E,P,C,run
os.environ.update(GIT_OPTIONAL_LOCKS='0',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');os.environ['PATH']=r'C:\Users\user\.cargo\bin;'+os.environ['PATH']
sys.path.insert(0,str(W/'crates/oh_save/tools'));import check_save_current as gate
sys.path.insert(0,str(W/'crates/oh_server/tests'));from pack_startup_native import serve
D=E/'new-boundaries';D.mkdir()
# Full comparer predicate with explicitly synthetic platform labels; actual producer bytes retained.
root=D/'synthetic-comparer'
for runner in gate.RUNNERS:
 f=root/('current-save-'+runner);shutil.copytree(E/'current',f);r=json.loads((f/'result.json').read_text());r['platform']=gate.PLATFORMS[runner];(f/'result.json').write_text(json.dumps(r))
control_stdout=io.StringIO()
with contextlib.redirect_stdout(control_stdout):gate.compare(root)
(D/'compare-control.stdout').write_text(control_stdout.getvalue())
f=root/'current-save-windows-latest';q=json.loads((f/'server/query.stdout').read_text());q['query']['world']['states'][0]['infrastructure']['tick']='49';(f/'server/query.stdout').write_text(json.dumps(q));r=json.loads((f/'server/result.json').read_text());r['query']=q;(f/'server/result.json').write_text(json.dumps(r))
code=run('comparer-ledger-tamper',[P,'crates/oh_save/tools/check_save_current.py','compare','--root',str(root)],1)
# Original native assertion must actually fail on these modified bytes.
js=D/'original-ledger-assert.cjs';js.write_text("const assert=require('node:assert/strict');const fs=require('node:fs');const q=JSON.parse(fs.readFileSync(process.argv[2]));const ledger=q.query.world.states[0].infrastructure;assert.equal(ledger.tick,'48');\n")
run('original-ledger-assert',[r'C:\Program Files\nodejs\node.exe',str(js),str(f/'server/query.stdout')],1)
# A registered nation path under a legacy scenario is silently considered validated.
parent=D/'legacy-nation';pack=parent/'testland';shutil.copytree(W/'data/packs/testland',pack)
scenario=pack/'scenarios/legacy';scenario.mkdir();(scenario/'scenario.toml').write_text("start_date='2000-01-01'\n");shutil.copyfile(pack/'scenarios/m1/defines.toml',scenario/'defines.toml')
run('legacy-extra-control',[str(W/'target/debug/oh_cli.exe'),'validate','--deny-warnings',str(pack)])
(scenario/'nations').mkdir();(scenario/'nations/NTH.toml').write_text('invalid [ syntax\n')
run('legacy-nation-invalid',[str(W/'target/debug/oh_cli.exe'),'validate','--deny-warnings',str(pack)],1)
before=gate.files(pack);receipt=serve(parent,D,'legacy-nation-startup',expect_online=False,cause='NTH.toml');assert before==gate.files(pack)
(D/'summary.json').write_text(json.dumps(dict(comparer_mutation_exit=code,expected_comparer_exit=1,comparer_scope='synthetic predicate test, not actual 3OS evidence',legacy_nation_receipt=receipt),indent=2)+'\n')
