# 검증 리포트 — WP-24 (M2-r1 P-05, 시도 3)

| 항목 | 값 |
|---|---|
| 판정 | **FAIL — 검증 불변성은 유효, 독립 재현 결함 2건** |
| 검증자 | Codex 검증 세션, 구현 비참여 새 앱 채팅, 추적 파일·index 무변경 |
| 브랜치·커밋 | detached HEAD `3d5636192c75a48020fff31a6acc721e31db81a8` |
| 검증 일시 | 2026-10-07, Asia/Seoul |
| 전용 worktree | `E:/openhoi/.orchestrator/wt/WP-24-M2-r1-verify3` |
| 원 실행 증거 | `E:/openhoi/.orchestrator/wt/WP-24-M2-r1-verify3/target/evidence/WP-24-M2-r1-P05-3` |
| 앱 종료 코드 | 해당 없음(앱 실행). 아래 종료 코드는 실제 자식 프로세스 관측값이다. |

## 직접 실행한 명령

모든 shell cwd는 전용 worktree다. cargo 실행 파일은 `C:/Users/user/.cargo/bin/cargo.exe` 존재를 확인했고 자식 PATH에도 그 디렉터리를 적용했다. `GIT_OPTIONAL_LOCKS=0`, 자기 `CARGO_TARGET_DIR`, Python UTF-8을 사용했다. 각 argv/cwd/필요 env/PID/stdout/stderr/native exit는 `command-results.json`과 개별 receipts에 있다. 아래 경로는 전용 worktree 기준이며 추적 source/expected를 수정하는 generator를 실행하지 않았다.

| 명령 | 종료 코드 | 결과 요약 |
|---|---|---|
| snapshot.py self-before --compare parent-before | 0 | 최초 자기 snapshot과 부모 원 snapshot·raw index 완전 일치 |
| npm --prefix client ci / run build | 0 / 0 | 자기 client/dist 생성 후 server 빌드 |
| cargo fmt --check | 0 | 통과 |
| cargo clippy --workspace -- -D warnings | 0 | 통과 |
| cargo test --workspace | 0 | workspace 및 기존 경계·저장·정책 테스트 통과 |
| cargo build -p oh_server --locked | 0 | 자기 executable 빌드 |
| npm --prefix client test / run typecheck | 0 / 0 | 7파일 130 client 테스트, malformed wire 회귀 및 typecheck 통과 |
| cargo test -p oh_proto req_net_04_generated_types_are_current --locked -- --exact | 0 | 실제 read-only 생성 TS 동등성 테스트 1개 통과 |
| tools/check_docs.py, check_architecture.py, check_assets.py, check_localisation.py | 각 0 | 문서·의존 경계·에셋·현재 catalog 검사 통과 |
| unittest test_localisation.py / test_save_evidence.py / test_save_current_evidence.py | 각 0 | 3 / 8 / 17 테스트. synthetic 제어를 실제 3OS로 취급하지 않음 |
| cargo deny check licenses bans / npm --prefix client run licenses | 0 / 0 | 실제 라이선스·금지 의존 검사 통과 |
| check_save_determinism.py capture --out …/original | 0 | 원 v1 실제 capture 2회, 새 process helper/CLI 재개 |
| check_save_current.py capture --out …/current | 0 | current 실제 capture 2회, 6개 distinct native PID, 전체 상태·canonical·원장·header·신원 검사 |
| pack_startup_native.py --out …/pack-native | 0 | 기존 정상/오류·원 M0·변조 48건 모두 기대 결과 |
| save_native.py --capture …/current, 동일 --force | 0 / 0 | HTTP200·Welcome·권위 query·served JS·exclusive PID·정상 Ctrl+C native0 |
| save_historical_native.py --capture …/original | 0 | force 양쪽 실제 native1, HTTP/WS 없음, 종료 signal 없음 |
| M0 run --scenario testland --days 365 --seed 1 --hash-out ×2 | 각 0 | `b039d35666b77fc2` |
| 최초 run --scenario m1 (pack 인자 누락) ×2 | 각 1 | 검증자 명령 준비 실패: M0 root의 m1 경로가 없음. 원 stderr 보존 |
| actual M1 run --pack data/packs/testland --scenario m1 --days 365 --seed 1 --hash-out ×2 | 각 0 | `b595dc2a1e5b4f8c` |
| validate --deny-warnings data/packs/testland | 0 | 실제 지도1·시나리오1 strict 검사 |
| validate --deny-warnings data/packs/examples/m0/testland | 1, 의도 negative | manifest.toml:3:12 ko/en 이름 누락 두 오류 유지 |
| independent probes, legacy defines·diamond 전체24 permutation·추가 FTL/native 경계 | 0 | CLI45건/native18건의 개별 기대 일치. 첫 probe의 nation 키 premise 오타로 종료1, 수정된 별도 출력 재실행을 구분 보존 |
| 원 v1 actual CLI header/container negative 14종 × force 양쪽 | 각 1, 의도 negative | tick/seed/hash/metadata/player/defs/scenario/checksum/trailing/version/header bounds 거부; 원 입력 bytes 보존 |
| 원 v1 → current pack resume, force 양쪽 | 1 / 0 | 정상은 기존 PackMismatch. force는 동일 정의의 metadata 변경만 수락; validation 면제가 아님 |
| 외부 --purpose 지정 resume | 1, 의도 negative | 공개 입력으로 호환 caller 선택 불가 |
| movement_fixture / strait_fixture 각 build·capture×2·fresh resume×2 | 각 0 | v2/v3 전체 DTO/canonical/hash·반복 저장 bytes 일치 |
| v2/v3 source 한 파일 추가 뒤 fresh resume | 각 1, 의도 negative | PackMismatch 거부 |
| legacy-nation-invalid validate / legacy-nation-save-consumer run --save-out | **0 / 0, 기대1** | 새 FAIL #1. 등록 nation의 invalid TOML을 무시함 |
| legacy-nation native startup / restore / restore-force | **각 native0, HTTP200/WS101, 기대 거부** | 새 FAIL #1. 열린 프로세스를 검증자가 Ctrl+C로 정상 정리했다. 자체 거부 종료로 기록하지 않음 |
| comparer-ledger-tamper actual compare | **0, 기대1** | 새 FAIL #2. synthetic platform copies에서 원장 tick 모순 수락 |
| 원 save_query.cjs의 ledger tick assertion 재실행 | 1 | 같은 변조 query가 원 assertion을 실제 위반함 |
| source·policy·original archive audits | 0 | 원19/정책22/원2722·6268 member bytes·SHA 전수 일치 |
| snapshot.py self-after --compare parent-before | 0 | HEAD·9878 tracked 파일·semantic/raw index·status/diff/cached 완전 일치 |
| 자기 worktree native 프로세스 종료 점검 | 0 | 자기 서버 잔류 없음. 다른 worktree 프로세스는 건드리지 않음 |

## REQ별 확인

| REQ | 검사하는 테스트 | 실제 검사 여부 | 결과 |
|---|---|---|---|
| REQ-MOD-01 | graph_errors_point_to_original_manifest_values, cycles_conflicts_duplicates_and_engine_ranges, lexical_ready_set_tie_and_redundant_edge, req_mod_01_diamond_order_and_identity_are_input_independent, 독립24 permutation | 실제 dependency DAG·version/engine/conflict/load_after·중복/미존재/순환·dedup·prerelease·lexical order와 모든 순열 identity 확인 | 검사 범위 PASS |
| REQ-MOD-02 | req_mod_02_shipped_pack_loads_real_map_and_national_data, hash_is_path_independent_and_changes_with_content, actual M0/M1 실행 및 frozen/current native capture | 실제 map/national/state 로드, path 무관 sorted bytes hash, 기존 oh_save pack_hash와 Python Postcard/FNV 계산 대조 | 검사 범위 PASS. base·merge/patch/UI·후속 registry 완료 주장은 없음 |
| REQ-MOD-04 | actual_registered_schema_refs_and_ftl_are_not_manifest_only, legacy_validation, CLI validate/run tests, source-change unit, host_policy, native48+추가18, 새 legacy-nation probe | 타입·범위/null/누락·비연속 ID·참조·Unicode 위치·warning exit·실패 source/save 보존은 검사됨. **legacy 아래 registered nation 파일 검사 누락을 직접 재현** | **FAIL #1** |
| REQ-LOC-03 | fluent_syntax_refs_attributes_duplicates_cycles_and_parity, fluent_duplicate_across_files_and_unicode_crlf_location, req_loc_03_missing_translation_is_error_and_real_fluent_is_accepted, check_localisation·3Python tests·Localisation workflow | multiline/select/term/attribute·정적 참조·중복·cycle·ko/en parity·unused·원 위치와 CLI/CI 입력 연결 확인 | 현재 지원 catalog 검사는 PASS. 역사 warning 두 건은 전체 LOC 성공으로 합산하지 않음. 실제 CI green은 미검증이며 Save 증거 consumer는 **FAIL #2** |

필드 의미·단위/type/range/null/default/ref/lifetime/authority 및 definition/initial/mutable/derived를 exact WP-24-schema/ADR과 실제 loader/validation 경계에서 대조했다. 새 validation/policy DTO는 host 파생값이며 simulation/save/wire/UI에 추가되지 않는다. 현재 registered adapter와 WP-13/14/15/35의 후속 producer 인수를 구분했다. 미지원 일반 콘텐츠의 warning은 실제 negative로 확인했으나 FAIL #1 경로는 경고조차 없이 registered로 분류된다.

## 결정론

- M0 해시1/2: `b039d35666b77fc2` / `b039d35666b77fc2`.
- actual M1 해시1/2: `b595dc2a1e5b4f8c` / `b595dc2a1e5b4f8c`. 최초 pack 누락 명령의 exit1은 별도 준비 실패로 남겼다.
- 원 frozen v1 실제 저장 SHA256: `57b13c62ef1a6f88ade1851d0b3ae398157f95ca5bc246068eac3b2a964322fa`, capture 두 회·committed fixture·원 expected와 동일. split `4eb703aad086c7aa`, resumed `d19d028857bb7485`, canonical SHA `e7376ea46cfaee09b976b97c12bc6f082e94bd6000f97ef013840b0675ee151c`.
- current 저장 SHA `d14b6a26fed60f6c8b2bd842ebb39f8da9631d091d930acd9cac10a51ed9665b`, paused SHA `baddb8d31ab1c5df71c29aae5f5f50f2cd2303bcfa72c7e481268eb66b18f620`; pack FNV `3792518183534317124`, effective defines hash `13657557416711793532`. 원/현재 bytes 신원은 다르며 실제 전체 상태와 split/resumed hash는 같다.
- current capture 6개 native PID, argv/cwd/executable SHA/exit/raw stdout/stderr, source raw before/after, header·seed·config·queue·DTO·ledger·canonical/hash·pack file list/SHA·입력 불변 및 두 회 bytes를 실제 대조했다. local current gate 통과는 Windows 증거다.
- v2 현재 저장 SHA `a6eba85f9d12d6141a479bf0b256ff76ed556a28bd9de67566ed0568d05e843e`; split `18bff036731f4f26`, continuous `a145b72ad0ad25e6`.
- v3 현재 저장 SHA `911fe1be92dfe331401d952e0e8c1d468938b918cceecfa830268160e048ae5a`; split `84462b78cc1a0f5d`, arrival `d2c3248b5eca4b8d`, continuous `299a80d49c17f3ec`.
- v2/v3 새 process에서 전체 DTO·canonical bytes·hash와 반복 저장 bytes가 같고, source 변경은 PackMismatch로 거부됐다. 원 v2 fixture/expected 보존 unit도 통과했다. `500ba0f→c28f904`의 strait.rs 변경은 동일 ko 키 추가5줄뿐이며 기존 PackMismatch 및 current v3 전체 DTO/hash 단언은 유지됐다.
- 원 v1 actual CLI 오류14종×force 양쪽은 자체 exit1, 원 저장·팩·mutation 입력 불변이다. workspace의 원 codec body/fullstate/metadata/bounds/trailing/preflight/force 테스트도 직접 실행했다.
- REQUEST-0008 정책은 engine-owned include_str, caller3/entry4, 원 M0 3파일·mutable-v1 19파일 전 경로·bytes·SHA256/FNV/id/version/scenario/kind/provenance 및 실제 bounded v1 header 조건을 비교한다. 원 ZIP22member와 runtime 정책·실제 capture의 전수 bytes가 일치한다. source 추가/삭제/한byte/SHA·동일FNV 주장/reparse/source-change/다른 caller·scenario·key·locale·format/일반purpose/plain frozen19/current pack/force 경계를 tests와 native 명령으로 검사했다.
- M0 compatibility는 정확 manifest.name_key/testland_name/ko·en/missing_message_value만 metadata unavailable warning으로 바꾸고 원 manifest.toml:3:12·code·field·key·locale·cause를 유지한다. 원 M0 strict validate exit1과 renderer 없는 headless run 계약은 별도이며 순수 LOC PASS로 포장하지 않았다. 원 mutable-v1 서버 복원은 force 양쪽 자체1/무HTTPWS다.

## 금지 사항 점검

| 항목 | 결과 |
|---|---|
| 시뮬레이션의 f32/f64 | oh_sim 실제 lib/world/movement/formula/time/ledger/save_state 소스를 직접 확인. Fx/정수 사용, 해당 float 없음 |
| HashMap 순회 | 상태/queue/관계는 BTreeMap/BTreeSet·정렬 Vec. 해당 HashMap/HashSet 순회 없음 |
| thread_rng / SystemTime | oh_sim에 OS 난수·시계·파일/네트워크 I/O 없음. CLI 저장 시각은 host metadata이며 simulation hash와 구분 |
| 코드 내 수치 리터럴 | 새 policy identity·format·기술 경계는 engine 정책 데이터/기존 계약. 신규 게임 수치·공식 없음 |
| 미결정 규칙 구현 | exact 기획과 REQUEST0006/7/8의 한정 잠정 범위 확인. D/OPEN 확정 변경·미구현 registry의 성공 선언 없음 |
| 골든 기대값 변경 근거 | 원 golden·v1 fixture/expected/checker/reference/tests bytes 미변경 전수대조. generator/golden update 미실행 |
| 클린룸 | 자체 synthetic 팩·정책·저장 입력. 원작 파일/수치/지도/위키 문장 사용 증거 없음. ASSETS 검사 통과 |

샌드박스·승인·네트워크·CI 설정을 우회 변경하지 않았다. 신규 fluent-syntax=0.12.0와 sha2=0.11.0의 실제 downloaded Cargo.toml/lock 및 허용 MIT OR Apache-2.0를 검사했다. sha2 공식 문서는 직접 열람했다([sha2 공식 문서](https://docs.rs/sha2/0.11.0/sha2/)). Fluent 해당 docs.rs 경로는 접근 실패를 기록했고 local 실제 manifest와 cargo-deny 결과로 검사했다. b651 대비 신규 lock node는 두 직접 의존과 SHA 계열 transitive5개이며 기존 package version 제거 없음; sha1/digest 텍스트 disambiguation을 실제 name/version edge로 정규화하면 기존 edge 변경은 없고 oh_data의 신규 두 edge만 있다. client와 oh_proto 원 source bytes도 보존됐다.

## 작업 로그 증거와 실제 결과 대조

- exact source·worklog·ADR와 main documentation head `f17acc233526e405a53befad6782121d6d1de06f` planning 사본을 구분했고 planning/identity.json의 모든 SHA를 확인했다.
- b651 원 Testland19파일은 git show 원 bytes, frozen fixture file set/bytes/SHA가 모두 같다. 원 M0·mutable-v122파일은 봉인 ZIP/manifest/runtime·새 actual capture와 모두 같다.
- 기존 frozen checker, test_save_evidence, save_reference, 원 fixture/expected/golden/contract tests·generic context를 전수 bytes 대조했다. helper의 additive frozen capture 연결과 current generic 유지, P06에서 helper/codec 미변경을 diff로 확인했다.
- 최초 구현 증거2722파일 및 P06 증거6268파일을 원 producer manifest·custody·ZIP member bytes/SHA에 전수대조: 0 mismatch. P06 원 manifest SHA `37c8634c52a606ffd14b20cd272ea116145b866cca8f8f15cae307b33efe8cb9` 유지.
- 원 attempt1의 legacy defines·dependency·broken FTL 세 FAIL은 새 실제 CLI/native에서 거부를 확인했다. 원 FAIL 리포트/증거와 WP17-P05-2 raw-index·CI 입력 무효 기록을 소급 수정하지 않았다.
- 필수 Save workflow에 원 두 capture/원3OS compare와 separate current 두 capture/current3OS compare·server/force positive·historical negative가 모두 존재하며 skip/continue-on-error/실패 삼킴 없음. producer의 기존 HTTP/WS/Welcome/query/servedJS/exclusivePID/CtrlC0 단언은 보존됐다. 하지만 새 comparer는 FAIL #2의 원 query assertion을 다시 검증하지 않는다.
- **미실행/미검증:** 실제 Linux/macOS 및 remote3OS CI, 통합 main 같은HEAD의5workflow/필수jobs/artifacts. synthetic comparer control은 OS 간 실증이 아니다. UI WP가 아니므로 Playwright 화면·AI bench/repro 게이트를 WP24 완료 근거로 추가하지 않았다. 미변경 write_atomic pre-encode body 재검사 가정은 별도 범위 밖 발견이며 이번 FAIL 또는 과거 PASS 취소로 확대하지 않았다.
- `parent-before`, `self-before`, `self-after`의 HEAD·9878개 tracked list/각 SHA·semantic index·raw index bytes/SHA·status/diff/cached 모두 동일. raw index SHA `96cf4bdd9d4fdc9d9e6e3f5d56aafb06f3ad671d5ae1fae158799770f3e08ae4`. index 복구/원baseline 교체 없이 유효 검증이다.
- 자기 native 서버 프로세스가 모두 종료된 뒤 보고한다. 잘못된 legacy nation을 받아 연 서버는 검증자가 Ctrl+C로 정리했으므로 정상 입력의 자체 성공 증거와 구분한다.

## FAIL 항목

| # | 재현 명령 | 기대 | 실제 |
|---|---|---|---|
| 1 | `target/debug/oh_cli.exe validate --deny-warnings target/evidence/WP-24-M2-r1-P05-3/new-boundaries/legacy-nation/testland`; 동일 팩 run --save-out 및 native startup/restore/force. fixture는 정상 current 팩에 legacy scenario+실제 numeric defines와 `scenarios/legacy/nations/NTH.toml`=`invalid [ syntax`를 추가한다. | 등록 nation TOML을 파싱해 file/line 오류 및 exit1. runnable 입구는 authority/HTTP/WS를 열지 않음. 최소한 unsupported 파일을 strict 정상으로 표시하지 않음 | validate exit0, stderr empty, `maps=1 scenarios=2`. run --save-out도 exit0·저장 생성. startup PID33908, restore36104, force16184의 HTTP200/WS101. 소스는 pack_validation.rs:491~527에서 legacy nations를 읽지 않고 :575에서 registered로 분류함. 모든 source/save bytes 보존. receipt의 native0은 관측 HTTP/WS 뒤 검증자 Ctrl+C 종료이며 자체 거부가 아님 |
| 2 | `python crates/oh_save/tools/check_save_current.py compare --root target/evidence/WP-24-M2-r1-P05-3/new-boundaries/synthetic-comparer`. 정상 actual Windows current bytes를 세 synthetic platform label로 복사한 제어가 먼저 통과한다. windows/server/query.stdout 및 result.json.query의 infrastructure.tick만 `48→49`로 일치시킨다. | comparer가 원 `save_query.cjs:33 assert.equal(ledger.tick,'48')` 또는 canonical/current 상태와의 모순을 거부하여 exit1 | actual compare exit0. 같은 query에 원 Node assertion을 직접 적용하면 exit1. check_save_current.py:283~333은 raw query와 receipt의 상호일치·몇 개 summary만 검사하고 원장 tick/원 ledger assertion을 재검증하지 않음. `comparer-ledger-boundary.json`, raw mutated query/receipt, comparer stdout/stderr/nativeexit 및 original-ledger-assert.stderr 보존. 실제3OS 성공 주장이 아님 |

FAIL #1은 실제 loader/CLI/server 입력 검증 누락이며 FAIL #2는 필수 current Save 증거 consumer의 검증 누락이다. 둘 다 추적 파일을 고치지 않은 독립 재현이다. 이번 판정은 유효 FAIL이며 P07/전체 M2/실제3OS green을 선언하지 않는다.
