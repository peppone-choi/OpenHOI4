import sys,os,json,pathlib,subprocess,hashlib,tomllib,zipfile
W=pathlib.Path(r'E:\openhoi\.orchestrator\wt\WP-24-M2-r1-verify3');E=W/'target/evidence/WP-24-M2-r1-P05-3'
sys.path.insert(0,str(W/'crates/oh_save/tools'));from save_reference import pack_hash
h=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(W),*args])
result={};fail=[]
meta=json.loads((W/'crates/oh_save/tests/fixtures/m1-pack-v1.source.json').read_text());frozen=W/'crates/oh_save/tests/fixtures/m1-pack-v1';rows=[]
for f in meta['files']:
 b=(frozen/f['path']).read_bytes();orig=git('show',meta['source_commit']+':'+meta['source_path']+'/'+f['path']);ok=b==orig and len(b)==f['bytes'] and h(b)==f['sha256'];rows.append(dict(path=f['path'],bytes=len(b),sha256=h(b),same_git_bytes=ok))
 if not ok:fail.append(f['path'])
assert {p.relative_to(frozen).as_posix() for p in frozen.rglob('*') if p.is_file()}=={f['path'] for f in meta['files']}
result['frozen19']=rows
policy=tomllib.loads((W/'crates/oh_data/policies/legacy-validation.toml').read_text());identity=json.loads((W/'docs/decisions/evidence/historical-load-policy/identity.json').read_text());archive=W/'docs/decisions/evidence/historical-load-policy/source-originals.zip';rows=[]
with zipfile.ZipFile(archive) as z:
 print('policy zip',z.namelist())
 for s in policy['sources']:
  assert s['files']==next(i['files'] for i in identity['original_sources'] if i['id']==s['id'])
  disk=W/'data/packs/examples/m0/testland' if s['id']=='original-m0' else E/'original/run-1/pack'
  assert len(s['files'])==len([p for p in disk.rglob('*') if p.is_file()])
  for f in s['files']:
   name=s['id']+'/'+f['path'];b=z.read(name);actual=(disk/f['path']).read_bytes();ok=b==actual and len(b)==f['bytes'] and h(b)==f['sha256'];rows.append(dict(source=s['id'],path=f['path'],same_bytes=ok,sha256=h(b)))
   if not ok:fail.append(name)
  assert pack_hash(disk)==int(identity['pack_fnv64'][s['id']])
 assert len(z.namelist())==22
result['policy22']=rows;result['policy_entries']=policy['entries']
base=meta['source_commit'];protected=['crates/oh_save/tests/fixtures/m1-v1.ohsave','crates/oh_save/tests/fixtures/m1-v1.expected.json','crates/oh_save/tools/check_save_determinism.py','crates/oh_save/tools/save_reference.py','crates/oh_save/tests/test_save_evidence.py','crates/oh_save/tests/contracts.rs','crates/oh_save/tests/save.rs','crates/oh_save/tests/relations.rs','crates/oh_save/src/context.rs']
protected+=git('ls-tree','-r','--name-only',base,'tests/golden','client','crates/oh_proto').decode().splitlines();rows=[]
for f in protected:
 old=git('show',base+':'+f);new=(W/f).read_bytes();ok=old==new;rows.append(dict(path=f,sha256=h(new),same_bytes=ok))
 # proto differs only due to independently merged WP17; record, do not classify unscoped baseline mismatch.
 if not ok and not f.startswith(('crates/oh_proto/','client/')):fail.append(f)
result['protected']=rows
for ref in [base,'c28f904','500ba0f']:
 (E/('source-diff-'+ref[:7]+'.patch')).write_bytes(git('diff',ref,'HEAD','--','crates/oh_save','crates/oh_proto','client','.github/workflows/save-determinism.yml','Cargo.lock','assets/ASSETS.toml'))
old=tomllib.loads(git('show',base+':Cargo.lock').decode());new=tomllib.loads((W/'Cargo.lock').read_text());a={(p['name'],p['version']):p for p in old['package']};b={(p['name'],p['version']):p for p in new['package']}
result['lock']=dict(added=[p for k,p in b.items() if k not in a],removed=[p for k,p in a.items() if k not in b],changed=[dict(before=a[k],after=b[k]) for k in a.keys()&b.keys() if a[k]!=b[k]])
rows=[]
for folder in ['WP-24-M2-r1-first','WP-24-M2-r1-P06']:
 d=W/'docs/worklog/evidence'/folder
 with zipfile.ZipFile(d/'originals.zip') as z:
  manifests=[n for n in z.namelist() if 'sha256' in n.lower() or n.endswith('SHA256SUMS.json')];print(folder,'manifests',manifests)
  # Every member is retained; compare custody SHA and original manifest when present.
  custody=json.loads((d/'parent-custody.json').read_text());(E/(folder+'-custody-structure.json')).write_text(json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in custody.items()},indent=2))
  for name in manifests:
   data=json.loads(z.read(name));entries=data if isinstance(data,list) else data.get('files',[])
   if not entries:continue
   mismatches=[];count=0
   for f in entries:
    p=f.get('path');sha=f.get('sha256');size=f.get('bytes',f.get('size'))
    if p in z.namelist() and sha:
     raw=z.read(p);count+=1
     if h(raw)!=sha or (size is not None and len(raw)!=size):mismatches.append(p)
   rows.append(dict(folder=folder,manifest=name,checked=count,mismatches=mismatches))
   fail+=mismatches
result['original_evidence']=rows
for name in ['sha2-0.11.0','fluent-syntax-0.12.0']:
 p=next(pathlib.Path(r'C:\Users\user\.cargo\registry\src').glob('*/'+name+'/Cargo.toml'));data=tomllib.loads(p.read_text());result[name]=dict(package=data['package'],path=str(p));(E/(name+'-Cargo.toml')).write_bytes(p.read_bytes())
planning=json.loads((E/'planning/identity.json').read_text());result['planning_audit']=[dict(copy=f['copy'],same_sha=h(pathlib.Path(f['copy']).read_bytes())==f['sha256']) for f in planning['files']];assert all(f['same_sha'] for f in result['planning_audit'])
result['failures']=fail;(E/'source-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('audit failures',fail);sys.exit(bool(fail))
