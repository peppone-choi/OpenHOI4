import sys,json,pathlib,subprocess,hashlib,zipfile,os,shutil,itertools,importlib.util
from run import run,W,E,C,P,N
os.environ.update(GIT_OPTIONAL_LOCKS='0',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');os.environ['PATH']=r'C:\Users\user\.cargo\bin;'+os.environ['PATH']
sys.path.insert(0,str(W/'crates/oh_save/tools'));from check_save_current import verify_folder,verify_servers
run('client-unit',[N,'--prefix','client','test'])
run('cargo-license-bans',[C,'deny','check','licenses','bans'])
for i in [1,2]:run('actual-m1-hash-'+str(i),[C,'run','-p','oh_cli','--','run','--pack','data/packs/testland','--scenario','m1','--days','365','--seed','1','--hash-out'])
# Current gate proves the local artifacts; it does not prove 3OS execution.
r=verify_folder(E/'current');verify_servers(E/'current',r);(E/'local-current-gate.json').write_text(json.dumps(dict(passed=True,head=r['head'],platform=r['platform'],scope='actual local Windows only'),indent=2))
# Source archive byte audit through the custody list: includes producer manifest.
rows=[]
for name in ['WP-24-M2-r1-first','WP-24-M2-r1-P06']:
 d=W/'docs/worklog/evidence'/name;custody=json.loads((d/'parent-custody.json').read_text());m=[]
 with zipfile.ZipFile(d/'originals.zip') as z:
  assert len(z.namelist())==custody['ZIP_members']
  for f in custody['actual_files']:
   b=z.read(f['path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'];m.append(f)
 rows.append(dict(folder=name,checked=len(m),mismatches=[],manifest=[f for f in m if f['path']==custody['producer_manifest']]))
(E/'original-evidence-custody-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
# Inspect lock package licenses and exact sources independent of implementation's statement.
# Read-only actual generated TS comparison is already in workspace tests; filter run supplies its own receipt.
run('proto-read-only',[C,'test','-p','oh_proto','req_net_04_generated_types_are_current','--locked','--','--exact'])
# Current native state proof comparer boundary: a mirrored raw-query/receipt manipulation must fail the original ledger tick assertion.
root=E/'comparer-probe';shutil.copytree(E/'current',root)
control=verify_folder(root);verify_servers(root,control)
path=root/'server/query.stdout';query=json.loads(path.read_text());original_tick=query['query']['world']['states'][0]['infrastructure']['tick'];assert original_tick=='48';query['query']['world']['states'][0]['infrastructure']['tick']='49';path.write_text(json.dumps(query))
path=root/'server/result.json';receipt=json.loads(path.read_text());receipt['query']=query;path.write_text(json.dumps(receipt))
try:
 verify_servers(root,verify_folder(root));accepted=True;error=None
except (AssertionError,ValueError,KeyError,TypeError,OSError) as exc:accepted=False;error=repr(exc)
(E/'comparer-ledger-boundary.json').write_text(json.dumps(dict(control_passed=True,mutation='server/query.stdout and result.query world.states[0].infrastructure.tick 48->49',original_assertion="save_query.cjs: assert.equal(ledger.tick,'48')",expected='reject',actual='accepted' if accepted else 'rejected',error=error),indent=2)+'\n')
print('COMPARER LEDGER TAMPER ACCEPTED',accepted,flush=True)
