import os,sys,json,pathlib,zipfile,hashlib,tomllib,shutil,subprocess
from run import W,E,run,P
rows=[]
for name in ['WP-24-M2-r1-first','WP-24-M2-r1-P06']:
 d=W/'docs/worklog/evidence'/name;c=json.loads((d/'parent-custody.json').read_text());zipbytes=(d/'originals.zip').read_bytes();assert len(zipbytes)==c['ZIP_bytes'] and hashlib.sha256(zipbytes).hexdigest()==c['ZIP_sha256']
 with zipfile.ZipFile(d/'originals.zip') as z:
  raw=z.read('producer-original-manifest.json');m=json.loads(raw);print(name,type(m),list(m)[:4] if isinstance(m,dict) else str(m[:1])[:250]);(E/(name+'-original-manifest.json')).write_bytes(raw)
  entries=m.get('files',[]) if isinstance(m,dict) else m
  bad=[];checked=0
  for f in entries:
   if not isinstance(f,dict):continue
   path=f.get('path');data=z.read(path);checked+=1
   if hashlib.sha256(data).hexdigest()!=f['sha256'] or len(data)!=f.get('bytes',f.get('size')):bad.append(path)
  # The parent custody itself is directly checked even if producer uses a different structure.
  for f in c['actual_files']:
   b=z.read(f['path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
  rows.append(dict(name=name,producer_manifest_sha256=hashlib.sha256(raw).hexdigest(),producer_manifest_entries=checked,custody_members_checked=len(c['actual_files']),mismatches=bad,zip_sha256=hashlib.sha256(zipbytes).hexdigest()));assert not bad
(E/'original-manifest-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
a=json.loads((E/'source-audit.json').read_text());base='b6516ed4e571a0359e1da2ee69e9b68e3356339f';old=tomllib.loads(subprocess.check_output(['git','--no-optional-locks','-C',str(W),'show',base+':Cargo.lock']).decode());new=tomllib.loads((W/'Cargo.lock').read_text())
def edges(packages,p):
 versions={n['name']:[q['version'] for q in packages if q['name']==n['name']] for n in packages}
 result=[]
 for edge in p.get('dependencies',[]):
  v=edge.split();version=v[1] if len(v)>1 else versions[v[0]][0];assert len(v)>1 or len(versions[v[0]])==1;result.append((v[0],version))
 return sorted(result)
changes=[]
for oldp in old['package']:
 p=next(q for q in new['package'] if (q['name'],q['version'])==(oldp['name'],oldp['version']));b=edges(old['package'],oldp);n=edges(new['package'],p)
 if b!=n:changes.append(dict(package=p['name'],before=b,after=n))
assert [p['package'] for p in changes]==['oh_data'];(E/'resolved-lock-edge-audit.json').write_text(json.dumps(dict(changes=changes,existing_versions_removed=[]),indent=2)+'\n')
# Archive test-generated ignored outputs located outside the explicit evidence folder, leaving originals intact.
for directory in [W/'target/evidence/WP-24',W/'target/evidence/WP-24-P06',W/'target/wp05',W/'target/wp09',W/'target/wp11-native-red']:
 if directory.exists():shutil.copytree(directory,E/'other-generated'/directory.relative_to(W/'target'),dirs_exist_ok=False)
# Inspected exact sources accompany the report; these are ignored copies only.
paths=['AGENTS.md','docs/03-production-prompts.md','docs/templates/VERIFY_REPORT_TEMPLATE.md','docs/plans/WP-24-schema.md','docs/adr/ADR-2401-pack-validation.md','docs/worklog/WP-24.md','crates/oh_data/src/pack_validation.rs','crates/oh_data/src/localisation.rs','crates/oh_data/src/host_policy.rs','crates/oh_data/src/scenario_defines.rs','crates/oh_data/src/m0.rs','crates/oh_data/src/national.rs','crates/oh_data/src/raw.rs','crates/oh_save/tools/check_save_current.py','crates/oh_save/tools/check_save_determinism.py','crates/oh_server/tests/save_query.cjs','crates/oh_server/tests/save_native.py','crates/oh_server/tests/save_historical_native.py','crates/oh_server/src/lib.rs','crates/oh_cli/src/lib.rs','.github/workflows/save-determinism.yml','.github/workflows/localisation.yml','Cargo.lock','crates/oh_data/Cargo.toml','assets/ASSETS.toml']
paths += [p.relative_to(W).as_posix() for p in (W/'crates/oh_sim/src').glob('*.rs')]
for rel in paths:
 t=E/'source-inspected'/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/rel,t)
(E/'technical-source-check.json').write_text(json.dumps(dict(date='2026-10-07',sha2=dict(version='0.11.0',license='MIT OR Apache-2.0',local_manifest='sha2-0.11.0-Cargo.toml',official='https://docs.rs/sha2/0.11.0/sha2/',web_verified=True),fluent=dict(version='0.12.0',license='MIT OR Apache-2.0',local_manifest='fluent-syntax-0.12.0-Cargo.toml',official_attempts=['https://docs.rs/crate/fluent-syntax/0.12.0/source/Cargo.toml','https://docs.rs/fluent-syntax/0.12.0/fluent_syntax/'],web_result='inaccessible; actual downloaded Cargo.toml and cargo-deny checked'),semver=dict(official='https://docs.rs/semver/1.0.27/semver/struct.VersionReq.html',principle='star excludes prerelease without an explicit matching prerelease comparator',actual_locked='1.0.28')),indent=2)+'\n')
run('self-after',[P,str(E/'snapshot.py'),str(W),str(E/'self-after'),'--compare',str(E/'parent-before')])
