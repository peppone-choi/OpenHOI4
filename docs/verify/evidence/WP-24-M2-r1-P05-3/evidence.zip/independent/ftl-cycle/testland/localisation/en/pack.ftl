testland_name = { other }
other = { testland_name }
