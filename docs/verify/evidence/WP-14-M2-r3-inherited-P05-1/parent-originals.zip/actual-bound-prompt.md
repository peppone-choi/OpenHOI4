역할: 검증 세션. OpenHOI4 M2-r2 W2 WP-14 새 독립 P05.

구현 중 확인된 원 M1 호환 회귀도 직접 재검사한다. 경제 정의가 없는 시나리오의 economy 조회는 기존 QueryResult 거부 응답을 유지하며, 경제 정의가 있는 시나리오에서만 새 EconomyResult를 사용한다. 원 브라우저 FAIL·수정 후 단일 전체 검사와 실제 normal/force 서버 결과를 각각 보존하고 최종 exact source에서 직접 확인한다. 이전 clean checkpoint의 Windows 벤치/서버 결과를 수정된 최종 source의 Linux·세 OS 결과로 대신하지 않는다.

준비 초안. actual completed final·exact clean source·schema/ADR·구현 원증거를 부모가 인수하고, 새 detached WT 및 최초 whole/raw snapshot을 착수 전에 저장한 뒤 바인딩한다. 구현 앱/기존 검증 앱·before를 재사용하지 않는다. source CI와 실제 고정입력 Linux·새 v5 세 OS 원격 증거가 아직 pending이면 그 상태를 별도로 명시하고 로컬 독립 검증을 병행할 수 있다. 부모가 같은 source SHA의 실제 원 API/ZIP·Linux·세 OS 증거를 인수해 검증자의 ignored 영역으로 전달하기 전에는 formal 최종 PASS/통합을 선언하지 않는다. 원격 pending은 로컬 실행 성공으로 대체하지 않으며 추적파일/before를 바꾸지 않는다. 실제 원격 FAIL은 그대로 판정·보존하고, source 수정이 필요하면 원 검증을 마친 뒤 새 source·새 독립 세션으로 진행한다. 제품/추적파일·index/기대값/골든·정책/설정을 수정하지 않고 모든 명령은 지정 WT에서 실행한다. Python -X utf8/GIT_OPTIONAL_LOCKS=0, 최신 parent planning 원문과 실제 구현 타입을 대조한다. 마지막 actual final은 VERIFY_REPORT_TEMPLATE 전문 PASS 또는 FAIL이며 추적 report 저장/commit/다른앱 생성은 금지다.

규칙은 01§4.2/4.3·REQUEST-0010 A-CEO-r1 유효 수정판이다. 원 PC 선지급 후보·미지원 zero 효과 성공은 채택되지 않았다. source worklog 설명을 믿지 말고 아래 실제 입구·자기 산술·부작용/거부·전체 상태를 검사한다. 스키마상의 실제 필드/단위/범위/refs/누락·null/default·수명·권위·새version/presence·constructor/command/phase/restore/wire/query/repro를 대응한다. 원 REQ별 RED가 실질적인 요구를 검사했는지도 원출력과 새 코드로 직접 확인한다.

CEO 수정판의 데이터 비용>0는 건물뿐 아니라 법령 PC cost의0/음수 로드 거부도 포함한다. cap/슬롯/보정0은 허용된 별도 skip 경계와 구분한다.

1. IC/자원/인구는 소유 주 집합의 실제 비연속ID·정렬·통제 상이·주 소유 변경과 계산tick으로 검사한다. 주 건물/IC 단가·국가보정의 Add/Mul source 정렬·원장 최종 raw bits=적용 raw bits를 자기 정수식으로 대조한다. 비율Fx(I32F32)/누적량Qty(I48F16)/인력i64를 실제 code에서 확인하고 Qty→Fx 묵시적 축소·float·overflow/missing 정의를 거부한다. 자원은 일일흐름이며 비축/부족생산/시장 거래가 지원됐다고 하지 않는다. 실제 immutable defs·주 contribution·derived snapshot과 다음 일일 계산을 구분한다.

2. 하한clamp(base+slope*(1-stability),0,1), 네비율 범위/정확합1·소비재 잔여 귀속을 원raw 단위/checked 곱셈·바이트전체로 독립 계산한다. 하한직전/동일/초과·ICraw5/각0.25·IC0·overflow·중복/unknown/null을 검사한다. law/stability 변경 뒤 하한실패는 PC/법령/비율/인력/flags와전체transaction을보존하며자동재배분하지 않는다. 조건/효과 목록의 앞선변경뒤후속오류는전체 rollback이다.

3. 건설은 현재수준+1 한단계·소유/건물/정의refs·같은대상 활성/대기 중복·단계/슬롯/cost0 거부를검사한다. cap0/보정0은 소비/진행0으로skip하고뒤유효프로젝트가진행한다. 원ICceil/초과유효진행폐기/같은날원IC잔여전달/미사용IC이월없음/완료산출다음일 반영을 독립정수식으로검사한다. 취소/재정렬·예약해제·환불없음·정의오류/overflow의원자성, 소유상실의진행/목표/queue/예약보존·새소유자슬롯독립·회복시targetconflict/slot 부족휴면/사유·명시취소·valid 재개를 실제native/probe에서 확인한다. 신규 점령/소유권명령을추가지원했다고하지 않는다.

4. 인력은 floor(소유인구합*징병비율) capacity와committed/reserved·가용max0·초과조회 수명이다. 초기capacity미만/초과/0, 매일누적지급없음, reserve/commit/cancel/consume/return의실제내부API·중복확정/초과/음수/타국참조·전체rollback을검사한다. capacity감소때기존소비/예약삭제없음·증가뒤동일식·overflow를검사한다. 내부API를임의플레이어인력생성/반환명령으로노출하지않았는지확인한다. 실제훈련/보충 consumer는후속임을추적한다.

5. PC는 기존Politics phase 날짜경계에한번만지급한다. 생성/PausedPump/조회/같은날save/resume에는지급없음, Commands에서경계PC0/cost3/daily3은의미오류소비/법령불변뒤정상Politics PC3, 뒤phase오류면그소비까지전체rollback을검사한다. 상한직전/동일/초과daily·중간overflow없는wide/checkedclamp·음수/누락/null/init>cap 로드거부·안정도/동원도0~1 경계와초과거부를검사한다. 동일법령·조건false·PC 부족·분야/ID오류·단계직접변경비용·명령직전상태조건·효과transaction·범주data-driven을native입구로검사한다. Economy→Production→Construction→ManpowerTrainingReinforcement→Research→Politics→…→Ledger→종료→Snapshot 기존순서/RNG/clock/futurequeue/wholephase rollback을확인한다.

6. 실제 정치/법령/IC score adapter·registry references·explicit nation scopes만지원하고 없음/값0의미지원조건/효과도capability거부인지검사한다. NAT03/ECO04/ECO07의 생산/항복/군사/훈련/시장 후속consumer를producer만으로전체완료라고하지 않는다. old flags/end와경제변경뒤성공commit 평가시점·초기평가·종료후query/save·새enqueue/step거부·futurequeue보존을검사한다.

7. source가선택한새경제형식의전체상태/정의identity·계산tick/원장·queue/누적진행/예약/휴면/인력/법령/PC를fullDTO/canonical/hash/save/wire/repro에대응한다. None/v1/v2/v3/v4 기존read/write/bytes/hash/fixture를원source로검사하고부재를새0state로바꾸지않는다. 새some/empty/없음·누락/null/unknown/version/mode/callerpurpose/force·tamper·budget·실제readonlyTS/runtime guard를검사한다. 새native record/replay·fresh save/resume·이전pending1회/future보존·Paused동일tick·의미오류소비/phase오류완전보존을확인한다. synthetic 예제만돌려실제consumer/Host지원이라고하지 않는다.

8. 벤치는고정prior81deb의**전체**팩을양쪽별도실제source library에같은immutable입력으로사용한다. 전체path/byte길이/SHA/actualpackhash·extra/missing/손상/symlink/reparse/참조이탈·load/warmup/측정전후identity와native실측을확인한다. current가실제candidate source/metadata pathdependencies/원lock·registry audit/별도binary이며prior로바뀌지않았는지검사한다. currentpack에새m2가추가돼도측정input은원같은팩인회귀와고정input mutation/linkage바뀜/exit/state/hash/15%두쌍거부를자체입력으로검사한다. 원driver/release/default features/m1/seed1000/240000/warm2400/pairs2/native240s/build1200s 유지. 실제Linux원API/run/head/attempt/job/log/artifact digest/wholeZIP/member CRC/SHA·두pair·fullDTO/canonical/hash/ended/future를직접검사한다. --ref dispatch의actualSHA를metadata와대조하고새source_ref입력/CI설정변경을전제하지않는다. 이m1bench로신경제활성부하/M2M3/UI성능PASS를주장하지않는다.

위 원driver 조건에는 CEO의 명시적 최소 팩 identity 계측 예외가 있다. 실제 검토 원문/세파일 old·working·diff를 읽고 final source의 driver timer~loop~elapsed/완료검사 문자열 및 regression15% AST를 원본과 직접 대조한다. driver pack_hash 전후와 output2필드 외 추가 측정 코드는 인수 범위가 아니다. 새 같은 driver bytes/SHA가 양 실제 library의 src/main.rs와 일치하고 metadata/path dependency/원 lock/registry/binary linkage가 실제 각 source인지 검사한다. old-driver 역사 출력을 새 필드로 소급 보충하거나 과거 시간을 새driver baseline 표본으로 섞지 않는다. 두 신규 필드 각각의 누락/null/길이·hex, withinpair·두쌍·양쪽 hash 차이, 전체표본이 같은 잘못된 hash여도 warmup prior-native/실제 전체input 바인딩과 달라 거부되는지 직접 검사한다. runner 전체 immutable inventory/loader/fullDTO 검사와 원 negative/15%/timeout/워크플로 조건은 유지한다.

fmt/clippy(alltargets)/workspace/readonlyTS/client/nativevalidators/oldM0M1hash각2/save/trigger/repro·새domain독립예제·원M1 E2E 단일전체·sourceCI 필수jobs/actual3OS를원설정으로실행한다. 원지도/GLB제품변경없으면새bake를반복요구하지않는다. 사용자desktop/CUA/focus/globalinput/기존PIDs/profile·BP/설정/한도/expected·LFS/배포는금지다. 필요한browser는자기headless/loopback/profile/PID만쓴다.

새 경제의 세 OS 판정은 실제 v5 반복 save/fresh native resume의 전체 DTO/canonical/hash·queue·정의/팩 identity·파일 bytes/SHA를 원 artifact에서 확인한다. 기존 v1/v4 current/trigger artifact의 성공만으로 새 v5 PASS를 쓰지 않는다. source가 기존 check_save_current capture/compare에 추가 연결했다면 기존 M1/server/force/historical 필수 검사와 새 하위 namespace 양쪽을 직접 확인하고 누락·변조·fullstate/canonical 불일치·잘못된 native exit/HEAD/OS identity를 자체 복사 입력으로 거부한다. 기존 일곱 workflow bytes/조건/한도 보존과 새 helper scope를 원 Git source로 대조한다.

초기 economy_reference fixture의 독립 인코더는 movement_present/strait_present=false 경로에 한정된다. 원 artifact의 실제 fixture presence·조건·수치 기대 범위를 기록하고 이 한 fixture를 전체 새 v5 조합 검증으로 확대하지 않는다. source가 지원하는 v5+기존 movement/strait/trigger presence 조합과 신규 Economy command를 자기 ignored native probe에서 별도로 왕복·fresh resume/replay해 전체 DTO/canonical/hash와 future queue를 검사한다. 실제 지원되지 않는 조합은 명시 거부/미완료로 판정하고 기본값으로 없애지 않는다.

모든cwd/argv/native0·expectednegative/원준비FAIL·stderr/stdout·실제입력/출력/elapsed·파일SHA와whole/rawbefore/after를자기ignored 증거에보존한다. 전체ZIP member→physical mapping·원manifest/CRC/identity를제공하고대형원ZIP/partial은원경로/크기/SHA와validity를분리한다. 부족증거/미실행/실제FAIL을PASS로취급하지않는다. 기본mainCI/P07·W2/M2게이트·사용자확정을대신하지 않는다.

실제 새독립P05-1 배정: source a9333419de89caf3ba95da5097ea2e3d0fa5f694 / product01119ae05013a1974e5ca096c705bf39846c9cff와 non-docGit430 동일인 dochead.
정확 detached worktree: E:/openhoi/.orchestrator/wt/WP-14-M2-r2-verify1
최초 tracked 11833, raw index SHA256 4d77c338769c8470b36519c468147b1736cf1fae467ce05070a1697321215a1c
모든 명령은 위 WT에서만 실행하고 initial cwd E:/openhoi는 앱 프로젝트 연결용이다. 최초 parent-before를 바꾸거나 다른세션을 만들지 않는다.
원 구현 actual completed99/final465chars·MF6254/ZIP6255(포장용manifest1)/원ZIP37066865B/SHA4d370a…·native-binaries 5개는 원WT target/debug mapping·4대형TAR 각2006323200B/SHA8ee7…을 부모가 직접인수했다. partial/원실패·첫부모경로가정 및 first recoverylabel실패를보존했다. 실제metadata/file원문은 planning에복사한원ZIP/API/custody 및source문서에있다. 설명을믿지않고 직접검사한다.
원대형TAR/실행파일 원locator는 producer WT에서부모가SHA를확인했으나 당신의 모든실행은현재WT에한정한다. 원자료의읽기검사는가능하고 원경로를고치거나 재작성하지 않는다. 원ZIP물리mapping 부족이 있으면기록하며 actor설명을PASS로대신하지않는다.
sourcebranch codex/wp14-economy-politics-m2r2를exact a9333419de89caf3ba95da5097ea2e3d0fa5f694로첫FF공개했고 기존 performance.yml --ref 단일dispatch native0다. 실제 sourceCI/Linux/새v5 세OS는 현재 pending이며 아직 PASS가아니다. 로컬검증을병행하고 같은exactSHA의실제API/artifact/원ZIP/Linuxproof가 planning/remote-final/에전달되기전formal최종PASS/통합을선언하지않는다. 로컬성공을원격으로소급하지않는다. source변경요구나원격FAIL은원판정/기준선유지하고새source의새독립세션이필요하다.
부모소유source/mainCI와원libWindows/실Linux를구분한다. 원source cd5/browser2FAIL→01119queryNone호환수정·고립trigger eagerimport회귀·targetReuse FileExistsError·cp949 UTF8복구를원출력으로확인한다. originaltests/expected/workflows/policy/원15%/240s1200s/driver조건부예외/원Nonev1~v4·some빈존재·후속consumer 경계를유지한다.
자기ignored네이티브증거 루트는 E:/openhoi/.orchestrator/wt/WP-14-M2-r2-verify1/target/evidence/WP-14-M2-r2-P05-1 아래새이름이다. repro_native --evidence-root는현재WT의target/evidence 아래를사용한다. parent ignored .orchestrator 경로를native runner에넘겨ROOT/target guard를위반하지 않는다. noCUA/focus/전역input/기존PIDs/BP/설정/한도/골든/새세션/추적보고서저장/commit 금지다.
최종은 VERIFY_REPORT_TEMPLATE 전체와 자기ZIP/member→physicalmapping/원본SHA·실제native명령·전후whole/raw불변을제공한다. 원격대기중에는나머지검증과봉인준비를진행하고 미실행PASS를내지않는다.
