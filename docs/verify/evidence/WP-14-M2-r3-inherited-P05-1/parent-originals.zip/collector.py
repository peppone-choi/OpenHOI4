"""Custody only after the actual completed app final and final seal are available."""
import pathlib,json,hashlib,zipfile,subprocess,re,shutil,stat,sys
r=pathlib.Path('E:/openhoi');w=r/'.orchestrator/wt/WP-14-M2-r2-verify1';s=w/'target/evidence/WP-14-M2-r2-P05-1';head='a9333419de89caf3ba95da5097ea2e3d0fa5f694';tag='WP-14-M2-r3-inherited-P05-1'
api=pathlib.Path(sys.argv[1]);label=sys.argv[2];a=json.loads(json.loads(api.read_text(encoding='utf-8'))['content'][0]['text'])
turn=[t for t in a['turns'] if t['id']=='01a1197e-86c8-71b2-9db2-d3839a30517c'];assert len(turn)==1 and turn[0]['status']=='completed'
finals=[x for x in turn[0]['items'] if x['type']=='agentMessage' and x.get('phase')=='final_answer'];assert finals
reports=[x for x in finals if re.search(r'\|\s*판정\s*\|\s*(?:\*\*)?FAIL\b[^\n|]*\|',x['text'])];assert len(reports)==1
report=reports[0];bundle=s/('bundle-'+label);m=json.loads((bundle/'manifest.json').read_text(encoding='utf-8'));rows=m['files'];mapping=json.loads((bundle/'member-physical-CRC.json').read_text());seal=json.loads((bundle/'seal.json').read_text());assert m['source']==head and m['remote_delivered'] and seal['remote_delivered']
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def physical(row):
 name=row['path'];pp=pathlib.PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts and ':' not in name and '\\' not in name and '\x00' not in name
 p=pathlib.Path(row['physical']);assert p.resolve().is_relative_to(w) and p.is_file() and not p.is_symlink()
 for q in [p,*p.parents]:assert not(getattr(q.lstat(),'st_file_attributes',0)&0x400)
 return p
indexed={x['path']:x for x in rows};assert len(indexed)==len(rows)==seal['manifest_files'] and len(mapping)==len(rows)
assert [{k:v for k,v in x.items() if k!='CRC'} for x in mapping]==rows
for row in rows:
 p=physical(row);assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
for row in m['excluded']:
 if 'sha256' in row:
  p=physical(row);assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
zp=pathlib.Path(seal['path']);assert zp.resolve().is_relative_to(w/'target/evidence') and digest(zp)==seal['sha256'] and zp.stat().st_size==seal['bytes']
indexed['BUNDLE_MANIFEST.json']=dict(path='BUNDLE_MANIFEST.json',physical=str(bundle/'manifest.json'))
with zipfile.ZipFile(zp) as z:
 infos=z.infolist();assert len(infos)==len({i.filename for i in infos})==seal['members']==len(indexed)
 for i in infos:
  assert i.filename in indexed and not stat.S_ISLNK(i.external_attr>>16)
  p=physical(indexed[i.filename]);size=0
  with z.open(i) as f,p.open('rb') as g:
   for chunk in iter(lambda:f.read(1024*1024),b''):assert g.read(len(chunk))==chunk;size+=len(chunk)
   assert not g.read(1)
  assert size==i.file_size
out=r/'.orchestrator/evidence'/tag;out.mkdir(exist_ok=True);before=r/'.orchestrator/evidence'/'WP-14-M2-r2-P05-1-before';after=r/'.orchestrator/evidence'/(tag+'-parent-after');assert not pathlib.Path(str(after)+'.json').exists()
argv=['python','-X','utf8',str(r/'.orchestrator/m2_snapshot.py'),str(w),str(after),'--compare',str(before)]
q=subprocess.run(argv,cwd=r,capture_output=True);(out/'parent-after.stdout').write_bytes(q.stdout);(out/'parent-after.stderr').write_bytes(q.stderr);(out/'parent-after.command.json').write_text(json.dumps(dict(argv=argv,cwd=str(r),native_exit=q.returncode),indent=2)+'\n',encoding='utf-8');q.check_returncode()
b=json.loads(pathlib.Path(str(before)+'.json').read_text());assert b['head']==head and len(b['files'])==11833 and b['raw_index_sha256']=='4d77c338769c8470b36519c468147b1736cf1fae467ce05070a1697321215a1c'
d=r/'docs/verify/evidence'/tag;d.mkdir(parents=True,exist_ok=False)
parts=[]
if zp.stat().st_size<100_000_000:
 shutil.copyfile(zp,d/'evidence.zip');assert digest(d/'evidence.zip')==seal['sha256']
else:
 h=hashlib.sha256();size=0
 with zp.open('rb') as source:
  i=0
  while True:
   data=source.read(90_000_000)
   if not data:break
   i+=1;p=d/f'evidence.zip.part{i:03}';p.write_bytes(data);assert p.read_bytes()==data
   h.update(data);size+=len(data);parts.append(dict(path=p.name,bytes=len(data),sha256=digest(p)))
 assert h.hexdigest()==seal['sha256'] and size==seal['bytes']
 (d/'ZIP-PARTS.json').write_text(json.dumps(dict(original=str(zp),whole_bytes=size,whole_sha256=h.hexdigest(),parts=parts,original_not_deleted_or_changed=True),indent=2)+'\n',encoding='utf-8')
for p in (bundle/'manifest.json',bundle/'member-physical-CRC.json',bundle/'seal.json'):shutil.copyfile(p,d/p.name)
pf=r/'.orchestrator/prompts/WP-14-M2-r2-P05-1-bound.md';payload=r/'.orchestrator/evidence/WP-14-P05-1-create-payload.json';assert json.loads(payload.read_text())['prompt'].encode('utf-8')==pf.read_bytes()
files={'actual-final-api.json':api,'actual-bound-prompt.md':pf,'create-payload.json':payload,'create-result.json':r/'.orchestrator/evidence/WP-14-P05-1-create-result.json','parent-before.json':pathlib.Path(str(before)+'.json'),'parent-before.index':pathlib.Path(str(before)+'.index'),'parent-after.json':pathlib.Path(str(after)+'.json'),'parent-after.index':pathlib.Path(str(after)+'.index'),'collector.py':pathlib.Path(__file__)}
with zipfile.ZipFile(d/'parent-originals.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():z.writestr(name,p.read_bytes())
with zipfile.ZipFile(d/'parent-originals.zip') as z:
 for name,p in files.items():assert z.read(name)==p.read_bytes()
for i,x in enumerate(finals):(d/f'actual-final-{i+1}.md').write_bytes((x['text']+'\n').encode('utf-8'))
rp=r/'docs/verify/WP-14.M2-r2.attempt1.md';assert not rp.exists();rp.write_bytes((report['text']+'\n').encode('utf-8'))
record=dict(head=head,judgement='FAIL',verification_invariance_valid=True,parent_full_raw_invariance=True,raw_index_bytes_identical=True,tracked_count=len(b['files']),manifest_files_checked=len(rows),ZIP_members_checked=len(infos),ZIP_bytes=seal['bytes'],ZIP_sha256=seal['sha256'],review_parts=parts,mismatches=0,actual_final_message_count=len(finals),formal_report_message_id=report['id'],formal_report_chars=len(report['text']),formal_report_exact=True,external_large_originals=[x for x in m['excluded'] if 'sha256' in x],attack_links_metadata_only=m['attack_links_metadata_only'],source_CI_not_main_CI=True)
(d/'parent-custody.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(d/'README.md').write_text(f'# WP14 새 독립 검증 원본\n\nexact `{head}`의 실제 completed app final과 원 보고서를 인수했다. 최초11833/전체SHA·HEAD·raw4d77…·diff/status는 부모 종료 검사와 동일하다. MF{len(rows)}/ZIP{len(infos)}를 실제 각 물리 원파일 및 원ZIP CRC·bytes/SHA로 전수 대조했다. 원 ZIP은 {len(parts)}개 순차 raw part로도 보존한다(0이면 evidence.zip 단일 원본). ZIP-PARTS.json이 있으면 순서대로 이어 붙인 bytes/whole SHA가 원 ZIP과 같고 원본은 지정 WT에 그대로 있다. LFS/설정 변경은 없다. 큰 원자료와 reparse fixture의 명시한 제외/metadata를 그대로 보존하며 작은review에 내장됐다고 주장하지 않는다. 원 구현/수집/검증 실행 실패와 후속 결과를 분리한다. 원 turn01a11877-ec5a는 interrupted/final 없음이며 이번 재개 turn01a1197e-86c8의 actual final을 인수했다. 과거 종료로 소급하지 않는다. 이는 독립 WP14 검증이며 P07·같은main CI·WP23/W2/M2 완료가 아니다.\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ('external_large_originals','attack_links_metadata_only')},ensure_ascii=False))
