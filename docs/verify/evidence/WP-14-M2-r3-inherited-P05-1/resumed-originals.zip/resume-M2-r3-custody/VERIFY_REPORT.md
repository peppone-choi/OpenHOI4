# 검증 리포트 — WP-14 M2-r2 P05-1

| 항목 | 값 |
|---|---|
| 판정 | **FAIL — v5 복원의 건물 단계 상한 검증 누락** |
| 검증자 | Codex 독립 검증 세션. 구현 비참여, 지정 detached WT 사용, 추적 파일 무변경 |
| 브랜치·커밋 | codex/wp14-economy-politics-m2r2 / a9333419de89caf3ba95da5097ea2e3d0fa5f694; 제품 01119ae05013a1974e5ca096c705bf39846c9cff와 non-doc Git 동일 |
| 검증 일시 | 원실행 2026-10-08 KST. 이번 M2-r3 재개에서는 원증거·whole/raw 인수만 수행하고 이 메시지로 실제 종료한다 |

지정 WT는 `E:/openhoi/.orchestrator/wt/WP-14-M2-r2-verify1`이다. 아래 실행 결과는 원검증의 실제 기록이다. 이번 재개에서 제품 테스트를 재실행하거나 새 소스를 검증하지 않았다. 중단된 원 turn에 final/completedAt가 있었다고 소급하지 않는다.

## 직접 실행한 명령

| 명령 | 종료 코드 | 결과 요약 |
|---|---|---|
| cargo fmt --check | 0 | 원최종 소스 통과 |
| cargo clippy --workspace --all-targets --locked -- -D warnings | 0 | 통과 |
| cargo test --workspace --locked / cargo build --workspace --locked | 0 / 0 | 통과. 아래 독립 복원 결함은 기존 테스트가 놓침 |
| npm --prefix client ci / run typecheck / run build / test | 0 | client 12 files, 246 tests 통과 |
| npm --prefix client run test:e2e | 0 | M0 Chromium/Firefox/WebKit 전체 36개 |
| npm --prefix client run test:e2e -- --config playwright.m1.config.ts --project chromium --project webkit | 0 | 단일 전체 M1 실행 82개; None economy의 기존 QueryResult 거부 확인 |
| check_save_current.py capture; save_native.py normal/--force | 0 | 원 M1 및 새 v5 native 저장·fresh/paused 재개·서버/query |
| check_save_determinism.py capture; check_trigger_determinism.py capture; repro_native.py | 0 | legacy·trigger·repro 검사. repro native 15개 |
| 독립 domain probe 및 6개 v5 presence 조합의 실제 CLI resume/save-out/repro | 0 | 전체 DTO/canonical/hash와 future queue 대조 |
| 실제 loader 17개 입력, save-current predicates 25개, trigger predicates 16개, bench 회귀 18개 | 기대 코드 일치 | 비용0/음수·누락·미지원 false/zero 및 예외 경계 구분 |
| cargo deny --metadata-path 실제 원 metadata check licenses bans advisories sources | 0 | 동일 원정책·286개 registry index bytes; child-only E 캐시의 fresh advisory DB. 원 C: ENOSPC도 보존 |
| check_architecture.py / check_assets.py --release / check_docs.py | 0 | 통과 |
| bench/run.py --local-evidence | 0 | Windows 로컬 결과. Linux 결과로 대체하지 않음 |
| 원격 원본의 check_save_determinism.py / check_save_current.py / check_trigger_determinism.py compare | 0 / 0 / 0 | 실제 세 OS artifact 9개. 새 v5 포함 |
| restore_stage_probe 실제 native 실행 | **2** | 정의 3단계인데 저장 복원에서 level4를 수락하여 독립 predicate FAIL |
| oh_cli.exe resume --load industry-level4.ohsave --pack own-inputs/plain --ticks 0 --hash-out [--force] | **0 / 0** | 각각 기대1. normal/force 모두 잘못된 저장 수락 |
| oh_cli.exe run --pack initial-level4-pack --scenario m1 --ticks 0 --seed 1000 --hash-out | 1 | 같은 level4 초기 데이터는 정상 거부 |
| oh_server.exe --load-save industry-level4.ohsave, normal/--force | **HTTP200 / HTTP200** | 각각 기대 startup exit1. 권위 조회가 industry level4를 반환, 종료0 |
| 이번 재개: m2_snapshot.py --compare parent-before 및 원 ZIP/물리 mapping/remote custody 읽기 대조 | 0 | 11,833개 whole/raw 동일, 원 ZIP CRC·SHA 및 전달 96개 파일 불일치0 |

각 원명령의 전체 절대 argv·cwd·native exit·stdout/stderr·PID·elapsed는 [원 판정 기록](../verification-result.json)의 all_commands와 각 receipt에 있다. 위 표의 짧은 파일명은 원 argv를 변경하거나 새로 실행했다는 뜻이 아니다.

## REQ별 확인

| REQ | 검사하는 테스트 | 실제 검사 여부 | 결과 |
|---|---|---|---|
| REQ-ECO-01 | 소유 주 기여·비연속 ID·IC 정수식·원장·wide Qty·산업 score | 직접 native/독립 산술 | 일반 산출 검사 통과. 복원된 현재 건물 수준 상한은 FAIL |
| REQ-ECO-02 | 네 비율 정확합1·잔여 귀속·하한 경계·법령/효과 rollback | 직접 | 검사 범위 통과 |
| REQ-ECO-04 | 소유 주 자원 일일 흐름·통제 구분·overflow | 직접 | producer 검사 통과. 비축·부족 생산·시장 consumer 완료 아님 |
| REQ-ECO-06 | 한 단계·슬롯/중복·0 cap/factor skip·올림·소유 상실/회복·휴면·취소·복원 | 직접 | **FAIL: 정의상 3단계인데 level4 저장을 복원** |
| REQ-ECO-07 | capacity floor·committed/reserved·내부 API·감소/과예약·rollback | 직접 | producer 검사 통과. 실제 훈련/보충·객체 권한 consumer 후속 |
| REQ-NAT-02 | PC 날짜 경계·선지급 거부·Pause 무지급·wide cap·phase rollback | 직접 | 검사 범위 통과 |
| REQ-NAT-03 | 안정도/동원도·조건/효과 transaction·commit 종료 checkpoint | 직접 | producer 검사 통과. 군사·항복 consumer 후속 |
| REQ-NAT-04 | 법령 category/ID/양수 비용·조건·직전 상태·동일 법령·하한 거부 | 직접 | 검사 범위 통과 |

전체 WP/REQ 완료를 부분 producer 성공으로 판정하지 않는다. WP15/16/20/29, 경제 활성 부하·M2/M3/UI 성능은 본 검증의 완료 주장이 아니다.

## 결정론

- 해시 1: M0 `ff921fd8148e699d`, M1 `60448355cecffa9d`.
- 해시 2: 각 원 반복 실행이 위 값과 동일.
- 저장 후 재개: 실제 v5 split `48e02ba01e8fddfe`, paused `263071b34065aa8d`, continued `373a5a6eeea13715`. 실제 세 OS 원 artifact의 전체 DTO/canonical/hash·bytes·정의/팩 identity 및 fresh resume/replay 일치.
- 초기 economy_reference 인코더의 fixture는 movement_present/strait_present=false에 한정한다. 별도 6조합의 trusted native 및 실제 CLI 검사를 전체 consumer 구현 증거로 확대하지 않는다.
- 실제 Linux: run `37695537881`, attempt1, job `113046236165`, artifact `11514894569`. prior `81deb803944cf6297f13b3f14ca454774cea141b` 전체 팩 hash `3bde1bed90d3734e`; 완료 hash `3b8853acbddce251`. baseline ns `[195802551,193460349]`, current ns `[192623408,193688056]`, regression=false. 원 두 쌍/15%/240s/1200s 유지.

## 금지 사항 점검

| 항목 | 결과 |
|---|---|
| 시뮬레이션의 f32/f64 | production source 금지 타입 사용 발견 없음; Fx I32F32 / Qty I48F16 / 인력 i64 확인 |
| HashMap 순회 | 결정론 계층에서 발견 없음 |
| thread_rng / SystemTime | 시뮬레이션에서 발견 없음 |
| 코드 내 수치 리터럴 | 신규 경제 수치는 명시 정의 입력. 고정 정수 산술·형식 경계를 게임 수치로 오인하지 않음 |
| 미결정 규칙 구현 | REQUEST-0010 A-CEO-r1 잠정 기준 유지. 사용자 확정으로 변경하지 않음 |
| 골든 기대값 변경 근거 | 기존 테스트/골든/expected·팩·원 lock·일곱 workflow 보호 경로 변경0 확인 |
| 클린룸 | 검증 과정에서 금지 원작 자료 사용 없음. 지도/GLB 재 bake 요구 없음 |

검증 WT reset, 제품/추적 파일·index·원before 수정, commit, 새 앱/세션 생성, CUA/focus/global input·설정·한도 변경을 하지 않았다.

## 작업 로그 증거와 실제 결과 대조

- 원 browser 2 FAIL과 None query 호환 수정 후 단일 전체 82개 통과, trigger eager import·잘못된 준비 argv/입력·target reuse·UTF8/공간 오류를 별도 원출력으로 보존했다. 환경/준비 실패를 제품 성공으로 소급하지 않았다.
- 같은 a933 source CI 7종·26 jobs 성공과 실제 세 OS 저장/trigger 9 artifacts는 planning/remote-final에 실제 전달되었다. 이번 재개에서 delivery custody 96개 파일 길이/SHA 불일치0을 확인했다. 초기 pending 기록은 과거 상태로 유지한다.
- 원 Linux artifact의 직접 대조가 보존되어 있다. 원격 executable 객체·전체 library tree 및 external source.lock 복사본은 업로드되지 않았다는 한계를 유지한다. env SHA·원 metadata/inventory·Git/prior TAR·job runtime guard 이상의 물리 바이너리 인수를 주장하지 않는다.
- **CI 성공과 일반 roundtrip 통과에도 독립 stagecap 반례가 존재하므로 최종 판정은 FAIL이다.** 초기 loader는 level4를 거부하지만 v5 restore는 같은 단계 상한을 적용하지 않았다. 관련 원 source 위치는 oh_data/src/economy.rs:231, oh_sim/src/economy.rs:417이다.
- 최초 parent-before, 원 final-before/after, 이번 resume snapshot은 whole JSON까지 동일하다. tracked **11,833**, raw index SHA256 `4d77c338769c8470b36519c468147b1736cf1fae467ce05070a1697321215a1c`; 각 snapshot JSON SHA256 `58db43ee24844a59e0a4ab7fed10170ff2eef39bc103180310513bbc257fe448`.
- 기본 main CI·P07·W2/M2 gate·사용자 확정을 대신하지 않는다. 이번 actual final을 중단된 원 turn의 종료로 소급하지 않는다.

원 판정: [verification-result.json](../verification-result.json), SHA256 `0523f017a5be12a6fc6b1449c30331acb75c2b952a6d92d0b95287de0e062da0`.

원 ZIP: [WP-14-M2-r2-P05-1-final-FAIL.zip](../../WP-14-M2-r2-P05-1-final-FAIL.zip), **136,217,870 bytes**, SHA256 `ddcf54590e7285f6f48d4a8285f73da6d2012470bdff7c729d6d1866dbade8c3`. 원본을 재포장/수정하지 않았다. 14,173 members의 CRC 및 14,172개 원 [member→physical mapping](../bundle-final-FAIL/member-physical-CRC.json) 대조 불일치0. 이번 인수 결과는 [audit.json](audit.json), 원 before/after·이번 비교는 [resume-M2-r3-whole-raw-summary.json](../resume-M2-r3-whole-raw-summary.json)에 있다.

## FAIL 항목

| # | 재현 명령 | 기대 | 실제 |
|---|---|---|---|
| F-01 | 원 CLI resume, level4 v5 저장, normal | 정의 3단계 초과 거부, exit1 | exit0, 복원 수락 |
| F-01-force | 같은 원 CLI resume --force | 의미 검증 유지, exit1 | exit0, 복원 수락 |
| F-01-server | 원 server --load-save, normal 및 --force | startup exit1, 서비스 시작 거부 | 둘 다 HTTP200, 실제 권위 query에서 industry level4, 정상 종료0 |

반례 저장은 [industry-level4.ohsave](../restore-stage-case/industry-level4.ohsave), **458 bytes**, SHA256 `c67f5cefbba865be78643b920536678f789b8375b418b9034ddd2cd2b4db1e53`이다. [서버 원영수증](../restore-stage-case/server-both-ready.json)과 원 CLI stdout/stderr를 보존했다. source를 고치지 않았으며 부모의 P06 인수 대상으로 보고한다.
