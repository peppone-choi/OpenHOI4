from pathlib import Path
import json,hashlib,zipfile,datetime
E=Path('target/evidence/WP-14-M2-r2-P05-1').resolve();out=E/'resume-M2-r3-custody';out.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
Z=E.parent/'WP-14-M2-r2-P05-1-final-FAIL.zip';assert Z.stat().st_size==136217870;digest=sha(Z);assert digest=='ddcf54590e7285f6f48d4a8285f73da6d2012470bdff7c729d6d1866dbade8c3'
rows=json.loads((E/'bundle-final-FAIL/member-physical-CRC.json').read_text(encoding='utf-8'));mismatches=[]
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 for row in rows:
  p=Path(row['physical']);info=z.getinfo(row['path']);data=z.read(row['path']);good=len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and info.CRC==row['CRC'] and p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
  if not good:mismatches.append(row['path'])
 count=len(z.infolist());original_verification=z.read('verification-result.json');assert original_verification==(E/'verification-result.json').read_bytes()
delivery=json.loads((E/'planning/remote-final/delivery-custody.json').read_text(encoding='utf-8'));remote_mismatch=[]
for row in delivery['copies']:
 p=E/'planning/remote-final'/row['path']
 if not (p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']):remote_mismatch.append(row['path'])
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_verdict='FAIL',source=delivery['head'],ZIP_path=str(Z),ZIP_bytes=Z.stat().st_size,ZIP_SHA256=digest,ZIP_CRC_valid=True,members=count,original_member_physical_mapping=str(E/'bundle-final-FAIL/member-physical-CRC.json'),physical_mismatches=mismatches,original_verification_result_SHA256=hashlib.sha256(original_verification).hexdigest(),remote_final_delivered=True,remote_custody_files=len(delivery['copies']),remote_copy_mismatches=remote_mismatch,remote_delivery_utc=delivery['utc'],new_source_or_test_execution=False,interrupted_original_turn_not_retroactively_completed=True)
(out/'audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2));assert not mismatches and not remote_mismatch
